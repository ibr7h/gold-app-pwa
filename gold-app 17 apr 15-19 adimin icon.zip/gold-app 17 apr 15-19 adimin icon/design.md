# Gold App - Design Document

## Overview
A premium gold trading and portfolio management mobile app with Arabic RTL layout and dark theme. The app allows users to track live gold prices, manage portfolios, record purchases, set price alerts, and access admin tools.

## Design System

### Color Palette
- **Main Background**: `#0F1115` (deep dark)
- **Cards/Surfaces**: `#1F252E` (elevated dark)
- **Primary Text**: `#FFFFFF` (white)
- **Secondary Text**: `#C7CBD2` (muted gray)
- **Accent Gold**: `#D4AF37` (premium gold)
- **Success/Green**: `#22C55E` (price up)
- **Error/Red**: `#EF4444` (price down)
- **Border**: `rgba(255,255,255,0.08)` (subtle light borders)
- **Border Radius**: 12px throughout

### Typography
- Modern Arabic sans font (system default Arabic)
- RTL text direction throughout
- Headings: Bold, 20-24px
- Body: Regular, 14-16px
- Caption: Regular, 12px

### Components
- **GoldButton**: Full-width gold accent button with loading spinner state
- **GoldCard**: Dark card with subtle border and shadow, 12px radius
- **GoldInput**: Text input with label, error message support, RTL aligned
- **GoldToggle**: Switch component for enable/disable
- **ListItem**: Reusable list row with icon, title, subtitle, and trailing content
- **StateView**: Empty, loading, and error state displays
- **PriceTag**: Colored price display (green/red based on change)

---

## Screen List

### 1. Login Screen
- Centered card on dark background
- App logo/title at top
- Email text field (RTL)
- Password text field (RTL, secure)
- Full-width gold "تسجيل الدخول" button
- Loading spinner inside button during auth
- Error message display under fields
- Demo credentials hint

### 2. Home Screen (الرئيسية)
- **App Bar**: Title "الرئيسية" in drawer header
- **Welcome Card**: User email, role badge (مستخدم/مدير)
- **Gold Price Now Card**: Highlighted 24K purchase price with currency
- **Quick Services Grid** (2x2): شراء، بيع، تحويل، حفظ (Buy, Sell, Transfer, Save)
- **Portfolio Summary Card**: Total value, profit/loss percentage
- **Market Movement Chart**: Line chart with tabs (يوم، أسبوع، شهر، سنة)
- **Top Movers List**: Gold karat items with green/red change values
- **Featured Offers Carousel**: Horizontal scrollable offer cards
- **Gold Karat Prices List**: All karats with buy/sell prices

### 3. Prices Screen (الأسعار)
- **Main Live Pricing Card**: Current gold price prominently displayed
- **Price Table**: Currency, karat, source, buy price, sell price, last update time
- **Refresh Button**: Manual refresh with loading indicator
- **States**: Loading skeleton, empty state, error state with retry

### 4. Portfolio Screen (المحفظة)
- **Portfolio Summary**: Total value, total profit/loss, item count
- **Portfolio List**: Items with name, currency, current value, last update
- **Add Portfolio Button**: FAB or top-right button
- **Portfolio Detail View**: Selected portfolio with linked purchases list

### 5. Purchases Screen (المشتريات)
- **Purchases List**: Each item shows name, price, quantity, date
- **Edit/Delete Icons**: On each list item
- **Add Purchase Button**: FAB
- **Add/Edit Form**: Fields for name/description, currency, price, quantity, date, optional notes
- **Save Button**: Gold accent
- **States**: Success toast, error message

### 6. Alerts Screen (التنبيهات)
- **Alerts List**: Each alert shows title, target price, status, last update
- **Toggle Switch**: Enable/disable each alert
- **Delete Icon**: Remove alert
- **Add Alert Form**: Karat/currency selector, target price, condition (>= or <=), optional note

### 7. Admin Tools Screen (أدوات المدير)
- Visible only for admin role users
- **Utility Card**: Admin actions panel
- **Update Prices Button**: Trigger price update action
- Simple, clean admin interface

---

## Key User Flows

### Login Flow
1. User opens app → Login screen appears
2. Enter email and password
3. Tap "تسجيل الدخول" → Loading state in button
4. Success → Navigate to Home with drawer
5. Error → Show error message under fields

### View Prices Flow
1. User taps "الأسعار" in drawer
2. Prices screen loads with current data
3. User can tap refresh to update
4. Prices table shows all karats with buy/sell

### Manage Portfolio Flow
1. User taps "المحفظة" in drawer
2. Portfolio summary and list appear
3. Tap "+" to add new portfolio item
4. Fill form and save
5. Tap item to see detail with linked purchases

### Record Purchase Flow
1. User taps "المشتريات" in drawer
2. Purchases list appears
3. Tap "+" to add new purchase
4. Fill form (name, currency, price, quantity, date, notes)
5. Save → Success state
6. Can edit/delete existing purchases

### Set Alert Flow
1. User taps "التنبيهات" in drawer
2. Alerts list with toggle switches
3. Tap "+" to add new alert
4. Select karat/currency, set target price, choose condition
5. Save alert → Appears in list
6. Toggle to enable/disable

---

## Navigation
- **Drawer Navigation** (RTL direction)
- Drawer items:
  1. الرئيسية (Home)
  2. الأسعار (Prices)
  3. المحفظة (Portfolio)
  4. المشتريات (Purchases)
  5. التنبيهات (Alerts)
  6. أدوات المدير (Admin Tools) - admin only
- Gold accent on active item
- Dark drawer background matching app theme
