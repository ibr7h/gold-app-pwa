import React,{useState,useEffect,useRef,useCallback} from 'react';
import {useAuth} from '../contexts/AuthContext';
import AuthForm from './AuthForm';
import {QuickLockScreen,QuickPinSetup} from './QuickLockScreen';
import PurchaseFormFields from './PurchaseFormFields';
import PriceHistoryChart from './PriceHistoryChart';
import {TrendRange} from './price-trend';
import {Money,formatTwo,CurrencyMark} from './price-display';
import NotificationSettings from './NotificationSettings';
import NearbyMarkets from './NearbyMarkets';
import GoldHelp from './GoldHelp';
import {LegalDocumentLinks} from './RegistrationLegalDocuments';
import UserPersonalDetails from './UserPersonalDetails';
import {revokePushBeforeLogout,syncMarketPushPreferences} from './push-client';
import {api,jsonRequest,errorMessage,ApiError} from './api';
import {Portfolio,Purchase,PriceAlert,MarketPrice,KARATS,CURRENCIES,totals,purchasePerformance,purchasePayload,alertPayload,localDate} from './model';
import {priceFreshness,isGlobalGoldMarketOpen} from './price-status';
import './user.css';
import EstimatedPriceReceiptPrinter from './EstimatedPriceReceiptPrinter';
import {APP_DISPLAY_VERSION} from './app-version';
import {canShowBiometricLogin} from './biometric-visibility';
import {calculatorQuoteWithTaxRate} from './calculator-quote';
import OfflineWorkspace from './OfflineWorkspace';
import {savePublicMarketSnapshot,readPublicMarketSnapshot} from './public-market-cache';
import {quoteShareText,shareQuotePng,preloadQuoteIcon,ShareQuote} from './calculator-sharing';
import {amountToDisplayCurrencyWords} from './arabic-amount-words';
import {homeMarketMovement,homeUpdateAge} from './home-data';
import {displayAmount,displayPortfolioSummary,sarPerUsd,DisplayCurrency} from './display-currency';
import {loadEuroReferenceRates,euroHistoryRows,euroHistoryStartDay} from './euro-reference';
import {loadEuroHistorySources} from './euro-history-source';
import {loadEuroSpot,euroSpotRows} from './euro-spot';
import {LanguageProvider,useLanguage,activeLocale} from './i18n';
import {amountToLocalizedWords} from './amount-words-localized';
import {translateUiText} from './i18n-messages';
import {localizeFeedback} from './i18n-feedback';
import {DisplayCalendar,readDisplayCalendar,saveDisplayCalendar,formatDisplayDate} from './date-display';
/** Build-time type bridge for the extracted native app's older AuthContext.
 * The Web bundle uses the specialized contexts/AuthContext.web provider.
 */
type UserLockAuth=ReturnType<typeof useAuth> & {
 lockedAccount:{id?:number|string;email:string;role:'user'|'admin'|'trader';name?:string}|null;
 quickPinEnabled:boolean;
 pinReconnectRequired:boolean;
 reconnectQuickPin:(currentPin:string)=>Promise<void>;
 recoverQuickPin:(password:string,newPin:string)=>Promise<void>;
 unlockWithPin:(pin:string)=>Promise<{ok:boolean;waitSeconds:number;remaining:number}>;
 enableQuickPin:(pin:string,currentPin?:string)=>Promise<void>;
 disableQuickPin:(currentPin:string)=>Promise<void>;
 lockWithBiometric:()=>Promise<boolean>;
 continueWithPassword:()=>void;
};
const useUserLockAuth=()=>useAuth() as UserLockAuth;
type Page='home'|'prices'|'calculator'|'portfolio'|'more'|'purchases'|'alerts'|'notification-settings'|'map'|'account'|'help';
const pages:{id:Page;label:string;icon:string;navLabel?:string}[]=[
 {id:'home',label:'الرئيسية',icon:'home'},
 {id:'prices',label:'الأسعار',icon:'chart'},
 {id:'calculator',label:'الحاسبة',icon:'calculator'},
 {id:'portfolio',label:'المحفظة',icon:'wallet'},
 {id:'more',label:'المزيد',icon:'menu'},
 {id:'purchases',label:'المشتريات',icon:'receipt'},
 {id:'alerts',label:'التنبيهات',icon:'bell'},
 {id:'notification-settings',label:'إعدادات الإشعارات',icon:'bell'},
 {id:'map',label:'التجار القريبون',navLabel:'التجار',icon:'map'},
 {id:'account',label:'الملف الشخصي',navLabel:'الملف',icon:'user'},
 {id:'help',label:'المساعدة',icon:'help'}
];
const primaryPages=pages.filter(p=>['home','prices','portfolio','purchases','alerts','map','account'].includes(p.id));
const mobilePages=pages.filter(p=>['home','prices','calculator','portfolio','more'].includes(p.id));
function Icon({name}:{name:string}){
 // Lucide-style 22px outline glyphs used by iPhone More/Preferences only.
 // Keep the icon language uniform without changing navigation or feature logic.
 if(name==='storefront'||name==='receipt-text'||name==='bell-ring'||name==='circle-help'||name==='globe'||name==='coins'){
  const strokes:Record<string,React.ReactNode>={
   storefront:<><path d="M3 10 5 4h14l2 6v10H3V10Z"/><path d="M3 10h18M9 20v-7h6v7M8 4l-1 6m9-6 1 6"/></>,
   'receipt-text':<><path d="M4 3h16v18l-3-2-3 2-3-2-3 2-4-2V3Z"/><path d="M8 8h8M8 12h8M8 16h4"/></>,
   'bell-ring':<><path d="M18 8a6 6 0 0 0-12 0c0 6-3 8-3 8h18s-3-2-3-8ZM10 20h4"/><path d="m3 5-1.5 2M21 5l1.5 2"/></>,
   'circle-help':<><circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.5 2.5 0 1 1 4.1 2c-1 .7-1.6 1.3-1.6 2.7M12 17h.01"/></>,
   globe:<><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 2.8 4.5 5.8 4.5 9s-1.5 6.2-4.5 9M12 3c-3 2.8-4.5 5.8-4.5 9s1.5 6.2 4.5 9"/></>,
   coins:<><circle cx="9" cy="9" r="5.5"/><path d="M9 6v6m-2.5-3h5"/><path d="M16 9.5a5.5 5.5 0 1 1-6.5 6.5"/></>
  };
  return <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false">{strokes[name]}</svg>;
 }
 if(name==='gem')return <svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true"><path fill="currentColor" d="m3 8 4-5h10l4 5-9 12Z"/><path fill="none" stroke="#D4AF37" strokeWidth="1.1" d="M3 8h18M7 3l5 5 5-5"/></svg>;
 if(name==='store')return <svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor" aria-hidden="true"><path d="M5 3h14l3 6H2ZM3 11h5v10H3Zm7 0h4v10h-4Zm6 0h5v10h-5Z"/></svg>;
 const paths:Record<string,string>={home:'m3 10 9-7 9 7v10H3Z M9 20v-7h6v7',chart:'M4 4v16h16 M7 14l4-5 4 3 5-7',wallet:'M3 6h17v14H3Z M3 6V4h14 M15 11h6v5h-6Z',receipt:'M5 3h14v18l-3-2-4 2-4-2-3 2Z M8 8h8 M8 12h8',bell:'M5 16h14l-2-3V9a5 5 0 0 0-10 0v4Z M10 20h4',user:'M16 7a4 4 0 1 1-8 0 4 4 0 0 1 8 0 M4 21v-2a8 8 0 0 1 16 0v2',help:'M12 17v1 M9 8a3 3 0 1 1 4 3c-1 .5-1 1-1 3 M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0',menu:'M4 6h16 M4 12h16 M4 18h16',copy:'M8 8h12v12H8Z M4 16H3V4h12v2',share:'M12 16V3 M7 8l5-5 5 5 M5 14v6h14v-6',download:'M12 3v12 M7 10l5 5 5-5 M4 17v4h16v-4',close:'m6 6 12 12 M6 18 18 6',refresh:'M20 8a9 9 0 1 0 1 8 M20 3v6h-6',plus:'M12 5v14 M5 12h14',logout:'M9 3H4v18h5 M9 12h12 m-4-4 4 4-4 4',calculator:'M5 3h14v18H5Z M8 7h8 M8 11h2 M12 11h2 M16 11h1 M8 15h2 M12 15h2 M16 15h1 M8 18h2 M12 18h5',chevron:'m9 18 6-6-6-6',edit:'M12 20h9 m-3-15 2 2L9 18l-5 1 1-5L16 4l2 2Z',trash:'M4 7h16 M9 7V4h6v3 M6 7l1 14h10l1-14 M10 11v6 M14 11v6',settings:'M12 15.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7 M19.4 15a1.7 1.7 0 0 0 .34 1.88l.06.06-2.12 3.67-.08-.02a1.7 1.7 0 0 0-1.8-.35l-.1.04a1.7 1.7 0 0 0-1.1 1.55V22h-4.24v-.17a1.7 1.7 0 0 0-1.1-1.55l-.1-.04a1.7 1.7 0 0 0-1.8.35l-.08.02-2.12-3.67.06-.06A1.7 1.7 0 0 0 5.56 15l-.02-.1A1.7 1.7 0 0 0 4 13.8H3.8V9.56H4a1.7 1.7 0 0 0 1.54-1.1l.02-.1a1.7 1.7 0 0 0-.34-1.88l-.06-.06 2.12-3.67.08.02a1.7 1.7 0 0 0 1.8.35l.1-.04a1.7 1.7 0 0 0 1.1-1.55V1.4h4.24v.17a1.7 1.7 0 0 0 1.1 1.55l.1.04a1.7 1.7 0 0 0 1.8-.35l.08-.02 2.12 3.67-.06.06a1.7 1.7 0 0 0-.34 1.88l.02.1A1.7 1.7 0 0 0 21 9.56h.2v4.24H21a1.7 1.7 0 0 0-1.54 1.1Z',map:'M9 18 3 21V6l6-3 6 3 6-3v15l-6 3-6-3Z M9 3v15 M15 6v15'};
 return <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={paths[name]||paths.home}/></svg>;
}
const number=(n:number)=>formatTwo(n);
const money=(n:number|null,c:string)=><Money amount={n} currency={c}/>;
const dateTime=(s:string,calendar:DisplayCalendar)=>formatDisplayDate(s,activeLocale(),calendar,{dateStyle:'medium',timeStyle:'short'});
function Empty({children}:{children:React.ReactNode}){return <div className="empty"><Icon name="wallet"/><p>{children}</p></div>;}
function CurrencySelect({value='SAR'}:{value?:string}){return <select name="currency" defaultValue={value}>{(CURRENCIES.includes(value)?CURRENCIES:[value,...CURRENCIES]).map(c=><option key={c}>{c}</option>)}</select>;}
function KaratSelect({value=24}:{value?:number}){return <select name="karat" defaultValue={value}>{(KARATS.includes(value)?KARATS:[value,...KARATS]).map(k=><option key={k} value={k}>عيار {k}</option>)}</select>;}
interface PriceHistoryRow{id:string;source:string;currency:string;karat:number;buyPrice:string;sellPrice?:string;timestamp?:string;createdAt?:string;kind?:'spot'|'daily-average';day?:string}
function BootScreen(){
 const {language,direction}=useLanguage();
 const [slow,setSlow]=useState(false);
 useEffect(()=>{const timer=setTimeout(()=>setSlow(true),6500);return()=>clearTimeout(timer);},[]);
 return <div className="gold-web boot" dir={direction} role="status" aria-live="polite">
  <div className="boot-shell">
   <img className="boot-photo-icon" src="/gold-app-pwa/full/app_icon_user.jpg" alt="" aria-hidden="true"/>
   <div className="boot-copy"><h1>{translateUiText('ذهبك',language)}</h1><p>{translateUiText('نجهّز ذهبك لك…',language)}</p></div>
   <span className="boot-loader" aria-hidden="true"><i/><i/><i/></span>
       {slow&&<p className="boot-slow">قد يستغرق التشغيل الأول بضع ثوانٍ.</p>}
  </div>
 </div>;
}
export default function UserWorkspace(){
 const {user,lockedAccount}=useUserLockAuth();
 const mode=user||lockedAccount?'app':'auth';
 return <LanguageProvider key={mode} mode={mode}><LocalizedUserWorkspace/></LanguageProvider>;
}
function LocalizedUserWorkspace(){
 const {user,lockedAccount,isLoading,error,logout,continueWithPassword,quickPinEnabled,biometricEnabled,unlockWithPin,loginWithBiometric}=useUserLockAuth();
 const [online,setOnline]=useState(()=>typeof navigator==='undefined'||navigator.onLine!==false);
 const [publicTools,setPublicTools]=useState(false);
 useEffect(()=>{const changed=()=>{const connected=navigator.onLine!==false;setOnline(connected);if(connected)setPublicTools(false);};window.addEventListener('online',changed);window.addEventListener('offline',changed);return()=>{window.removeEventListener('online',changed);window.removeEventListener('offline',changed);};},[]);
 if(!online||publicTools)return <OfflineWorkspace online={online} onReturn={()=>{setOnline(navigator.onLine!==false);setPublicTools(false);}}/>;
 if(isLoading&&!user&&!lockedAccount)return <BootScreen/>;
 if(lockedAccount)return <QuickLockScreen key={String(lockedAccount.id)}
  account={lockedAccount} quickPinEnabled={quickPinEnabled} biometricEnabled={biometricEnabled}
  loading={isLoading} error={error} onPin={unlockWithPin}
  onBiometric={loginWithBiometric} onForgot={continueWithPassword} onOfflineTools={()=>setPublicTools(true)}/>;
 if(!user)return <AuthForm onOfflineTools={()=>setPublicTools(true)}/>;
 return <Workspace key={String(user.id)} email={user.email} role={user.role} logout={logout}/>;
}
export function Workspace({email,role,logout}:{email:string;role:string;logout:()=>void}){
  const {language,setLanguage,direction}=useLanguage();
  // Explicit React translations for dynamic/critical labels: no dependence on DOM observer timing.
  const tr=(source:string)=>translateUiText(source,language);
 const {user,biometricAvailable,biometricEnabled,biometricEnrolled,enableBiometric,disableBiometric,lockWithBiometric,quickPinEnabled,pinReconnectRequired,reconnectQuickPin,recoverQuickPin,enableQuickPin,disableQuickPin}=useUserLockAuth();
 const [biometricNotice,setBiometricNotice]=useState('');
 const [pinSetup,setPinSetup]=useState<'enable'|'change'|'disable'|'reconnect'|'recover'|null>(null);
 const biometricActive=canShowBiometricLogin({biometricAvailable,biometricEnabled,biometricEnrolled});
 const [page,setPage]=useState<Page>('home'),[menu,setMenu]=useState(false),[expandedPortfolioId,setExpandedPortfolioId]=useState<string|null>(null);
 const [portfolios,setPortfolios]=useState<Portfolio[]>([]),[purchases,setPurchases]=useState<Purchase[]>([]),[alerts,setAlerts]=useState<PriceAlert[]>([]);
 const [priceCurrency,setPriceCurrency]=useState<DisplayCurrency>(()=>{
  try{const saved=typeof window!=='undefined'?window.localStorage.getItem('dhahabi:user:price-currency'):null;
   return saved==='USD'||saved==='EUR'?saved:'SAR';}
  catch{return 'SAR';}
 });
 useEffect(()=>{try{window.localStorage.setItem('dhahabi:user:price-currency',priceCurrency);}catch{/* Storage may be blocked on iOS private browsing. */}},[priceCurrency]);
 // Each PWA install retains its own chosen language and currency for Push,
 // even when the application is closed. This never requests OS permission.
 useEffect(()=>{
  const sync=()=>{if(document.visibilityState==='visible')
    void syncMarketPushPreferences(language,priceCurrency).catch(()=>{});};
  sync();
  window.addEventListener('online',sync);
  window.addEventListener('focus',sync);
  return()=>{window.removeEventListener('online',sync);window.removeEventListener('focus',sync);};
 },[language,priceCurrency]);
 const [eurPerUsd,setEurPerUsd]=useState<number|null>(null);
 const [calendar,setCalendar]=useState<DisplayCalendar>(readDisplayCalendar);
 useEffect(()=>saveDisplayCalendar(calendar),[calendar]);
 const [homeHistory,setHomeHistory]=useState<PriceHistoryRow[]>([]),[homeHistoryCurrency,setHomeHistoryCurrency]=useState(''),[homeRange,setHomeRange]=useState<TrendRange>('day');
 const [history,setHistory]=useState<PriceHistoryRow[]>([]),[historyQuery,setHistoryQuery]=useState(''),
  [allMarketRows,setAllMarketRows]=useState<MarketPrice[]>(()=>readPublicMarketSnapshot()?.rows||[]),
  [marketVerified,setMarketVerified]=useState(false),[historyLoading,setHistoryLoading]=useState(false),
  [historyError,setHistoryError]=useState(''),[chartKarat,setChartKarat]=useState(24),[chartRange,setChartRange]=useState<TrendRange>('available');
 const [calcKarat,setCalcKarat]=useState(24),[calcWeight,setCalcWeight]=useState('10'),[calcFee,setCalcFee]=useState('0');
 const [calcTaxInput,setCalcTaxInput]=useState('0'),[calcUseManual,setCalcUseManual]=useState(false),[calcManualPrice,setCalcManualPrice]=useState('');
 const [loading,setLoading]=useState(true),[loaded,setLoaded]=useState(false),[busy,setBusy]=useState(false),[error,setError]=useState(''),[message,setMessage]=useState('');
 const [marketLoading,setMarketLoading]=useState(false),[marketError,setMarketError]=useState('');
 const [dialog,setDialog]=useState<{type:'portfolio'|'purchase'|'alert';portfolio?:Portfolio;purchase?:Purchase;alert?:PriceAlert}|null>(null),[confirm,setConfirm]=useState<{path:string;label:string}|null>(null),[formError,setFormError]=useState('');
 useEffect(()=>{if(page==='calculator')void preloadQuoteIcon().catch(()=>{});},[page]);
 const [clock,setClock]=useState(Date.now());const active=useRef(true),loadSequence=useRef(0),marketLoadSequence=useRef(0),marketQuoteSequence=useRef(0),writeLock=useRef(false),modalRef=useRef<HTMLDivElement>(null),headingRef=useRef<HTMLHeadingElement>(null);
 const loadData=useCallback(async()=>{
  const seq=++loadSequence.current;setLoading(true);setError('');
  try{
   const [ps,buys,first]=await Promise.all([api<Portfolio[]>('/portfolio'),api<Purchase[]>('/portfolio/purchase'),api<{items:PriceAlert[];total:number}>('/alerts?limit=100&page=1')]);
   if(!Array.isArray(ps)||!Array.isArray(buys)||!Array.isArray(first.items)||!Number.isFinite(first.total))throw new Error('Invalid response');
   const all=[...first.items];for(let p=2;all.length<first.total;p++){const next=await api<{items:PriceAlert[]}>('/alerts?limit=100&page='+p);if(!next.items.length)break;all.push(...next.items);}
   if(active.current&&seq===loadSequence.current){setPortfolios(ps);setPurchases(buys);setAlerts(all);setLoaded(true);}
  }catch(e){if(active.current&&seq===loadSequence.current)setError(errorMessage(e));}
  finally{if(active.current&&seq===loadSequence.current)setLoading(false);}
 },[]);
 // Quote refresh is independent of history and account data. Never wait for chart FX or
 // a slow historical query before displaying the latest independently verified spot price.
 const loadLiveQuotes=useCallback(async()=>{
  const seq=++marketQuoteSequence.current;
  if(active.current)setMarketLoading(true);
  try{
   const requestSnapshot=async():Promise<PriceHistoryRow[]>=>{
    try{return await api<PriceHistoryRow[]>('/prices/snapshot');}
    catch(e){
     // During a safe staged backend rollout, remain compatible with the old API.
     if(!(e instanceof ApiError)||e.status!==404)throw e;
     const rows=await Promise.all(['SAR','USD'].flatMap(currency=>
      [24,22,21,18].map(karat=>api<PriceHistoryRow|null>('/prices/latest?currency='+currency+'&karat='+karat))));
     return rows.filter((row):row is PriceHistoryRow=>!!row);
    }
   };
   const [latest,eurSpot]=await Promise.all([
    requestSnapshot(),
    priceCurrency==='EUR'?loadEuroSpot().catch(()=>null):Promise.resolve(null)
   ]);
   if(!Array.isArray(latest))throw new Error('Invalid spot response');
   const cleanLatest=latest.filter((row):row is PriceHistoryRow&MarketPrice=>
    !!row&&typeof row.timestamp==='string'&&row.kind!=='daily-average'&&
    typeof row.sellPrice==='string'&&Number.isFinite(Number(row.buyPrice))&&Number(row.buyPrice)>0);
   if(!cleanLatest.length)throw new Error('No validated spot prices');
   if(active.current&&seq===marketQuoteSequence.current){
    const publicRows=eurSpot?[...cleanLatest,...euroSpotRows(eurSpot)]:cleanLatest;
    setAllMarketRows(publicRows);
    savePublicMarketSnapshot(publicRows);
    setMarketVerified(true);
    setEurPerUsd(eurSpot?.eurPerUsd??null);
    setMarketError(priceCurrency==='EUR'&&!eurSpot?
     'تعذر تحديث سعر الذهب باليورو. لا يوجد سعر يورو موثوق متاح الآن.':'');
   }
  }catch{
   // Keep verified real offline snapshots; a failed request is never a new live price.
   if(active.current&&seq===marketQuoteSequence.current){
    setMarketVerified(false);
    setMarketError('تعذر تحديث الأسعار من المصدر. المعروض آخر سعر محفوظ إن توفر.');
   }
  }finally{
   if(active.current&&seq===marketQuoteSequence.current)setMarketLoading(false);
  }
 },[priceCurrency]);
 const loadMarket=useCallback(async()=>{
  const seq=++marketLoadSequence.current;
  if(active.current){
   setHistoryLoading(true);setHistoryError('');
   setHistoryQuery(previous=>previous===priceCurrency+':'+chartKarat+':'+chartRange?previous:'');
  }
  // Start the current quote first. Historical queries run alongside it, not ahead of it.
  void loadLiveQuotes();
  try{
   const sourceCurrency=priceCurrency==='EUR'?'USD':priceCurrency;
   const requestHistory=(karat:number,range:TrendRange)=>{
    const request=(currency:string)=>api<PriceHistoryRow[]>('/prices/history/chart?currency='+encodeURIComponent(currency)+'&karat='+karat+'&range='+range);
    return priceCurrency==='EUR'?loadEuroHistorySources(request):request(sourceCurrency);
   };
   const selectedHistory=requestHistory(chartKarat,chartRange);
   const selectedHomeHistory=chartKarat===24&&chartRange===homeRange?selectedHistory:requestHistory(24,homeRange);
   const eurFxRequest=priceCurrency==='EUR'?Promise.all([selectedHistory,selectedHomeHistory])
    .then(rows=>loadEuroReferenceRates(Date.now(),fetch,euroHistoryStartDay(rows.flat())))
    .catch(()=>null):Promise.resolve(null);
   const [historyRows,homeHistoryRows,reference]=await Promise.all([
    selectedHistory,selectedHomeHistory,eurFxRequest
   ]);
   if(!Array.isArray(historyRows)||!Array.isArray(homeHistoryRows))throw new Error('Invalid history response');
   if(active.current&&seq===marketLoadSequence.current){
    setHistory(priceCurrency==='EUR'?(reference?euroHistoryRows(historyRows,reference):[]):historyRows);
    setHomeHistory(priceCurrency==='EUR'?(reference?euroHistoryRows(homeHistoryRows,reference):[]):homeHistoryRows);
    setHomeHistoryCurrency(priceCurrency);
    setHistoryQuery(priceCurrency+':'+chartKarat+':'+chartRange);
    setHistoryError(priceCurrency==='EUR'&&!reference?
     'تعذر تحميل الرسم التاريخي باليورو. سعر الذهب الحالي مستقل عن بيانات الرسم.':'');
   }
  }catch{
   if(active.current&&seq===marketLoadSequence.current)
    setHistoryError('تعذر تحديث الرسم البياني. لا يؤثر ذلك على السعر الحالي.');
  }finally{
   if(active.current&&seq===marketLoadSequence.current)setHistoryLoading(false);
  }
 },[priceCurrency,chartKarat,chartRange,homeRange,loadLiveQuotes]);
 useEffect(()=>{active.current=true;void loadData();void loadMarket();
  const clockTimer=setInterval(()=>setClock(Date.now()),30000);
  // Global spot market only: 30-second source refresh; the chart remains on-demand.
  const marketTimer=setInterval(()=>{
   if(document.visibilityState==='visible'&&isGlobalGoldMarketOpen(Date.now()))void loadLiveQuotes();
  },30000);
  const focus=()=>{if(document.visibilityState==='visible'){
   setClock(Date.now());void loadData();void loadMarket();
  }};
  document.addEventListener('visibilitychange',focus);
  return()=>{active.current=false;loadSequence.current++;marketLoadSequence.current++;
   marketQuoteSequence.current++;clearInterval(clockTimer);clearInterval(marketTimer);
   document.removeEventListener('visibilitychange',focus);
  };},[loadData,loadMarket,loadLiveQuotes]);
 useEffect(()=>{const read=()=>{const id=location.hash.slice(1);if(pages.some(p=>p.id===id))setPage(id as Page);};read();window.addEventListener('hashchange',read);return()=>window.removeEventListener('hashchange',read);},[]);
 const navigate=(p:Page)=>{setPage(p);setMenu(false);location.hash=p;requestAnimationFrame(()=>headingRef.current?.focus());};
 const signOut=()=>{void (async()=>{try{await revokePushBeforeLogout();}finally{logout();}})();};
 useEffect(()=>{if(!message)return;const timer=setTimeout(()=>setMessage(''),6000);return()=>clearTimeout(timer);},[message]);
 useEffect(()=>{if(!dialog&&!confirm&&!menu)return;const previous=document.activeElement as HTMLElement,el=modalRef.current;
  const controls=()=>el?.querySelectorAll<HTMLElement>('button:not(:disabled),input:not(:disabled),select:not(:disabled),[tabindex="0"]');controls()?.[0]?.focus();
  const key=(e:KeyboardEvent)=>{if(e.key==='Escape'&&!writeLock.current){setDialog(null);setConfirm(null);setMenu(false);}if(e.key==='Tab'&&el){const c=controls();if(!c?.length)return;if(e.shiftKey&&document.activeElement===c[0]){e.preventDefault();c[c.length-1].focus();}else if(!e.shiftKey&&document.activeElement===c[c.length-1]){e.preventDefault();c[0].focus();}}};
  document.addEventListener('keydown',key);return()=>{document.removeEventListener('keydown',key);previous?.focus();};},[dialog,confirm,menu]);
 const mutate=async(path:string,method:string,data?:object)=>{
  if(writeLock.current)return;writeLock.current=true;setBusy(true);setError('');setFormError('');setMessage('');
  try{await api(path,jsonRequest(method,data));if(!active.current)return;setDialog(null);setConfirm(null);setMessage('تم حفظ التغيير على الخادم.');await loadData();}
  catch(e){if(active.current){const msg=errorMessage(e);setFormError(msg);setError(msg);}}
  finally{writeLock.current=false;if(active.current)setBusy(false);}
 };
 const openDialog=(type:'portfolio'|'purchase'|'alert',purchase?:Purchase)=>{setFormError('');setDialog({type,purchase});};
 const openPortfolioDialog=(portfolio?:Portfolio)=>{setFormError('');setDialog({type:'portfolio',portfolio});};
  const openAlertDialog=(alert?:PriceAlert)=>{setFormError('');setDialog({type:'alert',alert});};
 const submit=async(e:React.FormEvent<HTMLFormElement>)=>{e.preventDefault();const data=new FormData(e.currentTarget);if(!dialog)return;
  try{
   if(dialog.type==='portfolio'){const name=String(data.get('name')||'').trim();if(!name)throw new Error('أدخل اسم المحفظة.');await mutate(dialog.portfolio?'/portfolio/'+dialog.portfolio.id:'/portfolio',dialog.portfolio?'PATCH':'POST',{name});}
   if(dialog.type==='purchase'){const payload=purchasePayload(data);await mutate(dialog.purchase?'/portfolio/purchase/'+dialog.purchase.id:'/portfolio/purchase',dialog.purchase?'PATCH':'POST',payload);}
   if(dialog.type==='alert'){
    const payload=alertPayload(data);
    await mutate(dialog.alert?'/alerts/'+dialog.alert.id:'/alerts',dialog.alert?'PATCH':'POST',payload);
   }
  }catch(e){setFormError(e instanceof Error?e.message:'تحقق من القيم.');}
 };
 // Daily averages never serve as the current market quote, even as a fallback.
 const sortedHistory=[...(historyQuery===priceCurrency+':'+chartKarat+':'+chartRange?history:[])].filter(r=>r.kind!=='daily-average'&&!!r.timestamp).sort((a,b)=>Date.parse(a.timestamp||a.createdAt||'')-Date.parse(b.timestamp||b.createdAt||''));
 const selectedMarketRows=allMarketRows.filter(r=>r.currency===priceCurrency);
  const currentMarket=selectedMarketRows.find(r=>r.karat===chartKarat)||sortedHistory[sortedHistory.length-1]||null;
 const homeMarket=allMarketRows.find(r=>r.currency===priceCurrency&&r.karat===24);
 const freshness=priceFreshness(homeMarket,clock);
 const marketClosed=!isGlobalGoldMarketOpen(clock);
 const stale=marketClosed||!marketVerified||freshness!=='fresh'||!!marketError;
 const marketLabel=marketClosed?'السوق العالمي مغلق':marketVerified&&freshness==='fresh'&&!marketError?'السعر العالمي المحدّث':freshness==='missing'?'غير متاح':'آخر سعر محفوظ';
 const summary=totals(purchases,allMarketRows),statusLabels={active:'نشط',paused:'متوقف',triggered:'تحقق الشرط'};
 const visibleHistory=historyQuery===priceCurrency+':'+chartKarat+':'+chartRange?history:[];
  const fxRate=sarPerUsd(allMarketRows);
  const showMoney=(amount:number|null|undefined,source:string)=>{const display=displayAmount(amount,source,priceCurrency,fxRate,eurPerUsd);return <Money amount={display.amount} currency={display.currency}/>;};
 const priceNote=<p className="fine">{tr('لا تشمل الأسعار المصنعية أو الضريبة أو هامش المتجر.')}</p>;
 const marketTime=(row:Pick<MarketPrice,'timestamp'>|null|undefined)=>row&&Number.isFinite(Date.parse(row.timestamp))?dateTime(row.timestamp,calendar):'لا يوجد تحديث موثوق';
 const priceBlock=<section className="market-price-card">
  <div className="row"><div><p className="mock-supporting">{marketClosed?'آخر سعر مسجل':'سعر الذهب الآن'}</p><strong className="mock-gold-number">{money(homeMarket?Number(homeMarket.buyPrice):null,priceCurrency)}</strong><p className="mock-supporting">عيار 24 · سعر الجرام</p></div><span className={'pill '+(!stale?'good':'warn')}>{marketLabel}</span></div>
  <p className="market-update">آخر تحديث: {marketTime(homeMarket)}</p>
 </section>;
 const nav=<><div className="nav-brand"><span className="brand-mark small">ذ</span><div><strong>{tr("ذهبك")}</strong><small>حساب المستخدم</small></div></div><nav aria-label="القائمة الرئيسية">{primaryPages.map(p=><button key={p.id} className={'nav-item '+(p.id===page?'selected':'')} aria-current={p.id===page?'page':undefined} onClick={()=>navigate(p.id)}><Icon name={p.icon}/><span>{p.navLabel||p.label}</span></button>)}</nav><div className="nav-account"><span className="avatar">{email[0].toUpperCase()}</span><span className="email" dir="ltr">{email}</span><button className="icon-button" title="تسجيل الخروج" aria-label="تسجيل الخروج" onClick={signOut}><Icon name="logout"/></button></div></>;
 const calcMarket=allMarketRows.find(r=>r.currency===priceCurrency&&r.karat===calcKarat);
 const calcBaseUnit=calcMarket&&Number.isFinite(Number(calcMarket.buyPrice))?Number(calcMarket.buyPrice):null;
 const calcUnit=calcUseManual?(calcManualPrice.trim()&&Number(calcManualPrice)>0?Number(calcManualPrice):null):calcBaseUnit;
 const calcWeightN=calcWeight.trim()?Number(calcWeight):0,calcFeeN=calcFee.trim()?Number(calcFee):0;
 const calcTaxRate=calcTaxInput.trim()?Number(calcTaxInput):0;
 const {raw:calcRaw,fees:calcFeeTotal,tax:calcTax,total:calcTotal}=calculatorQuoteWithTaxRate(calcUnit,calcWeightN,calcFeeN,calcTaxRate);
 const quoteSnapshot=():ShareQuote|null=>{
  if(calcUnit===null||calcRaw===null||calcFeeTotal===null||calcTax===null||calcTotal===null)return null;
  return {language,currency:priceCurrency,karat:calcKarat,weight:calcWeightN,unitPrice:calcUnit,
   basePrice:calcBaseUnit,priceSource:calcUseManual?'manual':'market',raw:calcRaw,fees:calcFeeTotal,
   tax:calcTax,total:calcTotal,words:language==='ar'?amountToDisplayCurrencyWords(calcTotal,priceCurrency):amountToLocalizedWords(calcTotal,priceCurrency,language),
   generatedAt:new Date().toISOString()};
 };
 const copyQuoteDetails=async()=>{
  const snapshot=quoteSnapshot();if(!snapshot)return;
  try{await navigator.clipboard.writeText(quoteShareText(snapshot));setMessage(tr('تم نسخ تفاصيل السعر المقدر.'));}
  catch{setMessage(tr('تعذر النسخ على هذا الجهاز.'));}
 };
 const shareQuoteImage=async(download:boolean)=>{
  const snapshot=quoteSnapshot();if(!snapshot)return;
  try{const outcome=await shareQuotePng(snapshot,download);
   if(outcome==='downloaded')setMessage(tr('تم إعداد صورة التقدير للحفظ.'));
  }catch{setMessage(tr('تعذر تجهيز صورة المشاركة. حاول مرة أخرى.'));}
 };
 const totalWeight=purchases.reduce((sum,p)=>sum+(Number(p.weightGrams)||0),0);
 const homePortfolio=displayPortfolioSummary(purchases,allMarketRows,priceCurrency,fxRate,loaded,eurPerUsd);
 const selectedHomeHistory=homeHistoryCurrency===priceCurrency?homeHistory:[];
  // Daily historical averages are not live quotes and must not enter daily P/L.
  const realHomeQuotes=selectedHomeHistory.filter((r):r is PriceHistoryRow&{timestamp:string}=>
    r.kind!=='daily-average'&&typeof r.timestamp==='string');
  const homeMovement=homeMarketMovement(realHomeQuotes,homeMarket,clock,priceCurrency);
 const accountName=user?.name?.trim()||'أضف اسمك';
 const mobilePage=mobilePages.some(p=>p.id===page)?page:'more';
 const content=()=>{
  if(page==='home')return <>
   <section className="approved-card live-price-card" aria-label={marketClosed?"آخر سعر مسجل عيار 24":"سعر الذهب الآن عيار 24"}>
    <div className="live-card-top"><span className={!stale?'live-badge':'pill warn'}>{!stale&&<i/>}{marketLabel}</span><strong>{marketClosed?'آخر سعر مسجل - عيار 24':'سعر الذهب الآن - عيار 24'}</strong></div>
    <div className="live-price-main"><div className="home-quote"><div className="price-tag-large" dir={direction}><span className="dh-home-price-amount">{money(homeMarket?Number(homeMarket.buyPrice):null,priceCurrency)}</span><small className="dh-home-price-unit" dir={direction}><span className="dh-unit-slash" aria-hidden="true">/</span><span>{tr('جرام')}</span></small></div>
     <p className={'home-market-change '+(homeMovement===null?'neutral':homeMovement.difference>=0?'positive':'negative')} title="مقارنة بأول تحديث متاح اليوم بتوقيت السعودية">
      {marketClosed?'لا تداول حاليًا':homeMovement?<><Icon name="chart"/><span dir="ltr">{homeMovement.difference>=0?'+':'−'}{money(Math.abs(homeMovement.difference),priceCurrency)} ({homeMovement.percent>=0?'+':'−'}{number(Math.abs(homeMovement.percent))}%)</span> اليوم</>:'لا توجد مقارنة كافية اليوم'}
     </p></div><div className="buy-sell-mini"><span className="dh-buy-sell-row"><span>{tr('شراء التاجر:')}</span><b>{tr('غير متاح')}</b></span><span className="dh-buy-sell-row"><span>{tr('بيع التاجر:')}</span><b>{tr('غير متاح')}</b></span></div></div>
    <div className="live-card-footer"><span>السعر العالمي الاسترشادي</span><button className="home-price-refresh" title={marketTime(homeMarket)} aria-label="تحديث أسعار الذهب من خادم ذهبك" disabled={marketLoading} onClick={()=>void loadMarket()}>{marketClosed?'آخر تحديث: '+marketTime(homeMarket):marketLoading?'جارٍ التحديث…':homeUpdateAge(homeMarket?.timestamp,clock)}</button></div>
   </section>
   <div className="approved-section-title"><h3>الخدمات السريعة</h3></div>
   <section className="approved-services-grid">{[
    ['calculator','حاسبة الذهب','calculator'],['prices','أسعار اليوم','chart'],['portfolio','المحفظة','wallet'],['map','أقرب تاجر','store']
   ].map(([id,label,icon])=><button key={id} className="approved-service-item" onClick={()=>navigate(id as Page)}><span className="approved-service-icon"><Icon name={icon}/></span><span>{label}</span></button>)}</section>
   <section className="approved-card portfolio-mini" aria-label={'ملخص المحفظة بعملة العرض '+priceCurrency}><div className="approved-card-title"><span><Icon name="wallet"/>{tr('محفظتي الذهبية')}</span><button className="text-button" onClick={()=>navigate('portfolio')}>{tr('التفاصيل ←')}</button></div>
    <div className="portfolio-mini-body"><div><strong>{money(homePortfolio.value,priceCurrency)}</strong><span>{tr('إجمالي الوزن:')} {homePortfolio.weight===null?tr('غير متاح'):<><span dir="ltr">{number(homePortfolio.weight)}</span> {tr('جرام')}</>}</span></div>{homePortfolio.difference!==null&&homePortfolio.percent!==null&&<div className={'portfolio-delta '+(homePortfolio.difference>=0?'positive':'negative')} title="الفرق عن تكلفة الشراء"><b><span>{homePortfolio.difference>=0?'+':'−'}</span>{money(Math.abs(homePortfolio.difference),priceCurrency)}</b><small dir="ltr">{homePortfolio.percent>=0?'+':'−'}{number(Math.abs(homePortfolio.percent))}%</small></div>}</div>
    {homePortfolio.hasUnconverted&&<p className="home-currency-note">بعض مشترياتك بعملات لا تتوفر لها بيانات تحويل موثوقة؛ راجع التفاصيل حسب عملة التسجيل.</p>}
     {homePortfolio.hasMissingValuation&&<p className="home-currency-note">تقدير قيمة بعض المشتريات غير متاح لغياب سعر سوق موثوق.</p>}
   </section>
   <section className="approved-card home-chart-card"><PriceHistoryChart rows={selectedHomeHistory} currency={priceCurrency} karat={24} calendar={calendar} compact range={homeRange} onRangeChange={setHomeRange} now={clock} loading={historyLoading}/></section>
  </>;

  if(page==='prices')return <>
   <section className="approved-card prices-header-card"><span className={!stale?'live-badge':'pill warn'}>{!stale&&<i/>}{!stale?tr('آخر سعر متاح'):marketLabel}</span><p>{tr('سعر الأونصة المشتق من عيار 24')}</p><strong className="ounce-price">{currentMarket&&currentMarket.karat===24?money(Number(currentMarket.buyPrice)*31.1034768,priceCurrency):money((selectedMarketRows.find(r=>r.karat===24)?Number(selectedMarketRows.find(r=>r.karat===24)!.buyPrice):NaN)*31.1034768||null,priceCurrency)}</strong><small>{tr('آخر فحص:')} {marketTime(selectedMarketRows.find(r=>r.karat===24))}</small></section>
   <section className="approved-card"><div className="approved-card-title"><span>أسعار الجرام بحسب العيار</span><label className="inline-select">العملة<select value={priceCurrency} onChange={e=>setPriceCurrency(e.target.value==='USD'||e.target.value==='EUR'?e.target.value:'SAR')}><option>SAR</option><option>USD</option><option>EUR</option></select></label></div>
    <div className="approved-price-table"><div className="price-row head"><span>العيار</span><span>السعر العالمي</span><span>شراء/بيع التاجر</span></div>{[24,22,21,18].map(k=>{const row=selectedMarketRows.find(r=>r.karat===k);return <div className="price-row" key={k}><span><b className="karat-badge">عيار {k}</b></span><strong>{money(row?Number(row.buyPrice):null,priceCurrency)}</strong><span>{tr('غير متاح')}</span></div>;})}</div>
   </section>
   <section className="approved-card"><div className="approved-card-title"><span>{tr('الرسم الزمني للأسعار')}</span><label className="inline-select">{tr('العيار')}<select value={chartKarat} onChange={e=>setChartKarat(Number(e.target.value))}>{[24,22,21,18].map(k=><option key={k} value={k}>{k}K</option>)}</select></label></div>{historyError?<p className="notice warning">{localizeFeedback(historyError,language)}</p>:<PriceHistoryChart rows={visibleHistory} currency={priceCurrency} karat={chartKarat} calendar={calendar} range={chartRange} onRangeChange={setChartRange} now={clock} loading={historyLoading}/>}</section>
   <p className="fine">{tr('أسعار شراء التاجر وبيعه تختلف بحسب المتجر والمصنعية والضريبة. المصدر الحالي يوفر السعر العالمي فقط، وليس عرضًا من تاجر.')}</p>
   {priceNote}
  </>;

  if(page==='calculator')return <>
   <section className="approved-card calculator-form">
    <label>1. اختر عيار الذهب<div className="karat-switch">{[24,22,21,18].map(k=><button type="button" key={k} className={calcKarat===k?'active':''} onClick={()=>setCalcKarat(k)}>{k}K</button>)}</div></label>
    <div className="calc-unit-price" role="status" aria-live="polite">
     <span className="calc-unit-label">سعر الجرام الأساسي حسب العيار المحدد<small>عيار {calcKarat} · السعر العالمي الاسترشادي، دون مصنعية أو ضريبة{marketClosed?' · آخر سعر مسجل':''}</small></span>
     <strong dir="ltr">{money(calcBaseUnit,priceCurrency)}</strong>
    </div>
    <div className="calc-price-switch" role="group" aria-label="مصدر السعر المستخدم في الحساب">
     <button type="button" className={!calcUseManual?'active':''} aria-pressed={!calcUseManual} onClick={()=>setCalcUseManual(false)}>السعر الأساسي</button>
     <button type="button" className={calcUseManual?'active':''} aria-pressed={calcUseManual} onClick={()=>setCalcUseManual(true)}>إدخال سعر آخر</button>
    </div>
    {calcUseManual&&<label className="calc-manual-price">سعر الجرام المعتمد في الحساب <span dir="ltr">({priceCurrency})</span>
     <input type="number" inputMode="decimal" min="0.01" step="0.01" value={calcManualPrice} placeholder="0.00" onChange={e=>setCalcManualPrice(e.target.value)}/>
     <small>يُحسب الإجمالي بالسعر الذي تُدخله، ويمكنك استعادة السعر الأساسي في أي وقت.</small>
    </label>}
    <label>الوزن (جرام)<input type="number" inputMode="decimal" min="0" step="0.1" value={calcWeight} onChange={e=>setCalcWeight(e.target.value)}/><div className="weight-presets">{[5,10,20,31.1,50].map(w=><button type="button" key={w} onClick={()=>setCalcWeight(String(w))}>{w===31.1?'أونصة 31.1g':w+' جرام'}</button>)}</div></label>
    <label>المصنعية / جرام <span dir="ltr">({priceCurrency})</span> (اختياري)<input type="number" inputMode="decimal" min="0" step="0.01" value={calcFee} onChange={e=>setCalcFee(e.target.value)}/></label>
    <label className="calc-tax-input">{tr('الضريبة (%) — اختيارية')}
     <input type="number" inputMode="decimal" min="0" max="100" step="0.01" value={calcTaxInput} onChange={e=>setCalcTaxInput(e.target.value)}/>
     <small>{tr('تُحسب النسبة على قيمة الذهب وإجمالي المصنعية.')}</small>
    </label>
   </section>
   <section className="approved-card calc-estimate-card" aria-label="تفاصيل السعر المقدر">
    <div className="approved-card-title">
     <span>تفاصيل السعر المقدر</span>
     <div className="calc-title-actions" role="group" aria-label={tr('إجراءات تفاصيل السعر المقدر')}>
      <button type="button" className="calc-badge-btn" title={tr('مشاركة كصورة')} aria-label={tr('مشاركة كصورة')} disabled={calcTotal===null} onClick={()=>void shareQuoteImage(false)}>
       <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M18 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6ZM6 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6ZM18 22a3 3 0 1 0 0-6 3 3 0 0 0 0 6ZM8.59 13.51l6.83 3.98M15.41 6.51 8.59 10.49"/></svg>
      </button>
      <button type="button" className="calc-badge-btn" title={tr('حفظ الصورة')} aria-label={tr('حفظ الصورة')} disabled={calcTotal===null} onClick={()=>void shareQuoteImage(true)}>
       <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4 M7 10l5 5 5-5 M12 15V3"/></svg>
      </button>
      <button type="button" className="calc-badge-btn" title={tr('نسخ التفاصيل')} aria-label={tr('نسخ التفاصيل')} disabled={calcTotal===null} onClick={()=>void copyQuoteDetails()}>
       <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M9 9h10v11H9Z M5 15H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v1"/></svg>
      </button>
     </div>
    </div>
    <EstimatedPriceReceiptPrinter language={language} ready={calcTotal!==null} karat={calcKarat} weight={calcWeightN} total={money(calcTotal,priceCurrency)}>
    <dl className="calc-breakdown">
     <div><dt>قيمة الذهب الخام</dt><dd dir="ltr">{money(calcRaw,priceCurrency)}</dd></div>
     <div><dt>إجمالي المصنعية</dt><dd dir="ltr">{money(calcFeeTotal,priceCurrency)}</dd></div>
     <div><dt>{tr('مبلغ الضريبة')}</dt><dd dir="ltr">{money(calcTax,priceCurrency)}</dd></div>
     <div className="final"><dt>{tr('الإجمالي النهائي التقديري')}</dt><dd dir="ltr">{money(calcTotal,priceCurrency)}</dd></div>
    </dl>
    <div className="calc-words-block">
     <div className="calc-words-label">{tr('المبلغ كتابة:')}</div>
     <p className="calc-words-value" aria-label={tr('المبلغ كتابة:')}>{calcTotal!==null?(language==='ar'?amountToDisplayCurrencyWords(calcTotal,priceCurrency):amountToLocalizedWords(calcTotal,priceCurrency,language)):'—'}</p>
    </div>
    </EstimatedPriceReceiptPrinter>
   </section>
  </>;

  if(page==='portfolio')return <>
   <section className="approved-card portfolio-summary-card"><div><span>إجمالي الوزن المسجل</span><strong>{number(totalWeight)} جرام</strong></div><button className="primary" disabled={busy||!loaded} onClick={()=>openDialog('portfolio')}><Icon name="plus"/>محفظة جديدة</button></section>
   <section className="approved-card">
    <div className="approved-card-title"><span>محافظك</span><button className="text-button" disabled={busy||!loaded||!portfolios.length} onClick={()=>openDialog(portfolios.length?'purchase':'portfolio')}>{portfolios.length?tr('تسجيل شراء'):tr('إنشاء محفظة')}</button></div>
    {!loaded?<Empty>لم يتم تحميل المحافظ بعد.</Empty>:!portfolios.length?<Empty>لا توجد محافظ بعد. أنشئ محفظتك الأولى.</Empty>:
    <div className="approved-portfolio-list">{portfolios.map((portfolio,index)=>{
     const rows=purchases.filter(p=>p.portfolioId===portfolio.id);
     const summary=totals(rows,allMarketRows);
     const expanded=expandedPortfolioId===portfolio.id;
     const detailsId='portfolio-purchases-'+index;
     return <article className={'portfolio-entry '+(expanded?'is-expanded':'')} key={portfolio.id}>
       <div className="portfolio-entry-header">
        <div className="portfolio-card-top">
         <div className="portfolio-heading">
          <span className="portfolio-icon" aria-hidden="true"><Icon name="wallet"/></span>
          <span className="portfolio-heading-text"><strong className="portfolio-name" data-no-translate>{portfolio.name}</strong>
           <span className="portfolio-subtitle">{rows.length===0?'محفظة فارغة':rows.length===1?'عملية شراء واحدة':rows.length+' عمليات شراء'}</span>
          </span>
         </div>
         <div className="portfolio-card-actions">
          <button type="button" className="portfolio-action portfolio-edit" title="تعديل الاسم"
           aria-label={'تعديل اسم محفظة '+portfolio.name} disabled={busy} onClick={()=>openPortfolioDialog(portfolio)}><Icon name="edit"/></button>
          {rows.length===0&&<button type="button" className="portfolio-action portfolio-delete" title="حذف المحفظة الفارغة"
           aria-label={'حذف المحفظة الفارغة '+portfolio.name} disabled={busy} onClick={()=>{setFormError('');setConfirm({path:'/portfolio/'+portfolio.id,label:portfolio.name});}}><Icon name="trash"/></button>}
          <button type="button" className="portfolio-action portfolio-toggle" aria-expanded={expanded} aria-controls={detailsId}
           aria-label={(expanded?'طي':'عرض')+' محتويات محفظة '+portfolio.name} onClick={()=>setExpandedPortfolioId(expanded?null:portfolio.id)}>
           <span className={'portfolio-chevron '+(expanded?'rotated':'')}><Icon name="chevron"/></span></button>
         </div>
        </div>
        <div className="portfolio-currency-list">
         {summary.length===0?<p className="portfolio-empty-hint">لم تُسجّل مشتريات بعد. أضف عملية شراء لعرض القيمة.</p>:
          summary.map(item=>{
           const change=item.value===null?null:item.value-item.cost;
           return <div className="portfolio-currency-card" key={item.currency}>
            <div className="portfolio-money-row">
             <span className="portfolio-metric-label">القيمة الحالية <b dir="ltr" title="عملة التسجيل الأصلية">({item.currency})</b></span>
             <strong className="portfolio-market-value" dir="ltr">{showMoney(item.value,item.currency)}</strong>
            </div>
            <div className="portfolio-money-row portfolio-change-row">
             <span className="portfolio-metric-label">الفرق عن الشراء</span>
             <strong className={'portfolio-change-value '+(change===null?'delta-unavailable':change>=0?'delta-positive':'delta-negative')} dir="ltr">
              {change===null?'غير متاح':<>{change>0?'+':change<0?'−':''}{showMoney(Math.abs(change),item.currency)}</>}
             </strong>
            </div>
           </div>;
          })}
        </div>
       </div>
       {expanded&&<div className="portfolio-purchases" id={detailsId} aria-label={'محتويات محفظة '+portfolio.name}>
       <p className="portfolio-purchases-caption">القيمة تقديرية بحسب آخر سعر متاح للعيار والعملة. المبالغ معروضة بعملة التفضيلات عند توفر تحويل موثوق، دون تعديل الفواتير الأصلية. تحويل الريال والدولار استرشادي من أسعار الذهب وليس سعر صرف بنكي. الفرق لا يشمل رسوم أو فروقات إعادة البيع.</p>
       {!rows.length?<p className="portfolio-empty">لا توجد مشتريات في هذه المحفظة حتى الآن.</p>:
       <div className="portfolio-purchases-list">{rows.map(purchase=>{
        const position=purchasePerformance(purchase,allMarketRows);
        return <div className="portfolio-purchase-row" key={purchase.id}>
         <div className="portfolio-purchase-identity"><strong>ذهب عيار {purchase.karat}</strong>
          <span>{number(Number(purchase.weightGrams))} جرام · {formatDisplayDate(purchase.purchasedAt,activeLocale(),calendar,{dateStyle:'medium'})}</span>
         </div>
         <dl className="portfolio-purchase-metrics">
          <div><dt>{purchase.invoiceDetails?.goldUnitPrice!==undefined?'سعر جرام الذهب دون إضافات':'سعر الجرام المسجل (شامل)'}</dt><dd>{showMoney(purchase.invoiceDetails?.goldUnitPrice??Number(purchase.unitPrice),purchase.currency)}</dd></div>
          <div><dt>التكلفة الفعلية للجرام</dt><dd>{showMoney(Number(purchase.totalPrice)/Number(purchase.weightGrams),purchase.currency)}</dd></div>
          <div><dt>تكلفة الشراء الإجمالية</dt><dd>{showMoney(position.cost,purchase.currency)}</dd></div>
          <div><dt>القيمة السوقية التقديرية</dt><dd>{showMoney(position.value,purchase.currency)}</dd></div>
         </dl>
         <div className={'portfolio-purchase-difference '+(position.difference===null?'delta-unavailable':position.difference>=0?'delta-positive':'delta-negative')}>
          <span>الفرق عن تكلفة الشراء</span>
          <strong>{position.difference===null?'غير متاح':<>{position.difference>0?'+':''}{showMoney(position.difference,purchase.currency)}</>}
           {position.cost&&position.difference!==null&&<small className="portfolio-return-percent">{' ('}{position.difference>0?'+':''}{number(100*position.difference/position.cost)}%{')'}</small>}
          </strong>
         </div>
        </div>;
       })}</div>}
      </div>}
     </article>;
    })}</div>}
   </section>
  </>;

  if(page==='purchases')return <section className="approved-card"><div className="approved-card-title"><span>سجل المشتريات</span><button className="primary compact-primary" disabled={busy||!loaded} onClick={()=>openDialog(portfolios.length?'purchase':'portfolio')}><Icon name="plus"/>{portfolios.length?tr('تسجيل شراء'):tr('إنشاء محفظة')}</button></div>{!loaded?<Empty>لم يتم تحميل المشتريات بعد.</Empty>:!purchases.length?<Empty>لا توجد مشتريات مسجلة.</Empty>:<div className="records">{purchases.map(p=><article className="record" key={p.id}><div className="record-title"><span className="card-icon"><Icon name="receipt"/></span><div><h3>ذهب عيار {p.karat}</h3><p className="approved-muted">{portfolios.find(x=>x.id===p.portfolioId)?.name||'محفظة'} · {formatDisplayDate(p.purchasedAt,activeLocale(),calendar,{dateStyle:'medium'})}</p></div><strong className="record-total">{showMoney(Number(p.totalPrice),p.currency)}</strong></div><dl className="record-details"><div><dt>الوزن</dt><dd>{number(Number(p.weightGrams))} جم</dd></div><div><dt>{p.invoiceDetails?.goldUnitPrice!==undefined?'سعر جرام الذهب دون إضافات':'سعر الجرام المسجل (شامل)'}</dt><dd>{showMoney(p.invoiceDetails?.goldUnitPrice??Number(p.unitPrice),p.currency)}</dd></div>
 <div><dt>التكلفة الفعلية للجرام</dt><dd>{showMoney(Number(p.totalPrice)/Number(p.weightGrams),p.currency)}</dd></div>
 {p.invoiceDetails?.pricingMode==='itemized'&&<div><dt>المصنعية والضريبة والأحجار</dt><dd>{showMoney((p.invoiceDetails.makingCharge||0)+(p.invoiceDetails.vatAmount||0)+(p.invoiceDetails.stonePrice||0),p.currency)}</dd></div>}
 {p.invoiceDetails?.invoiceNumber&&<div><dt>الفاتورة</dt><dd data-no-translate>{p.invoiceDetails.invoiceNumber}</dd></div>}
 {p.invoiceDetails?.sellerName&&<div><dt>التاجر</dt><dd data-no-translate>{p.invoiceDetails.sellerName}</dd></div>}<div className="actions"><button className="secondary" disabled={busy} onClick={()=>openDialog('purchase',p)}>تعديل</button><button className="danger text-button" disabled={busy} onClick={()=>{setFormError('');setConfirm({path:'/portfolio/purchase/'+p.id,label:'سجل الشراء'});}}>حذف</button></div></dl></article>)}</div>}</section>;

  if(page==='notification-settings')return <NotificationSettings/>;
  if(page==='alerts')return <section className="approved-card"><div className="approved-card-title"><span>تنبيهات الأسعار</span><button className="primary compact-primary" disabled={busy||!loaded} onClick={()=>openAlertDialog()}><Icon name="plus"/>{tr('تنبيه جديد')}</button></div><div className="dh-push-alert-entry"><p>عندما يصل السعر إلى هدفك، يرسل ذهبك إشعار Push إلى أجهزتك المسجلة، حتى إن كانت الصفحة مغلقة وفق دعم الجهاز.</p><button type="button" className="secondary" onClick={()=>navigate('notification-settings')}><Icon name="bell"/>إعدادات إشعارات الجهاز</button></div>{!loaded?<Empty>لم يتم تحميل التنبيهات بعد.</Empty>:!alerts.length?<Empty>لا توجد تنبيهات. أضف السعر الذي تريد متابعته.</Empty>:<div className="approved-alert-list">{alerts.map(a=><article key={a.id}><div><span className={'pill '+(a.status==='active'?'good':a.status==='triggered'?'warn':'')}>{statusLabels[a.status]}</span><h3>عيار {a.karat} · <span className="dh-currency-label"><CurrencyMark currency={a.currency}/></span></h3><p>{a.direction==='above'?'عند وصول السعر إلى أو أعلى من':'عند وصول السعر إلى أو أقل من'} <b>{showMoney(Number(a.targetPrice),a.currency)}</b></p></div><div className="actions"><button className="secondary" disabled={busy} onClick={()=>void mutate('/alerts/'+a.id+(a.status==='active'?'/pause':'/activate'),'POST')}>{a.status==='active'?'إيقاف':a.status==='triggered'?'إعادة تفعيل':'تفعيل'}</button><button className="secondary" disabled={busy} onClick={()=>openAlertDialog(a)}>تعديل</button><button className="danger text-button" disabled={busy} onClick={()=>{setFormError('');setConfirm({path:'/alerts/'+a.id,label:'التنبيه'});}}>حذف</button></div></article>)}</div>}</section>;

  if(page==='map')return <NearbyMarkets/>;

  if(page==='account')return <div className="dh-ux-profile">
   <section className="approved-card dh-ux-profile-hero" aria-label="ملخص حسابك">
    <span className="avatar large dh-ux-avatar" aria-hidden="true">{accountName.trim().charAt(0).toUpperCase()||'ذ'}</span>
    <div className="dh-ux-identity"><span className="dh-ux-kicker">حساب ذهبك</span><h2 dir="auto" data-no-translate>{accountName}</h2><p dir="ltr">{email}</p></div>
    <span className="dh-ux-role">{role==='admin'?'مسؤول':role==='trader'?'تاجر':'مستخدم'}</span>
   </section>
   <UserPersonalDetails/>
   <section className="approved-card dh-quick-settings">
 <h3 className="dh-section-label">الأمان والدخول</h3>
 <p className="dh-security-intro">اختر طريقة فتح ذهبك الآمنة على هذا الجهاز.</p>
 <div className="dh-quick-setting-row">
  <span><strong>رمز الدخول السريع</strong><small>شاشة قفل ولوحة أرقام على هذا الجهاز</small></span>
  <button type="button" role="switch" aria-label="تفعيل رمز الدخول السريع" aria-checked={quickPinEnabled}
   className={'dh-quick-toggle '+(quickPinEnabled?'on':'')}
   onClick={()=>void (async()=>{
    setBiometricNotice('');
    if(quickPinEnabled){
     setPinSetup('disable');
    }else setPinSetup('enable');
   })()}><span/></button>
 </div>
 {quickPinEnabled&&pinReconnectRequired&&<div className="dh-quick-reconnect" role="status"><p>رمز الدخول محفوظ على جهازك. بعد تسجيل الدخول بكلمة المرور، أكّد الرمز الحالي مرة واحدة لربطه بالجلسة الجديدة.</p><button type="button" className="primary" onClick={()=>setPinSetup('reconnect')}>تأكيد رمز الدخول المحفوظ</button></div>}
  {quickPinEnabled&&<div className="dh-quick-row-actions">
  <button type="button" className="secondary" onClick={()=>setPinSetup('change')}>تغيير رمز الدخول السريع</button>
  <button type="button" className="secondary" onClick={()=>setPinSetup('recover')}>نسيت الرمز؟ إعادة تعيين بكلمة المرور</button>
 </div>}
 <div className="dh-quick-setting-row">
  <span><strong>خدمة بصمة الوجه/الإصبع</strong><small>{pinReconnectRequired?'أكّد رمز الدخول المحفوظ قبل تفعيل البصمة':biometricAvailable?'تتطلب بصمة الجهاز ومفتاح تشفير قابلًا للاستعادة':'غير مدعومة في هذا المتصفح'}</small></span>
  <button type="button" role="switch" aria-label="خدمة بصمة الوجه والإصبع"
   aria-checked={biometricActive} disabled={!biometricAvailable||pinReconnectRequired}
   className={'dh-quick-toggle '+(biometricActive?'on':'')}
   onClick={()=>void (async()=>{
    setBiometricNotice('');
    try{
     if(biometricActive){await disableBiometric();setBiometricNotice('أُوقفت بصمة الجهاز في ذهبك.');}
     else{await enableBiometric();setBiometricNotice('تم تفعيل بصمة الجهاز مع مفتاح جلسة مشفّر قابل للاستعادة. سيطلب iOS التحقق بالطريقة التي يدعمها المتصفح.');}
    }catch(e){setBiometricNotice(e instanceof Error?e.message:'تعذر تغيير إعداد بصمة الجهاز.');}
   })()}><span/></button>
 </div>
 {biometricNotice&&<p className="notice info" role="status">{biometricNotice}</p>}
 <div className="dh-quick-row-actions">
  {!pinReconnectRequired&&(quickPinEnabled||biometricActive)&&<button type="button" className="primary" onClick={()=>void (async()=>{
   if(!await lockWithBiometric())setBiometricNotice('تعذر قفل التطبيق. تحقق من جلسة الدخول.');
  })()}>قفل ذهبك الآن</button>}
 </div>
 <details className="dh-security-help"><summary>كيف يعمل الدخول السريع؟</summary><p>يمكنك فتح ذهبك برمز من ٦ أرقام. تُحفظ الجلسة مشفّرة وتجزئة الرمز محليًا؛ ولا تُخزّن بيانات بصمتك. يظهر القفل عند إعادة فتح التطبيق بجلسة محفوظة أو بعد العودة من الخلفية بدقيقة. وقد يطلب النظام تحقق Face ID أو Touch ID بحسب دعم المتصفح.</p></details>
 <details className="dh-security-help"><summary>نسيت رمز الدخول؟</summary><p>إذا كنت خارج التطبيق، اختر «الدخول بكلمة المرور» من شاشة القفل. بعد الدخول، افتح الملف الشخصي ← الأمان والدخول ← «نسيت الرمز؟» لإعادة تعيينه بكلمة المرور، دون الرمز السابق. تحتاج إلى تفعيل بصمة الجهاز مجددًا.</p></details>
 </section>
   <section className="dh-ux-group dh-ux-profile-tools" aria-labelledby="dh-profile-tools-title">
    <h3 id="dh-profile-tools-title" className="dh-ux-group-title">الحساب والخدمات</h3>
    <div className="approved-card dh-ux-link-list">
     <button type="button" onClick={()=>navigate('portfolio')}><span className="dh-ux-row-icon"><Icon name="wallet"/></span><span className="dh-ux-row-copy"><strong>محفظتي الذهبية</strong><small>الذهب الذي تتابعه</small></span><Icon name="chevron"/></button>
     <button type="button" onClick={()=>navigate('purchases')}><span className="dh-ux-row-icon"><Icon name="receipt"/></span><span className="dh-ux-row-copy"><strong>سجل المشتريات</strong><small>عمليات الشراء المسجلة</small></span><Icon name="chevron"/></button>
     <button type="button" onClick={()=>navigate('alerts')}><span className="dh-ux-row-icon"><Icon name="bell"/></span><span className="dh-ux-row-copy"><strong>تنبيهات الأسعار</strong><small>الأهداف والتنبيهات المحفوظة</small></span><Icon name="chevron"/></button>
     <button type="button" onClick={()=>navigate('notification-settings')}><span className="dh-ux-row-icon"><Icon name="bell-ring"/></span><span className="dh-ux-row-copy"><strong>إعدادات الإشعارات</strong><small>الأذونات والاشتراكات</small></span><Icon name="chevron"/></button>
     <button type="button" onClick={()=>window.dispatchEvent(new Event('dhahabi:user-check-update'))}><span className="dh-ux-row-icon"><Icon name="refresh"/></span><span className="dh-ux-row-copy"><strong>{tr('التحقق من تحديث التطبيق')}</strong><small>{tr('البحث عن إصدار أحدث')}</small></span><Icon name="chevron"/></button>
    </div>
   </section>
   <button type="button" className="dh-ux-logout" onClick={signOut}><Icon name="logout"/>تسجيل الخروج</button>
   <LegalDocumentLinks language={language}/>
   <footer className="dh-ux-profile-footer"><span className="app-version-account" dir="ltr">{APP_DISPLAY_VERSION}</span><span className="dh-profile-copyright">© 2026 Ibrahim Alneami — All Rights Reserved</span></footer>
  </div>;

  if(page==='help')return <GoldHelp language={language}/>;

  return <div className="dh-ux-more">
   <button type="button" className="approved-card dh-ux-account-link" onClick={()=>navigate('account')} aria-label="فتح الملف الشخصي">
    <span className="avatar dh-ux-avatar" aria-hidden="true">{accountName.trim().charAt(0).toUpperCase()||'ذ'}</span>
    <span className="dh-ux-account-text"><strong dir="auto" data-no-translate>{accountName}</strong><small dir="ltr">{email}</small><span>عرض الملف الشخصي وتعديل بياناتي</span></span>
    <Icon name="chevron"/>
   </button>
   <section className="dh-ux-group" aria-labelledby="dh-more-services-title">
    <h3 className="dh-ux-group-title" id="dh-more-services-title">خدماتي</h3>
    <div className="approved-card dh-ux-link-list">
     <button type="button" onClick={()=>navigate('map')}><span className="dh-ux-row-icon"><Icon name="storefront"/></span><span className="dh-ux-row-copy"><strong>التجار القريبون</strong><small>استكشاف محلات الذهب من موقعك</small></span><Icon name="chevron"/></button>
     <button type="button" onClick={()=>navigate('purchases')}><span className="dh-ux-row-icon"><Icon name="receipt-text"/></span><span className="dh-ux-row-copy"><strong>المشتريات والفواتير</strong><small>مراجعة المشتريات المسجلة</small></span><Icon name="chevron"/></button>
     <button type="button" onClick={()=>navigate('alerts')}><span className="dh-ux-row-icon"><Icon name="bell"/></span><span className="dh-ux-row-copy"><strong>تنبيهات الأسعار</strong><small>متابعة أهداف الأسعار</small></span><Icon name="chevron"/></button>
    </div>
   </section>
   <section className="dh-ux-group" aria-labelledby="dh-more-settings-title">
    <h3 className="dh-ux-group-title" id="dh-more-settings-title">الإعدادات والمساعدة</h3>
    <div className="approved-card dh-ux-link-list">
     <button type="button" onClick={()=>navigate('notification-settings')}><span className="dh-ux-row-icon"><Icon name="bell-ring"/></span><span className="dh-ux-row-copy"><strong>إعدادات الإشعارات</strong><small>السماح بالإشعارات واختبارها</small></span><Icon name="chevron"/></button>
     <button type="button" onClick={()=>navigate('help')}><span className="dh-ux-row-icon"><Icon name="circle-help"/></span><span className="dh-ux-row-copy"><strong>{tr('المساعدة')}</strong><small>{tr('دليل الذهب والعيارات والأحجار والمصنعية')}</small></span><Icon name="chevron"/></button>
    </div>
   </section>
   <section className="approved-card dh-preference-card" aria-labelledby="dh-preferences-title">
    <h3 className="dh-ux-group-title" id="dh-preferences-title">التفضيلات</h3>
    <div className="dh-preference-row dh-preference-item">
     <div className="dh-preference-head">
     <span className="dh-ux-row-icon"><Icon name="globe"/></span>
     <span className="dh-preference-text"><strong>لغة التطبيق</strong><small>لغة الواجهة الحالية</small></span>
     </div>
     <div className="dh-language-options" role="group" aria-label="لغة التطبيق">
      <button type="button" lang="ar" aria-pressed={language==='ar'} className={language==='ar'?'selected':''} onClick={()=>setLanguage('ar')}>العربية</button>
      <button type="button" lang="en" aria-pressed={language==='en'} className={language==='en'?'selected':''} onClick={()=>setLanguage('en')}>English</button>
      <button type="button" lang="fr" aria-pressed={language==='fr'} className={language==='fr'?'selected':''} onClick={()=>setLanguage('fr')}>Français</button>
     </div>
    </div>
    <div className="dh-preference-row dh-preference-item">
     <div className="dh-preference-head">
     <span className="dh-ux-row-icon"><Icon name="coins"/></span>
     <span className="dh-preference-text"><strong>عملة عرض الأسعار</strong><small>{tr('العملة المعتمدة للأسعار والحاسبة')}</small></span>
     </div>
     <span className="dh-currency-options" role="group" aria-label="اختيار عملة عرض الأسعار">
      <button type="button" aria-pressed={priceCurrency==='SAR'} className={priceCurrency==='SAR'?'selected':''} onClick={()=>setPriceCurrency('SAR')}>SAR</button>
      <button type="button" aria-pressed={priceCurrency==='USD'} className={priceCurrency==='USD'?'selected':''} onClick={()=>setPriceCurrency('USD')}>USD</button>
      <button type="button" aria-pressed={priceCurrency==='EUR'} className={priceCurrency==='EUR'?'selected':''} onClick={()=>setPriceCurrency('EUR')}>EUR €</button>
     </span>
    </div>
    <div className="dh-preference-row dh-preference-item">
     <div className="dh-preference-head">
     <span className="dh-ux-row-icon"><Icon name="globe"/></span>
     <span className="dh-preference-text"><strong>{tr('التقويم')}</strong><small>{tr('نوع التاريخ')}</small></span>
     </div>
     <span className="dh-calendar-options" role="group" aria-label={tr('التاريخ الهجري أو الميلادي')}>
      <button type="button" aria-pressed={calendar==='gregorian'} className={calendar==='gregorian'?'selected':''} onClick={()=>setCalendar('gregorian')}>{tr('ميلادي')}</button>
      <button type="button" aria-pressed={calendar==='hijri'} className={calendar==='hijri'?'selected':''} onClick={()=>setCalendar('hijri')}>{tr('هجري')}</button>
     </span>
    </div>
   </section>
   <button type="button" className="dh-ux-logout" onClick={signOut}><Icon name="logout"/>تسجيل الخروج</button>
  </div>;
 };
 return <div className={'gold-web workspace '+(page==='home'?'reference-home':'')} dir={direction} lang={language}><aside className="desktop-nav">{nav}</aside><div className="workspace-main">{page==='home'?<header className="topbar home-topbar">
  <div className="home-identity"><span className="home-brand-emblem" aria-label="ذهبك"><Icon name="gem"/></span><div><p>مرحبًا بعودتك</p><h1 tabIndex={-1} ref={headingRef} title={accountName}><button type="button" className="home-name-link" onClick={()=>navigate('account')} aria-label="فتح الملف الشخصي"><span dir="auto">{accountName}</span><span aria-hidden="true">👋</span></button></h1></div></div>
  <div className="home-head-actions"><button className="icon-button" aria-label="فتح التنبيهات" onClick={()=>navigate('alerts')}><Icon name="bell"/>{alerts.some(a=>a.status==='active')&&<i className="notification-dot"/>}</button><button className="icon-button home-menu-button" aria-label="فتح قائمة التنقل" onClick={()=>setMenu(true)}><Icon name="menu"/></button></div>
 </header>:<header className="topbar"><button className="icon-button menu-trigger" aria-label="العودة للرئيسية" onClick={()=>navigate('home')}><Icon name="chevron"/></button><div><p className="eyebrow"><span className="role-dot"/>ذهبك · حساب المستخدم</p><h1 tabIndex={-1} ref={headingRef}>{pages.find(p=>p.id===page)?.label}</h1></div>{page==='prices'&&<button className="secondary refresh-button" aria-label="تحديث أسعار الذهب من خادم ذهبك" disabled={marketLoading} onClick={()=>void loadMarket()}><Icon name="refresh"/><span>{marketLoading?'جارٍ التحديث…':'تحديث الأسعار'}</span></button>}</header>}<main className="workspace-content" aria-busy={loading}>{error&&<div className="notice error" role="alert">{localizeFeedback(error,language)} <button className="text-button" disabled={loading} onClick={()=>void loadData()}>إعادة المحاولة</button></div>}{(page==='home'||page==='prices')&&marketError&&<p className="notice warning" role="status">{localizeFeedback(marketError,language)}</p>}{message&&<p className="notice success" role="status">{localizeFeedback(message,language)}</p>}{loading&&!loaded&&<p className="notice info" role="status">جارٍ تحميل بيانات حسابك…</p>}{content()}</main><nav className="mobile-bottom-nav" aria-label="التنقل السريع">{mobilePages.map(p=><button key={p.id} className={'mobile-tab '+(p.id===mobilePage?'selected':'')} aria-current={p.id===mobilePage?'page':undefined} onClick={()=>navigate(p.id)}><Icon name={p.icon}/><span>{p.navLabel||p.label}</span></button>)}</nav></div>
 {menu&&<div className="mobile-nav-backdrop" onClick={()=>setMenu(false)}><div className="mobile-nav" ref={modalRef} role="dialog" aria-modal="true" aria-label="قائمة التنقل" onClick={e=>e.stopPropagation()}><button className="icon-button close-menu" aria-label="إغلاق القائمة" onClick={()=>setMenu(false)}><Icon name="close"/></button>{nav}</div></div>}
 {pinSetup&&<QuickPinSetup mode={pinSetup} onClose={()=>setPinSetup(null)}
  onSave={async(pin,currentPin,password)=>{
   if(pinSetup==='disable'){await disableQuickPin(currentPin||'');setBiometricNotice('أُوقف رمز الدخول السريع على هذا الجهاز.');}
   else if(pinSetup==='reconnect'){await reconnectQuickPin(currentPin||'');setBiometricNotice('تم ربط رمز الدخول المحفوظ بالجلسة الجديدة.');}
   else if(pinSetup==='recover'){await recoverQuickPin(password||'',pin);setBiometricNotice('تم تعيين رمز جديد. فعّل بصمة الجهاز مجددًا إن أردت استخدامها.');}
   else{await enableQuickPin(pin,currentPin);setBiometricNotice('تم حفظ رمز الدخول السريع لهذا الجهاز.');}
  }}/>}
 {(dialog||confirm)&&<div className="dialog-backdrop"><div className={'dialog '+(confirm?'confirm-dialog':'')} ref={modalRef} role={confirm?'alertdialog':'dialog'} dir={direction} lang={language} aria-modal="true" aria-labelledby="dialog-title" aria-describedby={confirm?'confirm-warning-description':undefined}><div className="section-heading"><h2 id="dialog-title">{tr(confirm?'تأكيد الحذف':dialog?.type==='portfolio'?(dialog.portfolio?'تعديل اسم المحفظة':'محفظة جديدة'):dialog?.type==='alert'?(dialog.alert?'تعديل التنبيه':'تنبيه جديد'):dialog?.purchase?'تعديل سجل الشراء':'تسجيل شراء')}</h2><button className="icon-button" aria-label={tr('إغلاق')} disabled={busy} onClick={()=>{setDialog(null);setConfirm(null);}}><Icon name="close"/></button></div>
 {confirm?<><div className="confirm-warning" id="confirm-warning-description"><strong>هل تريد حذف {confirm.label}؟</strong><p>هذا الإجراء نهائي، ولا يمكن التراجع عن الحذف من التطبيق.</p></div><div className="actions"><button className="secondary" disabled={busy} onClick={()=>setConfirm(null)}>إلغاء</button><button className="danger-button" disabled={busy} onClick={()=>void mutate(confirm.path,'DELETE')}>{busy?'جارٍ الحذف…':'حذف'}</button></div></>:<form onSubmit={submit}>
 {dialog?.type==='portfolio'&&<label>اسم المحفظة<input key={dialog.portfolio?.id||'new'} name="name" required maxLength={100} defaultValue={dialog.portfolio?.name||''} placeholder="مثال: ادخار الأسرة" autoComplete="off"/></label>}
 {dialog?.type==='purchase'&&<PurchaseFormFields key={dialog.purchase?.id||'new'} purchase={dialog.purchase} portfolios={portfolios} preferredCurrency={priceCurrency}/>}
 {dialog?.type==='alert'&&<><div className="form-grid"><label>العيار<KaratSelect value={dialog.alert?.karat||24}/></label><label>العملة<CurrencySelect value={dialog.alert?.currency||(priceCurrency==='EUR'?'USD':priceCurrency)}/></label></div><label>السعر المستهدف<input name="targetPrice" type="number" inputMode="decimal" min="0.0001" max="99999999" step="0.0001" required defaultValue={dialog.alert?.targetPrice||''}/></label><label>الشرط<select name="direction" defaultValue={dialog.alert?.direction||'above'}><option value="above">يرتفع إلى الهدف أو أكثر</option><option value="below">ينخفض إلى الهدف أو أقل</option></select></label>{dialog.alert&&<p className="fine alert-edit-guidance" role="note">{dialog.alert.status==='active'?'سيُطبّق الشرط الجديد عند الفحص القادم. إذا كان السعر يحقق الشرط الآن، فقد يصلك إشعار.':dialog.alert.status==='paused'?'سيبقى التنبيه متوقفًا بعد حفظ التعديل حتى تفعّله بنفسك.':'هذا التنبيه تحقق شرطه سابقًا، وسيظل كذلك بعد التعديل حتى تضغط «إعادة تفعيل».'}</p>}</>}
 {formError&&<p className="notice error" role="alert">{localizeFeedback(formError,language)}</p>}<div className="actions"><button className="primary" disabled={busy}>{tr(busy?'جارٍ الحفظ…':'حفظ')}</button><button type="button" className="secondary" disabled={busy} onClick={()=>setDialog(null)}>{tr('إلغاء')}</button></div></form>}{confirm&&formError&&<p className="notice error" role="alert">{localizeFeedback(formError,language)}</p>}
 </div></div>}</div>;
}
