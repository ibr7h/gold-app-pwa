import "@/global.css";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Stack } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { useCallback, useEffect, useMemo, useState } from "react";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import "react-native-reanimated";
import { Platform, View, Text, ActivityIndicator, StyleSheet } from "react-native";
import "@/lib/_core/nativewind-pressable";
import { ThemeProvider } from "@/lib/theme-provider";
import {
  SafeAreaFrameContext,
  SafeAreaInsetsContext,
  SafeAreaProvider,
  initialWindowMetrics,
} from "react-native-safe-area-context";
import type { EdgeInsets, Metrics, Rect } from "react-native-safe-area-context";
import * as Font from "expo-font";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";

import { trpc, createTRPCClient } from "@/lib/trpc";
import { initManusRuntime, subscribeSafeAreaInsets } from "@/lib/_core/manus-runtime";
import { AuthProvider } from '@/contexts/AuthContext';
import { AppDataProvider } from '@/contexts/AppDataContext';
import { I18nProvider } from '@/i18n/I18nProvider';
import { ApiKeyProvider } from '@/contexts/ApiKeyContext';
import { SettingsProvider } from '@/contexts/SettingsContext';
import { TraderDataProvider } from '@/contexts/TraderDataContext';
import { MessagingProvider } from '@/contexts/MessagingContext';
import { OfflineProvider } from '@/contexts/OfflineContext';

const DEFAULT_WEB_INSETS: EdgeInsets = { top: 0, right: 0, bottom: 0, left: 0 };
const DEFAULT_WEB_FRAME: Rect = { x: 0, y: 0, width: 0, height: 0 };

export const unstable_settings = {
  anchor: "(drawer)",
};

export default function RootLayout() {
  const initialInsets = initialWindowMetrics?.insets ?? DEFAULT_WEB_INSETS;
  const initialFrame = initialWindowMetrics?.frame ?? DEFAULT_WEB_FRAME;

  const [insets, setInsets] = useState<EdgeInsets>(initialInsets);
  const [frame, setFrame] = useState<Rect>(initialFrame);
  const [fontsLoaded, setFontsLoaded] = useState(false);

  useEffect(() => {
    initManusRuntime();
  }, []);

  // Preload fonts to avoid FontFaceObserver timeout
  useEffect(() => {
    async function loadFonts() {
      try {
        // Load MaterialIcons font explicitly
        await Font.loadAsync(MaterialIcons.font);
      } catch (e) {
        // Font loading failed (e.g., web preview timeout) - continue anyway
        // The icons will still work as the font may load lazily
        console.warn('Font preload warning (non-critical):', e);
      } finally {
        setFontsLoaded(true);
      }
    }
    loadFonts();
  }, []);

  const handleSafeAreaUpdate = useCallback((metrics: Metrics) => {
    setInsets(metrics.insets);
    setFrame(metrics.frame);
  }, []);

  useEffect(() => {
    if (Platform.OS !== "web") return;
    const unsubscribe = subscribeSafeAreaInsets(handleSafeAreaUpdate);
    return () => unsubscribe();
  }, [handleSafeAreaUpdate]);

  const [queryClient] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: {
            refetchOnWindowFocus: false,
            retry: 1,
          },
        },
      }),
  );
  const [trpcClient] = useState(() => createTRPCClient());

  const providerInitialMetrics = useMemo(() => {
    const metrics = initialWindowMetrics ?? { insets: initialInsets, frame: initialFrame };
    return {
      ...metrics,
      insets: {
        ...metrics.insets,
        top: Math.max(metrics.insets.top, 16),
        bottom: Math.max(metrics.insets.bottom, 12),
      },
    };
  }, [initialInsets, initialFrame]);

  // Show loading screen while fonts are loading
  if (!fontsLoaded) {
    return (
      <View style={splashStyles.container}>
        <ActivityIndicator size="large" color="#C5A021" />
        <Text style={splashStyles.text}>ذهبي</Text>
      </View>
    );
  }

  const content = (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <I18nProvider>
      <SettingsProvider>
      <ApiKeyProvider>
      <AuthProvider>
        <OfflineProvider>
        <TraderDataProvider>
        <MessagingProvider>
        <AppDataProvider>
          <trpc.Provider client={trpcClient} queryClient={queryClient}>
            <QueryClientProvider client={queryClient}>
              <Stack screenOptions={{ headerShown: false }}>
                <Stack.Screen name="(drawer)" />
                <Stack.Screen name="login" options={{ presentation: "fullScreenModal" }} />
                <Stack.Screen name="register" options={{ presentation: "fullScreenModal" }} />
                <Stack.Screen name="oauth/callback" />
              </Stack>
              <StatusBar style="light" />
            </QueryClientProvider>
          </trpc.Provider>
        </AppDataProvider>
        </MessagingProvider>
        </TraderDataProvider>
        </OfflineProvider>
      </AuthProvider>
      </ApiKeyProvider>
      </SettingsProvider>
      </I18nProvider>
    </GestureHandlerRootView>
  );

  const shouldOverrideSafeArea = Platform.OS === "web";

  if (shouldOverrideSafeArea) {
    return (
      <ThemeProvider>
        <SafeAreaProvider initialMetrics={providerInitialMetrics}>
          <SafeAreaFrameContext.Provider value={frame}>
            <SafeAreaInsetsContext.Provider value={insets}>
              {content}
            </SafeAreaInsetsContext.Provider>
          </SafeAreaFrameContext.Provider>
        </SafeAreaProvider>
      </ThemeProvider>
    );
  }

  return (
    <ThemeProvider>
      <SafeAreaProvider initialMetrics={providerInitialMetrics}>{content}</SafeAreaProvider>
    </ThemeProvider>
  );
}

const splashStyles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#001F3F',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 16,
  },
  text: {
    fontSize: 24,
    fontWeight: '700',
    color: '#C5A021',
  },
});
