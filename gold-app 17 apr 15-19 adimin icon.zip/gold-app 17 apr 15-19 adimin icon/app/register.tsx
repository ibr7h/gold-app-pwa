import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, TouchableOpacity, KeyboardAvoidingView, Platform, StyleSheet, Alert } from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { GoldButton, GoldInput, GoldCard } from '@/components/gold';
import { useAuth } from '@/contexts/AuthContext';
import { useI18n } from '@/i18n';
import { useRouter } from 'expo-router';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';

export default function RegisterScreen() {
  const { t, isRTL, textAlign, direction } = useI18n();
  const router = useRouter();
  const {
    isLoading,
    error,
    clearError,
    registerStep,
    registerEmail,
    registerCode,
    startRegistration,
    verifyRegistration,
    resendRegisterCode,
    cancelRegistration,
  } = useAuth();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [code, setCode] = useState('');
  const [localError, setLocalError] = useState('');
  const [showDemoCode, setShowDemoCode] = useState(false);

  useEffect(() => {
    clearError();
    return () => {
      cancelRegistration();
    };
  }, []);

  // Map auth errors to translated messages
  const getErrorMessage = () => {
    if (localError) return localError;
    if (!error) return '';
    switch (error) {
      case 'email_exists': return t.register.errorEmailExists;
      case 'invalid_code': return t.register.errorInvalidCode;
      case 'registration_expired': return t.register.errorEmailRequired;
      default: return t.error;
    }
  };

  // Step 1: Submit registration form
  const handleSubmitForm = async () => {
    setLocalError('');
    clearError();

    if (!name.trim()) {
      setLocalError(t.register.errorNameRequired);
      return;
    }
    if (!email.trim()) {
      setLocalError(t.register.errorEmailRequired);
      return;
    }
    if (!email.includes('@')) {
      setLocalError(t.register.errorInvalidEmail);
      return;
    }
    if (!password.trim()) {
      setLocalError(t.register.errorPasswordRequired);
      return;
    }
    if (password.length < 6) {
      setLocalError(t.register.errorPasswordTooShort);
      return;
    }
    if (password !== confirmPassword) {
      setLocalError(t.register.errorPasswordMismatch);
      return;
    }

    const success = await startRegistration(name.trim(), email.trim(), password);
    if (success) {
      setShowDemoCode(true);
    }
  };

  // Step 2: Verify code
  const handleVerifyCode = async () => {
    setLocalError('');
    clearError();

    if (!code.trim()) {
      setLocalError(t.register.errorCodeRequired);
      return;
    }
    if (code.trim().length !== 6) {
      setLocalError(t.register.errorInvalidCode);
      return;
    }

    await verifyRegistration(code.trim());
  };

  // Handle resend
  const handleResend = async () => {
    setLocalError('');
    clearError();
    const success = await resendRegisterCode();
    if (success) {
      setShowDemoCode(true);
      Alert.alert(t.register.codeSent);
    }
  };

  // Back to login
  const handleBackToLogin = () => {
    cancelRegistration();
    router.replace('/login');
  };

  // Step indicator
  const steps = [
    { key: 'form', label: t.register.step1, icon: 'person-add' as const },
    { key: 'verify', label: t.register.step2, icon: 'verified-user' as const },
    { key: 'success', label: t.register.step3, icon: 'check-circle' as const },
  ];

  const currentStepIndex = registerStep === 'form' ? 0 : registerStep === 'verify' ? 1 : 2;

  const errorMsg = getErrorMessage();

  return (
    <ScreenContainer edges={['top', 'bottom', 'left', 'right']}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.flex}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
        >
          {/* Header with back button */}
          <View style={[styles.header, { flexDirection: isRTL ? 'row-reverse' : 'row' }]}>
            <TouchableOpacity
              onPress={handleBackToLogin}
              style={styles.backButton}
            >
              <MaterialIcons
                name={isRTL ? 'arrow-forward' : 'arrow-back'}
                size={24}
                color="#F8F9FA"
              />
            </TouchableOpacity>
            <Text style={[styles.headerTitle, { textAlign }]}>
              {t.register.title}
            </Text>
            <View style={styles.backButton} />
          </View>

          {/* Step Indicator */}
          {registerStep !== 'success' && (
            <View style={[styles.stepsContainer, { flexDirection: isRTL ? 'row-reverse' : 'row' }]}>
              {steps.map((step, index) => {
                const isActive = index === currentStepIndex;
                const isCompleted = index < currentStepIndex;
                return (
                  <React.Fragment key={step.key}>
                    {index > 0 && (
                      <View style={[styles.stepLine, isCompleted && styles.stepLineCompleted]} />
                    )}
                    <View style={styles.stepItem}>
                      <View style={[
                        styles.stepCircle,
                        isActive && styles.stepCircleActive,
                        isCompleted && styles.stepCircleCompleted,
                      ]}>
                        {isCompleted ? (
                          <MaterialIcons name="check" size={16} color="#001F3F" />
                        ) : (
                          <MaterialIcons name={step.icon} size={16} color={isActive ? '#001F3F' : '#6C737F'} />
                        )}
                      </View>
                      <Text style={[
                        styles.stepLabel,
                        isActive && styles.stepLabelActive,
                        isCompleted && styles.stepLabelCompleted,
                      ]}>
                        {step.label}
                      </Text>
                    </View>
                  </React.Fragment>
                );
              })}
            </View>
          )}

          {/* Step Content */}
          <View style={styles.cardContainer}>
            <GoldCard>
              {/* Step 1: Registration Form */}
              {registerStep === 'form' && (
                <View style={styles.stepContent}>
                  <MaterialIcons name="person-add" size={48} color="#C5A021" style={styles.stepIcon} />
                  <Text style={[styles.subtitle, { textAlign }]}>
                    {t.register.subtitle}
                  </Text>

                  <GoldInput
                    label={t.register.fullName}
                    placeholder={t.register.fullNamePlaceholder}
                    value={name}
                    onChangeText={(val) => { setName(val); setLocalError(''); clearError(); }}
                    autoCapitalize="words"
                    returnKeyType="next"
                  />

                  <GoldInput
                    label={t.register.email}
                    placeholder={t.register.emailPlaceholder}
                    value={email}
                    onChangeText={(val) => { setEmail(val); setLocalError(''); clearError(); }}
                    keyboardType="email-address"
                    autoCapitalize="none"
                    returnKeyType="next"
                  />

                  <GoldInput
                    label={t.register.password}
                    placeholder={t.register.passwordPlaceholder}
                    value={password}
                    onChangeText={(val) => { setPassword(val); setLocalError(''); clearError(); }}
                    secureTextEntry
                    returnKeyType="next"
                  />

                  <GoldInput
                    label={t.register.confirmPassword}
                    placeholder={t.register.confirmPasswordPlaceholder}
                    value={confirmPassword}
                    onChangeText={(val) => { setConfirmPassword(val); setLocalError(''); clearError(); }}
                    secureTextEntry
                    returnKeyType="done"
                    onSubmitEditing={handleSubmitForm}
                  />

                  {!!errorMsg && (
                    <Text style={styles.errorText}>{errorMsg}</Text>
                  )}

                  <GoldButton
                    title={isLoading ? t.register.creating : t.register.createAccount}
                    onPress={handleSubmitForm}
                    loading={isLoading}
                    disabled={isLoading}
                  />

                  {/* Already have account link */}
                  <View style={[styles.linkRow, { flexDirection: isRTL ? 'row-reverse' : 'row' }]}>
                    <Text style={styles.linkLabel}>{t.register.alreadyHaveAccount}</Text>
                    <TouchableOpacity onPress={handleBackToLogin}>
                      <Text style={styles.linkText}>{t.register.signIn}</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              )}

              {/* Step 2: Verification Code */}
              {registerStep === 'verify' && (
                <View style={styles.stepContent}>
                  <MaterialIcons name="verified-user" size={48} color="#C5A021" style={styles.stepIcon} />
                  <Text style={[styles.subtitle, { textAlign }]}>
                    {t.register.codeHint}
                  </Text>
                  <Text style={[styles.emailHint, { textAlign }]}>
                    {registerEmail}
                  </Text>

                  <GoldInput
                    label={t.register.verificationCode}
                    placeholder={t.register.codePlaceholder}
                    value={code}
                    onChangeText={(val) => { setCode(val); setLocalError(''); clearError(); }}
                    keyboardType="number-pad"
                    maxLength={6}
                    returnKeyType="done"
                    onSubmitEditing={handleVerifyCode}
                  />

                  {/* Demo: show the code */}
                  {showDemoCode && !!registerCode && (
                    <View style={styles.demoCodeBox}>
                      <Text style={[styles.demoCodeLabel, { textAlign }]}>
                        {'Demo Code:'}
                      </Text>
                      <Text style={styles.demoCodeValue}>{registerCode}</Text>
                    </View>
                  )}

                  {!!errorMsg && (
                    <Text style={styles.errorText}>{errorMsg}</Text>
                  )}

                  <GoldButton
                    title={isLoading ? t.register.verifying : t.register.verifyCode}
                    onPress={handleVerifyCode}
                    loading={isLoading}
                    disabled={isLoading}
                  />

                  <TouchableOpacity onPress={handleResend} disabled={isLoading}>
                    <Text style={styles.resendText}>{t.register.resendCode}</Text>
                  </TouchableOpacity>
                </View>
              )}

              {/* Step 3: Success */}
              {registerStep === 'success' && (
                <View style={styles.stepContent}>
                  <View style={styles.successIcon}>
                    <MaterialIcons name="check-circle" size={64} color="#22C55E" />
                  </View>
                  <Text style={[styles.successTitle, { textAlign }]}>
                    {t.register.success}
                  </Text>
                  <Text style={[styles.successSubtitle, { textAlign }]}>
                    {t.register.successSubtitle}
                  </Text>

                  <GoldButton
                    title={t.register.backToLogin}
                    onPress={handleBackToLogin}
                  />
                </View>
              )}
            </GoldCard>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  flex: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    paddingHorizontal: 20,
    paddingBottom: 40,
  },
  header: {
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 16,
    marginBottom: 8,
  },
  backButton: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#F8F9FA',
    flex: 1,
    textAlign: 'center',
  },
  stepsContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 24,
    paddingHorizontal: 16,
  },
  stepItem: {
    alignItems: 'center',
    gap: 6,
  },
  stepCircle: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#1A2A40',
    borderWidth: 2,
    borderColor: '#6C737F',
    alignItems: 'center',
    justifyContent: 'center',
  },
  stepCircleActive: {
    backgroundColor: '#C5A021',
    borderColor: '#C5A021',
  },
  stepCircleCompleted: {
    backgroundColor: '#C5A021',
    borderColor: '#C5A021',
  },
  stepLine: {
    flex: 1,
    height: 2,
    backgroundColor: '#6C737F',
    marginHorizontal: 4,
    marginBottom: 20,
  },
  stepLineCompleted: {
    backgroundColor: '#C5A021',
  },
  stepLabel: {
    fontSize: 11,
    color: '#6C737F',
    fontWeight: '500',
  },
  stepLabelActive: {
    color: '#C5A021',
    fontWeight: '700',
  },
  stepLabelCompleted: {
    color: '#C5A021',
  },
  cardContainer: {
    flex: 1,
    justifyContent: 'center',
  },
  stepContent: {
    gap: 16,
  },
  stepIcon: {
    alignSelf: 'center',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 14,
    color: '#6C737F',
    lineHeight: 22,
    marginBottom: 8,
  },
  emailHint: {
    fontSize: 15,
    fontWeight: '600',
    color: '#C5A021',
    marginBottom: 4,
  },
  errorText: {
    fontSize: 13,
    color: '#EF4444',
    textAlign: 'center',
    marginTop: -8,
  },
  demoCodeBox: {
    backgroundColor: 'rgba(197, 160, 33, 0.15)',
    borderRadius: 10,
    padding: 14,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(197, 160, 33, 0.4)',
  },
  demoCodeLabel: {
    fontSize: 12,
    color: '#C5A021',
    marginBottom: 4,
  },
  demoCodeValue: {
    fontSize: 28,
    fontWeight: '800',
    color: '#C5A021',
    letterSpacing: 8,
  },
  resendText: {
    fontSize: 14,
    color: '#C5A021',
    textAlign: 'center',
    fontWeight: '600',
    marginTop: 4,
  },
  linkRow: {
    justifyContent: 'center',
    alignItems: 'center',
    gap: 6,
    marginTop: 8,
  },
  linkLabel: {
    fontSize: 14,
    color: '#6C737F',
  },
  linkText: {
    fontSize: 14,
    fontWeight: '700',
    color: '#C5A021',
  },
  successIcon: {
    alignSelf: 'center',
    marginBottom: 8,
  },
  successTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: '#1A1A1B',
    marginBottom: 4,
  },
  successSubtitle: {
    fontSize: 14,
    color: '#6C737F',
    lineHeight: 22,
    marginBottom: 16,
  },
});
