import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, KeyboardAvoidingView, Platform, TextInput } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { GoldButton } from '@/components/gold/GoldButton';
import { useI18n } from '@/i18n';
import { useTraderData } from '@/contexts/TraderDataContext';

interface NewClientScreenProps {
  onOpenDrawer: () => void;
  onNavigate?: (screen: string) => void;
}

export default function NewClientScreen({ onOpenDrawer, onNavigate }: NewClientScreenProps) {
  const { isRTL, textAlign, direction, flexDir, lang } = useI18n();
  const { addClient } = useTraderData();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  // Translations
  const titleLabel = lang === 'ar' ? 'عميل جديد' : lang === 'fr' ? 'Nouveau client' : 'New Client';
  const nameLabel = lang === 'ar' ? 'الاسم الكامل' : lang === 'fr' ? 'Nom complet' : 'Full Name';
  const emailLabel = lang === 'ar' ? 'البريد الإلكتروني' : lang === 'fr' ? 'Email' : 'Email';
  const phoneLabel = lang === 'ar' ? 'رقم الهاتف' : lang === 'fr' ? 'Téléphone' : 'Phone Number';
  const submitLabel = lang === 'ar' ? 'إضافة العميل' : lang === 'fr' ? 'Ajouter le client' : 'Add Client';
  const successMsg = lang === 'ar' ? 'تم إضافة العميل بنجاح!' : lang === 'fr' ? 'Client ajouté avec succès !' : 'Client added successfully!';
  const requiredField = lang === 'ar' ? 'هذا الحقل مطلوب' : lang === 'fr' ? 'Champ requis' : 'Required field';
  const invalidEmail = lang === 'ar' ? 'بريد إلكتروني غير صالح' : lang === 'fr' ? 'Email invalide' : 'Invalid email';

  const validate = (): boolean => {
    const newErrors: Record<string, string> = {};
    if (!name.trim()) newErrors.name = requiredField;
    if (!email.trim()) {
      newErrors.email = requiredField;
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      newErrors.email = invalidEmail;
    }
    if (!phone.trim()) newErrors.phone = requiredField;
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async () => {
    if (!validate()) return;
    setIsSubmitting(true);

    await addClient({
      name: name.trim(),
      email: email.trim(),
      phone: phone.trim(),
      status: 'active',
    });

    setIsSubmitting(false);
    setShowSuccess(true);
  };

  if (showSuccess) {
    return (
      <View style={styles.screen}>
        <SafeAreaView style={styles.safeArea} edges={['top']}>
          <View style={styles.successContainer}>
            <View style={styles.successIcon}>
              <MaterialIcons name="person-add" size={64} color="#22C55E" />
            </View>
            <Text style={styles.successText}>{successMsg}</Text>
            <Text style={styles.successName}>{name}</Text>
            <View style={styles.successActions}>
              <TouchableOpacity
                style={styles.successBtn}
                onPress={() => {
                  setShowSuccess(false);
                  setName('');
                  setEmail('');
                  setPhone('');
                }}
                activeOpacity={0.7}
              >
                <MaterialIcons name="person-add" size={20} color="#C5A021" />
                <Text style={styles.successBtnText}>
                  {lang === 'ar' ? 'عميل آخر' : lang === 'fr' ? 'Autre client' : 'Another Client'}
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.successBtn}
                onPress={() => onNavigate?.('trader-clients')}
                activeOpacity={0.7}
              >
                <MaterialIcons name="people" size={20} color="#C5A021" />
                <Text style={styles.successBtnText}>
                  {lang === 'ar' ? 'عرض العملاء' : lang === 'fr' ? 'Voir clients' : 'View Clients'}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </SafeAreaView>
      </View>
    );
  }

  return (
    <View style={styles.screen}>
      <SafeAreaView style={styles.safeArea} edges={['top']}>
        {/* App Bar */}
        <View style={styles.appBar}>
          <View style={{ width: 40 }} />
          <Text style={[styles.appBarTitle, { writingDirection: direction }]}>{titleLabel}</Text>
          <TouchableOpacity onPress={() => onNavigate?.('trader-clients')} style={styles.menuBtn} activeOpacity={0.7}>
            <MaterialIcons name="arrow-forward" size={24} color="#F8F9FA" />
          </TouchableOpacity>
        </View>

        <KeyboardAvoidingView
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          style={{ flex: 1 }}
        >
          <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
            {/* Avatar Preview */}
            <View style={styles.avatarPreview}>
              <View style={styles.avatarCircle}>
                <Text style={styles.avatarText}>{name.charAt(0) || '?'}</Text>
              </View>
            </View>

            {/* Name */}
            <Text style={[styles.label, { textAlign, writingDirection: direction }]}>{nameLabel}</Text>
            <View style={styles.inputContainer}>
              <TextInput
                style={[styles.input, { textAlign: isRTL ? 'right' : 'left', writingDirection: direction }]}
                value={name}
                onChangeText={setName}
                placeholder={lang === 'ar' ? 'أدخل الاسم الكامل' : lang === 'fr' ? 'Entrez le nom complet' : 'Enter full name'}
                placeholderTextColor="#6C737F"
                autoCapitalize="words"
              />
            </View>
            {errors.name && <Text style={styles.errorText}>{errors.name}</Text>}

            {/* Email */}
            <Text style={[styles.label, { textAlign, writingDirection: direction }]}>{emailLabel}</Text>
            <View style={styles.inputContainer}>
              <TextInput
                style={[styles.input, { textAlign: isRTL ? 'right' : 'left' }]}
                value={email}
                onChangeText={setEmail}
                placeholder="email@example.com"
                placeholderTextColor="#6C737F"
                keyboardType="email-address"
                autoCapitalize="none"
              />
            </View>
            {errors.email && <Text style={styles.errorText}>{errors.email}</Text>}

            {/* Phone */}
            <Text style={[styles.label, { textAlign, writingDirection: direction }]}>{phoneLabel}</Text>
            <View style={styles.inputContainer}>
              <TextInput
                style={[styles.input, { textAlign: isRTL ? 'right' : 'left' }]}
                value={phone}
                onChangeText={setPhone}
                placeholder="+966 5XX XXX XXXX"
                placeholderTextColor="#6C737F"
                keyboardType="phone-pad"
              />
            </View>
            {errors.phone && <Text style={styles.errorText}>{errors.phone}</Text>}

            {/* Submit */}
            <View style={styles.submitContainer}>
              <GoldButton
                title={submitLabel}
                onPress={handleSubmit}
                loading={isSubmitting}
              />
            </View>

            <View style={{ height: 40 }} />
          </ScrollView>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#001F3F' },
  safeArea: { flex: 1 },
  appBar: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 12,
    borderBottomWidth: 1, borderBottomColor: 'rgba(248,249,250,0.08)',
  },
  appBarTitle: { fontSize: 18, fontWeight: '700', color: '#F8F9FA' },
  menuBtn: { padding: 8 },
  scrollContent: { paddingHorizontal: 16, paddingTop: 16 },

  // Avatar
  avatarPreview: { alignItems: 'center', marginBottom: 8 },
  avatarCircle: {
    width: 72, height: 72, borderRadius: 36,
    backgroundColor: 'rgba(197,160,33,0.2)',
    alignItems: 'center', justifyContent: 'center',
    borderWidth: 2, borderColor: '#C5A021',
  },
  avatarText: { fontSize: 28, fontWeight: '700', color: '#C5A021' },

  // Labels
  label: { fontSize: 14, fontWeight: '600', color: '#F8F9FA', marginBottom: 8, marginTop: 16 },

  // Input
  inputContainer: { position: 'relative' },
  input: {
    backgroundColor: 'rgba(248,249,250,0.06)',
    borderWidth: 1, borderColor: 'rgba(248,249,250,0.1)',
    borderRadius: 12, paddingHorizontal: 16, paddingVertical: 14,
    fontSize: 16, color: '#F8F9FA', fontWeight: '500',
  },

  // Error
  errorText: { fontSize: 12, color: '#EF4444', marginTop: 4 },

  // Submit
  submitContainer: { marginTop: 32 },

  // Success
  successContainer: {
    flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 32,
  },
  successIcon: { marginBottom: 16 },
  successText: { fontSize: 20, fontWeight: '700', color: '#F8F9FA', marginBottom: 8 },
  successName: { fontSize: 24, fontWeight: '800', color: '#C5A021', marginBottom: 32 },
  successActions: { flexDirection: 'row', gap: 16 },
  successBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    backgroundColor: 'rgba(197,160,33,0.15)',
    paddingHorizontal: 20, paddingVertical: 12, borderRadius: 12,
    borderWidth: 1, borderColor: '#C5A021',
  },
  successBtnText: { fontSize: 14, fontWeight: '600', color: '#C5A021' },
});
