import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Dimensions, FlatList, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { useAuth } from '@/contexts/AuthContext';
import { useAppData } from '@/contexts/AppDataContext';
import { GoldCard } from '@/components/gold/GoldCard';
import { PriceTag } from '@/components/gold/PriceTag';
import { SimpleChart } from '@/components/gold/SimpleChart';
import { chartData, topMovers, offers } from '@/data/mock';
import { useI18n } from '@/i18n';
import { useGoldPrice } from '@/hooks/useGoldPrice';
import { useSettings } from '@/contexts/SettingsContext';

const SCREEN_WIDTH = Dimensions.get('window').width;

interface HomeScreenProps {
  onOpenDrawer: () => void;
  onNavigate?: (screen: string, params?: any) => void;
}

export default function HomeScreen({ onOpenDrawer, onNavigate }: HomeScreenProps) {
  const { user } = useAuth();
  const { portfolios } = useAppData();
  const { t, isRTL, textAlign, direction, flexDir } = useI18n();
  const { settings } = useSettings();
  const { data: goldData, loading: priceLoading, isLive, refresh, lastUpdated } = useGoldPrice();
  const [chartTab, setChartTab] = useState('day');
  const isAdmin = user?.role === 'admin';

  const totalPortfolioValue = portfolios.reduce((sum, p) => sum + p.totalValue, 0);
  const totalProfitLoss = portfolios.reduce((sum, p) => sum + p.profitLoss, 0);

  const currentChartData = chartData[chartTab as keyof typeof chartData] || chartData.day;

  const services = [
    { key: 'buy', label: t.home.buy, icon: 'add-shopping-cart', color: '#22C55E' },
    { key: 'sell', label: t.home.sell, icon: 'sell', color: '#EF4444' },
    { key: 'transfer', label: t.home.transfer, icon: 'swap-horiz', color: '#3B82F6' },
    { key: 'save', label: t.home.save, icon: 'savings', color: '#C5A021' },
  ];

  const chartTabs = [
    { key: 'day', label: t.home.day },
    { key: 'week', label: t.home.week },
    { key: 'month', label: t.home.month },
    { key: 'year', label: t.home.year },
  ];

  const formatTime = (ts: number | null) => {
    if (!ts) return '--';
    const d = new Date(ts);
    return d.toLocaleTimeString(isRTL ? 'ar' : 'en', { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <View style={styles.screen}>
      <SafeAreaView style={styles.safeArea} edges={['top']}>
        {/* App Bar */}
        <View style={styles.appBar}>
          <TouchableOpacity onPress={() => onNavigate?.('search')} style={styles.menuBtn} activeOpacity={0.7}>
            <MaterialIcons name="search" size={24} color="#F8F9FA" />
          </TouchableOpacity>
          <Text style={[styles.appBarTitle, { writingDirection: direction }]}>{t.nav.home}</Text>
          <TouchableOpacity onPress={onOpenDrawer} style={styles.menuBtn} activeOpacity={0.7}>
            <MaterialIcons name="menu" size={24} color="#F8F9FA" />
          </TouchableOpacity>
        </View>

        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
          {/* Welcome Card */}
          <GoldCard style={styles.welcomeCard}>
            <View style={[styles.welcomeRow, { flexDirection: flexDir }]}>
              <View style={[styles.welcomeInfo, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
                <Text style={[styles.welcomeLabel, { writingDirection: direction }]}>{t.home.welcome}</Text>
                <Text style={[styles.welcomeEmail, { writingDirection: direction }]} numberOfLines={1}>{user?.email}</Text>
                <View style={styles.roleBadge}>
                  <Text style={[styles.roleText, { writingDirection: direction }]}>{isAdmin ? t.home.roleAdmin : user?.role === 'trader' ? t.home.roleTrader : t.home.roleUser}</Text>
                </View>
              </View>
              <View style={[styles.welcomeAvatar, isRTL ? { marginLeft: 14 } : { marginRight: 14 }]}>
                <Text style={styles.welcomeAvatarText}>
                  {user?.email?.charAt(0).toUpperCase() || 'U'}
                </Text>
              </View>
            </View>
          </GoldCard>

          {/* Gold Price Now Card - LIVE */}
          <GoldCard style={styles.priceNowCard}>
            <View style={[styles.priceNowHeader, { flexDirection: flexDir }]}>
              <View style={[styles.liveBadge, { flexDirection: flexDir }]}>
                <View style={[styles.liveDot, { backgroundColor: isLive ? '#22C55E' : '#F59E0B' }, isRTL ? { marginLeft: 6 } : { marginRight: 6 }]} />
                <Text style={[styles.liveText, { color: isLive ? '#22C55E' : '#F59E0B' }]}>
                  {isLive ? t.prices.live : 'Offline'}
                </Text>
              </View>
              <View style={[styles.priceNowTitleRow, { flexDirection: flexDir }]}>
                <TouchableOpacity onPress={refresh} activeOpacity={0.7} style={styles.refreshBtn}>
                  {priceLoading ? (
                    <ActivityIndicator size="small" color="#C5A021" />
                  ) : (
                    <MaterialIcons name="refresh" size={20} color="#C5A021" />
                  )}
                </TouchableOpacity>
                <Text style={[styles.priceNowTitle, { writingDirection: direction }]}>{t.home.goldPriceNow}</Text>
              </View>
            </View>
            {goldData ? (
              <View style={[styles.priceNowBody, { flexDirection: flexDir }]}>
                <View style={styles.priceNowChange}>
                  <PriceTag
                    value={goldData.pricePerGram24K}
                    change={goldData.change}
                    changePercent={goldData.changePercent}
                    size="large"
                  />
                  <Text style={styles.priceUpdateTime}>{formatTime(lastUpdated)}</Text>
                </View>
                <View style={[styles.priceNowKarat, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
                  <Text style={styles.karatBig}>24K</Text>
                  <Text style={[styles.karatLabel, { writingDirection: direction }]}>{t.home.karat24} - {goldData.currency}</Text>
                </View>
              </View>
            ) : priceLoading ? (
              <View style={styles.priceLoadingContainer}>
                <ActivityIndicator size="large" color="#C5A021" />
              </View>
            ) : null}
          </GoldCard>

          {/* Quick Services Grid */}
          <Text style={[styles.sectionTitle, { textAlign, writingDirection: direction }]}>{t.home.quickServices}</Text>
          <View style={[styles.servicesGrid, { flexDirection: flexDir }]}>
            {services.map(service => (
              <TouchableOpacity key={service.key} style={styles.serviceItem} activeOpacity={0.7}>
                <View style={[styles.serviceIcon, { backgroundColor: service.color + '18' }]}>
                  <MaterialIcons name={service.icon as any} size={24} color={service.color} />
                </View>
                <Text style={[styles.serviceLabel, { writingDirection: direction }]}>{service.label}</Text>
              </TouchableOpacity>
            ))}
          </View>

          {/* Portfolio Summary */}
          <GoldCard title={t.home.portfolioSummary}>
            <View style={[styles.portfolioSummary, { flexDirection: flexDir }]}>
              <View style={styles.portfolioItem}>
                <Text style={[styles.portfolioValue, { color: totalProfitLoss >= 0 ? '#22C55E' : '#EF4444' }]}>
                  {totalProfitLoss >= 0 ? '+' : ''}{totalProfitLoss.toFixed(2)} {settings.preferredCurrency}
                </Text>
                <Text style={[styles.portfolioLabel, { writingDirection: direction }]}>{t.home.profitLoss}</Text>
              </View>
              <View style={styles.portfolioDivider} />
              <View style={styles.portfolioItem}>
                <Text style={styles.portfolioValue}>{totalPortfolioValue.toFixed(2)} {settings.preferredCurrency}</Text>
                <Text style={[styles.portfolioLabel, { writingDirection: direction }]}>{t.home.totalValue}</Text>
              </View>
            </View>
          </GoldCard>

          {/* Market Movement Chart */}
          <GoldCard title={t.home.marketMovement}>
            <View style={[styles.chartTabs, { flexDirection: flexDir }]}>
              {chartTabs.map(tab => (
                <TouchableOpacity
                  key={tab.key}
                  onPress={() => setChartTab(tab.key)}
                  style={[styles.chartTab, chartTab === tab.key && styles.chartTabActive]}
                  activeOpacity={0.7}
                >
                  <Text style={[styles.chartTabText, chartTab === tab.key && styles.chartTabTextActive]}>
                    {tab.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
            <SimpleChart data={currentChartData} width={SCREEN_WIDTH - 64} height={180} />
          </GoldCard>

          {/* Top Movers */}
          <GoldCard title={t.home.topMovers}>
            {topMovers.map((item, index) => (
              <View key={index} style={[styles.moverRow, { flexDirection: flexDir }, index < topMovers.length - 1 && styles.moverBorder]}>
                <View style={styles.moverChange}>
                  <Text style={[styles.moverChangeText, { color: item.change >= 0 ? '#22C55E' : '#EF4444' }]}>
                    {item.change >= 0 ? '▲' : '▼'} {item.changePercent.toFixed(2)}%
                  </Text>
                </View>
                <View style={[styles.moverInfo, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
                  <Text style={styles.moverPrice}>{item.price.toFixed(2)} {settings.preferredCurrency}</Text>
                  <Text style={[styles.moverKarat, { writingDirection: direction }]}>{item.karat}</Text>
                </View>
              </View>
            ))}
          </GoldCard>

          {/* Featured Offers Carousel */}
          <Text style={[styles.sectionTitle, { textAlign, writingDirection: direction }]}>{t.home.featuredOffers}</Text>
          <FlatList
            data={offers}
            horizontal
            inverted={isRTL}
            showsHorizontalScrollIndicator={false}
            keyExtractor={item => item.id}
            contentContainerStyle={styles.offersContainer}
            renderItem={({ item }) => (
              <View style={styles.offerCard}>
                <View style={[styles.offerBadge, { alignSelf: isRTL ? 'flex-end' : 'flex-start' }]}>
                  <Text style={styles.offerBadgeText}>{item.discount}</Text>
                </View>
                <Text style={[styles.offerTitle, { textAlign, writingDirection: direction }]}>{item.title}</Text>
                <Text style={[styles.offerDesc, { textAlign, writingDirection: direction }]}>{item.description}</Text>
                <Text style={[styles.offerValid, { textAlign, writingDirection: direction }]}>{item.validUntil}</Text>
              </View>
            )}
          />

          {/* Gold Karat Prices List - LIVE */}
          <GoldCard title={t.home.goldKaratPrices}>
            <View style={[styles.priceTableHeader, { flexDirection: flexDir }]}>
              <Text style={[styles.priceTableHeaderText, { flex: 1 }]}>{t.prices.sell}</Text>
              <Text style={[styles.priceTableHeaderText, { flex: 1 }]}>{t.prices.buy}</Text>
              <Text style={[styles.priceTableHeaderText, { flex: 1 }]}>{t.prices.karat}</Text>
            </View>
            {goldData ? goldData.karatPrices.map((item, index) => (
              <View key={index} style={[styles.priceTableRow, { flexDirection: flexDir }, index < goldData.karatPrices.length - 1 && styles.priceTableBorder]}>
                <Text style={[styles.priceTableCell, { flex: 1 }]}>{((item.pricePerGram ?? 0) * 0.98).toFixed(2)}</Text>
                <Text style={[styles.priceTableCell, { flex: 1, color: '#C5A021' }]}>{(item.pricePerGram ?? 0).toFixed(2)}</Text>
                <Text style={[styles.priceTableCell, { flex: 1, fontWeight: '600' }]}>{item.karat}</Text>
              </View>
            )) : (
              <View style={styles.priceLoadingContainer}>
                <ActivityIndicator size="small" color="#C5A021" />
              </View>
            )}
          </GoldCard>

          <View style={{ height: 32 }} />
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#001F3F' },
  safeArea: { flex: 1 },
  appBar: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 12,
    borderBottomWidth: 1, borderBottomColor: 'rgba(248,249,250,0.08)',
  },
  appBarTitle: { fontSize: 18, fontWeight: '700', color: '#F8F9FA' },
  menuBtn: { padding: 8 },
  scrollContent: { paddingHorizontal: 16, paddingTop: 16 },
  sectionTitle: { fontSize: 17, fontWeight: '700', color: '#F8F9FA', marginBottom: 12, marginTop: 8 },
  // Welcome
  welcomeCard: { marginBottom: 16 },
  welcomeRow: { alignItems: 'center' },
  welcomeAvatar: {
    width: 52, height: 52, borderRadius: 26,
    backgroundColor: '#C5A021', alignItems: 'center', justifyContent: 'center',
  },
  welcomeAvatarText: { fontSize: 22, fontWeight: '700', color: '#001F3F' },
  welcomeInfo: { flex: 1 },
  welcomeLabel: { fontSize: 13, color: '#6C737F' },
  welcomeEmail: { fontSize: 16, fontWeight: '600', color: '#1A1A1B', marginTop: 2 },
  roleBadge: { backgroundColor: 'rgba(197,160,33,0.15)', borderRadius: 6, paddingHorizontal: 10, paddingVertical: 3, marginTop: 6 },
  roleText: { fontSize: 11, fontWeight: '600', color: '#C5A021' },
  // Price Now
  priceNowCard: { marginBottom: 16, borderWidth: 1, borderColor: 'rgba(197,160,33,0.25)' },
  priceNowHeader: { alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 },
  priceNowTitleRow: { alignItems: 'center', gap: 8 },
  priceNowTitle: { fontSize: 16, fontWeight: '700', color: '#C5A021' },
  refreshBtn: { padding: 4 },
  liveBadge: { alignItems: 'center', backgroundColor: 'rgba(34,197,94,0.12)', borderRadius: 8, paddingHorizontal: 10, paddingVertical: 4 },
  liveDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: '#22C55E' },
  liveText: { fontSize: 11, fontWeight: '600', color: '#22C55E' },
  priceNowBody: { alignItems: 'center', justifyContent: 'space-between' },
  priceNowKarat: {},
  karatBig: { fontSize: 32, fontWeight: '800', color: '#C5A021' },
  karatLabel: { fontSize: 12, color: '#6C737F', marginTop: 4 },
  priceNowChange: { alignItems: 'flex-start' },
  priceUpdateTime: { fontSize: 11, color: '#6C737F', marginTop: 4, fontVariant: ['tabular-nums'] },
  priceLoadingContainer: { paddingVertical: 24, alignItems: 'center' },
  // Services
  servicesGrid: { justifyContent: 'space-between', marginBottom: 16 },
  serviceItem: { alignItems: 'center', width: (SCREEN_WIDTH - 64) / 4 },
  serviceIcon: { width: 52, height: 52, borderRadius: 14, alignItems: 'center', justifyContent: 'center', marginBottom: 8 },
  serviceLabel: { fontSize: 13, fontWeight: '500', color: '#F8F9FA' },
  // Portfolio
  portfolioSummary: { alignItems: 'center' },
  portfolioItem: { flex: 1, alignItems: 'center' },
  portfolioLabel: { fontSize: 12, color: '#6C737F', marginTop: 4 },
  portfolioValue: { fontSize: 16, fontWeight: '700', color: '#1A1A1B', fontVariant: ['tabular-nums'] },
  portfolioDivider: { width: 1, height: 40, backgroundColor: '#E6E8EA' },
  // Chart
  chartTabs: { marginBottom: 12, gap: 8 },
  chartTab: { paddingHorizontal: 16, paddingVertical: 6, borderRadius: 8, backgroundColor: 'rgba(0,31,63,0.08)' },
  chartTabActive: { backgroundColor: 'rgba(197,160,33,0.15)' },
  chartTabText: { fontSize: 13, color: '#6C737F', fontWeight: '500' },
  chartTabTextActive: { color: '#C5A021', fontWeight: '700' },
  // Top Movers
  moverRow: { alignItems: 'center', paddingVertical: 12 },
  moverBorder: { borderBottomWidth: 1, borderBottomColor: '#E6E8EA' },
  moverInfo: { flex: 1 },
  moverKarat: { fontSize: 14, fontWeight: '600', color: '#1A1A1B' },
  moverPrice: { fontSize: 13, color: '#6C737F', marginTop: 2, fontVariant: ['tabular-nums'] },
  moverChange: { alignItems: 'flex-start' },
  moverChangeText: { fontSize: 13, fontWeight: '600', fontVariant: ['tabular-nums'] },
  // Offers
  offersContainer: { paddingBottom: 16 },
  offerCard: {
    width: 220, backgroundColor: '#001F3F', borderRadius: 12, padding: 16,
    marginLeft: 12, borderWidth: 1, borderColor: 'rgba(197,160,33,0.2)',
  },
  offerBadge: { backgroundColor: 'rgba(197,160,33,0.2)', borderRadius: 6, paddingHorizontal: 10, paddingVertical: 4, marginBottom: 10 },
  offerBadgeText: { fontSize: 14, fontWeight: '700', color: '#C5A021' },
  offerTitle: { fontSize: 15, fontWeight: '600', color: '#F8F9FA', marginBottom: 6 },
  offerDesc: { fontSize: 13, color: '#F8F9FA', opacity: 0.7, marginBottom: 8 },
  offerValid: { fontSize: 11, color: '#6C737F' },
  // Price Table
  priceTableHeader: { paddingBottom: 10, borderBottomWidth: 1, borderBottomColor: '#E6E8EA' },
  priceTableHeaderText: { fontSize: 12, fontWeight: '600', color: '#6C737F', textAlign: 'center' },
  priceTableRow: { paddingVertical: 12 },
  priceTableBorder: { borderBottomWidth: 1, borderBottomColor: '#E6E8EA' },
  priceTableCell: { fontSize: 14, color: '#1A1A1B', textAlign: 'center', fontVariant: ['tabular-nums'] },
});
