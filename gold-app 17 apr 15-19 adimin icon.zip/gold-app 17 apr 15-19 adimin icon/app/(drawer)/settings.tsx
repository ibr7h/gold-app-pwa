import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { GoldCard } from '@/components/gold/GoldCard';
import { GoldButton } from '@/components/gold/GoldButton';
import { useI18n } from '@/i18n';
import { useSettings } from '@/contexts/SettingsContext';
import { SUPPORTED_CURRENCIES, KARAT_OPTIONS } from '@/services/GoldApiService';
import { notificationService, type NotificationSettings } from '@/services/NotificationService';

interface SettingsScreenProps {
  onOpenDrawer: () => void;
}

export default function SettingsScreen({ onOpenDrawer }: SettingsScreenProps) {
  const { t, isRTL, textAlign, direction, flexDir, lang } = useI18n();
  const { settings, updateSettings, resetSettings } = useSettings();
  const [showCurrencyPicker, setShowCurrencyPicker] = useState(false);
  const [showKaratPicker, setShowKaratPicker] = useState(false);
  const [notifSettings, setNotifSettings] = useState<NotificationSettings>(notificationService.getSettings());

  React.useEffect(() => {
    notificationService.loadSettings().then(s => setNotifSettings(s));
  }, []);

  const toggleNotifSetting = async (key: keyof NotificationSettings) => {
    const updated = { ...notifSettings, [key]: !notifSettings[key] };
    setNotifSettings(updated);
    await notificationService.saveSettings({ [key]: !notifSettings[key] });
  };

  const frequencyOptions = [
    { value: 0, label: lang === 'ar' ? 'معطل' : lang === 'fr' ? 'Désactivé' : 'Disabled' },
    { value: 15, label: lang === 'ar' ? '15 دقيقة' : lang === 'fr' ? '15 minutes' : '15 minutes' },
    { value: 30, label: lang === 'ar' ? '30 دقيقة' : lang === 'fr' ? '30 minutes' : '30 minutes' },
    { value: 60, label: lang === 'ar' ? 'ساعة' : lang === 'fr' ? '1 heure' : '1 hour' },
    { value: 120, label: lang === 'ar' ? 'ساعتان' : lang === 'fr' ? '2 heures' : '2 hours' },
    { value: 360, label: lang === 'ar' ? '6 ساعات' : lang === 'fr' ? '6 heures' : '6 hours' },
  ];

  const refreshOptions = [
    { value: 0, label: lang === 'ar' ? 'يدوي فقط' : lang === 'fr' ? 'Manuel uniquement' : 'Manual only' },
    { value: 60, label: lang === 'ar' ? 'كل دقيقة' : lang === 'fr' ? 'Chaque minute' : 'Every minute' },
    { value: 120, label: lang === 'ar' ? 'كل دقيقتين' : lang === 'fr' ? 'Toutes les 2 min' : 'Every 2 min' },
    { value: 300, label: lang === 'ar' ? 'كل 5 دقائق' : lang === 'fr' ? 'Toutes les 5 min' : 'Every 5 min' },
    { value: 600, label: lang === 'ar' ? 'كل 10 دقائق' : lang === 'fr' ? 'Toutes les 10 min' : 'Every 10 min' },
  ];

  const getCurrencyLabel = (code: string) => {
    const c = SUPPORTED_CURRENCIES.find(x => x.code === code);
    if (!c) return code;
    const name = lang === 'ar' ? c.nameAr : lang === 'fr' ? c.nameFr : c.nameEn;
    return `${c.symbol} ${name} (${c.code})`;
  };

  const settingsTitle = lang === 'ar' ? 'الإعدادات' : lang === 'fr' ? 'Paramètres' : 'Settings';
  const currencyTitle = lang === 'ar' ? 'العملة المفضلة' : lang === 'fr' ? 'Devise préférée' : 'Preferred Currency';
  const karatTitle = lang === 'ar' ? 'العيار الافتراضي' : lang === 'fr' ? 'Carat par défaut' : 'Default Karat';
  const notifTitle = lang === 'ar' ? 'تكرار التنبيهات' : lang === 'fr' ? 'Fréquence des alertes' : 'Alert Frequency';
  const refreshTitle = lang === 'ar' ? 'تحديث تلقائي للأسعار' : lang === 'fr' ? 'Actualisation auto des prix' : 'Auto-Refresh Prices';
  const bgCheckTitle = lang === 'ar' ? 'فحص الأسعار في الخلفية' : lang === 'fr' ? 'Vérification en arrière-plan' : 'Background Price Check';
  const bgCheckDesc = lang === 'ar' ? 'فحص الأسعار تلقائياً حتى عند إغلاق التطبيق' : lang === 'fr' ? 'Vérifier les prix même quand l\'app est fermée' : 'Check prices even when app is closed';
  const resetTitle = lang === 'ar' ? 'إعادة تعيين الإعدادات' : lang === 'fr' ? 'Réinitialiser' : 'Reset Settings';
  const selectLabel = lang === 'ar' ? 'اختر' : lang === 'fr' ? 'Choisir' : 'Select';

  return (
    <View style={styles.screen}>
      <SafeAreaView style={styles.safeArea} edges={['top']}>
        <View style={styles.appBar}>
          <View style={{ width: 40 }} />
          <Text style={[styles.appBarTitle, { writingDirection: direction }]}>{settingsTitle}</Text>
          <TouchableOpacity onPress={onOpenDrawer} style={styles.menuBtn} activeOpacity={0.7}>
            <MaterialIcons name="menu" size={24} color="#F8F9FA" />
          </TouchableOpacity>
        </View>

        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
          {/* Currency Setting */}
          <GoldCard>
            <View style={[styles.settingRow, { flexDirection: flexDir }]}>
              <TouchableOpacity
                onPress={() => setShowCurrencyPicker(!showCurrencyPicker)}
                style={[styles.settingValue, { flexDirection: flexDir }]}
                activeOpacity={0.7}
              >
                <MaterialIcons name="chevron-right" size={18} color="#6C737F" style={isRTL ? { transform: [{ scaleX: -1 }] } : {}} />
                <Text style={styles.settingValueText}>{getCurrencyLabel(settings.preferredCurrency)}</Text>
              </TouchableOpacity>
              <View style={[styles.settingLabel, { flexDirection: flexDir }]}>
                <Text style={[styles.settingLabelText, { writingDirection: direction }]}>{currencyTitle}</Text>
                <MaterialIcons name="attach-money" size={20} color="#C5A021" style={isRTL ? { marginLeft: 8 } : { marginRight: 8 }} />
              </View>
            </View>
            {showCurrencyPicker && (
              <View style={styles.pickerContainer}>
                {SUPPORTED_CURRENCIES.map(c => (
                  <TouchableOpacity
                    key={c.code}
                    style={[styles.pickerItem, settings.preferredCurrency === c.code && styles.pickerItemActive, { flexDirection: flexDir }]}
                    onPress={() => { updateSettings({ preferredCurrency: c.code }); setShowCurrencyPicker(false); }}
                    activeOpacity={0.7}
                  >
                    {settings.preferredCurrency === c.code && (
                      <MaterialIcons name="check" size={16} color="#C5A021" />
                    )}
                    <Text style={[styles.pickerItemText, settings.preferredCurrency === c.code && styles.pickerItemTextActive, { writingDirection: direction }]}>
                      {getCurrencyLabel(c.code)}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            )}
          </GoldCard>

          {/* Karat Setting */}
          <GoldCard>
            <View style={[styles.settingRow, { flexDirection: flexDir }]}>
              <TouchableOpacity
                onPress={() => setShowKaratPicker(!showKaratPicker)}
                style={[styles.settingValue, { flexDirection: flexDir }]}
                activeOpacity={0.7}
              >
                <MaterialIcons name="chevron-right" size={18} color="#6C737F" style={isRTL ? { transform: [{ scaleX: -1 }] } : {}} />
                <Text style={styles.settingValueText}>{settings.defaultKarat}</Text>
              </TouchableOpacity>
              <View style={[styles.settingLabel, { flexDirection: flexDir }]}>
                <Text style={[styles.settingLabelText, { writingDirection: direction }]}>{karatTitle}</Text>
                <MaterialIcons name="diamond" size={20} color="#C5A021" style={isRTL ? { marginLeft: 8 } : { marginRight: 8 }} />
              </View>
            </View>
            {showKaratPicker && (
              <View style={[styles.karatGrid, { flexDirection: flexDir }]}>
                {KARAT_OPTIONS.map(k => (
                  <TouchableOpacity
                    key={k}
                    style={[styles.karatChip, settings.defaultKarat === k && styles.karatChipActive]}
                    onPress={() => { updateSettings({ defaultKarat: k }); setShowKaratPicker(false); }}
                    activeOpacity={0.7}
                  >
                    <Text style={[styles.karatChipText, settings.defaultKarat === k && styles.karatChipTextActive]}>{k}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            )}
          </GoldCard>

          {/* Notification Frequency */}
          <GoldCard>
            <View style={[styles.settingHeader, { flexDirection: flexDir }]}>
              <Text style={[styles.settingLabelText, { writingDirection: direction }]}>{notifTitle}</Text>
              <MaterialIcons name="notifications" size={20} color="#C5A021" style={isRTL ? { marginLeft: 8 } : { marginRight: 8 }} />
            </View>
            <View style={[styles.chipGrid, { flexDirection: flexDir }]}>
              {frequencyOptions.map(opt => (
                <TouchableOpacity
                  key={opt.value}
                  style={[styles.chip, settings.notificationFrequency === opt.value && styles.chipActive]}
                  onPress={() => updateSettings({ notificationFrequency: opt.value })}
                  activeOpacity={0.7}
                >
                  <Text style={[styles.chipText, settings.notificationFrequency === opt.value && styles.chipTextActive]}>{opt.label}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </GoldCard>

          {/* Auto-Refresh */}
          <GoldCard>
            <View style={[styles.settingHeader, { flexDirection: flexDir }]}>
              <Text style={[styles.settingLabelText, { writingDirection: direction }]}>{refreshTitle}</Text>
              <MaterialIcons name="autorenew" size={20} color="#C5A021" style={isRTL ? { marginLeft: 8 } : { marginRight: 8 }} />
            </View>
            <View style={[styles.chipGrid, { flexDirection: flexDir }]}>
              {refreshOptions.map(opt => (
                <TouchableOpacity
                  key={opt.value}
                  style={[styles.chip, settings.autoRefreshInterval === opt.value && styles.chipActive]}
                  onPress={() => updateSettings({ autoRefreshInterval: opt.value })}
                  activeOpacity={0.7}
                >
                  <Text style={[styles.chipText, settings.autoRefreshInterval === opt.value && styles.chipTextActive]}>{opt.label}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </GoldCard>

          {/* Push Notification Settings */}
          <GoldCard>
            <View style={[styles.settingHeader, { flexDirection: flexDir }]}>
              <Text style={[styles.settingLabelText, { writingDirection: direction }]}>
                {lang === 'ar' ? '\u0625\u0634\u0639\u0627\u0631\u0627\u062A \u0641\u0648\u0631\u064A\u0629' : lang === 'fr' ? 'Notifications push' : 'Push Notifications'}
              </Text>
              <MaterialIcons name="notifications-active" size={20} color="#C5A021" style={isRTL ? { marginLeft: 8 } : { marginRight: 8 }} />
            </View>
            {[
              { key: 'enabled' as const, label: lang === 'ar' ? '\u062A\u0641\u0639\u064A\u0644 \u0627\u0644\u0625\u0634\u0639\u0627\u0631\u0627\u062A' : lang === 'fr' ? 'Activer les notifications' : 'Enable Notifications', icon: 'notifications' as const },
              { key: 'newOrders' as const, label: lang === 'ar' ? '\u0637\u0644\u0628\u0627\u062A \u062C\u062F\u064A\u062F\u0629' : lang === 'fr' ? 'Nouvelles commandes' : 'New Orders', icon: 'shopping-cart' as const },
              { key: 'statusChanges' as const, label: lang === 'ar' ? '\u062A\u063A\u064A\u064A\u0631 \u062D\u0627\u0644\u0629 \u0627\u0644\u0637\u0644\u0628' : lang === 'fr' ? 'Changements de statut' : 'Status Changes', icon: 'update' as const },
              { key: 'newMessages' as const, label: lang === 'ar' ? '\u0631\u0633\u0627\u0626\u0644 \u062C\u062F\u064A\u062F\u0629' : lang === 'fr' ? 'Nouveaux messages' : 'New Messages', icon: 'chat' as const },
              { key: 'priceAlerts' as const, label: lang === 'ar' ? '\u062A\u0646\u0628\u064A\u0647\u0627\u062A \u0627\u0644\u0623\u0633\u0639\u0627\u0631' : lang === 'fr' ? 'Alertes de prix' : 'Price Alerts', icon: 'trending-up' as const },
            ].map(item => (
              <TouchableOpacity
                key={item.key}
                style={[styles.toggleRow, { flexDirection: flexDir, marginTop: 8 }]}
                onPress={() => toggleNotifSetting(item.key)}
                activeOpacity={0.7}
                disabled={item.key !== 'enabled' && !notifSettings.enabled}
              >
                <View style={[styles.toggleSwitch, notifSettings[item.key] && styles.toggleSwitchActive, item.key !== 'enabled' && !notifSettings.enabled && { opacity: 0.4 }]}>
                  <View style={[styles.toggleKnob, notifSettings[item.key] && styles.toggleKnobActive]} />
                </View>
                <View style={[styles.toggleInfo, { alignItems: isRTL ? 'flex-end' : 'flex-start', flexDirection: flexDir }]}>
                  <Text style={[styles.settingLabelText, { writingDirection: direction, flex: 1, fontSize: 14 }]}>{item.label}</Text>
                  <MaterialIcons name={item.icon} size={18} color={notifSettings[item.key] ? '#C5A021' : '#6C737F'} style={isRTL ? { marginLeft: 8 } : { marginRight: 8 }} />
                </View>
              </TouchableOpacity>
            ))}
          </GoldCard>

          {/* Background Check Toggle */}
          <GoldCard>
            <TouchableOpacity
              style={[styles.toggleRow, { flexDirection: flexDir }]}
              onPress={() => updateSettings({ backgroundCheckEnabled: !settings.backgroundCheckEnabled })}
              activeOpacity={0.7}
            >
              <View style={[styles.toggleSwitch, settings.backgroundCheckEnabled && styles.toggleSwitchActive]}>
                <View style={[styles.toggleKnob, settings.backgroundCheckEnabled && styles.toggleKnobActive]} />
              </View>
              <View style={[styles.toggleInfo, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
                <Text style={[styles.settingLabelText, { writingDirection: direction }]}>{bgCheckTitle}</Text>
                <Text style={[styles.toggleDesc, { writingDirection: direction }]}>{bgCheckDesc}</Text>
              </View>
            </TouchableOpacity>
          </GoldCard>

          {/* Reset */}
          <View style={styles.resetContainer}>
            <GoldButton
              title={resetTitle}
              onPress={resetSettings}
              variant="outline"
            />
          </View>

          <View style={{ height: 32 }} />
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#001F3F' },
  safeArea: { flex: 1 },
  appBar: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: 'rgba(248,249,250,0.08)',
  },
  appBarTitle: { fontSize: 18, fontWeight: '700', color: '#F8F9FA' },
  menuBtn: { padding: 8 },
  scrollContent: { paddingHorizontal: 16, paddingTop: 16 },
  // Setting Row
  settingRow: { alignItems: 'center', justifyContent: 'space-between' },
  settingLabel: { alignItems: 'center' },
  settingLabelText: { fontSize: 15, fontWeight: '600', color: '#1A1A1B' },
  settingValue: { alignItems: 'center', gap: 4 },
  settingValueText: { fontSize: 13, color: '#6C737F' },
  settingHeader: { alignItems: 'center', marginBottom: 12 },
  // Picker
  pickerContainer: { marginTop: 12, borderTopWidth: 1, borderTopColor: '#E6E8EA', paddingTop: 12 },
  pickerItem: { paddingVertical: 10, paddingHorizontal: 8, borderRadius: 8, alignItems: 'center', gap: 8 },
  pickerItemActive: { backgroundColor: 'rgba(197,160,33,0.08)' },
  pickerItemText: { fontSize: 14, color: '#1A1A1B' },
  pickerItemTextActive: { color: '#C5A021', fontWeight: '600' },
  // Karat Grid
  karatGrid: { flexWrap: 'wrap', gap: 8, marginTop: 12, borderTopWidth: 1, borderTopColor: '#E6E8EA', paddingTop: 12 },
  karatChip: { paddingHorizontal: 20, paddingVertical: 10, borderRadius: 10, backgroundColor: 'rgba(0,31,63,0.06)', borderWidth: 1, borderColor: '#E6E8EA' },
  karatChipActive: { backgroundColor: 'rgba(197,160,33,0.15)', borderColor: '#C5A021' },
  karatChipText: { fontSize: 14, fontWeight: '600', color: '#6C737F' },
  karatChipTextActive: { color: '#C5A021' },
  // Chip Grid
  chipGrid: { flexWrap: 'wrap', gap: 8 },
  chip: { paddingHorizontal: 16, paddingVertical: 8, borderRadius: 8, backgroundColor: 'rgba(0,31,63,0.06)', borderWidth: 1, borderColor: '#E6E8EA' },
  chipActive: { backgroundColor: 'rgba(197,160,33,0.15)', borderColor: '#C5A021' },
  chipText: { fontSize: 13, color: '#6C737F', fontWeight: '500' },
  chipTextActive: { color: '#C5A021', fontWeight: '600' },
  // Toggle
  toggleRow: { alignItems: 'center', gap: 12 },
  toggleInfo: { flex: 1 },
  toggleDesc: { fontSize: 12, color: '#6C737F', marginTop: 4 },
  toggleSwitch: {
    width: 48, height: 28, borderRadius: 14, backgroundColor: '#E6E8EA',
    justifyContent: 'center', paddingHorizontal: 2,
  },
  toggleSwitchActive: { backgroundColor: '#C5A021' },
  toggleKnob: {
    width: 24, height: 24, borderRadius: 12, backgroundColor: '#FFFFFF',
    alignSelf: 'flex-start',
  },
  toggleKnobActive: { alignSelf: 'flex-end' },
  // Reset
  resetContainer: { marginTop: 24 },
});
