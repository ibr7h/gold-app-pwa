import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, TextInput, Alert, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { GoldCard } from '@/components/gold/GoldCard';
import { GoldButton } from '@/components/gold/GoldButton';
import { useAuth, type UserRole } from '@/contexts/AuthContext';
import { useI18n } from '@/i18n';
import * as Auth from '@/lib/_core/auth';
import { getApiBaseUrl } from '@/constants/oauth';

interface AdminUsersScreenProps {
  onOpenDrawer: () => void;
  onNavigate?: (screen: string) => void;
}

interface ManagedUser {
  id: number;
  openId: string;
  email: string | null;
  role: UserRole;
  name: string | null;
  isActive: boolean;
  createdAt: string;
  lastSignedIn: string | null;
}

// ===== tRPC API Helper =====
async function trpcCall<T>(path: string, input?: any, method: 'query' | 'mutation' = 'query'): Promise<T> {
  const baseUrl = getApiBaseUrl();
  const url = `${baseUrl}/api/trpc/${path}`;

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };

  if (Platform.OS !== 'web') {
    const token = await Auth.getSessionToken();
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
  }

  if (method === 'query') {
    const queryUrl = input !== undefined
      ? `${url}?input=${encodeURIComponent(JSON.stringify(input))}`
      : url;
    const response = await fetch(queryUrl, {
      method: 'GET',
      headers,
      credentials: 'include',
    });
    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`tRPC query failed: ${response.status} ${errText}`);
    }
    const data = await response.json();
    return (data?.result?.data?.json ?? data?.result?.data ?? data) as T;
  } else {
    const response = await fetch(url, {
      method: 'POST',
      headers,
      credentials: 'include',
      body: JSON.stringify(input !== undefined ? { json: input } : {}),
    });
    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`tRPC mutation failed: ${response.status} ${errText}`);
    }
    const data = await response.json();
    return (data?.result?.data?.json ?? data?.result?.data ?? data) as T;
  }
}

export default function AdminUsersScreen({ onOpenDrawer, onNavigate }: AdminUsersScreenProps) {
  const { user } = useAuth();
  const { isRTL, textAlign, direction, flexDir, lang } = useI18n();
  const [users, setUsers] = useState<ManagedUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState<'all' | UserRole>('all');
  const [editingUser, setEditingUser] = useState<number | null>(null);

  // Edit form state
  const [editName, setEditName] = useState('');
  const [editRole, setEditRole] = useState<UserRole>('user');

  // Translations
  const t = useMemo(() => ({
    title: lang === 'ar' ? 'إدارة المستخدمين' : lang === 'fr' ? 'Gestion des utilisateurs' : 'User Management',
    searchPlaceholder: lang === 'ar' ? 'بحث بالاسم أو البريد...' : lang === 'fr' ? 'Rechercher par nom ou email...' : 'Search by name or email...',
    all: lang === 'ar' ? 'الكل' : lang === 'fr' ? 'Tous' : 'All',
    users: lang === 'ar' ? 'مستخدمين' : lang === 'fr' ? 'Utilisateurs' : 'Users',
    traders: lang === 'ar' ? 'تجار' : lang === 'fr' ? 'Commerçants' : 'Traders',
    admins: lang === 'ar' ? 'مدراء' : lang === 'fr' ? 'Administrateurs' : 'Admins',
    editUser: lang === 'ar' ? 'تعديل المستخدم' : lang === 'fr' ? 'Modifier l\'utilisateur' : 'Edit User',
    deleteUser: lang === 'ar' ? 'حذف المستخدم' : lang === 'fr' ? 'Supprimer l\'utilisateur' : 'Delete User',
    deleteConfirm: lang === 'ar' ? 'هل أنت متأكد من حذف هذا المستخدم؟' : lang === 'fr' ? 'Êtes-vous sûr de vouloir supprimer cet utilisateur ?' : 'Are you sure you want to delete this user?',
    name: lang === 'ar' ? 'الاسم' : lang === 'fr' ? 'Nom' : 'Name',
    email: lang === 'ar' ? 'البريد الإلكتروني' : lang === 'fr' ? 'Email' : 'Email',
    role: lang === 'ar' ? 'الدور' : lang === 'fr' ? 'Rôle' : 'Role',
    roleUser: lang === 'ar' ? 'مستخدم' : lang === 'fr' ? 'Utilisateur' : 'User',
    roleTrader: lang === 'ar' ? 'تاجر' : lang === 'fr' ? 'Commerçant' : 'Trader',
    roleAdmin: lang === 'ar' ? 'مدير' : lang === 'fr' ? 'Administrateur' : 'Admin',
    save: lang === 'ar' ? 'حفظ' : lang === 'fr' ? 'Enregistrer' : 'Save',
    cancel: lang === 'ar' ? 'إلغاء' : lang === 'fr' ? 'Annuler' : 'Cancel',
    activate: lang === 'ar' ? 'تفعيل' : lang === 'fr' ? 'Activer' : 'Activate',
    deactivate: lang === 'ar' ? 'تعطيل' : lang === 'fr' ? 'Désactiver' : 'Deactivate',
    active: lang === 'ar' ? 'نشط' : lang === 'fr' ? 'Actif' : 'Active',
    inactive: lang === 'ar' ? 'معطل' : lang === 'fr' ? 'Inactif' : 'Inactive',
    noUsers: lang === 'ar' ? 'لا يوجد مستخدمين' : lang === 'fr' ? 'Aucun utilisateur' : 'No users found',
    totalUsers: lang === 'ar' ? 'إجمالي المستخدمين' : lang === 'fr' ? 'Total utilisateurs' : 'Total Users',
    activeUsers: lang === 'ar' ? 'نشطون' : lang === 'fr' ? 'Actifs' : 'Active',
    userUpdated: lang === 'ar' ? 'تم تحديث المستخدم' : lang === 'fr' ? 'Utilisateur mis à jour' : 'User updated',
    userDeleted: lang === 'ar' ? 'تم حذف المستخدم' : lang === 'fr' ? 'Utilisateur supprimé' : 'User deleted',
    cannotDeleteSelf: lang === 'ar' ? 'لا يمكنك حذف حسابك' : lang === 'fr' ? 'Vous ne pouvez pas supprimer votre compte' : 'Cannot delete your own account',
    joined: lang === 'ar' ? 'انضم' : lang === 'fr' ? 'Inscrit' : 'Joined',
    loadError: lang === 'ar' ? 'فشل تحميل المستخدمين' : lang === 'fr' ? 'Échec du chargement' : 'Failed to load users',
  }), [lang]);

  const roleColors: Record<UserRole, string> = {
    user: '#3B82F6',
    trader: '#C5A021',
    admin: '#EF4444',
  };

  const roleLabels: Record<UserRole, string> = {
    user: t.roleUser,
    trader: t.roleTrader,
    admin: t.roleAdmin,
  };

  // Load users from server
  const loadUsers = useCallback(async () => {
    try {
      setLoading(true);
      const input = roleFilter !== 'all' ? { role: roleFilter, search: searchQuery || undefined } : { search: searchQuery || undefined };
      const result = await trpcCall<ManagedUser[]>('admin.users.list', input);
      setUsers(result || []);
    } catch (e) {
      console.warn('Failed to load users:', e);
    }
    setLoading(false);
  }, [roleFilter, searchQuery]);

  useEffect(() => { loadUsers(); }, [loadUsers]);

  // Edit user role
  const startEdit = useCallback((u: ManagedUser) => {
    setEditingUser(u.id);
    setEditName(u.name || '');
    setEditRole(u.role);
  }, []);

  const handleSaveEdit = useCallback(async () => {
    if (editingUser === null) return;
    try {
      await trpcCall('admin.users.updateRole', { id: editingUser, role: editRole }, 'mutation');
      setEditingUser(null);
      await loadUsers();
      if (Platform.OS !== 'web') Alert.alert('', t.userUpdated);
    } catch (e) {
      console.error('Failed to update user:', e);
    }
  }, [editingUser, editRole, loadUsers, t]);

  // Toggle active
  const handleToggleActive = useCallback(async (userId: number, currentActive: boolean) => {
    try {
      await trpcCall('admin.users.toggleActive', { id: userId, isActive: !currentActive }, 'mutation');
      await loadUsers();
    } catch (e) {
      console.error('Failed to toggle user:', e);
    }
  }, [loadUsers]);

  // Delete user
  const handleDeleteUser = useCallback(async (userId: number) => {
    if (userId === user?.id) {
      if (Platform.OS !== 'web') Alert.alert('', t.cannotDeleteSelf);
      return;
    }
    const doDelete = async () => {
      try {
        await trpcCall('admin.users.delete', { id: userId }, 'mutation');
        await loadUsers();
        if (Platform.OS !== 'web') Alert.alert('', t.userDeleted);
      } catch (e) {
        console.error('Failed to delete user:', e);
      }
    };
    if (Platform.OS === 'web') {
      if (confirm(t.deleteConfirm)) await doDelete();
    } else {
      Alert.alert(t.deleteUser, t.deleteConfirm, [
        { text: t.cancel, style: 'cancel' },
        { text: t.deleteUser, style: 'destructive', onPress: doDelete },
      ]);
    }
  }, [user, loadUsers, t]);

  // Filter users locally (server already filters by role, but search is done client-side for responsiveness)
  const filteredUsers = useMemo(() => {
    let result = users;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter(u =>
        (u.name || '').toLowerCase().includes(q) ||
        (u.email || '').toLowerCase().includes(q)
      );
    }
    return result;
  }, [users, searchQuery]);

  // Stats
  const stats = useMemo(() => ({
    total: users.length,
    active: users.filter(u => u.isActive).length,
    byRole: {
      user: users.filter(u => u.role === 'user').length,
      trader: users.filter(u => u.role === 'trader').length,
      admin: users.filter(u => u.role === 'admin').length,
    },
  }), [users]);

  const roleFilters: { key: 'all' | UserRole; label: string; count: number }[] = [
    { key: 'all', label: t.all, count: stats.total },
    { key: 'user', label: t.users, count: stats.byRole.user },
    { key: 'trader', label: t.traders, count: stats.byRole.trader },
    { key: 'admin', label: t.admins, count: stats.byRole.admin },
  ];

  const roles: { key: UserRole; label: string }[] = [
    { key: 'user', label: t.roleUser },
    { key: 'trader', label: t.roleTrader },
    { key: 'admin', label: t.roleAdmin },
  ];

  if (user?.role !== 'admin') {
    return (
      <View style={styles.screen}>
        <SafeAreaView style={styles.safeArea} edges={['top']}>
          <View style={styles.appBar}>
            <View style={{ width: 40 }} />
            <Text style={[styles.appBarTitle, { writingDirection: direction }]}>{t.title}</Text>
            <TouchableOpacity onPress={onOpenDrawer} style={styles.menuBtn} activeOpacity={0.7}>
              <MaterialIcons name="menu" size={24} color="#F8F9FA" />
            </TouchableOpacity>
          </View>
          <View style={styles.accessDenied}>
            <MaterialIcons name="lock" size={48} color="#6C737F" />
          </View>
        </SafeAreaView>
      </View>
    );
  }

  const renderUserCard = (u: ManagedUser) => {
    const isEditing = editingUser === u.id;
    const isSelf = u.id === user?.id;

    if (isEditing) {
      return (
        <GoldCard key={u.id} style={styles.userCard}>
          <View style={[styles.editHeader, { flexDirection: flexDir }]}>
            <Text style={[styles.editTitle, { writingDirection: direction }]}>{t.editUser}</Text>
            <TouchableOpacity onPress={() => setEditingUser(null)}>
              <MaterialIcons name="close" size={22} color="#6C737F" />
            </TouchableOpacity>
          </View>

          <Text style={[styles.fieldLabel, { textAlign, writingDirection: direction }]}>{t.name}</Text>
          <View style={styles.readOnlyField}>
            <Text style={[styles.readOnlyText, { writingDirection: direction }]}>{u.name || '-'}</Text>
          </View>

          <Text style={[styles.fieldLabel, { textAlign, writingDirection: direction }]}>{t.email}</Text>
          <View style={styles.readOnlyField}>
            <Text style={[styles.readOnlyText, { writingDirection: direction }]}>{u.email || '-'}</Text>
          </View>

          <Text style={[styles.fieldLabel, { textAlign, writingDirection: direction }]}>{t.role}</Text>
          <View style={styles.roleSelector}>
            {roles.map(r => (
              <TouchableOpacity
                key={r.key}
                onPress={() => setEditRole(r.key)}
                style={[styles.roleChip, editRole === r.key && { backgroundColor: roleColors[r.key] + '25', borderColor: roleColors[r.key] }]}
                activeOpacity={0.7}
              >
                <Text style={[styles.roleChipText, editRole === r.key && { color: roleColors[r.key] }]}>{r.label}</Text>
              </TouchableOpacity>
            ))}
          </View>

          <View style={[styles.editActions, { flexDirection: flexDir }]}>
            <TouchableOpacity onPress={() => setEditingUser(null)} style={styles.cancelBtn}>
              <Text style={styles.cancelBtnText}>{t.cancel}</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={handleSaveEdit} style={styles.saveBtn} activeOpacity={0.7}>
              <MaterialIcons name="check" size={18} color="#001F3F" />
              <Text style={styles.saveBtnText}>{t.save}</Text>
            </TouchableOpacity>
          </View>
        </GoldCard>
      );
    }

    return (
      <GoldCard key={u.id} style={styles.userCard}>
        <View style={[styles.userHeader, { flexDirection: flexDir }]}>
          {/* Avatar */}
          <View style={[styles.avatar, { backgroundColor: roleColors[u.role] + '20' }, isRTL ? { marginLeft: 12 } : { marginRight: 12 }]}>
            <Text style={[styles.avatarText, { color: roleColors[u.role] }]}>
              {(u.name || u.email || '?')[0].toUpperCase()}
            </Text>
          </View>
          <View style={{ flex: 1 }}>
            <View style={[styles.nameRow, { flexDirection: flexDir }]}>
              <Text style={[styles.userName, { writingDirection: direction }]}>{u.name || u.email || '-'}</Text>
              {isSelf && (
                <View style={styles.selfBadge}>
                  <Text style={styles.selfBadgeText}>{lang === 'ar' ? 'أنت' : lang === 'fr' ? 'Vous' : 'You'}</Text>
                </View>
              )}
            </View>
            <Text style={[styles.userEmail, { textAlign, writingDirection: direction }]}>{u.email || '-'}</Text>
          </View>
        </View>

        {/* Role & Status */}
        <View style={[styles.badgeRow, { flexDirection: flexDir }]}>
          <View style={[styles.roleBadge, { backgroundColor: roleColors[u.role] + '20' }]}>
            <MaterialIcons
              name={u.role === 'admin' ? 'admin-panel-settings' : u.role === 'trader' ? 'store' : 'person'}
              size={14}
              color={roleColors[u.role]}
            />
            <Text style={[styles.roleBadgeText, { color: roleColors[u.role] }]}>{roleLabels[u.role]}</Text>
          </View>
          <View style={[styles.statusBadge, { backgroundColor: u.isActive ? 'rgba(34,197,94,0.15)' : 'rgba(108,115,127,0.15)' }]}>
            <View style={[styles.statusDot, { backgroundColor: u.isActive ? '#22C55E' : '#6C737F' }]} />
            <Text style={[styles.statusBadgeText, { color: u.isActive ? '#22C55E' : '#6C737F' }]}>
              {u.isActive ? t.active : t.inactive}
            </Text>
          </View>
        </View>

        {/* Joined date */}
        <Text style={[styles.joinedText, { textAlign, writingDirection: direction }]}>
          {t.joined}: {new Date(u.createdAt).toLocaleDateString(lang === 'ar' ? 'ar-SA' : lang === 'fr' ? 'fr-FR' : 'en-US')}
        </Text>

        {/* Actions */}
        <View style={[styles.userActions, { flexDirection: flexDir }]}>
          <TouchableOpacity onPress={() => startEdit(u)} style={styles.actionBtn} activeOpacity={0.7}>
            <MaterialIcons name="edit" size={16} color="#C5A021" />
            <Text style={[styles.actionBtnText, { color: '#C5A021' }]}>{lang === 'ar' ? 'تعديل' : lang === 'fr' ? 'Modifier' : 'Edit'}</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => handleToggleActive(u.id, u.isActive)} style={styles.actionBtn} activeOpacity={0.7}>
            <MaterialIcons name={u.isActive ? 'pause-circle-outline' : 'play-circle-outline'} size={16} color={u.isActive ? '#F59E0B' : '#22C55E'} />
            <Text style={[styles.actionBtnText, { color: u.isActive ? '#F59E0B' : '#22C55E' }]}>
              {u.isActive ? t.deactivate : t.activate}
            </Text>
          </TouchableOpacity>
          {!isSelf && (
            <TouchableOpacity onPress={() => handleDeleteUser(u.id)} style={styles.actionBtn} activeOpacity={0.7}>
              <MaterialIcons name="delete-outline" size={16} color="#EF4444" />
              <Text style={[styles.actionBtnText, { color: '#EF4444' }]}>{lang === 'ar' ? 'حذف' : lang === 'fr' ? 'Supprimer' : 'Delete'}</Text>
            </TouchableOpacity>
          )}
        </View>
      </GoldCard>
    );
  };

  return (
    <View style={styles.screen}>
      <SafeAreaView style={styles.safeArea} edges={['top', 'left', 'right']}>
        {/* Header */}
        <View style={[styles.appBar, { flexDirection: flexDir }]}>
          <TouchableOpacity onPress={() => onNavigate?.('admin')} style={styles.backBtn}>
            <MaterialIcons name={isRTL ? 'chevron-right' : 'chevron-left'} size={28} color="#C5A021" />
          </TouchableOpacity>
          <Text style={[styles.appBarTitle, { textAlign, writingDirection: direction, flex: 1 }]}>{t.title}</Text>
          <TouchableOpacity onPress={onOpenDrawer} style={styles.menuBtn} activeOpacity={0.7}>
            <MaterialIcons name="menu" size={24} color="#F8F9FA" />
          </TouchableOpacity>
        </View>

        {/* Stats Summary */}
        <View style={[styles.statsRow, { flexDirection: flexDir }]}>
          <View style={styles.statBox}>
            <Text style={styles.statValue}>{stats.total}</Text>
            <Text style={[styles.statLabel, { writingDirection: direction }]}>{t.totalUsers}</Text>
          </View>
          <View style={styles.statBox}>
            <Text style={[styles.statValue, { color: '#22C55E' }]}>{stats.active}</Text>
            <Text style={[styles.statLabel, { writingDirection: direction }]}>{t.activeUsers}</Text>
          </View>
          <View style={styles.statBox}>
            <Text style={[styles.statValue, { color: '#C5A021' }]}>{stats.byRole.trader}</Text>
            <Text style={[styles.statLabel, { writingDirection: direction }]}>{t.traders}</Text>
          </View>
        </View>

        {/* Search */}
        <View style={styles.searchRow}>
          <View style={[styles.searchBox, { flexDirection: flexDir }]}>
            <MaterialIcons name="search" size={20} color="#6C737F" style={isRTL ? { marginLeft: 8 } : { marginRight: 8 }} />
            <TextInput
              style={[styles.searchInput, { textAlign, writingDirection: direction }]}
              placeholder={t.searchPlaceholder}
              placeholderTextColor="#6C737F"
              value={searchQuery}
              onChangeText={setSearchQuery}
            />
          </View>
        </View>

        {/* Role Filter */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.filterScroll} contentContainerStyle={styles.filterContent}>
          {roleFilters.map(f => (
            <TouchableOpacity
              key={f.key}
              onPress={() => setRoleFilter(f.key)}
              style={[styles.filterChip, roleFilter === f.key && styles.filterChipActive]}
              activeOpacity={0.7}
            >
              <Text style={[styles.filterChipText, roleFilter === f.key && styles.filterChipTextActive]}>
                {f.label} ({f.count})
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
          {/* Users List */}
          {loading ? (
            <View style={styles.emptyContainer}>
              <Text style={[styles.emptyText, { writingDirection: direction }]}>
                {lang === 'ar' ? 'جاري التحميل...' : lang === 'fr' ? 'Chargement...' : 'Loading...'}
              </Text>
            </View>
          ) : filteredUsers.length === 0 ? (
            <View style={styles.emptyContainer}>
              <MaterialIcons name="people-outline" size={48} color="#6C737F" />
              <Text style={[styles.emptyText, { writingDirection: direction }]}>{t.noUsers}</Text>
            </View>
          ) : (
            filteredUsers.map(u => renderUserCard(u))
          )}

          <View style={{ height: 100 }} />
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#001F3F' },
  safeArea: { flex: 1 },
  appBar: {
    alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 12,
    borderBottomWidth: 1, borderBottomColor: 'rgba(248,249,250,0.08)',
  },
  backBtn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  appBarTitle: { fontSize: 18, fontWeight: '700', color: '#F8F9FA' },
  menuBtn: { padding: 8 },
  accessDenied: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  scrollContent: { paddingHorizontal: 16, paddingTop: 8 },

  // Stats
  statsRow: { paddingHorizontal: 16, paddingVertical: 12, gap: 10 },
  statBox: {
    flex: 1, backgroundColor: 'rgba(248,249,250,0.06)',
    borderRadius: 12, padding: 12, alignItems: 'center',
    borderWidth: 1, borderColor: 'rgba(248,249,250,0.08)',
  },
  statValue: { fontSize: 22, fontWeight: '800', color: '#F8F9FA' },
  statLabel: { fontSize: 11, color: '#6C737F', marginTop: 4, fontWeight: '500' },

  // Search
  searchRow: { paddingHorizontal: 16, paddingBottom: 8 },
  searchBox: {
    backgroundColor: 'rgba(248,249,250,0.06)',
    borderRadius: 12, paddingHorizontal: 14, paddingVertical: 10,
    alignItems: 'center',
    borderWidth: 1, borderColor: 'rgba(248,249,250,0.1)',
  },
  searchInput: { flex: 1, fontSize: 14, color: '#F8F9FA' },

  // Filter
  filterScroll: { maxHeight: 44 },
  filterContent: { paddingHorizontal: 16, gap: 8 },
  filterChip: {
    paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20,
    backgroundColor: 'rgba(248,249,250,0.06)',
    borderWidth: 1, borderColor: 'rgba(248,249,250,0.1)',
  },
  filterChipActive: { backgroundColor: 'rgba(197,160,33,0.15)', borderColor: '#C5A021' },
  filterChipText: { fontSize: 13, color: '#6C737F', fontWeight: '500' },
  filterChipTextActive: { color: '#C5A021', fontWeight: '700' },

  // User card
  userCard: { marginBottom: 12 },
  userHeader: { alignItems: 'center', marginBottom: 10 },
  avatar: {
    width: 44, height: 44, borderRadius: 22,
    alignItems: 'center', justifyContent: 'center',
  },
  avatarText: { fontSize: 18, fontWeight: '700' },
  nameRow: { alignItems: 'center', gap: 8 },
  userName: { fontSize: 15, fontWeight: '700', color: '#F8F9FA' },
  userEmail: { fontSize: 12, color: '#6C737F', marginTop: 2 },
  selfBadge: {
    backgroundColor: 'rgba(59,130,246,0.15)', paddingHorizontal: 8, paddingVertical: 2, borderRadius: 8,
  },
  selfBadgeText: { fontSize: 10, fontWeight: '700', color: '#3B82F6' },
  badgeRow: { gap: 8, marginBottom: 8 },
  roleBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    paddingHorizontal: 10, paddingVertical: 5, borderRadius: 8,
  },
  roleBadgeText: { fontSize: 12, fontWeight: '700' },
  statusBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    paddingHorizontal: 10, paddingVertical: 5, borderRadius: 8,
  },
  statusDot: { width: 6, height: 6, borderRadius: 3 },
  statusBadgeText: { fontSize: 12, fontWeight: '600' },
  joinedText: { fontSize: 11, color: '#6C737F', marginBottom: 10 },

  // Actions
  userActions: { gap: 12, borderTopWidth: 1, borderTopColor: 'rgba(248,249,250,0.08)', paddingTop: 10 },
  actionBtn: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingVertical: 4 },
  actionBtnText: { fontSize: 12, fontWeight: '600' },

  // Edit form
  editHeader: { alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 },
  editTitle: { fontSize: 16, fontWeight: '700', color: '#C5A021' },
  fieldLabel: { fontSize: 13, fontWeight: '600', color: '#9BA1A6', marginBottom: 6, marginTop: 12 },
  readOnlyField: {
    backgroundColor: 'rgba(248,249,250,0.04)',
    borderRadius: 10, paddingHorizontal: 14, paddingVertical: 10,
    borderWidth: 1, borderColor: 'rgba(248,249,250,0.08)',
  },
  readOnlyText: { fontSize: 14, color: '#6C737F' },
  roleSelector: { flexDirection: 'row', gap: 8, marginTop: 4 },
  roleChip: {
    flex: 1, paddingVertical: 10, borderRadius: 10, alignItems: 'center',
    backgroundColor: 'rgba(248,249,250,0.06)',
    borderWidth: 1.5, borderColor: 'rgba(248,249,250,0.1)',
  },
  roleChipText: { fontSize: 13, fontWeight: '600', color: '#6C737F' },
  editActions: { alignItems: 'center', justifyContent: 'flex-end', gap: 12, marginTop: 16 },
  cancelBtn: { paddingHorizontal: 16, paddingVertical: 10 },
  cancelBtnText: { fontSize: 14, color: '#6C737F', fontWeight: '600' },
  saveBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: '#C5A021', paddingHorizontal: 18, paddingVertical: 10, borderRadius: 10,
  },
  saveBtnText: { fontSize: 14, fontWeight: '700', color: '#001F3F' },

  // Empty
  emptyContainer: { alignItems: 'center', justifyContent: 'center', paddingVertical: 60, gap: 12 },
  emptyText: { fontSize: 16, color: '#6C737F', fontWeight: '500' },
});
