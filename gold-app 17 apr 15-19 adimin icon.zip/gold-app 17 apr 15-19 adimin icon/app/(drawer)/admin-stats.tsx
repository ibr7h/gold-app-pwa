import React, { useState, useMemo } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Dimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { GoldCard } from '@/components/gold/GoldCard';
import { InteractiveBarChart } from '@/components/gold/InteractiveBarChart';
import { InteractivePieChart } from '@/components/gold/InteractivePieChart';
import { InteractiveLineChart } from '@/components/gold/InteractiveLineChart';
import { useI18n } from '@/i18n';
import { useTraderData } from '@/contexts/TraderDataContext';
import { useAppData } from '@/contexts/AppDataContext';

const SCREEN_WIDTH = Dimensions.get('window').width;
const CHART_WIDTH = SCREEN_WIDTH - 80;

interface AdminStatsScreenProps {
  onOpenDrawer: () => void;
  onNavigate?: (screen: string) => void;
}

type Period = 'week' | 'month' | 'all';

export default function AdminStatsScreen({ onOpenDrawer, onNavigate }: AdminStatsScreenProps) {
  const { isRTL, textAlign, direction, flexDir, lang } = useI18n();
  const { orders, clients, stats } = useTraderData();
  const { portfolios, purchasesList, alertsList } = useAppData();
  const [period, setPeriod] = useState<Period>('month');

  // Translations
  const titleLabel = lang === 'ar' ? 'الإحصائيات المتقدمة' : lang === 'fr' ? 'Statistiques avancées' : 'Advanced Statistics';
  const weekLabel = lang === 'ar' ? 'الأسبوع' : lang === 'fr' ? 'Semaine' : 'Week';
  const monthLabel = lang === 'ar' ? 'الشهر' : lang === 'fr' ? 'Mois' : 'Month';
  const allLabel = lang === 'ar' ? 'الكل' : lang === 'fr' ? 'Tous' : 'All';
  const overviewLabel = lang === 'ar' ? 'نظرة عامة على النظام' : lang === 'fr' ? 'Vue d\'ensemble du système' : 'System Overview';
  const totalSalesLabel = lang === 'ar' ? 'إجمالي المبيعات' : lang === 'fr' ? 'Ventes totales' : 'Total Sales';
  const activeTradersLabel = lang === 'ar' ? 'التجار النشطون' : lang === 'fr' ? 'Commerçants actifs' : 'Active Traders';
  const totalUsersLabel = lang === 'ar' ? 'إجمالي المستخدمين' : lang === 'fr' ? 'Total utilisateurs' : 'Total Users';
  const totalOrdersLabel = lang === 'ar' ? 'إجمالي الطلبات' : lang === 'fr' ? 'Total commandes' : 'Total Orders';
  const revenueChartLabel = lang === 'ar' ? 'الإيرادات حسب الفترة' : lang === 'fr' ? 'Revenus par période' : 'Revenue by Period';
  const userGrowthLabel = lang === 'ar' ? 'نمو المستخدمين' : lang === 'fr' ? 'Croissance des utilisateurs' : 'User Growth';
  const topTradersLabel = lang === 'ar' ? 'أفضل التجار' : lang === 'fr' ? 'Meilleurs commerçants' : 'Top Traders';
  const orderStatusLabel = lang === 'ar' ? 'حالة الطلبات' : lang === 'fr' ? 'Statut des commandes' : 'Order Status';
  const portfolioStatsLabel = lang === 'ar' ? 'إحصائيات المحافظ' : lang === 'fr' ? 'Statistiques des portefeuilles' : 'Portfolio Statistics';
  const pendingLabel = lang === 'ar' ? 'معلق' : lang === 'fr' ? 'En attente' : 'Pending';
  const processingLabel = lang === 'ar' ? 'قيد التنفيذ' : lang === 'fr' ? 'En cours' : 'Processing';
  const completedLabel = lang === 'ar' ? 'مكتمل' : lang === 'fr' ? 'Terminé' : 'Completed';
  const cancelledLabel = lang === 'ar' ? 'ملغي' : lang === 'fr' ? 'Annulé' : 'Cancelled';
  const traderLabel = lang === 'ar' ? 'التاجر' : lang === 'fr' ? 'Commerçant' : 'Trader';
  const revenueLabel = lang === 'ar' ? 'الإيرادات' : lang === 'fr' ? 'Revenus' : 'Revenue';
  const ordersCountLabel = lang === 'ar' ? 'الطلبات' : lang === 'fr' ? 'Commandes' : 'Orders';
  const activeAlertsLabel = lang === 'ar' ? 'التنبيهات النشطة' : lang === 'fr' ? 'Alertes actives' : 'Active Alerts';
  const totalPortfoliosLabel = lang === 'ar' ? 'المحافظ' : lang === 'fr' ? 'Portefeuilles' : 'Portfolios';
  const totalPurchasesLabel = lang === 'ar' ? 'المشتريات' : lang === 'fr' ? 'Achats' : 'Purchases';

  // Filter orders by period
  const filteredOrders = useMemo(() => {
    const now = new Date();
    return orders.filter(o => {
      if (period === 'all') return true;
      const orderDate = new Date(o.date);
      const diff = (now.getTime() - orderDate.getTime()) / (1000 * 60 * 60 * 24);
      if (period === 'week') return diff <= 7;
      if (period === 'month') return diff <= 30;
      return true;
    });
  }, [orders, period]);

  // Stats calculations
  const totalSales = filteredOrders.reduce((sum, o) => sum + o.totalAmount, 0);
  const completedOrders = filteredOrders.filter(o => o.status === 'completed').length;
  const pendingOrders = filteredOrders.filter(o => o.status === 'pending').length;
  const processingOrders = filteredOrders.filter(o => o.status === 'processing').length;
  const cancelledOrders = filteredOrders.filter(o => o.status === 'cancelled').length;
  const activeClients = clients.filter(c => c.status === 'active').length;
  const activeAlerts = alertsList.filter(a => a.status === 'active').length;

  // Simulated top traders data
  const topTraders = useMemo(() => {
    const traderMap = new Map<string, { name: string; revenue: number; orders: number }>();
    filteredOrders.forEach(o => {
      const existing = traderMap.get(o.clientName) || { name: o.clientName, revenue: 0, orders: 0 };
      existing.revenue += o.totalAmount;
      existing.orders += 1;
      traderMap.set(o.clientName, existing);
    });
    return Array.from(traderMap.values())
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 5);
  }, [filteredOrders]);

  // Revenue by day (last 7 days)
  const dailyRevenue = useMemo(() => {
    const days: { label: string; value: number }[] = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().split('T')[0];
      const dayLabel = d.toLocaleDateString(lang === 'ar' ? 'ar-SA' : lang === 'fr' ? 'fr-FR' : 'en-US', { weekday: 'short' });
      const dayRevenue = orders
        .filter(o => o.date === dateStr && o.status !== 'cancelled')
        .reduce((sum, o) => sum + o.totalAmount, 0);
      days.push({ label: dayLabel, value: dayRevenue });
    }
    return days;
  }, [orders, lang]);

  const maxDailyRevenue = Math.max(...dailyRevenue.map(d => d.value), 1);

  // User growth simulation (monthly)
  const userGrowthData = useMemo(() => {
    const months: { label: string; users: number; traders: number }[] = [];
    const monthNames = lang === 'ar'
      ? ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو']
      : lang === 'fr'
      ? ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Juin']
      : ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
    let baseUsers = 120;
    let baseTraders = 8;
    for (let i = 0; i < 6; i++) {
      baseUsers += Math.floor(Math.random() * 30) + 10;
      baseTraders += Math.floor(Math.random() * 3) + 1;
      months.push({ label: monthNames[i], users: baseUsers, traders: baseTraders });
    }
    return months;
  }, [lang]);

  const maxUsers = Math.max(...userGrowthData.map(d => d.users), 1);

  // Order status distribution
  const statusData = [
    { label: completedLabel, count: completedOrders, color: '#22C55E', bgColor: 'rgba(34,197,94,0.15)' },
    { label: pendingLabel, count: pendingOrders, color: '#F59E0B', bgColor: 'rgba(245,158,11,0.15)' },
    { label: processingLabel, count: processingOrders, color: '#3B82F6', bgColor: 'rgba(59,130,246,0.15)' },
    { label: cancelledLabel, count: cancelledOrders, color: '#EF4444', bgColor: 'rgba(239,68,68,0.15)' },
  ];
  const totalStatusOrders = Math.max(filteredOrders.length, 1);

  const periods: { key: Period; label: string }[] = [
    { key: 'week', label: weekLabel },
    { key: 'month', label: monthLabel },
    { key: 'all', label: allLabel },
  ];

  return (
    <View style={styles.screen}>
      <SafeAreaView style={styles.safeArea} edges={['top']}>
        {/* App Bar */}
        <View style={styles.appBar}>
          <View style={{ width: 40 }} />
          <Text style={[styles.appBarTitle, { writingDirection: direction }]}>{titleLabel}</Text>
          <TouchableOpacity onPress={onOpenDrawer} style={styles.menuBtn} activeOpacity={0.7}>
            <MaterialIcons name="menu" size={24} color="#F8F9FA" />
          </TouchableOpacity>
        </View>

        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
          {/* Period Selector */}
          <View style={[styles.periodRow, { flexDirection: flexDir }]}>
            {periods.map(p => (
              <TouchableOpacity
                key={p.key}
                style={[styles.periodBtn, period === p.key && styles.periodBtnActive]}
                onPress={() => setPeriod(p.key)}
                activeOpacity={0.7}
              >
                <Text style={[styles.periodBtnText, period === p.key && styles.periodBtnTextActive, { writingDirection: direction }]}>
                  {p.label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          {/* System Overview */}
          <Text style={[styles.sectionTitle, { textAlign, writingDirection: direction }]}>{overviewLabel}</Text>
          <View style={[styles.statsGrid, { flexDirection: flexDir }]}>
            <GoldCard style={styles.statCard}>
              <MaterialIcons name="attach-money" size={28} color="#C5A021" />
              <Text style={styles.statValue}>{totalSales.toLocaleString()}</Text>
              <Text style={[styles.statLabel, { writingDirection: direction }]}>{totalSalesLabel}</Text>
            </GoldCard>
            <GoldCard style={styles.statCard}>
              <MaterialIcons name="storefront" size={28} color="#3B82F6" />
              <Text style={styles.statValue}>{activeClients}</Text>
              <Text style={[styles.statLabel, { writingDirection: direction }]}>{activeTradersLabel}</Text>
            </GoldCard>
          </View>
          <View style={[styles.statsGrid, { flexDirection: flexDir }]}>
            <GoldCard style={styles.statCard}>
              <MaterialIcons name="receipt-long" size={28} color="#22C55E" />
              <Text style={styles.statValue}>{filteredOrders.length}</Text>
              <Text style={[styles.statLabel, { writingDirection: direction }]}>{totalOrdersLabel}</Text>
            </GoldCard>
            <GoldCard style={styles.statCard}>
              <MaterialIcons name="people" size={28} color="#8B5CF6" />
              <Text style={styles.statValue}>{userGrowthData[userGrowthData.length - 1]?.users || 0}</Text>
              <Text style={[styles.statLabel, { writingDirection: direction }]}>{totalUsersLabel}</Text>
            </GoldCard>
          </View>

          {/* Additional stats row */}
          <View style={[styles.statsGrid, { flexDirection: flexDir }]}>
            <GoldCard style={styles.statCard}>
              <MaterialIcons name="account-balance-wallet" size={28} color="#F59E0B" />
              <Text style={styles.statValue}>{portfolios.length}</Text>
              <Text style={[styles.statLabel, { writingDirection: direction }]}>{totalPortfoliosLabel}</Text>
            </GoldCard>
            <GoldCard style={styles.statCard}>
              <MaterialIcons name="shopping-cart" size={28} color="#EC4899" />
              <Text style={styles.statValue}>{purchasesList.length}</Text>
              <Text style={[styles.statLabel, { writingDirection: direction }]}>{totalPurchasesLabel}</Text>
            </GoldCard>
          </View>

          {/* Revenue Chart - Interactive */}
          <Text style={[styles.sectionTitle, { textAlign, writingDirection: direction }]}>{revenueChartLabel}</Text>
          <GoldCard>
            <InteractiveBarChart
              data={dailyRevenue.map(d => ({ label: d.label, value: d.value }))}
              height={180}
              formatValue={(v) => v >= 1000 ? `${(v / 1000).toFixed(1)}K` : v.toLocaleString()}
              isRTL={isRTL}
            />
          </GoldCard>

          {/* Order Status Distribution - Interactive Pie */}
          <Text style={[styles.sectionTitle, { textAlign, writingDirection: direction }]}>{orderStatusLabel}</Text>
          <GoldCard>
            <InteractivePieChart
              data={statusData.filter(s => s.count > 0).map(s => ({
                label: s.label,
                value: s.count,
                color: s.color,
              }))}
              isRTL={isRTL}
              formatValue={(v) => `${v} ${ordersCountLabel}`}
            />
          </GoldCard>

          {/* User Growth Chart - Interactive Line */}
          <Text style={[styles.sectionTitle, { textAlign, writingDirection: direction }]}>{userGrowthLabel}</Text>
          <GoldCard>
            <InteractiveLineChart
              data={userGrowthData.map(m => ({ label: m.label, value: m.users }))}
              height={180}
              color="#8B5CF6"
              formatValue={(v) => `${v} ${totalUsersLabel}`}
              isRTL={isRTL}
            />
          </GoldCard>

          {/* Top Traders */}
          <Text style={[styles.sectionTitle, { textAlign, writingDirection: direction }]}>{topTradersLabel}</Text>
          <GoldCard>
            {topTraders.length === 0 ? (
              <Text style={[styles.emptyText, { textAlign, writingDirection: direction }]}>
                {lang === 'ar' ? 'لا توجد بيانات' : lang === 'fr' ? 'Aucune donnée' : 'No data'}
              </Text>
            ) : (
              topTraders.map((trader, i) => (
                <View key={i} style={[styles.traderRow, { flexDirection: flexDir }, i < topTraders.length - 1 && styles.traderRowBorder]}>
                  <View style={[styles.traderInfo, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
                    <Text style={[styles.traderRevenue, { writingDirection: direction }]}>
                      {trader.revenue.toLocaleString()} • {trader.orders} {ordersCountLabel}
                    </Text>
                  </View>
                  <View style={[styles.traderRank, { flexDirection: flexDir }]}>
                    <Text style={[styles.traderName, { writingDirection: direction }]}>{trader.name}</Text>
                    <View style={[styles.rankBadge, i === 0 && styles.rankBadgeGold, i === 1 && styles.rankBadgeSilver, i === 2 && styles.rankBadgeBronze]}>
                      <Text style={styles.rankText}>#{i + 1}</Text>
                    </View>
                  </View>
                </View>
              ))
            )}
          </GoldCard>

          {/* Portfolio Stats */}
          <Text style={[styles.sectionTitle, { textAlign, writingDirection: direction }]}>{portfolioStatsLabel}</Text>
          <GoldCard>
            <View style={[styles.portfolioStatsRow, { flexDirection: flexDir }]}>
              <View style={styles.portfolioStatItem}>
                <Text style={styles.portfolioStatValue}>{portfolios.length}</Text>
                <Text style={[styles.portfolioStatLabel, { writingDirection: direction }]}>{totalPortfoliosLabel}</Text>
              </View>
              <View style={styles.portfolioStatDivider} />
              <View style={styles.portfolioStatItem}>
                <Text style={styles.portfolioStatValue}>{purchasesList.length}</Text>
                <Text style={[styles.portfolioStatLabel, { writingDirection: direction }]}>{totalPurchasesLabel}</Text>
              </View>
              <View style={styles.portfolioStatDivider} />
              <View style={styles.portfolioStatItem}>
                <Text style={styles.portfolioStatValue}>{activeAlerts}</Text>
                <Text style={[styles.portfolioStatLabel, { writingDirection: direction }]}>{activeAlertsLabel}</Text>
              </View>
            </View>
          </GoldCard>

          <View style={{ height: 40 }} />
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#001F3F' },
  safeArea: { flex: 1 },
  appBar: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 12,
    borderBottomWidth: 1, borderBottomColor: 'rgba(248,249,250,0.08)',
  },
  appBarTitle: { fontSize: 18, fontWeight: '700', color: '#F8F9FA' },
  menuBtn: { padding: 8 },
  scrollContent: { paddingHorizontal: 16, paddingTop: 8 },

  // Period selector
  periodRow: { gap: 8, marginBottom: 16, marginTop: 8 },
  periodBtn: {
    flex: 1, paddingVertical: 10, borderRadius: 10,
    backgroundColor: 'rgba(248,249,250,0.06)', alignItems: 'center',
  },
  periodBtnActive: { backgroundColor: '#C5A021' },
  periodBtnText: { fontSize: 13, fontWeight: '600', color: '#6C737F' },
  periodBtnTextActive: { color: '#001F3F' },

  sectionTitle: { fontSize: 16, fontWeight: '700', color: '#F8F9FA', marginBottom: 12, marginTop: 20 },

  // Stats grid
  statsGrid: { gap: 10, marginBottom: 4 },
  statCard: { flex: 1, alignItems: 'center', paddingVertical: 16 },
  statValue: { fontSize: 22, fontWeight: '800', color: '#1A1A1B', marginTop: 8, fontVariant: ['tabular-nums'] },
  statLabel: { fontSize: 11, color: '#6C737F', marginTop: 4, textAlign: 'center' },

  // Chart
  chartContainer: { flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-around', height: 160, paddingTop: 10 },
  barCol: { alignItems: 'center', flex: 1 },
  barValue: { fontSize: 9, color: '#6C737F', marginBottom: 4, fontVariant: ['tabular-nums'] },
  barTrack: { width: 24, height: 100, backgroundColor: 'rgba(0,31,63,0.06)', borderRadius: 6, justifyContent: 'flex-end', overflow: 'hidden' },
  barFill: { width: '100%', backgroundColor: '#C5A021', borderRadius: 6, minHeight: 2 },
  barLabel: { fontSize: 10, color: '#6C737F', marginTop: 6 },

  // Legend
  legendRow: { gap: 16, justifyContent: 'center', marginTop: 12, paddingTop: 10, borderTopWidth: 1, borderTopColor: '#E6E8EA' },
  legendItem: { alignItems: 'center', gap: 6 },
  legendDot: { width: 10, height: 10, borderRadius: 5 },
  legendText: { fontSize: 11, color: '#6C737F' },

  // Status
  statusRow: { alignItems: 'center', gap: 10, marginBottom: 12 },
  statusBarContainer: { flex: 1 },
  statusBarBg: { height: 20, borderRadius: 10, overflow: 'hidden' },
  statusBarFill: { height: '100%', borderRadius: 10, minWidth: 4 },
  statusLabel: { fontSize: 12, fontWeight: '600', color: '#1A1A1B', minWidth: 70, textAlign: 'right' },
  statusCount: { fontSize: 14, fontWeight: '700', minWidth: 30, textAlign: 'center', fontVariant: ['tabular-nums'] },

  // Top traders
  traderRow: { alignItems: 'center', paddingVertical: 12, gap: 10 },
  traderRowBorder: { borderBottomWidth: 1, borderBottomColor: '#E6E8EA' },
  traderRank: { alignItems: 'center', gap: 8 },
  traderName: { fontSize: 14, fontWeight: '600', color: '#1A1A1B' },
  traderInfo: { flex: 1 },
  traderRevenue: { fontSize: 12, color: '#6C737F', fontVariant: ['tabular-nums'] },
  rankBadge: { width: 28, height: 28, borderRadius: 14, backgroundColor: '#E5E7EB', alignItems: 'center', justifyContent: 'center' },
  rankBadgeGold: { backgroundColor: '#C5A021' },
  rankBadgeSilver: { backgroundColor: '#94A3B8' },
  rankBadgeBronze: { backgroundColor: '#D97706' },
  rankText: { fontSize: 11, fontWeight: '700', color: '#FFF' },

  // Portfolio stats
  portfolioStatsRow: { alignItems: 'center' },
  portfolioStatItem: { flex: 1, alignItems: 'center', paddingVertical: 8 },
  portfolioStatValue: { fontSize: 20, fontWeight: '800', color: '#1A1A1B', fontVariant: ['tabular-nums'] },
  portfolioStatLabel: { fontSize: 11, color: '#6C737F', marginTop: 4 },
  portfolioStatDivider: { width: 1, height: 36, backgroundColor: '#E6E8EA' },

  // Empty
  emptyText: { fontSize: 14, color: '#6C737F', paddingVertical: 20 },
});
