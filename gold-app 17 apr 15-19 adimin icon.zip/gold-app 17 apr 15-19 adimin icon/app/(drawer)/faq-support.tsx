import React, { useState, useCallback } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, TextInput, Alert, Platform, Linking } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { GoldCard } from '@/components/gold/GoldCard';
import { useI18n } from '@/i18n';

interface FAQSupportScreenProps {
  onOpenDrawer: () => void;
}

interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category: string;
}

export default function FAQSupportScreen({ onOpenDrawer }: FAQSupportScreenProps) {
  const { isRTL, textAlign, direction, flexDir, lang } = useI18n();
  const [expandedFAQ, setExpandedFAQ] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'faq' | 'contact'>('faq');
  const [searchQuery, setSearchQuery] = useState('');
  const [contactName, setContactName] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [contactSubject, setContactSubject] = useState('');
  const [contactMessage, setContactMessage] = useState('');
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);

  // Translations
  const title = lang === 'ar' ? 'المساعدة والدعم' : lang === 'fr' ? 'Aide & Support' : 'Help & Support';
  const faqTab = lang === 'ar' ? 'الأسئلة الشائعة' : lang === 'fr' ? 'FAQ' : 'FAQ';
  const contactTab = lang === 'ar' ? 'تواصل معنا' : lang === 'fr' ? 'Contactez-nous' : 'Contact Us';
  const searchPlaceholder = lang === 'ar' ? 'ابحث في الأسئلة...' : lang === 'fr' ? 'Rechercher...' : 'Search questions...';
  const nameLabel = lang === 'ar' ? 'الاسم' : lang === 'fr' ? 'Nom' : 'Name';
  const emailLabel = lang === 'ar' ? 'البريد الإلكتروني' : lang === 'fr' ? 'Email' : 'Email';
  const subjectLabel = lang === 'ar' ? 'الموضوع' : lang === 'fr' ? 'Sujet' : 'Subject';
  const messageLabel = lang === 'ar' ? 'الرسالة' : lang === 'fr' ? 'Message' : 'Message';
  const sendBtn = lang === 'ar' ? 'إرسال' : lang === 'fr' ? 'Envoyer' : 'Send';
  const sendingLabel = lang === 'ar' ? 'جاري الإرسال...' : lang === 'fr' ? 'Envoi en cours...' : 'Sending...';
  const sentSuccess = lang === 'ar' ? 'تم إرسال رسالتك بنجاح! سنتواصل معك قريباً.' : lang === 'fr' ? 'Votre message a été envoyé ! Nous vous contacterons bientôt.' : 'Your message has been sent! We will contact you soon.';
  const sentTitle = lang === 'ar' ? 'تم الإرسال' : lang === 'fr' ? 'Envoyé' : 'Sent';
  const fillAllFields = lang === 'ar' ? 'يرجى ملء جميع الحقول' : lang === 'fr' ? 'Veuillez remplir tous les champs' : 'Please fill in all fields';
  const noResults = lang === 'ar' ? 'لا توجد نتائج' : lang === 'fr' ? 'Aucun résultat' : 'No results found';
  const callUs = lang === 'ar' ? 'اتصل بنا' : lang === 'fr' ? 'Appelez-nous' : 'Call Us';
  const emailUs = lang === 'ar' ? 'راسلنا' : lang === 'fr' ? 'Envoyez un email' : 'Email Us';
  const workingHours = lang === 'ar' ? 'ساعات العمل' : lang === 'fr' ? 'Heures de travail' : 'Working Hours';
  const workingHoursValue = lang === 'ar' ? 'الأحد - الخميس، 9 ص - 5 م' : lang === 'fr' ? 'Dim - Jeu, 9h - 17h' : 'Sun - Thu, 9 AM - 5 PM';
  const sendAnother = lang === 'ar' ? 'إرسال رسالة أخرى' : lang === 'fr' ? 'Envoyer un autre message' : 'Send Another Message';

  // Category labels
  const catGeneral = lang === 'ar' ? 'عام' : lang === 'fr' ? 'Général' : 'General';
  const catTrading = lang === 'ar' ? 'التداول' : lang === 'fr' ? 'Trading' : 'Trading';
  const catAccount = lang === 'ar' ? 'الحساب' : lang === 'fr' ? 'Compte' : 'Account';
  const catPayment = lang === 'ar' ? 'الدفع' : lang === 'fr' ? 'Paiement' : 'Payment';
  const catSecurity = lang === 'ar' ? 'الأمان' : lang === 'fr' ? 'Sécurité' : 'Security';

  // FAQ data
  const faqData: FAQItem[] = [
    // General
    {
      id: '1',
      category: catGeneral,
      question: lang === 'ar' ? 'ما هو تطبيق الذهب؟' : lang === 'fr' ? "Qu'est-ce que l'application Gold ?" : 'What is the Gold App?',
      answer: lang === 'ar' ? 'تطبيق الذهب هو منصة متكاملة لتتبع أسعار الذهب في الوقت الفعلي، إدارة محفظتك من الذهب، وتنفيذ عمليات البيع والشراء بسهولة.' : lang === 'fr' ? "L'application Gold est une plateforme complète pour suivre les prix de l'or en temps réel, gérer votre portefeuille d'or et effectuer des transactions facilement." : 'The Gold App is a comprehensive platform for tracking real-time gold prices, managing your gold portfolio, and executing buy/sell transactions easily.',
    },
    {
      id: '2',
      category: catGeneral,
      question: lang === 'ar' ? 'هل التطبيق مجاني؟' : lang === 'fr' ? "L'application est-elle gratuite ?" : 'Is the app free?',
      answer: lang === 'ar' ? 'نعم، التطبيق مجاني للتحميل والاستخدام. بعض الميزات المتقدمة قد تتطلب اشتراكاً.' : lang === 'fr' ? "Oui, l'application est gratuite à télécharger et à utiliser. Certaines fonctionnalités avancées peuvent nécessiter un abonnement." : 'Yes, the app is free to download and use. Some advanced features may require a subscription.',
    },
    // Trading
    {
      id: '3',
      category: catTrading,
      question: lang === 'ar' ? 'كيف أشتري الذهب من التطبيق؟' : lang === 'fr' ? "Comment acheter de l'or via l'application ?" : 'How do I buy gold through the app?',
      answer: lang === 'ar' ? 'يمكنك شراء الذهب من خلال الذهاب إلى صفحة الأسعار، اختيار العيار المطلوب، تحديد الكمية، ثم تأكيد الطلب. سيتم التواصل معك من قبل التاجر لإتمام العملية.' : lang === 'fr' ? "Vous pouvez acheter de l'or en allant sur la page des prix, en sélectionnant le carat souhaité, en spécifiant la quantité, puis en confirmant la commande." : 'You can buy gold by going to the Prices page, selecting the desired karat, specifying the quantity, and confirming the order. A trader will contact you to complete the transaction.',
    },
    {
      id: '4',
      category: catTrading,
      question: lang === 'ar' ? 'ما هي العيارات المتاحة؟' : lang === 'fr' ? 'Quels sont les carats disponibles ?' : 'What karats are available?',
      answer: lang === 'ar' ? 'نوفر عيارات 24K و22K و21K و18K. كل عيار له نسبة نقاء مختلفة وسعر مختلف.' : lang === 'fr' ? 'Nous proposons les carats 24K, 22K, 21K et 18K. Chaque carat a une pureté et un prix différents.' : 'We offer 24K, 22K, 21K, and 18K gold. Each karat has a different purity level and price.',
    },
    {
      id: '5',
      category: catTrading,
      question: lang === 'ar' ? 'كم مرة يتم تحديث الأسعار؟' : lang === 'fr' ? 'À quelle fréquence les prix sont-ils mis à jour ?' : 'How often are prices updated?',
      answer: lang === 'ar' ? 'يتم تحديث أسعار الذهب كل 30 ثانية من مصادر عالمية موثوقة لضمان دقة الأسعار.' : lang === 'fr' ? "Les prix de l'or sont mis à jour toutes les 30 secondes à partir de sources mondiales fiables." : 'Gold prices are updated every 30 seconds from reliable global sources to ensure price accuracy.',
    },
    // Account
    {
      id: '6',
      category: catAccount,
      question: lang === 'ar' ? 'كيف أنشئ حساباً جديداً؟' : lang === 'fr' ? 'Comment créer un nouveau compte ?' : 'How do I create a new account?',
      answer: lang === 'ar' ? 'اضغط على "إنشاء حساب" في شاشة تسجيل الدخول، أدخل بياناتك (الاسم، البريد الإلكتروني، كلمة المرور)، ثم تحقق من بريدك الإلكتروني.' : lang === 'fr' ? 'Appuyez sur "Créer un compte" sur l\'écran de connexion, entrez vos informations, puis vérifiez votre email.' : 'Tap "Create Account" on the login screen, enter your details (name, email, password), then verify your email.',
    },
    {
      id: '7',
      category: catAccount,
      question: lang === 'ar' ? 'نسيت كلمة المرور، ماذا أفعل؟' : lang === 'fr' ? "J'ai oublié mon mot de passe, que faire ?" : 'I forgot my password, what should I do?',
      answer: lang === 'ar' ? 'اضغط على "نسيت كلمة المرور" في شاشة تسجيل الدخول، أدخل بريدك الإلكتروني، وسنرسل لك رابط إعادة تعيين كلمة المرور.' : lang === 'fr' ? 'Appuyez sur "Mot de passe oublié" sur l\'écran de connexion et entrez votre email pour recevoir un lien de réinitialisation.' : 'Tap "Forgot Password" on the login screen, enter your email, and we\'ll send you a password reset link.',
    },
    // Payment
    {
      id: '8',
      category: catPayment,
      question: lang === 'ar' ? 'ما هي طرق الدفع المتاحة؟' : lang === 'fr' ? 'Quels sont les modes de paiement disponibles ?' : 'What payment methods are available?',
      answer: lang === 'ar' ? 'نقبل التحويل البنكي، الدفع النقدي عند الاستلام، وبطاقات الائتمان. يتم تحديد طريقة الدفع مع التاجر عند تأكيد الطلب.' : lang === 'fr' ? 'Nous acceptons les virements bancaires, le paiement en espèces à la livraison et les cartes de crédit.' : 'We accept bank transfers, cash on delivery, and credit cards. Payment method is confirmed with the trader when placing an order.',
    },
    // Security
    {
      id: '9',
      category: catSecurity,
      question: lang === 'ar' ? 'هل بياناتي آمنة؟' : lang === 'fr' ? 'Mes données sont-elles sécurisées ?' : 'Is my data secure?',
      answer: lang === 'ar' ? 'نعم، نستخدم تشفيراً متقدماً لحماية جميع بياناتك الشخصية والمالية. كما نلتزم بأعلى معايير الأمان.' : lang === 'fr' ? 'Oui, nous utilisons un cryptage avancé pour protéger toutes vos données personnelles et financières.' : 'Yes, we use advanced encryption to protect all your personal and financial data. We adhere to the highest security standards.',
    },
    {
      id: '10',
      category: catSecurity,
      question: lang === 'ar' ? 'كيف أحمي حسابي؟' : lang === 'fr' ? 'Comment protéger mon compte ?' : 'How do I protect my account?',
      answer: lang === 'ar' ? 'استخدم كلمة مرور قوية، فعّل المصادقة الثنائية إن توفرت، ولا تشارك بيانات حسابك مع أحد.' : lang === 'fr' ? "Utilisez un mot de passe fort, activez l'authentification à deux facteurs si disponible, et ne partagez pas vos identifiants." : 'Use a strong password, enable two-factor authentication if available, and never share your account credentials.',
    },
  ];

  // Filter FAQs by search
  const filteredFAQs = searchQuery.trim()
    ? faqData.filter(f =>
        f.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
        f.answer.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : faqData;

  // Group FAQs by category
  const groupedFAQs = filteredFAQs.reduce((acc, faq) => {
    if (!acc[faq.category]) acc[faq.category] = [];
    acc[faq.category].push(faq);
    return acc;
  }, {} as Record<string, FAQItem[]>);

  const toggleFAQ = (id: string) => {
    setExpandedFAQ(expandedFAQ === id ? null : id);
  };

  const handleSend = useCallback(async () => {
    if (!contactName.trim() || !contactEmail.trim() || !contactSubject.trim() || !contactMessage.trim()) {
      Alert.alert('', fillAllFields);
      return;
    }
    setSending(true);
    // Simulate sending
    await new Promise(resolve => setTimeout(resolve, 1500));
    setSending(false);
    setSent(true);
    setContactName('');
    setContactEmail('');
    setContactSubject('');
    setContactMessage('');
  }, [contactName, contactEmail, contactSubject, contactMessage, fillAllFields]);

  const handleCall = () => {
    Linking.openURL('tel:+966500000000');
  };

  const handleEmail = () => {
    Linking.openURL('mailto:support@goldapp.com');
  };

  return (
    <View style={styles.screen}>
      <SafeAreaView style={styles.safeArea} edges={['top']}>
        {/* App Bar */}
        <View style={styles.appBar}>
          <View style={{ width: 40 }} />
          <Text style={[styles.appBarTitle, { writingDirection: direction }]}>{title}</Text>
          <TouchableOpacity onPress={onOpenDrawer} style={styles.menuBtn} activeOpacity={0.7}>
            <MaterialIcons name="menu" size={24} color="#F8F9FA" />
          </TouchableOpacity>
        </View>

        {/* Tabs */}
        <View style={[styles.tabRow, { flexDirection: flexDir }]}>
          <TouchableOpacity
            style={[styles.tab, activeTab === 'faq' && styles.tabActive]}
            onPress={() => setActiveTab('faq')}
            activeOpacity={0.7}
          >
            <MaterialIcons name="help-outline" size={18} color={activeTab === 'faq' ? '#C5A021' : '#6C737F'} />
            <Text style={[styles.tabText, activeTab === 'faq' && styles.tabTextActive]}>{faqTab}</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.tab, activeTab === 'contact' && styles.tabActive]}
            onPress={() => setActiveTab('contact')}
            activeOpacity={0.7}
          >
            <MaterialIcons name="mail-outline" size={18} color={activeTab === 'contact' ? '#C5A021' : '#6C737F'} />
            <Text style={[styles.tabText, activeTab === 'contact' && styles.tabTextActive]}>{contactTab}</Text>
          </TouchableOpacity>
        </View>

        <ScrollView style={styles.content} contentContainerStyle={styles.contentContainer}>
          {activeTab === 'faq' ? (
            <>
              {/* Search */}
              <View style={[styles.searchBar, { flexDirection: flexDir }]}>
                <MaterialIcons name="search" size={20} color="#6C737F" style={isRTL ? { marginLeft: 8 } : { marginRight: 8 }} />
                <TextInput
                  value={searchQuery}
                  onChangeText={setSearchQuery}
                  placeholder={searchPlaceholder}
                  placeholderTextColor="#6C737F"
                  style={[styles.searchInput, { textAlign, writingDirection: direction }]}
                />
                {searchQuery.length > 0 && (
                  <TouchableOpacity onPress={() => setSearchQuery('')} activeOpacity={0.7}>
                    <MaterialIcons name="close" size={18} color="#6C737F" />
                  </TouchableOpacity>
                )}
              </View>

              {/* FAQ List */}
              {Object.keys(groupedFAQs).length === 0 ? (
                <View style={styles.emptyContainer}>
                  <MaterialIcons name="search-off" size={48} color="#6C737F" />
                  <Text style={styles.emptyText}>{noResults}</Text>
                </View>
              ) : (
                Object.entries(groupedFAQs).map(([category, faqs]) => (
                  <View key={category} style={styles.categorySection}>
                    <Text style={[styles.categoryTitle, { textAlign, writingDirection: direction }]}>{category}</Text>
                    {faqs.map(faq => (
                      <TouchableOpacity
                        key={faq.id}
                        style={styles.faqItem}
                        onPress={() => toggleFAQ(faq.id)}
                        activeOpacity={0.7}
                      >
                        <View style={[styles.faqHeader, { flexDirection: flexDir }]}>
                          <MaterialIcons
                            name={expandedFAQ === faq.id ? 'expand-less' : 'expand-more'}
                            size={24}
                            color="#C5A021"
                          />
                          <Text style={[styles.faqQuestion, { textAlign, writingDirection: direction, flex: 1 }]}>
                            {faq.question}
                          </Text>
                        </View>
                        {expandedFAQ === faq.id && (
                          <Text style={[styles.faqAnswer, { textAlign, writingDirection: direction }]}>
                            {faq.answer}
                          </Text>
                        )}
                      </TouchableOpacity>
                    ))}
                  </View>
                ))
              )}
            </>
          ) : (
            <>
              {sent ? (
                <View style={styles.sentContainer}>
                  <View style={styles.sentIconCircle}>
                    <MaterialIcons name="check-circle" size={64} color="#22C55E" />
                  </View>
                  <Text style={[styles.sentTitle, { textAlign }]}>{sentTitle}</Text>
                  <Text style={[styles.sentMessage, { textAlign, writingDirection: direction }]}>{sentSuccess}</Text>
                  <TouchableOpacity
                    style={styles.sendAnotherBtn}
                    onPress={() => setSent(false)}
                    activeOpacity={0.7}
                  >
                    <Text style={styles.sendAnotherText}>{sendAnother}</Text>
                  </TouchableOpacity>
                </View>
              ) : (
                <>
                  {/* Quick Contact Options */}
                  <View style={[styles.quickContactRow, { flexDirection: flexDir }]}>
                    <TouchableOpacity style={styles.quickContactCard} onPress={handleCall} activeOpacity={0.7}>
                      <View style={styles.quickContactIcon}>
                        <MaterialIcons name="phone" size={24} color="#C5A021" />
                      </View>
                      <Text style={styles.quickContactLabel}>{callUs}</Text>
                      <Text style={styles.quickContactValue}>+966 50 000 0000</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.quickContactCard} onPress={handleEmail} activeOpacity={0.7}>
                      <View style={styles.quickContactIcon}>
                        <MaterialIcons name="email" size={24} color="#C5A021" />
                      </View>
                      <Text style={styles.quickContactLabel}>{emailUs}</Text>
                      <Text style={styles.quickContactValue}>support@goldapp.com</Text>
                    </TouchableOpacity>
                  </View>

                  {/* Working Hours */}
                  <GoldCard>
                    <View style={[styles.workingHoursRow, { flexDirection: flexDir }]}>
                      <View style={[styles.workingHoursInfo, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
                        <Text style={[styles.workingHoursLabel, { writingDirection: direction }]}>{workingHours}</Text>
                        <Text style={[styles.workingHoursValue, { writingDirection: direction }]}>{workingHoursValue}</Text>
                      </View>
                      <MaterialIcons name="access-time" size={28} color="#C5A021" />
                    </View>
                  </GoldCard>

                  {/* Contact Form */}
                  <GoldCard>
                    <View style={styles.formContainer}>
                      <View style={styles.inputGroup}>
                        <Text style={[styles.inputLabel, { textAlign, writingDirection: direction }]}>{nameLabel}</Text>
                        <TextInput
                          value={contactName}
                          onChangeText={setContactName}
                          style={[styles.input, { textAlign, writingDirection: direction }]}
                          placeholderTextColor="#6C737F"
                        />
                      </View>
                      <View style={styles.inputGroup}>
                        <Text style={[styles.inputLabel, { textAlign, writingDirection: direction }]}>{emailLabel}</Text>
                        <TextInput
                          value={contactEmail}
                          onChangeText={setContactEmail}
                          style={[styles.input, { textAlign: 'left', writingDirection: 'ltr' }]}
                          keyboardType="email-address"
                          autoCapitalize="none"
                          placeholderTextColor="#6C737F"
                        />
                      </View>
                      <View style={styles.inputGroup}>
                        <Text style={[styles.inputLabel, { textAlign, writingDirection: direction }]}>{subjectLabel}</Text>
                        <TextInput
                          value={contactSubject}
                          onChangeText={setContactSubject}
                          style={[styles.input, { textAlign, writingDirection: direction }]}
                          placeholderTextColor="#6C737F"
                        />
                      </View>
                      <View style={styles.inputGroup}>
                        <Text style={[styles.inputLabel, { textAlign, writingDirection: direction }]}>{messageLabel}</Text>
                        <TextInput
                          value={contactMessage}
                          onChangeText={setContactMessage}
                          style={[styles.textArea, { textAlign, writingDirection: direction }]}
                          multiline
                          numberOfLines={5}
                          textAlignVertical="top"
                          placeholderTextColor="#6C737F"
                        />
                      </View>
                      <TouchableOpacity
                        style={[styles.sendButton, sending && styles.sendButtonDisabled]}
                        onPress={handleSend}
                        disabled={sending}
                        activeOpacity={0.7}
                      >
                        {sending ? (
                          <Text style={styles.sendButtonText}>{sendingLabel}</Text>
                        ) : (
                          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                            <MaterialIcons name="send" size={18} color="#0A0A0B" style={isRTL ? { transform: [{ scaleX: -1 }] } : undefined} />
                            <Text style={styles.sendButtonText}>{sendBtn}</Text>
                          </View>
                        )}
                      </TouchableOpacity>
                    </View>
                  </GoldCard>
                </>
              )}
            </>
          )}
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#0A0A0B' },
  safeArea: { flex: 1 },
  appBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(197,160,33,0.15)',
  },
  appBarTitle: { fontSize: 18, fontWeight: '700', color: '#F8F9FA' },
  menuBtn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center', borderRadius: 20, backgroundColor: 'rgba(197,160,33,0.1)' },
  tabRow: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    paddingVertical: 8,
    gap: 8,
  },
  tab: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 10,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  tabActive: {
    backgroundColor: 'rgba(197,160,33,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(197,160,33,0.3)',
  },
  tabText: { fontSize: 14, fontWeight: '600', color: '#6C737F' },
  tabTextActive: { color: '#C5A021' },
  content: { flex: 1 },
  contentContainer: { padding: 16, paddingBottom: 40 },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 12,
    paddingHorizontal: 12,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: 'rgba(197,160,33,0.15)',
  },
  searchInput: { flex: 1, paddingVertical: 12, fontSize: 14, color: '#F8F9FA' },
  categorySection: { marginBottom: 20 },
  categoryTitle: {
    fontSize: 15,
    fontWeight: '700',
    color: '#C5A021',
    marginBottom: 8,
    paddingHorizontal: 4,
  },
  faqItem: {
    backgroundColor: 'rgba(255,255,255,0.04)',
    borderRadius: 12,
    padding: 14,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: 'rgba(197,160,33,0.1)',
  },
  faqHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  faqQuestion: {
    fontSize: 14,
    fontWeight: '600',
    color: '#F8F9FA',
    lineHeight: 22,
  },
  faqAnswer: {
    fontSize: 13,
    color: '#9BA1A6',
    lineHeight: 22,
    marginTop: 10,
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: 'rgba(197,160,33,0.1)',
    paddingHorizontal: 32,
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
    gap: 12,
  },
  emptyText: { fontSize: 15, color: '#6C737F' },
  quickContactRow: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 16,
  },
  quickContactCard: {
    flex: 1,
    backgroundColor: 'rgba(255,255,255,0.04)',
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
    gap: 8,
    borderWidth: 1,
    borderColor: 'rgba(197,160,33,0.15)',
  },
  quickContactIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(197,160,33,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  quickContactLabel: { fontSize: 13, fontWeight: '600', color: '#F8F9FA' },
  quickContactValue: { fontSize: 11, color: '#9BA1A6' },
  workingHoursRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  workingHoursInfo: { gap: 4 },
  workingHoursLabel: { fontSize: 14, fontWeight: '600', color: '#F8F9FA' },
  workingHoursValue: { fontSize: 13, color: '#C5A021' },
  formContainer: { gap: 14 },
  inputGroup: { gap: 6 },
  inputLabel: { fontSize: 13, fontWeight: '600', color: '#9BA1A6' },
  input: {
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 14,
    color: '#F8F9FA',
    borderWidth: 1,
    borderColor: 'rgba(197,160,33,0.15)',
  },
  textArea: {
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 14,
    color: '#F8F9FA',
    borderWidth: 1,
    borderColor: 'rgba(197,160,33,0.15)',
    minHeight: 120,
  },
  sendButton: {
    backgroundColor: '#C5A021',
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 4,
  },
  sendButtonDisabled: { opacity: 0.6 },
  sendButtonText: { fontSize: 15, fontWeight: '700', color: '#0A0A0B' },
  sentContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
    gap: 16,
  },
  sentIconCircle: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: 'rgba(34,197,94,0.1)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  sentTitle: { fontSize: 22, fontWeight: '700', color: '#F8F9FA' },
  sentMessage: { fontSize: 14, color: '#9BA1A6', lineHeight: 22, paddingHorizontal: 20 },
  sendAnotherBtn: {
    backgroundColor: 'rgba(197,160,33,0.15)',
    borderRadius: 12,
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderWidth: 1,
    borderColor: 'rgba(197,160,33,0.3)',
    marginTop: 8,
  },
  sendAnotherText: { fontSize: 14, fontWeight: '600', color: '#C5A021' },
});
