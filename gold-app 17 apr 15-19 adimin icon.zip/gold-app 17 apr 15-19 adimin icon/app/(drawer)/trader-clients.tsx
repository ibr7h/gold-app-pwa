import React, { useState, useMemo, useCallback } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, FlatList, TextInput, Alert, Platform, Modal, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { GoldCard } from '@/components/gold/GoldCard';
import { useI18n } from '@/i18n';
import { useSettings } from '@/contexts/SettingsContext';
import { useTraderData, type TraderClient } from '@/contexts/TraderDataContext';
import { exportClients } from '@/services/ExportService';
import { useTraderPermissions } from '@/hooks/useTraderPermissions';

interface TraderClientsScreenProps {
  onOpenDrawer: () => void;
  onNavigate?: (screen: string) => void;
}

export default function TraderClientsScreen({ onOpenDrawer, onNavigate }: TraderClientsScreenProps) {
  const { isRTL, textAlign, direction, flexDir, lang } = useI18n();
  const { settings } = useSettings();
  const { clients, orders, updateClient, deleteClient } = useTraderData();
  const { permissions } = useTraderPermissions();
  const [filter, setFilter] = useState<'all' | 'active' | 'inactive'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [editingClient, setEditingClient] = useState<TraderClient | null>(null);
  const [editName, setEditName] = useState('');
  const [editEmail, setEditEmail] = useState('');
  const [editPhone, setEditPhone] = useState('');
  const [editError, setEditError] = useState('');

  // Translations
  const titleLabel = lang === 'ar' ? 'العملاء' : lang === 'fr' ? 'Clients' : 'Clients';
  const allLabel = lang === 'ar' ? 'الكل' : lang === 'fr' ? 'Tous' : 'All';
  const activeLabel = lang === 'ar' ? 'نشط' : lang === 'fr' ? 'Actif' : 'Active';
  const inactiveLabel = lang === 'ar' ? 'غير نشط' : lang === 'fr' ? 'Inactif' : 'Inactive';
  const ordersLabel = lang === 'ar' ? 'طلبات' : lang === 'fr' ? 'commandes' : 'orders';
  const totalSpentLabel = lang === 'ar' ? 'إجمالي المشتريات' : lang === 'fr' ? 'Total dépensé' : 'Total Spent';
  const lastOrderLabel = lang === 'ar' ? 'آخر طلب' : lang === 'fr' ? 'Dernière commande' : 'Last Order';
  const noClients = lang === 'ar' ? 'لا يوجد عملاء' : lang === 'fr' ? 'Aucun client' : 'No clients';
  const summaryLabel = lang === 'ar' ? 'ملخص العملاء' : lang === 'fr' ? 'Résumé clients' : 'Client Summary';
  const totalClientsLabel = lang === 'ar' ? 'إجمالي العملاء' : lang === 'fr' ? 'Total clients' : 'Total Clients';
  const activeClientsLabel = lang === 'ar' ? 'عملاء نشطون' : lang === 'fr' ? 'Clients actifs' : 'Active Clients';
  const totalRevenueLabel = lang === 'ar' ? 'إجمالي الإيرادات' : lang === 'fr' ? 'Revenus totaux' : 'Total Revenue';
  const searchPlaceholder = lang === 'ar' ? 'بحث بالاسم أو البريد أو الهاتف...' : lang === 'fr' ? 'Rechercher par nom, email ou tél...' : 'Search by name, email or phone...';
  const noResults = lang === 'ar' ? 'لا توجد نتائج' : lang === 'fr' ? 'Aucun résultat' : 'No results found';
  const editClientLabel = lang === 'ar' ? 'تعديل العميل' : lang === 'fr' ? 'Modifier le client' : 'Edit Client';
  const deleteClientLabel = lang === 'ar' ? 'حذف العميل' : lang === 'fr' ? 'Supprimer le client' : 'Delete Client';
  const deleteConfirmMsg = lang === 'ar' ? 'هل أنت متأكد من حذف هذا العميل؟' : lang === 'fr' ? 'Êtes-vous sûr de vouloir supprimer ce client ?' : 'Are you sure you want to delete this client?';
  const nameLabel = lang === 'ar' ? 'الاسم' : lang === 'fr' ? 'Nom' : 'Name';
  const emailLabel = lang === 'ar' ? 'البريد الإلكتروني' : lang === 'fr' ? 'Email' : 'Email';
  const phoneLabel = lang === 'ar' ? 'الهاتف' : lang === 'fr' ? 'Téléphone' : 'Phone';
  const saveLabel = lang === 'ar' ? 'حفظ' : lang === 'fr' ? 'Enregistrer' : 'Save';
  const cancelLabel = lang === 'ar' ? 'إلغاء' : lang === 'fr' ? 'Annuler' : 'Cancel';
  const deactivateLabel = lang === 'ar' ? 'تعطيل' : lang === 'fr' ? 'Désactiver' : 'Deactivate';
  const activateLabel = lang === 'ar' ? 'تفعيل' : lang === 'fr' ? 'Activer' : 'Activate';
  const requiredField = lang === 'ar' ? 'هذا الحقل مطلوب' : lang === 'fr' ? 'Champ requis' : 'This field is required';

  const currencySymbol = settings.preferredCurrency === 'USD' ? '$' : settings.preferredCurrency === 'EUR' ? '€' : settings.preferredCurrency === 'SAR' ? 'ر.س' : settings.preferredCurrency === 'AED' ? 'د.إ' : settings.preferredCurrency === 'EGP' ? 'ج.م' : '$';

  // Compute client stats from orders
  const clientStats = useMemo(() => {
    const statsMap: Record<string, { totalOrders: number; totalSpent: number; lastOrder: string }> = {};
    for (const order of orders) {
      if (!statsMap[order.clientId]) {
        statsMap[order.clientId] = { totalOrders: 0, totalSpent: 0, lastOrder: '' };
      }
      statsMap[order.clientId].totalOrders++;
      if (order.status === 'completed') {
        statsMap[order.clientId].totalSpent += order.totalAmount;
      }
      if (!statsMap[order.clientId].lastOrder || order.date > statsMap[order.clientId].lastOrder) {
        statsMap[order.clientId].lastOrder = order.date;
      }
    }
    return statsMap;
  }, [orders]);

  // Search filter
  const searchFilteredClients = useMemo(() => {
    let result = filter === 'all' ? clients : clients.filter(c => c.status === filter);
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      result = result.filter(c =>
        c.name.toLowerCase().includes(q) ||
        c.email.toLowerCase().includes(q) ||
        c.phone.includes(q)
      );
    }
    return result;
  }, [clients, filter, searchQuery]);

  const totalRevenue = Object.values(clientStats).reduce((sum, s) => sum + s.totalSpent, 0);
  const activeCount = clients.filter(c => c.status === 'active').length;

  const [exportingClients, setExportingClients] = useState(false);
  const exportSuccessMsg = lang === 'ar' ? 'تم التصدير بنجاح' : lang === 'fr' ? 'Exporté avec succès' : 'Exported successfully';

  const handleExportClients = useCallback(async () => {
    setExportingClients(true);
    const exportData = searchFilteredClients.map(c => ({
      ...c,
      totalOrders: clientStats[c.id]?.totalOrders || 0,
      totalSpent: clientStats[c.id]?.totalSpent || 0,
    }));
    const currencySymbol = settings.preferredCurrency === 'USD' ? '$' : settings.preferredCurrency === 'EUR' ? '€' : settings.preferredCurrency === 'SAR' ? 'ر.س' : settings.preferredCurrency === 'AED' ? 'د.إ' : settings.preferredCurrency === 'EGP' ? 'ج.م' : '$';
    const success = await exportClients(exportData, lang, currencySymbol);
    if (success && Platform.OS !== 'web') {
      Alert.alert('', exportSuccessMsg);
    }
    setExportingClients(false);
  }, [searchFilteredClients, clientStats, lang, settings.preferredCurrency, exportSuccessMsg]);

  const filters: { key: 'all' | 'active' | 'inactive'; label: string; count: number }[] = [
    { key: 'all', label: allLabel, count: clients.length },
    { key: 'active', label: activeLabel, count: activeCount },
    { key: 'inactive', label: inactiveLabel, count: clients.length - activeCount },
  ];

  const openEditModal = (client: TraderClient) => {
    setEditingClient(client);
    setEditName(client.name);
    setEditEmail(client.email);
    setEditPhone(client.phone);
    setEditError('');
  };

  const handleSaveEdit = async () => {
    if (!editName.trim()) {
      setEditError(requiredField);
      return;
    }
    if (editingClient) {
      await updateClient(editingClient.id, {
        name: editName.trim(),
        email: editEmail.trim(),
        phone: editPhone.trim(),
      });
      setEditingClient(null);
    }
  };

  const handleDeleteClient = (client: TraderClient) => {
    if (Platform.OS === 'web') {
      if (confirm(deleteConfirmMsg)) {
        deleteClient(client.id);
      }
    } else {
      Alert.alert(
        deleteClientLabel,
        deleteConfirmMsg,
        [
          { text: cancelLabel, style: 'cancel' },
          { text: deleteClientLabel, style: 'destructive', onPress: () => deleteClient(client.id) },
        ]
      );
    }
  };

  const handleToggleStatus = async (client: TraderClient) => {
    const newStatus = client.status === 'active' ? 'inactive' : 'active';
    await updateClient(client.id, { status: newStatus });
  };

  const renderClient = ({ item }: { item: TraderClient }) => {
    const cs = clientStats[item.id] || { totalOrders: 0, totalSpent: 0, lastOrder: '-' };
    return (
      <GoldCard>
        <View style={[styles.clientHeader, { flexDirection: flexDir }]}>
          <View style={[styles.statusDot, { backgroundColor: item.status === 'active' ? '#22C55E' : '#6C737F' }]} />
          <View style={[styles.clientInfo, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
            <Text style={[styles.clientName, { writingDirection: direction }]}>{item.name}</Text>
            <Text style={[styles.clientEmail, { writingDirection: direction }]}>{item.email}</Text>
            <Text style={[styles.clientPhone, { writingDirection: direction }]}>{item.phone}</Text>
          </View>
          <View style={styles.avatarCircle}>
            <Text style={styles.avatarText}>{item.name.charAt(0)}</Text>
          </View>
        </View>

        <View style={styles.divider} />

        <View style={[styles.clientStats, { flexDirection: flexDir }]}>
          <View style={styles.statItem}>
            <Text style={[styles.statLabel, { writingDirection: direction }]}>{ordersLabel}</Text>
            <Text style={styles.statValue}>{cs.totalOrders}</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <Text style={[styles.statLabel, { writingDirection: direction }]}>{totalSpentLabel}</Text>
            <Text style={styles.statValue}>{currencySymbol} {cs.totalSpent.toLocaleString()}</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <Text style={[styles.statLabel, { writingDirection: direction }]}>{lastOrderLabel}</Text>
            <Text style={styles.statValue}>{cs.lastOrder || '-'}</Text>
          </View>
        </View>

        <View style={[styles.clientActions, { flexDirection: flexDir }]}>
          <TouchableOpacity style={styles.actionBtnIcon} activeOpacity={0.7} onPress={() => onNavigate?.('new-order')}>
            <MaterialIcons name="add-shopping-cart" size={18} color="#C5A021" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.actionBtnIcon} activeOpacity={0.7} onPress={() => handleToggleStatus(item)}>
            <MaterialIcons name={item.status === 'active' ? 'pause-circle-outline' : 'play-circle-outline'} size={18} color={item.status === 'active' ? '#F59E0B' : '#22C55E'} />
          </TouchableOpacity>
          {permissions.canEditClients && (
            <TouchableOpacity style={styles.actionBtnIcon} activeOpacity={0.7} onPress={() => openEditModal(item)}>
              <MaterialIcons name="edit" size={18} color="#3B82F6" />
            </TouchableOpacity>
          )}
          {permissions.canDeleteClients && (
            <TouchableOpacity style={styles.actionBtnIcon} activeOpacity={0.7} onPress={() => handleDeleteClient(item)}>
              <MaterialIcons name="delete" size={18} color="#EF4444" />
            </TouchableOpacity>
          )}
        </View>
      </GoldCard>
    );
  };

  return (
    <View style={styles.screen}>
      <SafeAreaView style={styles.safeArea} edges={['top']}>
        {/* App Bar */}
        <View style={styles.appBar}>
          <View style={{ flexDirection: 'row', gap: 4 }}>
            {permissions.canCreateClients && (
              <TouchableOpacity style={styles.addBtn} activeOpacity={0.7} onPress={() => onNavigate?.('new-client')}>
                <MaterialIcons name="person-add" size={24} color="#C5A021" />
              </TouchableOpacity>
            )}
            <TouchableOpacity style={styles.addBtn} activeOpacity={0.7} onPress={handleExportClients} disabled={exportingClients}>
              <MaterialIcons name="file-download" size={22} color={exportingClients ? '#6C737F' : '#C5A021'} />
            </TouchableOpacity>
          </View>
          <Text style={[styles.appBarTitle, { writingDirection: direction }]}>{titleLabel}</Text>
          <TouchableOpacity onPress={onOpenDrawer} style={styles.menuBtn} activeOpacity={0.7}>
            <MaterialIcons name="menu" size={24} color="#F8F9FA" />
          </TouchableOpacity>
        </View>

        {/* Search Bar */}
        <View style={styles.searchContainer}>
          <View style={[styles.searchBar, { flexDirection: flexDir }]}>
            <MaterialIcons name="search" size={20} color="#6C737F" style={isRTL ? { marginLeft: 8 } : { marginRight: 8 }} />
            <TextInput
              value={searchQuery}
              onChangeText={setSearchQuery}
              placeholder={searchPlaceholder}
              placeholderTextColor="#6C737F"
              style={[styles.searchInput, { textAlign, writingDirection: direction }]}
              returnKeyType="search"
            />
            {searchQuery.length > 0 && (
              <TouchableOpacity onPress={() => setSearchQuery('')} activeOpacity={0.7}>
                <MaterialIcons name="close" size={18} color="#6C737F" />
              </TouchableOpacity>
            )}
          </View>
        </View>

        {/* Summary Card */}
        <View style={styles.summaryContainer}>
          <GoldCard>
            <Text style={[styles.summaryTitle, { textAlign, writingDirection: direction }]}>{summaryLabel}</Text>
            <View style={[styles.summaryRow, { flexDirection: flexDir }]}>
              <View style={styles.summaryItem}>
                <MaterialIcons name="people" size={22} color="#3B82F6" />
                <Text style={styles.summaryValue}>{clients.length}</Text>
                <Text style={[styles.summaryLabel, { writingDirection: direction }]}>{totalClientsLabel}</Text>
              </View>
              <View style={styles.summaryDividerLine} />
              <View style={styles.summaryItem}>
                <MaterialIcons name="check-circle" size={22} color="#22C55E" />
                <Text style={styles.summaryValue}>{activeCount}</Text>
                <Text style={[styles.summaryLabel, { writingDirection: direction }]}>{activeClientsLabel}</Text>
              </View>
              <View style={styles.summaryDividerLine} />
              <View style={styles.summaryItem}>
                <MaterialIcons name="account-balance-wallet" size={22} color="#C5A021" />
                <Text style={styles.summaryValue}>{currencySymbol} {(totalRevenue / 1000).toFixed(0)}K</Text>
                <Text style={[styles.summaryLabel, { writingDirection: direction }]}>{totalRevenueLabel}</Text>
              </View>
            </View>
          </GoldCard>
        </View>

        {/* Filter Chips */}
        <View style={styles.filterRow}>
          {filters.map(f => (
            <TouchableOpacity
              key={f.key}
              style={[styles.filterChip, filter === f.key && styles.filterChipActive]}
              onPress={() => setFilter(f.key)}
              activeOpacity={0.7}
            >
              <Text style={[styles.filterChipText, filter === f.key && styles.filterChipTextActive]}>
                {f.label} ({f.count})
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Results count */}
        {searchQuery.trim() && (
          <View style={styles.resultsCount}>
            <Text style={[styles.resultsText, { textAlign, writingDirection: direction }]}>
              {searchFilteredClients.length} {lang === 'ar' ? 'نتيجة' : lang === 'fr' ? 'résultat(s)' : 'result(s)'}
            </Text>
          </View>
        )}

        {/* Clients List */}
        <FlatList
          data={searchFilteredClients}
          keyExtractor={item => item.id}
          renderItem={renderClient}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={
            <View style={styles.emptyState}>
              <MaterialIcons name={searchQuery ? 'search-off' : 'people-outline'} size={48} color="#6C737F" />
              <Text style={styles.emptyText}>{searchQuery ? noResults : noClients}</Text>
            </View>
          }
        />
      </SafeAreaView>

      {/* Edit Client Modal */}
      <Modal visible={!!editingClient} transparent animationType="fade" onRequestClose={() => setEditingClient(null)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <ScrollView showsVerticalScrollIndicator={false}>
              <Text style={[styles.modalTitle, { textAlign, writingDirection: direction }]}>{editClientLabel}</Text>

              <Text style={[styles.fieldLabel, { textAlign, writingDirection: direction }]}>{nameLabel}</Text>
              <TextInput
                value={editName}
                onChangeText={(t) => { setEditName(t); setEditError(''); }}
                style={[styles.modalInput, { textAlign, writingDirection: direction }]}
                placeholder={nameLabel}
                placeholderTextColor="#6C737F"
              />

              <Text style={[styles.fieldLabel, { textAlign, writingDirection: direction }]}>{emailLabel}</Text>
              <TextInput
                value={editEmail}
                onChangeText={setEditEmail}
                style={[styles.modalInput, { textAlign, writingDirection: direction }]}
                placeholder={emailLabel}
                placeholderTextColor="#6C737F"
                keyboardType="email-address"
                autoCapitalize="none"
              />

              <Text style={[styles.fieldLabel, { textAlign, writingDirection: direction }]}>{phoneLabel}</Text>
              <TextInput
                value={editPhone}
                onChangeText={setEditPhone}
                style={[styles.modalInput, { textAlign, writingDirection: direction }]}
                placeholder={phoneLabel}
                placeholderTextColor="#6C737F"
                keyboardType="phone-pad"
              />

              {editError ? <Text style={styles.errorText}>{editError}</Text> : null}

              <View style={[styles.modalActions, { flexDirection: flexDir }]}>
                <TouchableOpacity style={styles.cancelBtn} onPress={() => setEditingClient(null)} activeOpacity={0.7}>
                  <Text style={styles.cancelBtnText}>{cancelLabel}</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.saveBtn} onPress={handleSaveEdit} activeOpacity={0.7}>
                  <Text style={styles.saveBtnText}>{saveLabel}</Text>
                </TouchableOpacity>
              </View>
            </ScrollView>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#001F3F' },
  safeArea: { flex: 1 },
  appBar: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 12,
    borderBottomWidth: 1, borderBottomColor: 'rgba(248,249,250,0.08)',
  },
  appBarTitle: { fontSize: 18, fontWeight: '700', color: '#F8F9FA' },
  menuBtn: { padding: 8 },
  addBtn: { padding: 8 },
  listContent: { paddingHorizontal: 16, paddingBottom: 32 },

  // Search
  searchContainer: { paddingHorizontal: 16, paddingTop: 10, paddingBottom: 4 },
  searchBar: {
    backgroundColor: 'rgba(248,249,250,0.08)',
    borderRadius: 12, borderWidth: 1, borderColor: 'rgba(248,249,250,0.1)',
    paddingHorizontal: 14, paddingVertical: 10,
    alignItems: 'center',
  },
  searchInput: { flex: 1, fontSize: 14, color: '#F8F9FA', padding: 0 },

  // Results count
  resultsCount: { paddingHorizontal: 20, paddingVertical: 4 },
  resultsText: { fontSize: 12, color: '#6C737F' },

  // Summary
  summaryContainer: { paddingHorizontal: 16, paddingTop: 8 },
  summaryTitle: { fontSize: 14, fontWeight: '600', color: '#1A1A1B', marginBottom: 12 },
  summaryRow: { justifyContent: 'space-around', alignItems: 'center' },
  summaryItem: { alignItems: 'center', gap: 4 },
  summaryValue: { fontSize: 18, fontWeight: '700', color: '#1A1A1B' },
  summaryLabel: { fontSize: 11, color: '#6C737F' },
  summaryDividerLine: { width: 1, height: 40, backgroundColor: '#E6E8EA' },

  // Filters
  filterRow: { flexDirection: 'row', paddingHorizontal: 16, paddingVertical: 8, gap: 8 },
  filterChip: {
    paddingHorizontal: 16, paddingVertical: 8, borderRadius: 20,
    backgroundColor: 'rgba(248,249,250,0.06)',
    borderWidth: 1, borderColor: 'rgba(248,249,250,0.1)',
  },
  filterChipActive: {
    backgroundColor: 'rgba(197,160,33,0.15)', borderColor: '#C5A021',
  },
  filterChipText: { fontSize: 13, fontWeight: '500', color: '#6C737F' },
  filterChipTextActive: { color: '#C5A021', fontWeight: '600' },

  // Client Card
  clientHeader: { justifyContent: 'space-between', alignItems: 'center' },
  clientInfo: { flex: 1 },
  clientName: { fontSize: 15, fontWeight: '600', color: '#1A1A1B' },
  clientEmail: { fontSize: 12, color: '#6C737F', marginTop: 2 },
  clientPhone: { fontSize: 12, color: '#6C737F', marginTop: 1 },
  avatarCircle: {
    width: 40, height: 40, borderRadius: 20,
    backgroundColor: 'rgba(197,160,33,0.15)',
    alignItems: 'center', justifyContent: 'center',
  },
  avatarText: { fontSize: 16, fontWeight: '700', color: '#C5A021' },
  statusDot: { width: 8, height: 8, borderRadius: 4, marginHorizontal: 8 },
  divider: { height: 1, backgroundColor: '#E6E8EA', marginVertical: 10 },

  // Stats
  clientStats: { justifyContent: 'space-between', alignItems: 'center' },
  statItem: { alignItems: 'center', gap: 2, flex: 1 },
  statLabel: { fontSize: 10, color: '#6C737F' },
  statValue: { fontSize: 13, fontWeight: '600', color: '#1A1A1B' },
  statDivider: { width: 1, height: 30, backgroundColor: '#E6E8EA' },

  // Actions
  clientActions: { justifyContent: 'center', gap: 12, marginTop: 10, paddingTop: 10, borderTopWidth: 1, borderTopColor: '#E6E8EA' },
  actionBtnIcon: {
    width: 36, height: 36, borderRadius: 18,
    backgroundColor: 'rgba(248,249,250,0.06)',
    alignItems: 'center', justifyContent: 'center',
  },

  // Empty
  emptyState: { alignItems: 'center', paddingVertical: 60, gap: 12 },
  emptyText: { fontSize: 15, color: '#6C737F' },

  // Modal
  modalOverlay: {
    flex: 1, backgroundColor: 'rgba(0,31,63,0.85)',
    justifyContent: 'center', alignItems: 'center', padding: 24,
  },
  modalContent: {
    backgroundColor: '#FFFFFF', borderRadius: 20, padding: 24,
    width: '100%', maxWidth: 400, maxHeight: '80%',
  },
  modalTitle: { fontSize: 18, fontWeight: '700', color: '#1A1A1B', marginBottom: 20 },
  fieldLabel: { fontSize: 14, fontWeight: '600', color: '#1A1A1B', marginBottom: 8 },
  modalInput: {
    backgroundColor: '#F5F5F5', borderRadius: 12, borderWidth: 1,
    borderColor: '#E6E8EA', paddingHorizontal: 16, paddingVertical: 14,
    fontSize: 15, color: '#1A1A1B', marginBottom: 16,
  },
  errorText: { fontSize: 12, color: '#EF4444', marginBottom: 12 },
  modalActions: { gap: 12, marginTop: 8 },
  cancelBtn: {
    flex: 1, paddingVertical: 14, borderRadius: 12,
    backgroundColor: '#F5F5F5', alignItems: 'center',
  },
  cancelBtnText: { fontSize: 15, fontWeight: '600', color: '#6C737F' },
  saveBtn: {
    flex: 1, paddingVertical: 14, borderRadius: 12,
    backgroundColor: '#C5A021', alignItems: 'center',
  },
  saveBtnText: { fontSize: 15, fontWeight: '700', color: '#001F3F' },
});
