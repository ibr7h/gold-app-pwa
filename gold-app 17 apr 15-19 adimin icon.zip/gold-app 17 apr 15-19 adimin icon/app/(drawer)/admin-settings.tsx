import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet,
  ActivityIndicator, Alert, Platform, TextInput, Switch,
  Dimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { GoldButton } from '@/components/gold/GoldButton';
import { GoldCard } from '@/components/gold/GoldCard';
import { useI18n } from '@/i18n';
import { getApiBaseUrl } from '@/constants/oauth';
import * as Auth from '@/lib/_core/auth';

const SCREEN_WIDTH = Dimensions.get('window').width;

interface AdminSettingsScreenProps {
  onOpenDrawer: () => void;
  onNavigate?: (screen: string) => void;
}

interface TraderLocationAdmin {
  id: number;
  traderId: number;
  shopName: string;
  address: string;
  city: string | null;
  latitude: string;
  longitude: string;
  phone: string | null;
  whatsapp: string | null;
  workingHours: string | null;
  isVisible: boolean;
  traderName: string | null;
  traderEmail: string | null;
}

interface AdminSetting {
  id: number;
  key: string;
  value: string;
  label: string | null;
}

async function getAuthHeaders(): Promise<Record<string, string>> {
  const token = await Auth.getSessionToken();
  if (token) return { Authorization: `Bearer ${token}` };
  return {};
}

async function apiCall(path: string, method: 'GET' | 'POST' = 'GET', body?: any) {
  const baseUrl = getApiBaseUrl();
  const url = `${baseUrl}/api/trpc/${path}`;
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(await getAuthHeaders()),
  };
  const options: RequestInit = { method, headers, credentials: 'include' as any };
  if (body && method === 'POST') {
    options.body = JSON.stringify({ json: body });
  }
  const response = await fetch(url, options);
  const data = await response.json();
  if (data?.error) throw new Error(data.error.message || 'API error');
  return data?.result?.data?.json;
}

// Default contact settings keys
const CONTACT_KEYS = [
  { key: 'contact_phone_1', label: { ar: 'رقم الهاتف الأول', en: 'Primary Phone', fr: 'Téléphone principal' }, icon: 'phone' },
  { key: 'contact_phone_2', label: { ar: 'رقم الهاتف الثاني', en: 'Secondary Phone', fr: 'Téléphone secondaire' }, icon: 'phone' },
  { key: 'contact_whatsapp', label: { ar: 'واتساب', en: 'WhatsApp', fr: 'WhatsApp' }, icon: 'chat' },
  { key: 'contact_telegram', label: { ar: 'تيليجرام', en: 'Telegram', fr: 'Telegram' }, icon: 'send' },
  { key: 'contact_email', label: { ar: 'البريد الإلكتروني', en: 'Email', fr: 'Email' }, icon: 'email' },
  { key: 'support_message', label: { ar: 'رسالة الدعم', en: 'Support Message', fr: 'Message de support' }, icon: 'message' },
];

export default function AdminSettingsScreen({ onOpenDrawer, onNavigate }: AdminSettingsScreenProps) {
  const { isRTL, textAlign, direction, flexDir, lang } = useI18n();

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [activeTab, setActiveTab] = useState<'contact' | 'locations'>('contact');

  // Contact settings
  const [contactValues, setContactValues] = useState<Record<string, string>>({});
  const [originalValues, setOriginalValues] = useState<Record<string, string>>({});

  // Locations
  const [locations, setLocations] = useState<TraderLocationAdmin[]>([]);
  const [locationsLoading, setLocationsLoading] = useState(false);

  // Translations
  const tr = {
    title: lang === 'ar' ? 'إعدادات التطبيق' : lang === 'fr' ? 'Paramètres de l\'application' : 'App Settings',
    subtitle: lang === 'ar' ? 'إدارة معلومات الاتصال ومواقع التجار' : lang === 'fr' ? 'Gérer les contacts et emplacements' : 'Manage contact info and trader locations',
    contactTab: lang === 'ar' ? 'معلومات الاتصال' : lang === 'fr' ? 'Contacts' : 'Contact Info',
    locationsTab: lang === 'ar' ? 'مواقع التجار' : lang === 'fr' ? 'Emplacements' : 'Trader Locations',
    saveChanges: lang === 'ar' ? 'حفظ التغييرات' : lang === 'fr' ? 'Enregistrer' : 'Save Changes',
    saved: lang === 'ar' ? 'تم الحفظ بنجاح' : lang === 'fr' ? 'Enregistré avec succès' : 'Saved successfully',
    noChanges: lang === 'ar' ? 'لا توجد تغييرات' : lang === 'fr' ? 'Aucun changement' : 'No changes to save',
    contactDesc: lang === 'ar' ? 'هذه المعلومات ستظهر للمستخدمين والتجار في صفحة الدعم' : lang === 'fr' ? 'Ces informations seront visibles dans la page de support' : 'This information will be shown to users and traders on the support page',
    noLocations: lang === 'ar' ? 'لا توجد مواقع تجار مسجلة' : lang === 'fr' ? 'Aucun emplacement enregistré' : 'No trader locations registered',
    visible: lang === 'ar' ? 'ظاهر' : lang === 'fr' ? 'Visible' : 'Visible',
    hidden: lang === 'ar' ? 'مخفي' : lang === 'fr' ? 'Masqué' : 'Hidden',
    toggleVisibility: lang === 'ar' ? 'تبديل الظهور' : lang === 'fr' ? 'Basculer la visibilité' : 'Toggle Visibility',
    deleteLocation: lang === 'ar' ? 'حذف الموقع' : lang === 'fr' ? 'Supprimer' : 'Delete Location',
    confirmDelete: lang === 'ar' ? 'هل تريد حذف موقع هذا التاجر؟' : lang === 'fr' ? 'Supprimer cet emplacement ?' : 'Delete this trader\'s location?',
    totalTraders: lang === 'ar' ? 'إجمالي التجار' : lang === 'fr' ? 'Total commerçants' : 'Total Traders',
    visibleTraders: lang === 'ar' ? 'تجار ظاهرون' : lang === 'fr' ? 'Visibles' : 'Visible',
    hiddenTraders: lang === 'ar' ? 'تجار مخفيون' : lang === 'fr' ? 'Masqués' : 'Hidden',
  };

  // Load contact settings
  const loadSettings = useCallback(async () => {
    try {
      const settings: AdminSetting[] = await apiCall('settings.getAll');
      const values: Record<string, string> = {};
      if (settings) {
        for (const s of settings) {
          values[s.key] = s.value;
        }
      }
      setContactValues(values);
      setOriginalValues(values);
    } catch (e) {
      console.error('[AdminSettings] Load settings error:', e);
    }
  }, []);

  // Load locations
  const loadLocations = useCallback(async () => {
    setLocationsLoading(true);
    try {
      const data = await apiCall('location.adminAllLocations');
      setLocations(data || []);
    } catch (e) {
      console.error('[AdminSettings] Load locations error:', e);
    } finally {
      setLocationsLoading(false);
    }
  }, []);

  useEffect(() => {
    (async () => {
      setLoading(true);
      await loadSettings();
      setLoading(false);
    })();
  }, [loadSettings]);

  useEffect(() => {
    if (activeTab === 'locations') {
      loadLocations();
    }
  }, [activeTab, loadLocations]);

  // Save contact settings
  const handleSaveContact = async () => {
    // Check if anything changed
    const changedKeys = CONTACT_KEYS.filter(ck => (contactValues[ck.key] || '') !== (originalValues[ck.key] || ''));
    if (changedKeys.length === 0) {
      if (Platform.OS !== 'web') Alert.alert('', tr.noChanges);
      return;
    }

    setSaving(true);
    try {
      for (const ck of changedKeys) {
        const value = contactValues[ck.key] || '';
        const label = ck.label[lang as keyof typeof ck.label] || ck.label.en;
        await apiCall('settings.set', 'POST', { key: ck.key, value, label });
      }
      setOriginalValues({ ...contactValues });
      if (Platform.OS !== 'web') Alert.alert('', tr.saved);
    } catch (e) {
      console.error('[AdminSettings] Save error:', e);
      if (Platform.OS !== 'web') Alert.alert('', String(e));
    } finally {
      setSaving(false);
    }
  };

  // Toggle trader visibility
  const handleToggleVisibility = async (traderId: number) => {
    try {
      const result = await apiCall('location.adminToggleVisibility', 'POST', { traderId });
      setLocations(prev => prev.map(l =>
        l.traderId === traderId ? { ...l, isVisible: result.isVisible } : l
      ));
    } catch (e) {
      console.error('[AdminSettings] Toggle visibility error:', e);
    }
  };

  // Delete trader location
  const handleDeleteLocation = async (traderId: number) => {
    if (Platform.OS !== 'web') {
      Alert.alert('', tr.confirmDelete, [
        { text: lang === 'ar' ? 'إلغاء' : 'Cancel', style: 'cancel' },
        {
          text: lang === 'ar' ? 'حذف' : 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              await apiCall('location.adminDeleteLocation', 'POST', { traderId });
              setLocations(prev => prev.filter(l => l.traderId !== traderId));
            } catch (e) {
              console.error('[AdminSettings] Delete error:', e);
            }
          },
        },
      ]);
    } else {
      try {
        await apiCall('location.adminDeleteLocation', 'POST', { traderId });
        setLocations(prev => prev.filter(l => l.traderId !== traderId));
      } catch (e) {
        console.error('[AdminSettings] Delete error:', e);
      }
    }
  };

  const hasChanges = CONTACT_KEYS.some(ck => (contactValues[ck.key] || '') !== (originalValues[ck.key] || ''));

  if (loading) {
    return (
      <View style={styles.screen}>
        <SafeAreaView style={styles.safeArea} edges={['top']}>
          <View style={[styles.header, { flexDirection: flexDir }]}>
            <TouchableOpacity onPress={onOpenDrawer} style={styles.menuButton}>
              <MaterialIcons name="menu" size={24} color="#C5A021" />
            </TouchableOpacity>
            <View style={[styles.headerTitleContainer, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
              <Text style={[styles.headerTitle, { textAlign, writingDirection: direction }]}>{tr.title}</Text>
            </View>
          </View>
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color="#C5A021" />
          </View>
        </SafeAreaView>
      </View>
    );
  }

  return (
    <View style={styles.screen}>
      <SafeAreaView style={styles.safeArea} edges={['top']}>
        {/* Header */}
        <View style={[styles.header, { flexDirection: flexDir }]}>
          <TouchableOpacity onPress={onOpenDrawer} style={styles.menuButton}>
            <MaterialIcons name="menu" size={24} color="#C5A021" />
          </TouchableOpacity>
          <View style={[styles.headerTitleContainer, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
            <Text style={[styles.headerTitle, { textAlign, writingDirection: direction }]}>{tr.title}</Text>
            <Text style={[styles.headerSubtitle, { textAlign, writingDirection: direction }]}>{tr.subtitle}</Text>
          </View>
        </View>

        {/* Tabs */}
        <View style={styles.tabBar}>
          <TouchableOpacity
            onPress={() => setActiveTab('contact')}
            activeOpacity={0.7}
            style={[styles.tab, activeTab === 'contact' && styles.tabActive]}
          >
            <MaterialIcons name="contact-phone" size={18} color={activeTab === 'contact' ? '#C5A021' : '#6C737F'} />
            <Text style={[styles.tabText, activeTab === 'contact' && styles.tabTextActive, { writingDirection: direction }]}>
              {tr.contactTab}
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => setActiveTab('locations')}
            activeOpacity={0.7}
            style={[styles.tab, activeTab === 'locations' && styles.tabActive]}
          >
            <MaterialIcons name="location-on" size={18} color={activeTab === 'locations' ? '#C5A021' : '#6C737F'} />
            <Text style={[styles.tabText, activeTab === 'locations' && styles.tabTextActive, { writingDirection: direction }]}>
              {tr.locationsTab}
            </Text>
          </TouchableOpacity>
        </View>

        {/* Content */}
        <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
          {activeTab === 'contact' ? (
            <>
              {/* Description */}
              <View style={[styles.descRow, { flexDirection: flexDir }]}>
                <MaterialIcons name="info-outline" size={16} color="#6C737F" />
                <Text style={[styles.descText, { textAlign, writingDirection: direction }]}>{tr.contactDesc}</Text>
              </View>

              {/* Contact Fields */}
              {CONTACT_KEYS.map(ck => {
                const label = ck.label[lang as keyof typeof ck.label] || ck.label.en;
                return (
                  <View key={ck.key} style={styles.fieldCard}>
                    <View style={[styles.fieldHeader, { flexDirection: flexDir }]}>
                      <View style={styles.fieldIconBox}>
                        <MaterialIcons name={ck.icon as any} size={18} color="#C5A021" />
                      </View>
                      <Text style={[styles.fieldLabel, { textAlign, writingDirection: direction }]}>{label}</Text>
                    </View>
                    <TextInput
                      value={contactValues[ck.key] || ''}
                      onChangeText={(text) => setContactValues(prev => ({ ...prev, [ck.key]: text }))}
                      placeholder={label}
                      placeholderTextColor="#6C737F"
                      style={[
                        styles.fieldInput,
                        { textAlign: ck.key.includes('phone') || ck.key.includes('whatsapp') || ck.key.includes('telegram') ? 'left' : textAlign, writingDirection: direction },
                        ck.key === 'support_message' && styles.multilineInput,
                      ]}
                      multiline={ck.key === 'support_message'}
                      numberOfLines={ck.key === 'support_message' ? 3 : 1}
                      keyboardType={ck.key.includes('phone') || ck.key.includes('whatsapp') ? 'phone-pad' : ck.key.includes('email') ? 'email-address' : 'default'}
                      returnKeyType="done"
                    />
                  </View>
                );
              })}

              {/* Save Button */}
              <View style={styles.saveContainer}>
                <GoldButton
                  title={tr.saveChanges}
                  onPress={handleSaveContact}
                  loading={saving}
                  disabled={!hasChanges}
                />
              </View>
            </>
          ) : (
            <>
              {/* Location Stats */}
              <View style={[styles.statsRow, { flexDirection: flexDir }]}>
                <View style={styles.statItem}>
                  <Text style={styles.statNumber}>{locations.length}</Text>
                  <Text style={[styles.statLabel, { writingDirection: direction }]}>{tr.totalTraders}</Text>
                </View>
                <View style={styles.statDivider} />
                <View style={styles.statItem}>
                  <Text style={[styles.statNumber, { color: '#22C55E' }]}>{locations.filter(l => l.isVisible).length}</Text>
                  <Text style={[styles.statLabel, { writingDirection: direction }]}>{tr.visibleTraders}</Text>
                </View>
                <View style={styles.statDivider} />
                <View style={styles.statItem}>
                  <Text style={[styles.statNumber, { color: '#EF4444' }]}>{locations.filter(l => !l.isVisible).length}</Text>
                  <Text style={[styles.statLabel, { writingDirection: direction }]}>{tr.hiddenTraders}</Text>
                </View>
              </View>

              {/* Locations List */}
              {locationsLoading ? (
                <View style={styles.loadingContainer}>
                  <ActivityIndicator size="large" color="#C5A021" />
                </View>
              ) : locations.length === 0 ? (
                <View style={styles.emptyContainer}>
                  <MaterialIcons name="location-off" size={48} color="rgba(197,160,33,0.2)" />
                  <Text style={[styles.emptyTitle, { writingDirection: direction }]}>{tr.noLocations}</Text>
                </View>
              ) : (
                locations.map(loc => (
                  <View key={loc.id} style={[styles.locationCard, !loc.isVisible && styles.locationCardHidden]}>
                    {/* Location Header */}
                    <View style={[styles.locationHeader, { flexDirection: flexDir }]}>
                      <View style={styles.locationIconBox}>
                        <MaterialIcons name="storefront" size={20} color={loc.isVisible ? '#C5A021' : '#6C737F'} />
                      </View>
                      <View style={[styles.locationInfo, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
                        <Text style={[styles.locationName, { textAlign, writingDirection: direction }]}>{loc.shopName}</Text>
                        <Text style={[styles.locationTrader, { textAlign, writingDirection: direction }]} numberOfLines={1}>
                          {loc.traderName || loc.traderEmail || `ID: ${loc.traderId}`}
                        </Text>
                      </View>
                      <View style={[styles.visibilityBadge, { backgroundColor: loc.isVisible ? 'rgba(34,197,94,0.15)' : 'rgba(239,68,68,0.15)' }]}>
                        <Text style={[styles.visibilityText, { color: loc.isVisible ? '#22C55E' : '#EF4444' }]}>
                          {loc.isVisible ? tr.visible : tr.hidden}
                        </Text>
                      </View>
                    </View>

                    {/* Address */}
                    <View style={[styles.locationDetail, { flexDirection: flexDir }]}>
                      <MaterialIcons name="location-on" size={14} color="#6C737F" />
                      <Text style={[styles.locationDetailText, { textAlign, writingDirection: direction }]} numberOfLines={2}>
                        {loc.address}{loc.city ? ` - ${loc.city}` : ''}
                      </Text>
                    </View>

                    {/* Contact */}
                    {(loc.phone || loc.whatsapp) && (
                      <View style={[styles.locationDetail, { flexDirection: flexDir }]}>
                        <MaterialIcons name="phone" size={14} color="#6C737F" />
                        <Text style={[styles.locationDetailText, { textAlign: 'left' }]}>
                          {loc.phone || loc.whatsapp}
                        </Text>
                      </View>
                    )}

                    {/* Coordinates */}
                    <View style={[styles.locationDetail, { flexDirection: flexDir }]}>
                      <MaterialIcons name="my-location" size={14} color="#6C737F" />
                      <Text style={[styles.locationCoordText]}>
                        {Number(loc.latitude).toFixed(5)}, {Number(loc.longitude).toFixed(5)}
                      </Text>
                    </View>

                    {/* Actions */}
                    <View style={[styles.locationActions, { flexDirection: flexDir }]}>
                      <TouchableOpacity
                        onPress={() => handleToggleVisibility(loc.traderId)}
                        activeOpacity={0.7}
                        style={[styles.locActionBtn, styles.locActionToggle]}
                      >
                        <MaterialIcons name={loc.isVisible ? 'visibility-off' : 'visibility'} size={16} color="#F59E0B" />
                        <Text style={[styles.locActionText, { color: '#F59E0B' }]}>{tr.toggleVisibility}</Text>
                      </TouchableOpacity>
                      <TouchableOpacity
                        onPress={() => handleDeleteLocation(loc.traderId)}
                        activeOpacity={0.7}
                        style={[styles.locActionBtn, styles.locActionDelete]}
                      >
                        <MaterialIcons name="delete-outline" size={16} color="#EF4444" />
                        <Text style={[styles.locActionText, { color: '#EF4444' }]}>{tr.deleteLocation}</Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                ))
              )}
            </>
          )}

          <View style={{ height: 40 }} />
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#001F3F' },
  safeArea: { flex: 1 },
  header: {
    alignItems: 'center', paddingHorizontal: 16, paddingVertical: 12,
    borderBottomWidth: 1, borderBottomColor: 'rgba(197,160,33,0.15)',
  },
  menuButton: { padding: 8 },
  headerTitleContainer: { flex: 1, marginHorizontal: 12 },
  headerTitle: { fontSize: 18, fontWeight: '700', color: '#C5A021' },
  headerSubtitle: { fontSize: 12, color: '#F8F9FA', opacity: 0.6, marginTop: 2 },
  content: { flex: 1 },
  scrollContent: { paddingHorizontal: 16, paddingTop: 16 },
  loadingContainer: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingVertical: 60 },

  // Tabs
  tabBar: {
    flexDirection: 'row', paddingHorizontal: 16, paddingTop: 12, gap: 8,
  },
  tab: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6,
    paddingVertical: 12, borderRadius: 12,
    backgroundColor: 'rgba(248,249,250,0.04)',
    borderWidth: 1, borderColor: 'rgba(248,249,250,0.06)',
  },
  tabActive: {
    backgroundColor: 'rgba(197,160,33,0.1)',
    borderColor: 'rgba(197,160,33,0.3)',
  },
  tabText: { fontSize: 13, fontWeight: '600', color: '#6C737F' },
  tabTextActive: { color: '#C5A021' },

  // Description
  descRow: { alignItems: 'flex-start', gap: 8, marginBottom: 20 },
  descText: { flex: 1, fontSize: 13, color: '#6C737F', lineHeight: 20 },

  // Field card
  fieldCard: {
    backgroundColor: 'rgba(248,249,250,0.05)',
    borderRadius: 14, padding: 14, marginBottom: 12,
    borderWidth: 1, borderColor: 'rgba(248,249,250,0.06)',
  },
  fieldHeader: { alignItems: 'center', gap: 10, marginBottom: 10 },
  fieldIconBox: {
    width: 32, height: 32, borderRadius: 8,
    backgroundColor: 'rgba(197,160,33,0.12)',
    alignItems: 'center', justifyContent: 'center',
  },
  fieldLabel: { fontSize: 14, fontWeight: '600', color: '#F8F9FA', flex: 1 },
  fieldInput: {
    backgroundColor: 'rgba(248,249,250,0.06)',
    borderWidth: 1, borderColor: 'rgba(248,249,250,0.1)',
    borderRadius: 10, paddingHorizontal: 14, paddingVertical: 12,
    fontSize: 14, color: '#F8F9FA',
  },
  multilineInput: { minHeight: 70, textAlignVertical: 'top', paddingTop: 12 },

  // Save
  saveContainer: { marginTop: 12, marginBottom: 8 },

  // Stats
  statsRow: {
    justifyContent: 'space-around', alignItems: 'center',
    backgroundColor: 'rgba(248,249,250,0.05)',
    borderRadius: 14, padding: 16, marginBottom: 16,
    borderWidth: 1, borderColor: 'rgba(248,249,250,0.06)',
  },
  statItem: { alignItems: 'center' },
  statNumber: { fontSize: 24, fontWeight: '800', color: '#C5A021' },
  statLabel: { fontSize: 11, color: '#F8F9FA', opacity: 0.6, marginTop: 4 },
  statDivider: { width: 1, height: 40, backgroundColor: 'rgba(197,160,33,0.2)' },

  // Empty
  emptyContainer: { alignItems: 'center', paddingVertical: 40 },
  emptyTitle: { fontSize: 16, fontWeight: '600', color: '#F8F9FA', marginTop: 16 },

  // Location card
  locationCard: {
    backgroundColor: 'rgba(248,249,250,0.05)',
    borderRadius: 14, padding: 14, marginBottom: 12,
    borderWidth: 1, borderColor: 'rgba(248,249,250,0.08)',
  },
  locationCardHidden: {
    opacity: 0.6,
    borderColor: 'rgba(239,68,68,0.15)',
  },
  locationHeader: { alignItems: 'center', marginBottom: 10 },
  locationIconBox: {
    width: 40, height: 40, borderRadius: 10,
    backgroundColor: 'rgba(197,160,33,0.1)',
    alignItems: 'center', justifyContent: 'center',
  },
  locationInfo: { flex: 1, marginHorizontal: 10 },
  locationName: { fontSize: 15, fontWeight: '700', color: '#F8F9FA' },
  locationTrader: { fontSize: 12, color: '#6C737F', marginTop: 2 },
  visibilityBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12 },
  visibilityText: { fontSize: 11, fontWeight: '700' },

  // Location details
  locationDetail: { alignItems: 'flex-start', gap: 6, marginTop: 6, paddingHorizontal: 4 },
  locationDetailText: { flex: 1, fontSize: 12, color: '#9BA1A6', lineHeight: 18 },
  locationCoordText: { fontSize: 11, color: '#6C737F', fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace' },

  // Location actions
  locationActions: {
    gap: 8, marginTop: 12, paddingTop: 10,
    borderTopWidth: 1, borderTopColor: 'rgba(248,249,250,0.06)',
  },
  locActionBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    paddingHorizontal: 12, paddingVertical: 8, borderRadius: 8,
  },
  locActionToggle: { backgroundColor: 'rgba(245,158,11,0.1)' },
  locActionDelete: { backgroundColor: 'rgba(239,68,68,0.1)' },
  locActionText: { fontSize: 12, fontWeight: '600' },
});
