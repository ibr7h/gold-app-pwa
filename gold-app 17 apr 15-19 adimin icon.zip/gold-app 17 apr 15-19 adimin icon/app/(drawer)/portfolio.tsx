import React, { useState, useCallback } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Modal, Alert, Platform, Share } from 'react-native';
import * as FileSystem from 'expo-file-system/legacy';
import * as Sharing from 'expo-sharing';
import * as Print from 'expo-print';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { useAppData } from '@/contexts/AppDataContext';
import { GoldCard } from '@/components/gold/GoldCard';
import { GoldButton } from '@/components/gold/GoldButton';
import { GoldInput } from '@/components/gold/GoldInput';
import { GoldSelect } from '@/components/gold/GoldSelect';
import { StateView } from '@/components/gold/StateView';
import { useI18n } from '@/i18n';

interface PortfolioScreenProps {
  onOpenDrawer: () => void;
  onNavigate?: (screen: string) => void;
}

export default function PortfolioScreen({ onOpenDrawer, onNavigate }: PortfolioScreenProps) {
  const { portfolios, addPortfolio, deletePortfolio, purchasesList } = useAppData();
  const { t, isRTL, textAlign, direction, flexDir, lang } = useI18n();
  const [showAddForm, setShowAddForm] = useState(false);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [newName, setNewName] = useState('');
  const [newCurrency, setNewCurrency] = useState('SAR');
  const [exporting, setExporting] = useState(false);

  // PDF Export translations
  const exportLabel = lang === 'ar' ? 'تصدير PDF' : lang === 'fr' ? 'Exporter PDF' : 'Export PDF';
  const exportingLabel = lang === 'ar' ? 'جاري التصدير...' : lang === 'fr' ? 'Exportation...' : 'Exporting...';

  const totalValue = portfolios.reduce((sum, p) => sum + p.totalValue, 0);
  const totalProfitLoss = portfolios.reduce((sum, p) => sum + p.profitLoss, 0);

  const selectedPortfolio = portfolios.find(p => p.id === selectedId);
  const linkedPurchases = purchasesList.filter(p => p.portfolioId === selectedId);

  const handleExportPDF = useCallback(async () => {
    setExporting(true);
    try {
      const reportTitle = lang === 'ar' ? 'تقرير المحفظة' : lang === 'fr' ? 'Rapport du portefeuille' : 'Portfolio Report';
      const dateStr = new Date().toLocaleDateString(lang === 'ar' ? 'ar-SA' : lang === 'fr' ? 'fr-FR' : 'en-US');
      const summaryLabel = lang === 'ar' ? 'ملخص المحفظة' : lang === 'fr' ? 'Résumé du portefeuille' : 'Portfolio Summary';
      const purchasesTitle = lang === 'ar' ? 'المشتريات' : lang === 'fr' ? 'Achats' : 'Purchases';
      const nameCol = lang === 'ar' ? 'الاسم' : lang === 'fr' ? 'Nom' : 'Name';
      const valueCol = lang === 'ar' ? 'القيمة' : lang === 'fr' ? 'Valeur' : 'Value';
      const plCol = lang === 'ar' ? 'الربح/الخسارة' : lang === 'fr' ? 'Profit/Perte' : 'Profit/Loss';
      const currencyCol = lang === 'ar' ? 'العملة' : lang === 'fr' ? 'Devise' : 'Currency';
      const countCol = lang === 'ar' ? 'المشتريات' : lang === 'fr' ? 'Achats' : 'Purchases';
      const quantityCol = lang === 'ar' ? 'الكمية' : lang === 'fr' ? 'Quantité' : 'Quantity';
      const priceCol = lang === 'ar' ? 'السعر' : lang === 'fr' ? 'Prix' : 'Price';
      const dateCol = lang === 'ar' ? 'التاريخ' : lang === 'fr' ? 'Date' : 'Date';

      const html = `
<!DOCTYPE html>
<html dir="${isRTL ? 'rtl' : 'ltr'}" lang="${lang}">
<head>
<meta charset="utf-8">
<style>
  body { font-family: Arial, sans-serif; padding: 40px; color: #1a1a1b; direction: ${isRTL ? 'rtl' : 'ltr'}; }
  h1 { color: #001F3F; border-bottom: 3px solid #C5A021; padding-bottom: 10px; }
  h2 { color: #001F3F; margin-top: 30px; border-bottom: 1px solid #e5e7eb; padding-bottom: 8px; }
  .meta { color: #6c737f; margin-bottom: 20px; }
  .stats-grid { display: flex; gap: 20px; margin: 20px 0; }
  .stat-box { flex: 1; background: #f5f5f5; padding: 16px; border-radius: 8px; text-align: center; }
  .stat-value { font-size: 22px; font-weight: bold; color: #C5A021; }
  .stat-label { font-size: 12px; color: #6c737f; margin-top: 4px; }
  table { width: 100%; border-collapse: collapse; margin: 16px 0; }
  th, td { padding: 10px 14px; text-align: ${isRTL ? 'right' : 'left'}; border-bottom: 1px solid #e5e7eb; }
  th { background: #001F3F; color: white; font-weight: 600; }
  tr:nth-child(even) { background: #f9fafb; }
  .positive { color: #22c55e; font-weight: 600; }
  .negative { color: #ef4444; font-weight: 600; }
  .footer { margin-top: 40px; text-align: center; color: #6c737f; font-size: 12px; border-top: 1px solid #e5e7eb; padding-top: 16px; }
</style>
</head>
<body>
<h1>${reportTitle}</h1>
<p class="meta">${dateStr}</p>

<div class="stats-grid">
  <div class="stat-box">
    <div class="stat-value">${portfolios.length}</div>
    <div class="stat-label">${t.portfolio.portfolios}</div>
  </div>
  <div class="stat-box">
    <div class="stat-value">${totalValue.toFixed(2)}</div>
    <div class="stat-label">${t.portfolio.totalValue}</div>
  </div>
  <div class="stat-box">
    <div class="stat-value ${totalProfitLoss >= 0 ? 'positive' : 'negative'}">${totalProfitLoss >= 0 ? '+' : ''}${totalProfitLoss.toFixed(2)}</div>
    <div class="stat-label">${t.portfolio.profitLoss}</div>
  </div>
</div>

<h2>${summaryLabel}</h2>
<table>
  <tr><th>${nameCol}</th><th>${valueCol}</th><th>${plCol}</th><th>${currencyCol}</th><th>${countCol}</th></tr>
  ${portfolios.map(p => `<tr>
    <td>${p.name}</td>
    <td>${p.totalValue.toFixed(2)}</td>
    <td class="${p.profitLoss >= 0 ? 'positive' : 'negative'}">${p.profitLoss >= 0 ? '+' : ''}${p.profitLoss.toFixed(2)} (${p.profitLossPercent.toFixed(2)}%)</td>
    <td>${p.currency}</td>
    <td>${p.purchaseCount}</td>
  </tr>`).join('')}
</table>

<h2>${purchasesTitle}</h2>
<table>
  <tr><th>${nameCol}</th><th>${priceCol}</th><th>${quantityCol}</th><th>${dateCol}</th></tr>
  ${purchasesList.map(p => `<tr>
    <td>${p.name}</td>
    <td>${p.price.toFixed(2)} ${p.currency}</td>
    <td>${p.quantity}</td>
    <td>${p.date}</td>
  </tr>`).join('')}
</table>

<div class="footer">${lang === 'ar' ? 'تم إنشاء هذا التقرير بواسطة تطبيق ذهبي' : lang === 'fr' ? 'Rapport généré par l\'application Dhahabi' : 'Report generated by Dhahabi App'} - ${dateStr}</div>
</body>
</html>`;

      if (Platform.OS === 'web') {
        // On web, create an HTML blob and download it
        const blob = new Blob([html], { type: 'text/html' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `portfolio-report-${Date.now()}.html`;
        a.click();
        URL.revokeObjectURL(url);
      } else {
        // On native (Android/iOS), use expo-print to generate a real PDF
        const { uri: tempUri } = await Print.printToFileAsync({ html });
        // Move to a permanent location with .pdf extension
        const pdfUri = FileSystem.documentDirectory + `portfolio-report-${Date.now()}.pdf`;
        await FileSystem.moveAsync({ from: tempUri, to: pdfUri });
        const canShare = await Sharing.isAvailableAsync();
        if (canShare) {
          await Sharing.shareAsync(pdfUri, { mimeType: 'application/pdf', dialogTitle: reportTitle });
        } else {
          await Share.share({ message: reportTitle, title: reportTitle });
        }
      }
    } catch (error) {
      Alert.alert(
        lang === 'ar' ? 'خطأ' : lang === 'fr' ? 'Erreur' : 'Error',
        lang === 'ar' ? 'فشل تصدير التقرير' : lang === 'fr' ? 'Échec de l\'exportation' : 'Failed to export report'
      );
    } finally {
      setExporting(false);
    }
  }, [portfolios, purchasesList, totalValue, totalProfitLoss, lang, isRTL, t]);

  const handleAdd = () => {
    if (newName.trim()) {
      addPortfolio(newName.trim(), newCurrency);
      setNewName('');
      setNewCurrency('SAR');
      setShowAddForm(false);
    }
  };

  // Detail view
  if (selectedPortfolio) {
    return (
      <View style={styles.screen}>
        <SafeAreaView style={styles.safeArea} edges={['top']}>
          <View style={styles.appBar}>
            <View style={{ width: 40 }} />
            <Text style={[styles.appBarTitle, { writingDirection: direction }]}>{selectedPortfolio.name}</Text>
            <TouchableOpacity onPress={() => setSelectedId(null)} style={styles.menuBtn} activeOpacity={0.7}>
              <MaterialIcons name={isRTL ? 'arrow-forward' : 'arrow-back'} size={24} color="#F8F9FA" />
            </TouchableOpacity>
          </View>
          <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
            <GoldCard style={styles.detailCard}>
              <View style={[styles.detailRow, { flexDirection: flexDir }]}>
                <Text style={styles.detailValue}>{selectedPortfolio.totalValue.toFixed(2)} {selectedPortfolio.currency}</Text>
                <Text style={[styles.detailLabel, { writingDirection: direction }]}>{t.portfolio.totalValue}</Text>
              </View>
              <View style={[styles.detailRow, { flexDirection: flexDir }]}>
                <Text style={[styles.detailValue, { color: selectedPortfolio.profitLoss >= 0 ? '#22C55E' : '#EF4444' }]}>
                  {selectedPortfolio.profitLoss >= 0 ? '+' : ''}{selectedPortfolio.profitLoss.toFixed(2)} ({selectedPortfolio.profitLossPercent.toFixed(2)}%)
                </Text>
                <Text style={[styles.detailLabel, { writingDirection: direction }]}>{t.portfolio.profitLoss}</Text>
              </View>
              <View style={[styles.detailRow, { flexDirection: flexDir }]}>
                <Text style={styles.detailValue}>{selectedPortfolio.purchaseCount}</Text>
                <Text style={[styles.detailLabel, { writingDirection: direction }]}>{t.portfolio.purchaseCount}</Text>
              </View>
              <View style={[styles.detailRow, { flexDirection: flexDir }]}>
                <Text style={styles.detailValue}>{selectedPortfolio.lastUpdate}</Text>
                <Text style={[styles.detailLabel, { writingDirection: direction }]}>{t.portfolio.lastUpdate}</Text>
              </View>
            </GoldCard>

            <Text style={[styles.sectionTitle, { textAlign, writingDirection: direction }]}>{t.portfolio.linkedPurchases}</Text>
            {linkedPurchases.length === 0 ? (
              <StateView type="empty" message={t.portfolio.noLinkedPurchases} />
            ) : (
              linkedPurchases.map(purchase => (
                <GoldCard key={purchase.id} style={styles.purchaseCard}>
                  <View style={[styles.purchaseRow, { flexDirection: flexDir }]}>
                    <Text style={styles.purchasePrice}>{purchase.price.toFixed(2)} {purchase.currency}</Text>
                    <Text style={[styles.purchaseName, { writingDirection: direction }]}>{purchase.name}</Text>
                  </View>
                  <View style={[styles.purchaseRow, { flexDirection: flexDir }]}>
                    <Text style={styles.purchaseDate}>{purchase.date}</Text>
                    <Text style={[styles.purchaseQty, { writingDirection: direction }]}>{t.purchases.quantity}: {purchase.quantity}</Text>
                  </View>
                </GoldCard>
              ))
            )}
            <View style={{ height: 32 }} />
          </ScrollView>
        </SafeAreaView>
      </View>
    );
  }

  return (
    <View style={styles.screen}>
      <SafeAreaView style={styles.safeArea} edges={['top']}>
        <View style={styles.appBar}>
          <TouchableOpacity onPress={() => setShowAddForm(true)} style={styles.addBtn} activeOpacity={0.7}>
            <MaterialIcons name="add" size={24} color="#C5A021" />
          </TouchableOpacity>
          <Text style={[styles.appBarTitle, { writingDirection: direction }]}>{t.portfolio.title}</Text>
          <TouchableOpacity onPress={onOpenDrawer} style={styles.menuBtn} activeOpacity={0.7}>
            <MaterialIcons name="menu" size={24} color="#F8F9FA" />
          </TouchableOpacity>
        </View>

        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
          <GoldCard style={styles.summaryCard}>
            <View style={[styles.summaryRow, { flexDirection: flexDir }]}>
              <View style={styles.summaryItem}>
                <Text style={[styles.summaryValue, { color: totalProfitLoss >= 0 ? '#22C55E' : '#EF4444' }]}>
                  {totalProfitLoss >= 0 ? '+' : ''}{totalProfitLoss.toFixed(2)}
                </Text>
                <Text style={[styles.summaryLabel, { writingDirection: direction }]}>{t.portfolio.profitLoss}</Text>
              </View>
              <View style={styles.summaryDivider} />
              <View style={styles.summaryItem}>
                <Text style={styles.summaryValue}>{totalValue.toFixed(2)}</Text>
                <Text style={[styles.summaryLabel, { writingDirection: direction }]}>{t.portfolio.totalValue}</Text>
              </View>
              <View style={styles.summaryDivider} />
              <View style={styles.summaryItem}>
                <Text style={styles.summaryValue}>{portfolios.length}</Text>
                <Text style={[styles.summaryLabel, { writingDirection: direction }]}>{t.portfolio.portfolios}</Text>
              </View>
            </View>
          </GoldCard>

          {portfolios.length === 0 ? (
            <StateView type="empty" message={t.portfolio.noPortfolios} />
          ) : (
            portfolios.map(item => (
              <TouchableOpacity key={item.id} onPress={() => setSelectedId(item.id)} activeOpacity={0.7}>
                <GoldCard style={styles.portfolioCard}>
                  <View style={[styles.portfolioRow, { flexDirection: flexDir }]}>
                    <View style={styles.portfolioTrailing}>
                      <MaterialIcons name={isRTL ? 'chevron-left' : 'chevron-right'} size={20} color="#6C737F" />
                      <TouchableOpacity onPress={() => deletePortfolio(item.id)} style={styles.deleteBtn} activeOpacity={0.6}>
                        <MaterialIcons name="delete-outline" size={18} color="#EF4444" />
                      </TouchableOpacity>
                    </View>
                    <View style={[styles.portfolioInfo, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
                      <Text style={[styles.portfolioName, { writingDirection: direction }]}>{item.name}</Text>
                      <Text style={[styles.portfolioMeta, { writingDirection: direction }]}>{item.currency} • {item.purchaseCount} {t.portfolio.purchases}</Text>
                    </View>
                  </View>
                  <View style={[styles.portfolioFooter, { flexDirection: flexDir }]}>
                    <Text style={[styles.portfolioDate, { writingDirection: direction }]}>{t.portfolio.lastUpdate}: {item.lastUpdate}</Text>
                    <View style={[styles.portfolioValues, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
                      <Text style={[styles.portfolioPL, { color: item.profitLoss >= 0 ? '#22C55E' : '#EF4444' }]}>
                        {item.profitLoss >= 0 ? '+' : ''}{item.profitLoss.toFixed(2)} ({item.profitLossPercent.toFixed(2)}%)
                      </Text>
                      <Text style={styles.portfolioTotal}>{item.totalValue.toFixed(2)} {item.currency}</Text>
                    </View>
                  </View>
                </GoldCard>
              </TouchableOpacity>
            ))
          )}
          {/* Export PDF Button */}
          {portfolios.length > 0 && (
            <TouchableOpacity
              onPress={handleExportPDF}
              style={[styles.exportBtn, exporting && styles.exportBtnDisabled]}
              activeOpacity={0.7}
              disabled={exporting}
            >
              <MaterialIcons name="picture-as-pdf" size={20} color="#001F3F" />
              <Text style={[styles.exportBtnText, { writingDirection: direction }]}>
                {exporting ? exportingLabel : exportLabel}
              </Text>
            </TouchableOpacity>
          )}

          <View style={{ height: 32 }} />
        </ScrollView>

        <Modal visible={showAddForm} transparent animationType="fade">
          <TouchableOpacity style={styles.overlay} activeOpacity={1} onPress={() => setShowAddForm(false)}>
            <View style={styles.modal} onStartShouldSetResponder={() => true}>
              <Text style={[styles.modalTitle, { textAlign, writingDirection: direction }]}>{t.portfolio.addPortfolio}</Text>
              <GoldInput label={t.portfolio.portfolioName} value={newName} onChangeText={setNewName} placeholder={t.portfolio.portfolioNamePlaceholder} />
              <GoldSelect
                label={t.portfolio.currency}
                value={newCurrency}
                options={[
                  { label: t.portfolio.sarCurrency, value: 'SAR' },
                  { label: t.portfolio.usdCurrency, value: 'USD' },
                  { label: t.portfolio.eurCurrency, value: 'EUR' },
                ]}
                onSelect={setNewCurrency}
              />
              <GoldButton title={t.add} onPress={handleAdd} disabled={!newName.trim()} />
            </View>
          </TouchableOpacity>
        </Modal>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#001F3F' },
  safeArea: { flex: 1 },
  appBar: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: 'rgba(248,249,250,0.08)',
  },
  appBarTitle: { fontSize: 18, fontWeight: '700', color: '#F8F9FA' },
  menuBtn: { padding: 8 },
  addBtn: { padding: 8 },
  scrollContent: { paddingHorizontal: 16, paddingTop: 16 },
  sectionTitle: { fontSize: 17, fontWeight: '700', color: '#F8F9FA', marginBottom: 12, marginTop: 8 },
  summaryCard: { marginBottom: 16, borderWidth: 1, borderColor: 'rgba(197,160,33,0.2)' },
  summaryRow: { alignItems: 'center' },
  summaryItem: { flex: 1, alignItems: 'center' },
  summaryLabel: { fontSize: 11, color: '#6C737F', marginTop: 4 },
  summaryValue: { fontSize: 15, fontWeight: '700', color: '#1A1A1B', fontVariant: ['tabular-nums'] },
  summaryDivider: { width: 1, height: 36, backgroundColor: '#E6E8EA' },
  portfolioCard: { marginBottom: 10 },
  portfolioRow: { alignItems: 'center' },
  portfolioInfo: { flex: 1 },
  portfolioName: { fontSize: 15, fontWeight: '600', color: '#1A1A1B' },
  portfolioMeta: { fontSize: 12, color: '#6C737F', marginTop: 2 },
  portfolioTrailing: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  deleteBtn: { padding: 4 },
  portfolioFooter: { justifyContent: 'space-between', alignItems: 'flex-end', marginTop: 12, paddingTop: 10, borderTopWidth: 1, borderTopColor: '#E6E8EA' },
  portfolioValues: {},
  portfolioTotal: { fontSize: 14, fontWeight: '600', color: '#1A1A1B', fontVariant: ['tabular-nums'] },
  portfolioPL: { fontSize: 12, fontWeight: '600', marginTop: 2, fontVariant: ['tabular-nums'] },
  portfolioDate: { fontSize: 11, color: '#6C737F' },
  detailCard: { marginBottom: 16 },
  detailRow: { justifyContent: 'space-between', alignItems: 'center', paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: '#E6E8EA' },
  detailLabel: { fontSize: 14, color: '#6C737F' },
  detailValue: { fontSize: 14, fontWeight: '600', color: '#1A1A1B', fontVariant: ['tabular-nums'] },
  purchaseCard: { marginBottom: 8 },
  purchaseRow: { justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 },
  purchaseName: { fontSize: 14, fontWeight: '600', color: '#1A1A1B' },
  purchasePrice: { fontSize: 14, fontWeight: '600', color: '#C5A021', fontVariant: ['tabular-nums'] },
  purchaseQty: { fontSize: 12, color: '#6C737F' },
  purchaseDate: { fontSize: 12, color: '#6C737F' },
  overlay: { flex: 1, backgroundColor: 'rgba(0,31,63,0.7)', justifyContent: 'center', padding: 24 },
  modal: { backgroundColor: '#F8F9FA', borderRadius: 16, padding: 24 },
  modalTitle: { fontSize: 18, fontWeight: '700', color: '#1A1A1B', marginBottom: 20 },
  exportBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8,
    backgroundColor: '#C5A021', paddingVertical: 14, borderRadius: 12, marginTop: 16,
  },
  exportBtnDisabled: { opacity: 0.6 },
  exportBtnText: { fontSize: 15, fontWeight: '700', color: '#001F3F' },
});
