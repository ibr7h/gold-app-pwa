import React, { useState, useMemo, useCallback } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Dimensions, type DimensionValue, Alert, Platform, Share } from 'react-native';
import * as FileSystem from 'expo-file-system/legacy';
import * as Sharing from 'expo-sharing';
import * as Print from 'expo-print';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { GoldCard } from '@/components/gold/GoldCard';
import { InteractiveBarChart } from '@/components/gold/InteractiveBarChart';
import { InteractivePieChart } from '@/components/gold/InteractivePieChart';
import { useI18n } from '@/i18n';
import { useSettings } from '@/contexts/SettingsContext';
import { useTraderData } from '@/contexts/TraderDataContext';
import { useTraderPermissions } from '@/hooks/useTraderPermissions';

const SCREEN_WIDTH = Dimensions.get('window').width;
const CHART_WIDTH = SCREEN_WIDTH - 80;

interface TraderReportsScreenProps {
  onOpenDrawer: () => void;
  onNavigate?: (screen: string) => void;
}

type Period = 'week' | 'month' | 'all';

export default function TraderReportsScreen({ onOpenDrawer, onNavigate }: TraderReportsScreenProps) {
  const { isRTL, textAlign, direction, flexDir, lang } = useI18n();
  const { settings } = useSettings();
  const { orders, clients, stats } = useTraderData();
  const { permissions } = useTraderPermissions();
  const [period, setPeriod] = useState<Period>('week');

  // Translations
  const titleLabel = lang === 'ar' ? 'التقارير' : lang === 'fr' ? 'Rapports' : 'Reports';
  const weekLabel = lang === 'ar' ? 'الأسبوع' : lang === 'fr' ? 'Semaine' : 'Week';
  const monthLabel = lang === 'ar' ? 'الشهر' : lang === 'fr' ? 'Mois' : 'Month';
  const allLabel = lang === 'ar' ? 'الكل' : lang === 'fr' ? 'Tous' : 'All';
  const revenueOverview = lang === 'ar' ? 'نظرة عامة على الإيرادات' : lang === 'fr' ? "Vue d'ensemble des revenus" : 'Revenue Overview';
  const totalRevenue = lang === 'ar' ? 'إجمالي الإيرادات' : lang === 'fr' ? 'Revenus totaux' : 'Total Revenue';
  const avgOrderValue = lang === 'ar' ? 'متوسط قيمة الطلب' : lang === 'fr' ? 'Valeur moyenne' : 'Avg Order Value';
  const totalGrams = lang === 'ar' ? 'إجمالي الغرامات' : lang === 'fr' ? 'Total grammes' : 'Total Grams';
  const ordersByStatus = lang === 'ar' ? 'الطلبات حسب الحالة' : lang === 'fr' ? 'Commandes par statut' : 'Orders by Status';
  const ordersByType = lang === 'ar' ? 'الطلبات حسب النوع' : lang === 'fr' ? 'Commandes par type' : 'Orders by Type';
  const dailyRevenue = lang === 'ar' ? 'الإيرادات اليومية' : lang === 'fr' ? 'Revenus quotidiens' : 'Daily Revenue';
  const topClients = lang === 'ar' ? 'أفضل العملاء' : lang === 'fr' ? 'Meilleurs clients' : 'Top Clients';
  const pendingLabel = lang === 'ar' ? 'معلق' : lang === 'fr' ? 'En attente' : 'Pending';
  const processingLabel = lang === 'ar' ? 'قيد التنفيذ' : lang === 'fr' ? 'En cours' : 'Processing';
  const completedLabel = lang === 'ar' ? 'مكتمل' : lang === 'fr' ? 'Terminé' : 'Completed';
  const cancelledLabel = lang === 'ar' ? 'ملغي' : lang === 'fr' ? 'Annulé' : 'Cancelled';
  const buyLabel = lang === 'ar' ? 'شراء' : lang === 'fr' ? 'Achat' : 'Buy';
  const sellLabel = lang === 'ar' ? 'بيع' : lang === 'fr' ? 'Vente' : 'Sell';
  const ordersLabel = lang === 'ar' ? 'طلبات' : lang === 'fr' ? 'commandes' : 'orders';
  const karatDistribution = lang === 'ar' ? 'توزيع العيارات' : lang === 'fr' ? 'Distribution des carats' : 'Karat Distribution';

  const exportLabel = lang === 'ar' ? 'تصدير PDF' : lang === 'fr' ? 'Exporter PDF' : 'Export PDF';
  const exportingLabel = lang === 'ar' ? 'جاري التصدير...' : lang === 'fr' ? 'Exportation...' : 'Exporting...';
  const exportSuccess = lang === 'ar' ? 'تم تصدير التقرير بنجاح' : lang === 'fr' ? 'Rapport exporté avec succès' : 'Report exported successfully';
  const [exporting, setExporting] = useState(false);

  const currencySymbol = settings.preferredCurrency === 'USD' ? '$' : settings.preferredCurrency === 'EUR' ? '€' : settings.preferredCurrency === 'SAR' ? 'ر.س' : settings.preferredCurrency === 'AED' ? 'د.إ' : settings.preferredCurrency === 'EGP' ? 'ج.م' : '$';

  // Filter orders by period
  const periodOrders = useMemo(() => {
    const now = Date.now();
    switch (period) {
      case 'week': return orders.filter(o => o.createdAt >= now - 7 * 86400000);
      case 'month': return orders.filter(o => o.createdAt >= now - 30 * 86400000);
      default: return orders;
    }
  }, [orders, period]);

  // Revenue stats
  const revenueStats = useMemo(() => {
    const completedOrders = periodOrders.filter(o => o.status === 'completed');
    const total = completedOrders.reduce((sum, o) => sum + o.totalAmount, 0);
    const avg = completedOrders.length > 0 ? total / completedOrders.length : 0;
    const grams = periodOrders.reduce((sum, o) => sum + o.grams, 0);
    return { total, avg, grams, completedCount: completedOrders.length };
  }, [periodOrders]);

  // Orders by status
  const statusBreakdown = useMemo(() => {
    const counts = { pending: 0, processing: 0, completed: 0, cancelled: 0 };
    for (const o of periodOrders) {
      counts[o.status]++;
    }
    return counts;
  }, [periodOrders]);

  // Orders by type
  const typeBreakdown = useMemo(() => {
    const counts = { buy: 0, sell: 0 };
    for (const o of periodOrders) {
      counts[o.type]++;
    }
    return counts;
  }, [periodOrders]);

  // Karat distribution
  const karatBreakdown = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const o of periodOrders) {
      counts[o.karat] = (counts[o.karat] || 0) + 1;
    }
    return Object.entries(counts).sort((a, b) => b[1] - a[1]);
  }, [periodOrders]);

  // Daily revenue (last 7 days)
  const dailyRevenueData = useMemo(() => {
    const days: { label: string; value: number }[] = [];
    for (let i = 6; i >= 0; i--) {
      const date = new Date(Date.now() - i * 86400000);
      const dateStr = date.toISOString().split('T')[0];
      const dayLabel = date.toLocaleDateString(lang === 'ar' ? 'ar-SA' : lang === 'fr' ? 'fr-FR' : 'en-US', { weekday: 'short' });
      const dayRevenue = orders
        .filter(o => o.date === dateStr && o.status === 'completed')
        .reduce((sum, o) => sum + o.totalAmount, 0);
      days.push({ label: dayLabel, value: dayRevenue });
    }
    return days;
  }, [orders, lang]);

  const maxDailyRevenue = Math.max(...dailyRevenueData.map(d => d.value), 1);

  // Top clients by revenue
  const topClientsList = useMemo(() => {
    const clientRevenue: Record<string, { name: string; revenue: number; orders: number }> = {};
    for (const o of periodOrders) {
      if (o.status === 'completed') {
        if (!clientRevenue[o.clientId]) {
          clientRevenue[o.clientId] = { name: o.clientName, revenue: 0, orders: 0 };
        }
        clientRevenue[o.clientId].revenue += o.totalAmount;
        clientRevenue[o.clientId].orders++;
      }
    }
    return Object.values(clientRevenue).sort((a, b) => b.revenue - a.revenue).slice(0, 5);
  }, [periodOrders]);

  const maxClientRevenue = topClientsList.length > 0 ? topClientsList[0].revenue : 1;

  // PDF Export
  const handleExportPDF = useCallback(async () => {
    setExporting(true);
    try {
      const periodLabel = period === 'week' ? weekLabel : period === 'month' ? monthLabel : allLabel;
      const reportTitle = lang === 'ar' ? 'تقرير التاجر' : lang === 'fr' ? 'Rapport du commerçant' : 'Trader Report';
      const dateStr = new Date().toLocaleDateString(lang === 'ar' ? 'ar-SA' : lang === 'fr' ? 'fr-FR' : 'en-US');

      // Build HTML content for PDF
      const html = `
<!DOCTYPE html>
<html dir="${isRTL ? 'rtl' : 'ltr'}" lang="${lang}">
<head>
<meta charset="utf-8">
<style>
  body { font-family: Arial, sans-serif; padding: 40px; color: #1a1a1b; direction: ${isRTL ? 'rtl' : 'ltr'}; }
  h1 { color: #001F3F; border-bottom: 3px solid #C5A021; padding-bottom: 10px; }
  h2 { color: #001F3F; margin-top: 30px; border-bottom: 1px solid #e5e7eb; padding-bottom: 8px; }
  .meta { color: #6c737f; margin-bottom: 20px; }
  .stats-grid { display: flex; gap: 20px; margin: 20px 0; }
  .stat-box { flex: 1; background: #f5f5f5; padding: 16px; border-radius: 8px; text-align: center; }
  .stat-value { font-size: 22px; font-weight: bold; color: #C5A021; }
  .stat-label { font-size: 12px; color: #6c737f; margin-top: 4px; }
  table { width: 100%; border-collapse: collapse; margin: 16px 0; }
  th, td { padding: 10px 14px; text-align: ${isRTL ? 'right' : 'left'}; border-bottom: 1px solid #e5e7eb; }
  th { background: #001F3F; color: white; font-weight: 600; }
  tr:nth-child(even) { background: #f9fafb; }
  .badge { display: inline-block; padding: 3px 10px; border-radius: 12px; font-size: 12px; font-weight: 600; }
  .buy { background: #dcfce7; color: #22c55e; }
  .sell { background: #fee2e2; color: #ef4444; }
  .pending { background: #fef3c7; color: #f59e0b; }
  .processing { background: #dbeafe; color: #3b82f6; }
  .completed { background: #dcfce7; color: #22c55e; }
  .cancelled { background: #fee2e2; color: #ef4444; }
  .footer { margin-top: 40px; padding-top: 16px; border-top: 1px solid #e5e7eb; color: #6c737f; font-size: 11px; text-align: center; }
</style>
</head>
<body>
  <h1>${reportTitle}</h1>
  <p class="meta">${periodLabel} • ${dateStr}</p>

  <div class="stats-grid">
    <div class="stat-box">
      <div class="stat-value">${currencySymbol} ${revenueStats.total.toLocaleString()}</div>
      <div class="stat-label">${totalRevenue}</div>
    </div>
    <div class="stat-box">
      <div class="stat-value">${currencySymbol} ${revenueStats.avg.toFixed(0)}</div>
      <div class="stat-label">${avgOrderValue}</div>
    </div>
    <div class="stat-box">
      <div class="stat-value">${revenueStats.grams.toFixed(1)}</div>
      <div class="stat-label">${totalGrams}</div>
    </div>
  </div>

  <h2>${ordersByStatus}</h2>
  <table>
    <tr><th>${lang === 'ar' ? 'الحالة' : lang === 'fr' ? 'Statut' : 'Status'}</th><th>${lang === 'ar' ? 'العدد' : lang === 'fr' ? 'Nombre' : 'Count'}</th></tr>
    ${Object.entries(statusBreakdown).map(([s, c]) => `<tr><td><span class="badge ${s}">${statusLabels[s]}</span></td><td>${c}</td></tr>`).join('')}
  </table>

  <h2>${ordersByType}</h2>
  <table>
    <tr><th>${lang === 'ar' ? 'النوع' : lang === 'fr' ? 'Type' : 'Type'}</th><th>${lang === 'ar' ? 'العدد' : lang === 'fr' ? 'Nombre' : 'Count'}</th></tr>
    <tr><td><span class="badge buy">${buyLabel}</span></td><td>${typeBreakdown.buy}</td></tr>
    <tr><td><span class="badge sell">${sellLabel}</span></td><td>${typeBreakdown.sell}</td></tr>
  </table>

  <h2>${topClients}</h2>
  <table>
    <tr><th>#</th><th>${lang === 'ar' ? 'العميل' : lang === 'fr' ? 'Client' : 'Client'}</th><th>${lang === 'ar' ? 'الإيرادات' : lang === 'fr' ? 'Revenus' : 'Revenue'}</th><th>${ordersLabel}</th></tr>
    ${topClientsList.map((c, i) => `<tr><td>${i + 1}</td><td>${c.name}</td><td>${currencySymbol} ${c.revenue.toLocaleString()}</td><td>${c.orders}</td></tr>`).join('')}
  </table>

  <h2>${lang === 'ar' ? 'جميع الطلبات' : lang === 'fr' ? 'Toutes les commandes' : 'All Orders'}</h2>
  <table>
    <tr>
      <th>#</th>
      <th>${lang === 'ar' ? 'العميل' : lang === 'fr' ? 'Client' : 'Client'}</th>
      <th>${lang === 'ar' ? 'النوع' : lang === 'fr' ? 'Type' : 'Type'}</th>
      <th>${lang === 'ar' ? 'العيار' : lang === 'fr' ? 'Carat' : 'Karat'}</th>
      <th>${lang === 'ar' ? 'الوزن' : lang === 'fr' ? 'Poids' : 'Weight'}</th>
      <th>${lang === 'ar' ? 'الإجمالي' : lang === 'fr' ? 'Total' : 'Total'}</th>
      <th>${lang === 'ar' ? 'الحالة' : lang === 'fr' ? 'Statut' : 'Status'}</th>
      <th>${lang === 'ar' ? 'التاريخ' : lang === 'fr' ? 'Date' : 'Date'}</th>
    </tr>
    ${periodOrders.map((o, i) => `<tr>
      <td>${i + 1}</td>
      <td>${o.clientName}</td>
      <td><span class="badge ${o.type}">${o.type === 'buy' ? buyLabel : sellLabel}</span></td>
      <td>${o.karat}K</td>
      <td>${o.grams}g</td>
      <td>${currencySymbol} ${o.totalAmount.toLocaleString()}</td>
      <td><span class="badge ${o.status}">${statusLabels[o.status]}</span></td>
      <td>${o.date}</td>
    </tr>`).join('')}
  </table>

  <div class="footer">
    ${lang === 'ar' ? 'تم إنشاء هذا التقرير تلقائياً بواسطة تطبيق ذهبي' : lang === 'fr' ? 'Ce rapport a été généré automatiquement par l\'application Dhahabi' : 'This report was automatically generated by Dhahabi app'}
    • ${dateStr}
  </div>
</body>
</html>`;

      if (Platform.OS === 'web') {
        // On web, download as HTML
        const blob = new Blob([html], { type: 'text/html' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `trader-report-${period}-${Date.now()}.html`;
        a.click();
        URL.revokeObjectURL(url);
      } else {
        // On native (Android/iOS), use expo-print to generate a real PDF
        const { uri: tempUri } = await Print.printToFileAsync({ html });
        const pdfUri = FileSystem.documentDirectory + `trader-report-${period}-${Date.now()}.pdf`;
        await FileSystem.moveAsync({ from: tempUri, to: pdfUri });
        const canShare = await Sharing.isAvailableAsync();
        if (canShare) {
          await Sharing.shareAsync(pdfUri, {
            mimeType: 'application/pdf',
            dialogTitle: reportTitle,
          });
        }
        Alert.alert('', exportSuccess);
      }
    } catch (e) {
      console.warn('[Export] Failed:', e);
    }
    setExporting(false);
  }, [period, periodOrders, revenueStats, statusBreakdown, typeBreakdown, topClientsList, lang, isRTL, currencySymbol]);

  const periods: { key: Period; label: string }[] = [
    { key: 'week', label: weekLabel },
    { key: 'month', label: monthLabel },
    { key: 'all', label: allLabel },
  ];

  const statusColors: Record<string, string> = {
    pending: '#F59E0B',
    processing: '#3B82F6',
    completed: '#22C55E',
    cancelled: '#EF4444',
  };

  const statusLabels: Record<string, string> = {
    pending: pendingLabel,
    processing: processingLabel,
    completed: completedLabel,
    cancelled: cancelledLabel,
  };

  const totalStatusOrders = Object.values(statusBreakdown).reduce((a, b) => a + b, 0) || 1;

  return (
    <View style={styles.screen}>
      <SafeAreaView style={styles.safeArea} edges={['top']}>
        {/* App Bar */}
        <View style={styles.appBar}>
          <View style={{ width: 40 }} />
          <Text style={[styles.appBarTitle, { writingDirection: direction }]}>{titleLabel}</Text>
          <TouchableOpacity onPress={onOpenDrawer} style={styles.menuBtn} activeOpacity={0.7}>
            <MaterialIcons name="menu" size={24} color="#F8F9FA" />
          </TouchableOpacity>
        </View>

        {/* Period Selector */}
        <View style={styles.periodRow}>
          {periods.map(p => (
            <TouchableOpacity
              key={p.key}
              style={[styles.periodChip, period === p.key && styles.periodChipActive]}
              onPress={() => setPeriod(p.key)}
              activeOpacity={0.7}
            >
              <Text style={[styles.periodChipText, period === p.key && styles.periodChipTextActive]}>
                {p.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
          {/* Revenue Overview */}
          <GoldCard title={revenueOverview}>
            <View style={[styles.overviewGrid, { flexDirection: flexDir }]}>
              <View style={styles.overviewItem}>
                <MaterialIcons name="account-balance-wallet" size={24} color="#C5A021" />
                <Text style={styles.overviewValue}>{currencySymbol} {revenueStats.total.toLocaleString()}</Text>
                <Text style={[styles.overviewLabel, { writingDirection: direction }]}>{totalRevenue}</Text>
              </View>
              <View style={styles.overviewDivider} />
              <View style={styles.overviewItem}>
                <MaterialIcons name="trending-up" size={24} color="#22C55E" />
                <Text style={styles.overviewValue}>{currencySymbol} {revenueStats.avg.toFixed(0)}</Text>
                <Text style={[styles.overviewLabel, { writingDirection: direction }]}>{avgOrderValue}</Text>
              </View>
              <View style={styles.overviewDivider} />
              <View style={styles.overviewItem}>
                <MaterialIcons name="scale" size={24} color="#3B82F6" />
                <Text style={styles.overviewValue}>{revenueStats.grams.toFixed(1)}</Text>
                <Text style={[styles.overviewLabel, { writingDirection: direction }]}>{totalGrams}</Text>
              </View>
            </View>
          </GoldCard>

          {/* Daily Revenue Bar Chart - Interactive */}
          <GoldCard title={dailyRevenue}>
            <InteractiveBarChart
              data={dailyRevenueData.map(d => ({ label: d.label, value: d.value }))}
              height={180}
              formatValue={(v) => `${currencySymbol} ${v >= 1000 ? `${(v / 1000).toFixed(1)}K` : v.toLocaleString()}`}
              isRTL={isRTL}
            />
          </GoldCard>

          {/* Orders by Status - Interactive Pie */}
          <GoldCard title={ordersByStatus}>
            <InteractivePieChart
              data={Object.entries(statusBreakdown).filter(([_, c]) => c > 0).map(([status, count]) => ({
                label: statusLabels[status],
                value: count,
                color: statusColors[status],
              }))}
              isRTL={isRTL}
              formatValue={(v) => `${v} ${ordersLabel}`}
            />
          </GoldCard>

          {/* Orders by Type */}
          <GoldCard title={ordersByType}>
            <View style={[styles.typeRow, { flexDirection: flexDir }]}>
              <View style={styles.typeItem}>
                <View style={[styles.typeIcon, { backgroundColor: 'rgba(34,197,94,0.15)' }]}>
                  <MaterialIcons name="arrow-downward" size={24} color="#22C55E" />
                </View>
                <Text style={styles.typeValue}>{typeBreakdown.buy}</Text>
                <Text style={[styles.typeLabel, { writingDirection: direction }]}>{buyLabel}</Text>
              </View>
              <View style={styles.typeDivider} />
              <View style={styles.typeItem}>
                <View style={[styles.typeIcon, { backgroundColor: 'rgba(239,68,68,0.15)' }]}>
                  <MaterialIcons name="arrow-upward" size={24} color="#EF4444" />
                </View>
                <Text style={styles.typeValue}>{typeBreakdown.sell}</Text>
                <Text style={[styles.typeLabel, { writingDirection: direction }]}>{sellLabel}</Text>
              </View>
            </View>
          </GoldCard>

          {/* Karat Distribution */}
          {karatBreakdown.length > 0 && (
            <GoldCard title={karatDistribution}>
              {karatBreakdown.map(([karat, count]) => {
                const pct = ((count / periodOrders.length) * 100).toFixed(0);
                return (
                  <View key={karat} style={styles.progressRow}>
                    <View style={[styles.progressHeader, { flexDirection: flexDir }]}>
                      <Text style={styles.progressCount}>{count} {ordersLabel}</Text>
                      <Text style={[styles.karatLabel, { writingDirection: direction }]}>
                        {lang === 'ar' ? `عيار ${karat}` : `${karat}K`}
                      </Text>
                    </View>
                    <View style={styles.progressTrack}>
                      <View style={[styles.progressFill, { width: `${pct}%` as DimensionValue, backgroundColor: '#C5A021' }]} />
                    </View>
                  </View>
                );
              })}
            </GoldCard>
          )}

          {/* Top Clients */}
          {topClientsList.length > 0 && (
            <GoldCard title={topClients}>
              {topClientsList.map((client, i) => (
                <View key={i} style={styles.topClientRow}>
                  <View style={[styles.topClientHeader, { flexDirection: flexDir }]}>
                    <Text style={styles.topClientRevenue}>
                      {currencySymbol} {client.revenue.toLocaleString()}
                    </Text>
                    <View style={[styles.topClientInfo, { flexDirection: flexDir, alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
                      <View style={styles.topClientRank}>
                        <Text style={styles.topClientRankText}>{i + 1}</Text>
                      </View>
                      <View style={isRTL ? { marginLeft: 10 } : { marginRight: 0 }}>
                        <Text style={[styles.topClientName, { writingDirection: direction }]}>{client.name}</Text>
                        <Text style={[styles.topClientOrders, { writingDirection: direction }]}>{client.orders} {ordersLabel}</Text>
                      </View>
                    </View>
                  </View>
                  <View style={styles.topClientBar}>
                    <View style={[styles.topClientBarFill, { width: `${(client.revenue / maxClientRevenue) * 100}%` as DimensionValue }]} />
                  </View>
                </View>
              ))}
            </GoldCard>
          )}

          {/* Export Button */}
          {permissions.canExportReports && (
            <TouchableOpacity
              onPress={handleExportPDF}
              style={[styles.exportBtn, exporting && styles.exportBtnDisabled]}
              activeOpacity={0.7}
              disabled={exporting}
            >
              <MaterialIcons name="picture-as-pdf" size={20} color="#001F3F" />
              <Text style={[styles.exportBtnText, { writingDirection: direction }]}>
                {exporting ? exportingLabel : exportLabel}
              </Text>
            </TouchableOpacity>
          )}

          <View style={{ height: 40 }} />
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#001F3F' },
  safeArea: { flex: 1 },
  appBar: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 12,
    borderBottomWidth: 1, borderBottomColor: 'rgba(248,249,250,0.08)',
  },
  appBarTitle: { fontSize: 18, fontWeight: '700', color: '#F8F9FA' },
  menuBtn: { padding: 8 },
  scrollContent: { paddingHorizontal: 16, paddingTop: 8 },

  // Period selector
  periodRow: { flexDirection: 'row', paddingHorizontal: 16, paddingVertical: 10, gap: 8 },
  periodChip: {
    flex: 1, paddingVertical: 10, borderRadius: 12, alignItems: 'center',
    backgroundColor: 'rgba(248,249,250,0.06)',
    borderWidth: 1, borderColor: 'rgba(248,249,250,0.1)',
  },
  periodChipActive: {
    backgroundColor: 'rgba(197,160,33,0.15)', borderColor: '#C5A021',
  },
  periodChipText: { fontSize: 14, fontWeight: '500', color: '#6C737F' },
  periodChipTextActive: { color: '#C5A021', fontWeight: '700' },

  // Overview
  overviewGrid: { justifyContent: 'space-between', alignItems: 'center' },
  overviewItem: { alignItems: 'center', gap: 6, flex: 1 },
  overviewValue: { fontSize: 16, fontWeight: '700', color: '#1A1A1B' },
  overviewLabel: { fontSize: 11, color: '#6C737F', textAlign: 'center' },
  overviewDivider: { width: 1, height: 50, backgroundColor: '#E6E8EA' },

  // Bar chart
  barChart: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end', height: 140, paddingTop: 8 },
  barItem: { alignItems: 'center', flex: 1, gap: 4 },
  barValue: { fontSize: 9, color: '#6C737F', fontWeight: '600' },
  barTrack: {
    width: 24, height: 100, backgroundColor: 'rgba(197,160,33,0.08)',
    borderRadius: 6, overflow: 'hidden', justifyContent: 'flex-end',
  },
  barFill: { backgroundColor: '#C5A021', borderRadius: 6, width: '100%' },
  barLabel: { fontSize: 10, color: '#6C737F', fontWeight: '500' },

  // Progress bars
  progressRow: { marginBottom: 14 },
  progressHeader: { justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 },
  progressLabelRow: { alignItems: 'center', gap: 6 },
  progressDot: { width: 8, height: 8, borderRadius: 4 },
  progressLabel: { fontSize: 13, fontWeight: '500', color: '#1A1A1B' },
  progressCount: { fontSize: 13, fontWeight: '700', color: '#1A1A1B' },
  progressTrack: {
    height: 8, backgroundColor: '#F0F0F0', borderRadius: 4, overflow: 'hidden',
  },
  progressFill: { height: '100%', borderRadius: 4 },
  karatLabel: { fontSize: 14, fontWeight: '600', color: '#C5A021' },

  // Type breakdown
  typeRow: { justifyContent: 'space-around', alignItems: 'center', paddingVertical: 8 },
  typeItem: { alignItems: 'center', gap: 8 },
  typeIcon: { width: 48, height: 48, borderRadius: 24, alignItems: 'center', justifyContent: 'center' },
  typeValue: { fontSize: 24, fontWeight: '700', color: '#1A1A1B' },
  typeLabel: { fontSize: 13, color: '#6C737F', fontWeight: '500' },
  typeDivider: { width: 1, height: 60, backgroundColor: '#E6E8EA' },

  // Top clients
  topClientRow: { marginBottom: 16 },
  topClientHeader: { justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 },
  topClientInfo: { alignItems: 'center', gap: 10 },
  topClientRank: {
    width: 24, height: 24, borderRadius: 12,
    backgroundColor: 'rgba(197,160,33,0.15)',
    alignItems: 'center', justifyContent: 'center',
  },
  topClientRankText: { fontSize: 12, fontWeight: '700', color: '#C5A021' },
  topClientName: { fontSize: 14, fontWeight: '600', color: '#1A1A1B' },
  topClientOrders: { fontSize: 11, color: '#6C737F' },
  topClientRevenue: { fontSize: 14, fontWeight: '700', color: '#22C55E' },
  topClientBar: {
    height: 6, backgroundColor: '#F0F0F0', borderRadius: 3, overflow: 'hidden',
  },
  topClientBarFill: { height: '100%', backgroundColor: '#C5A021', borderRadius: 3 },

  // Export button
  exportBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: 8, backgroundColor: '#C5A021', paddingVertical: 14,
    borderRadius: 14, marginTop: 20,
  },
  exportBtnDisabled: { opacity: 0.6 },
  exportBtnText: { fontSize: 15, fontWeight: '700', color: '#001F3F' },
});
