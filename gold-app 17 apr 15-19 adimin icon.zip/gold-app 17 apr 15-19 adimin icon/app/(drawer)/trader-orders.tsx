import React, { useState, useMemo, useCallback } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, FlatList, ScrollView, TextInput, Platform, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { GoldCard } from '@/components/gold/GoldCard';
import { useI18n } from '@/i18n';
import { useSettings } from '@/contexts/SettingsContext';
import { useTraderData, type TraderOrder, type OrderStatus } from '@/contexts/TraderDataContext';
import { exportOrders } from '@/services/ExportService';
import { useTraderPermissions } from '@/hooks/useTraderPermissions';

interface TraderOrdersScreenProps {
  onOpenDrawer: () => void;
  onNavigate?: (screen: string, params?: any) => void;
}

export default function TraderOrdersScreen({ onOpenDrawer, onNavigate }: TraderOrdersScreenProps) {
  const { isRTL, textAlign, direction, flexDir, lang } = useI18n();
  const { settings } = useSettings();
  const { orders, updateOrderStatus } = useTraderData();
  const { permissions } = useTraderPermissions();
  const [filter, setFilter] = useState<'all' | OrderStatus>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [dateFilter, setDateFilter] = useState<'all' | 'today' | 'week' | 'month'>('all');

  // Translations
  const title = lang === 'ar' ? 'الطلبات' : lang === 'fr' ? 'Commandes' : 'Orders';
  const allLabel = lang === 'ar' ? 'الكل' : lang === 'fr' ? 'Tous' : 'All';
  const pendingLabel = lang === 'ar' ? 'معلق' : lang === 'fr' ? 'En attente' : 'Pending';
  const processingLabel = lang === 'ar' ? 'قيد التنفيذ' : lang === 'fr' ? 'En cours' : 'Processing';
  const completedLabel = lang === 'ar' ? 'مكتمل' : lang === 'fr' ? 'Terminé' : 'Completed';
  const cancelledLabel = lang === 'ar' ? 'ملغي' : lang === 'fr' ? 'Annulé' : 'Cancelled';
  const buyLabel = lang === 'ar' ? 'شراء' : lang === 'fr' ? 'Achat' : 'Buy';
  const sellLabel = lang === 'ar' ? 'بيع' : lang === 'fr' ? 'Vente' : 'Sell';
  const gramsLabel = lang === 'ar' ? 'غرام' : lang === 'fr' ? 'grammes' : 'grams';
  const karatLabel = lang === 'ar' ? 'عيار' : lang === 'fr' ? 'Carat' : 'Karat';
  const noOrders = lang === 'ar' ? 'لا توجد طلبات' : lang === 'fr' ? 'Aucune commande' : 'No orders';
  const totalLabel = lang === 'ar' ? 'الإجمالي' : lang === 'fr' ? 'Total' : 'Total';
  const markProcessing = lang === 'ar' ? 'قيد التنفيذ' : lang === 'fr' ? 'En cours' : 'Processing';
  const markCompleted = lang === 'ar' ? 'مكتمل' : lang === 'fr' ? 'Terminé' : 'Complete';
  const markCancelled = lang === 'ar' ? 'إلغاء' : lang === 'fr' ? 'Annuler' : 'Cancel';
  const searchPlaceholder = lang === 'ar' ? 'بحث بالاسم أو المبلغ...' : lang === 'fr' ? 'Rechercher par nom ou montant...' : 'Search by name or amount...';
  const todayLabel = lang === 'ar' ? 'اليوم' : lang === 'fr' ? "Aujourd'hui" : 'Today';
  const weekLabel = lang === 'ar' ? 'الأسبوع' : lang === 'fr' ? 'Semaine' : 'Week';
  const monthLabel = lang === 'ar' ? 'الشهر' : lang === 'fr' ? 'Mois' : 'Month';
  const noResults = lang === 'ar' ? 'لا توجد نتائج' : lang === 'fr' ? 'Aucun résultat' : 'No results found';
  const exportLabel = lang === 'ar' ? 'تصدير CSV' : lang === 'fr' ? 'Exporter CSV' : 'Export CSV';
  const exportSuccess = lang === 'ar' ? 'تم التصدير بنجاح' : lang === 'fr' ? 'Exporté avec succès' : 'Exported successfully';

  const currencySymbol = settings.preferredCurrency === 'USD' ? '$' : settings.preferredCurrency === 'EUR' ? '€' : settings.preferredCurrency === 'SAR' ? 'ر.س' : settings.preferredCurrency === 'AED' ? 'د.إ' : settings.preferredCurrency === 'EGP' ? 'ج.م' : '$';

  // Date filter logic
  const dateFilteredOrders = useMemo(() => {
    const now = Date.now();
    const todayStr = new Date().toISOString().split('T')[0];
    const weekAgo = now - 7 * 86400000;
    const monthAgo = now - 30 * 86400000;

    switch (dateFilter) {
      case 'today': return orders.filter(o => o.date === todayStr);
      case 'week': return orders.filter(o => o.createdAt >= weekAgo);
      case 'month': return orders.filter(o => o.createdAt >= monthAgo);
      default: return orders;
    }
  }, [orders, dateFilter]);

  // Status filter
  const statusFilteredOrders = useMemo(() => {
    return filter === 'all' ? dateFilteredOrders : dateFilteredOrders.filter(o => o.status === filter);
  }, [dateFilteredOrders, filter]);

  // Search filter
  const filteredOrders = useMemo(() => {
    if (!searchQuery.trim()) return statusFilteredOrders;
    const q = searchQuery.toLowerCase().trim();
    return statusFilteredOrders.filter(o =>
      o.clientName.toLowerCase().includes(q) ||
      o.id.toLowerCase().includes(q) ||
      o.totalAmount.toString().includes(q) ||
      o.grams.toString().includes(q)
    );
  }, [statusFilteredOrders, searchQuery]);

  const [exporting, setExporting] = useState(false);

  const handleExport = useCallback(async () => {
    setExporting(true);
    const success = await exportOrders(filteredOrders, lang, currencySymbol);
    if (success && Platform.OS !== 'web') {
      Alert.alert('', exportSuccess);
    }
    setExporting(false);
  }, [filteredOrders, lang, currencySymbol, exportSuccess]);

  const statusFilters: { key: 'all' | OrderStatus; label: string; count: number }[] = [
    { key: 'all', label: allLabel, count: dateFilteredOrders.length },
    { key: 'pending', label: pendingLabel, count: dateFilteredOrders.filter(o => o.status === 'pending').length },
    { key: 'processing', label: processingLabel, count: dateFilteredOrders.filter(o => o.status === 'processing').length },
    { key: 'completed', label: completedLabel, count: dateFilteredOrders.filter(o => o.status === 'completed').length },
    { key: 'cancelled', label: cancelledLabel, count: dateFilteredOrders.filter(o => o.status === 'cancelled').length },
  ];

  const dateFilters: { key: 'all' | 'today' | 'week' | 'month'; label: string }[] = [
    { key: 'all', label: allLabel },
    { key: 'today', label: todayLabel },
    { key: 'week', label: weekLabel },
    { key: 'month', label: monthLabel },
  ];

  const getStatusColor = (status: OrderStatus) => {
    switch (status) {
      case 'completed': return '#22C55E';
      case 'pending': return '#F59E0B';
      case 'processing': return '#3B82F6';
      case 'cancelled': return '#EF4444';
    }
  };

  const getStatusLabel = (status: OrderStatus) => {
    switch (status) {
      case 'completed': return completedLabel;
      case 'pending': return pendingLabel;
      case 'processing': return processingLabel;
      case 'cancelled': return cancelledLabel;
    }
  };

  const handleStatusChange = (order: TraderOrder, newStatus: OrderStatus) => {
    updateOrderStatus(order.id, newStatus);
  };

  const renderOrder = ({ item }: { item: TraderOrder }) => (
    <TouchableOpacity activeOpacity={0.8} onPress={() => onNavigate?.('order-detail', { orderId: item.id })}>
    <GoldCard>
      <View style={[styles.orderHeader, { flexDirection: flexDir }]}>
        <View style={[styles.statusBadge, { backgroundColor: getStatusColor(item.status) + '20' }]}>
          <Text style={[styles.statusText, { color: getStatusColor(item.status) }]}>
            {getStatusLabel(item.status)}
          </Text>
        </View>
        <View style={[styles.orderHeaderInfo, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
          <Text style={[styles.clientName, { writingDirection: direction }]}>{item.clientName}</Text>
          <Text style={[styles.orderDate, { writingDirection: direction }]}>{item.date} - {item.time}</Text>
        </View>
      </View>

      <View style={styles.orderDivider} />

      <View style={[styles.orderBody, { flexDirection: flexDir }]}>
        <View style={styles.orderDetail}>
          <Text style={[styles.detailLabel, { writingDirection: direction }]}>{totalLabel}</Text>
          <Text style={styles.detailValue}>{currencySymbol} {item.totalAmount.toLocaleString()}</Text>
        </View>
        <View style={styles.orderDetail}>
          <Text style={[styles.detailLabel, { writingDirection: direction }]}>{gramsLabel}</Text>
          <Text style={styles.detailValue}>{item.grams}</Text>
        </View>
        <View style={styles.orderDetail}>
          <Text style={[styles.detailLabel, { writingDirection: direction }]}>{karatLabel}</Text>
          <Text style={styles.detailValue}>{item.karat}</Text>
        </View>
        <View style={styles.orderDetail}>
          <Text style={[styles.detailLabel, { writingDirection: direction }]}>
            {lang === 'ar' ? 'النوع' : lang === 'fr' ? 'Type' : 'Type'}
          </Text>
          <Text style={[styles.detailValue, { color: item.type === 'buy' ? '#22C55E' : '#EF4444' }]}>
            {item.type === 'buy' ? buyLabel : sellLabel}
          </Text>
        </View>
      </View>

      {/* View Details hint */}
      <View style={[styles.viewDetailRow, { flexDirection: flexDir }]}>
        <Text style={[styles.viewDetailText, { writingDirection: direction }]}>
          {lang === 'ar' ? 'اضغط لعرض التفاصيل' : lang === 'fr' ? 'Appuyez pour voir les détails' : 'Tap to view details'}
        </Text>
        <MaterialIcons name={isRTL ? 'chevron-left' : 'chevron-right'} size={16} color="#6C737F" />
      </View>

      {permissions.canEditOrders && (item.status === 'pending' || item.status === 'processing') && (
        <>
          <View style={styles.orderDivider} />
          <View style={[styles.actionRow, { flexDirection: flexDir }]}>
            {item.status === 'pending' && (
              <TouchableOpacity
                style={[styles.actionBtn, { backgroundColor: 'rgba(59,130,246,0.15)' }]}
                onPress={() => handleStatusChange(item, 'processing')}
                activeOpacity={0.7}
              >
                <MaterialIcons name="autorenew" size={14} color="#3B82F6" />
                <Text style={[styles.actionBtnText, { color: '#3B82F6' }]}>{markProcessing}</Text>
              </TouchableOpacity>
            )}
            <TouchableOpacity
              style={[styles.actionBtn, { backgroundColor: 'rgba(34,197,94,0.15)' }]}
              onPress={() => handleStatusChange(item, 'completed')}
              activeOpacity={0.7}
            >
              <MaterialIcons name="check-circle" size={14} color="#22C55E" />
              <Text style={[styles.actionBtnText, { color: '#22C55E' }]}>{markCompleted}</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.actionBtn, { backgroundColor: 'rgba(239,68,68,0.15)' }]}
              onPress={() => handleStatusChange(item, 'cancelled')}
              activeOpacity={0.7}
            >
              <MaterialIcons name="cancel" size={14} color="#EF4444" />
              <Text style={[styles.actionBtnText, { color: '#EF4444' }]}>{markCancelled}</Text>
            </TouchableOpacity>
          </View>
        </>
      )}
    </GoldCard>
    </TouchableOpacity>
  );

  return (
    <View style={styles.screen}>
      <SafeAreaView style={styles.safeArea} edges={['top']}>
        {/* App Bar */}
        <View style={styles.appBar}>
          <View style={{ flexDirection: 'row', gap: 4 }}>
            {permissions.canCreateOrders && (
              <TouchableOpacity onPress={() => onNavigate?.('new-order')} style={styles.addBtn} activeOpacity={0.7}>
                <MaterialIcons name="add" size={24} color="#C5A021" />
              </TouchableOpacity>
            )}
            <TouchableOpacity onPress={handleExport} style={styles.addBtn} activeOpacity={0.7} disabled={exporting}>
              <MaterialIcons name="file-download" size={22} color={exporting ? '#6C737F' : '#C5A021'} />
            </TouchableOpacity>
          </View>
          <Text style={[styles.appBarTitle, { writingDirection: direction }]}>{title}</Text>
          <TouchableOpacity onPress={onOpenDrawer} style={styles.menuBtn} activeOpacity={0.7}>
            <MaterialIcons name="menu" size={24} color="#F8F9FA" />
          </TouchableOpacity>
        </View>

        {/* Search Bar */}
        <View style={styles.searchContainer}>
          <View style={[styles.searchBar, { flexDirection: flexDir }]}>
            <MaterialIcons name="search" size={20} color="#6C737F" style={isRTL ? { marginLeft: 8 } : { marginRight: 8 }} />
            <TextInput
              value={searchQuery}
              onChangeText={setSearchQuery}
              placeholder={searchPlaceholder}
              placeholderTextColor="#6C737F"
              style={[styles.searchInput, { textAlign, writingDirection: direction }]}
              returnKeyType="search"
            />
            {searchQuery.length > 0 && (
              <TouchableOpacity onPress={() => setSearchQuery('')} activeOpacity={0.7}>
                <MaterialIcons name="close" size={18} color="#6C737F" />
              </TouchableOpacity>
            )}
          </View>
        </View>

        {/* Date Range Filter */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.dateFilterContainer}
          style={styles.dateFilterScroll}
        >
          {dateFilters.map(f => (
            <TouchableOpacity
              key={f.key}
              style={[styles.dateChip, dateFilter === f.key && styles.dateChipActive]}
              onPress={() => setDateFilter(f.key)}
              activeOpacity={0.7}
            >
              <Text style={[styles.dateChipText, dateFilter === f.key && styles.dateChipTextActive]}>
                {f.label}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        {/* Status Filter Chips */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.filterContainer}
          style={styles.filterScroll}
        >
          {statusFilters.map(f => (
            <TouchableOpacity
              key={f.key}
              style={[styles.filterChip, filter === f.key && styles.filterChipActive]}
              onPress={() => setFilter(f.key)}
              activeOpacity={0.7}
            >
              <Text style={[styles.filterChipText, filter === f.key && styles.filterChipTextActive]}>
                {f.label} ({f.count})
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        {/* Results Count */}
        {(searchQuery.trim() || dateFilter !== 'all') && (
          <View style={styles.resultsCount}>
            <Text style={[styles.resultsText, { textAlign, writingDirection: direction }]}>
              {filteredOrders.length} {lang === 'ar' ? 'نتيجة' : lang === 'fr' ? 'résultat(s)' : 'result(s)'}
            </Text>
          </View>
        )}

        {/* Orders List */}
        <FlatList
          data={filteredOrders}
          keyExtractor={item => item.id}
          renderItem={renderOrder}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={
            <View style={styles.emptyState}>
              <MaterialIcons name={searchQuery ? 'search-off' : 'inbox'} size={48} color="#6C737F" />
              <Text style={styles.emptyText}>{searchQuery ? noResults : noOrders}</Text>
            </View>
          }
        />
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#001F3F' },
  safeArea: { flex: 1 },
  appBar: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 12,
    borderBottomWidth: 1, borderBottomColor: 'rgba(248,249,250,0.08)',
  },
  appBarTitle: { fontSize: 18, fontWeight: '700', color: '#F8F9FA' },
  menuBtn: { padding: 8 },
  addBtn: { padding: 8 },
  listContent: { paddingHorizontal: 16, paddingTop: 4, paddingBottom: 32 },

  // Search
  searchContainer: { paddingHorizontal: 16, paddingTop: 10, paddingBottom: 4 },
  searchBar: {
    backgroundColor: 'rgba(248,249,250,0.08)',
    borderRadius: 12, borderWidth: 1, borderColor: 'rgba(248,249,250,0.1)',
    paddingHorizontal: 14, paddingVertical: 10,
    alignItems: 'center',
  },
  searchInput: { flex: 1, fontSize: 14, color: '#F8F9FA', padding: 0 },

  // Date Filter
  dateFilterScroll: { maxHeight: 44 },
  dateFilterContainer: { paddingHorizontal: 16, paddingVertical: 6, gap: 6 },
  dateChip: {
    paddingHorizontal: 14, paddingVertical: 6, borderRadius: 16,
    backgroundColor: 'rgba(248,249,250,0.06)',
    borderWidth: 1, borderColor: 'rgba(248,249,250,0.08)',
  },
  dateChipActive: {
    backgroundColor: 'rgba(59,130,246,0.15)', borderColor: '#3B82F6',
  },
  dateChipText: { fontSize: 12, fontWeight: '500', color: '#6C737F' },
  dateChipTextActive: { color: '#3B82F6', fontWeight: '600' },

  // Status Filters
  filterScroll: { maxHeight: 44 },
  filterContainer: { paddingHorizontal: 16, paddingVertical: 6, gap: 8 },
  filterChip: {
    paddingHorizontal: 16, paddingVertical: 8, borderRadius: 20,
    backgroundColor: 'rgba(248,249,250,0.06)',
    borderWidth: 1, borderColor: 'rgba(248,249,250,0.1)',
  },
  filterChipActive: {
    backgroundColor: 'rgba(197,160,33,0.15)', borderColor: '#C5A021',
  },
  filterChipText: { fontSize: 13, fontWeight: '500', color: '#6C737F' },
  filterChipTextActive: { color: '#C5A021', fontWeight: '600' },

  // Results count
  resultsCount: { paddingHorizontal: 20, paddingVertical: 4 },
  resultsText: { fontSize: 12, color: '#6C737F' },

  // Order Card
  orderHeader: { justifyContent: 'space-between', alignItems: 'center' },
  orderHeaderInfo: { flex: 1 },
  clientName: { fontSize: 15, fontWeight: '600', color: '#1A1A1B' },
  orderDate: { fontSize: 12, color: '#6C737F', marginTop: 2 },
  statusBadge: { borderRadius: 8, paddingHorizontal: 10, paddingVertical: 4 },
  statusText: { fontSize: 11, fontWeight: '600' },
  orderDivider: { height: 1, backgroundColor: '#E6E8EA', marginVertical: 10 },
  orderBody: { justifyContent: 'space-between' },
  orderDetail: { alignItems: 'center', gap: 2 },
  detailLabel: { fontSize: 11, color: '#6C737F' },
  detailValue: { fontSize: 14, fontWeight: '700', color: '#1A1A1B' },

  // Action buttons
  actionRow: { gap: 8, justifyContent: 'center' },
  actionBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    paddingHorizontal: 12, paddingVertical: 6, borderRadius: 8,
  },
  actionBtnText: { fontSize: 12, fontWeight: '600' },

  // View detail
  viewDetailRow: { alignItems: 'center', justifyContent: 'center', gap: 4, paddingTop: 10, borderTopWidth: 1, borderTopColor: 'rgba(0,0,0,0.06)' },
  viewDetailText: { fontSize: 11, color: '#6C737F', fontWeight: '500' },

  // Empty
  emptyState: { alignItems: 'center', paddingVertical: 60, gap: 12 },
  emptyText: { fontSize: 15, color: '#6C737F' },
});
