import React, { useState, useMemo, useCallback } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, TextInput, Platform, Keyboard } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { GoldCard } from '@/components/gold/GoldCard';
import { useI18n } from '@/i18n';
import { useAuth } from '@/contexts/AuthContext';
import { useTraderData, type TraderOrder, type TraderClient } from '@/contexts/TraderDataContext';
import { useMessaging, type Conversation } from '@/contexts/MessagingContext';
import { useAppData } from '@/contexts/AppDataContext';
import type { GoldPrice, Purchase } from '@/data/mock';

interface SearchScreenProps {
  onOpenDrawer: () => void;
  onNavigate?: (screen: string, params?: any) => void;
}

type SearchCategory = 'all' | 'orders' | 'clients' | 'messages' | 'prices' | 'purchases';

export default function SearchScreen({ onOpenDrawer, onNavigate }: SearchScreenProps) {
  const { t, isRTL, direction, flexDir, lang } = useI18n();
  const { user } = useAuth();
  const traderData = useTraderData();
  const messaging = useMessaging();
  const appData = useAppData();
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState<SearchCategory>('all');

  const isTrader = user?.role === 'trader';
  const isAdmin = user?.role === 'admin';

  // Translations
  const searchTitle = lang === 'ar' ? 'البحث الشامل' : lang === 'fr' ? 'Recherche globale' : 'Universal Search';
  const searchPlaceholder = lang === 'ar' ? 'ابحث في الطلبات، العملاء، الرسائل...' : lang === 'fr' ? 'Rechercher commandes, clients, messages...' : 'Search orders, clients, messages...';
  const allLabel = lang === 'ar' ? 'الكل' : lang === 'fr' ? 'Tout' : 'All';
  const ordersLabel = lang === 'ar' ? 'الطلبات' : lang === 'fr' ? 'Commandes' : 'Orders';
  const clientsLabel = lang === 'ar' ? 'العملاء' : lang === 'fr' ? 'Clients' : 'Clients';
  const messagesLabel = lang === 'ar' ? 'الرسائل' : lang === 'fr' ? 'Messages' : 'Messages';
  const pricesLabel = lang === 'ar' ? 'الأسعار' : lang === 'fr' ? 'Prix' : 'Prices';
  const purchasesLabel = lang === 'ar' ? 'المشتريات' : lang === 'fr' ? 'Achats' : 'Purchases';
  const noResults = lang === 'ar' ? 'لا توجد نتائج' : lang === 'fr' ? 'Aucun résultat' : 'No results found';
  const startSearch = lang === 'ar' ? 'ابدأ البحث بكتابة كلمة...' : lang === 'fr' ? 'Commencez à taper pour chercher...' : 'Start typing to search...';
  const buyLabel = lang === 'ar' ? 'شراء' : lang === 'fr' ? 'Achat' : 'Buy';
  const sellLabel = lang === 'ar' ? 'بيع' : lang === 'fr' ? 'Vente' : 'Sell';

  const categories: { key: SearchCategory; label: string; icon: string; roles: string[] }[] = [
    { key: 'all', label: allLabel, icon: 'search', roles: ['user', 'trader', 'admin'] },
    { key: 'orders', label: ordersLabel, icon: 'receipt-long', roles: ['trader', 'admin'] },
    { key: 'clients', label: clientsLabel, icon: 'people', roles: ['trader', 'admin'] },
    { key: 'messages', label: messagesLabel, icon: 'chat', roles: ['trader', 'admin'] },
    { key: 'prices', label: pricesLabel, icon: 'trending-up', roles: ['user', 'trader', 'admin'] },
    { key: 'purchases', label: purchasesLabel, icon: 'shopping-bag', roles: ['user', 'admin'] },
  ];

  const visibleCategories = categories.filter(c => c.roles.includes(user?.role || 'user'));

  const normalizeQuery = (q: string) => q.toLowerCase().trim();

  // Search orders
  const filteredOrders = useMemo(() => {
    if (!query.trim() || (!isTrader && !isAdmin)) return [];
    const q = normalizeQuery(query);
    return traderData.orders.filter(o =>
      o.clientName.toLowerCase().includes(q) ||
      o.id.toLowerCase().includes(q) ||
      o.karat.toLowerCase().includes(q) ||
      o.status.toLowerCase().includes(q) ||
      o.totalAmount.toString().includes(q) ||
      (o.notes && o.notes.toLowerCase().includes(q))
    );
  }, [query, traderData.orders, isTrader, isAdmin]);

  // Search clients
  const filteredClients = useMemo(() => {
    if (!query.trim() || (!isTrader && !isAdmin)) return [];
    const q = normalizeQuery(query);
    return traderData.clients.filter(c =>
      c.name.toLowerCase().includes(q) ||
      c.email.toLowerCase().includes(q) ||
      c.phone.includes(q)
    );
  }, [query, traderData.clients, isTrader, isAdmin]);

  // Search conversations
  const filteredConversations = useMemo(() => {
    if (!query.trim() || (!isTrader && !isAdmin)) return [];
    const q = normalizeQuery(query);
    return messaging.conversations.filter(c =>
      c.clientName.toLowerCase().includes(q) ||
      c.traderName.toLowerCase().includes(q) ||
      c.lastMessage.toLowerCase().includes(q)
    );
  }, [query, messaging.conversations, isTrader, isAdmin]);

  // Search prices
  const filteredPrices = useMemo(() => {
    if (!query.trim()) return [];
    const q = normalizeQuery(query);
    return appData.prices.filter(p =>
      p.karat.toLowerCase().includes(q) ||
      p.karatLabel.toLowerCase().includes(q) ||
      p.buyPrice.toString().includes(q) ||
      p.sellPrice.toString().includes(q)
    );
  }, [query, appData.prices]);

  // Search purchases
  const filteredPurchases = useMemo(() => {
    if (!query.trim()) return [];
    const q = normalizeQuery(query);
    return appData.purchasesList.filter(p =>
      p.name.toLowerCase().includes(q) ||
      p.date.includes(q) ||
      p.price.toString().includes(q) ||
      p.quantity.toString().includes(q)
    );
  }, [query, appData.purchasesList]);

  const hasResults = (category === 'all' || category === 'orders') && filteredOrders.length > 0 ||
    (category === 'all' || category === 'clients') && filteredClients.length > 0 ||
    (category === 'all' || category === 'messages') && filteredConversations.length > 0 ||
    (category === 'all' || category === 'prices') && filteredPrices.length > 0 ||
    (category === 'all' || category === 'purchases') && filteredPurchases.length > 0;

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return '#22C55E';
      case 'pending': return '#F59E0B';
      case 'processing': return '#3B82F6';
      case 'cancelled': return '#EF4444';
      default: return '#6C737F';
    }
  };

  const renderOrderResult = (order: TraderOrder) => (
    <TouchableOpacity
      key={order.id}
      style={styles.resultItem}
      onPress={() => onNavigate?.('order-detail', { orderId: order.id })}
      activeOpacity={0.7}
    >
      <View style={[styles.resultRow, { flexDirection: flexDir }]}>
        <View style={[styles.resultIcon, { backgroundColor: order.type === 'buy' ? 'rgba(34,197,94,0.15)' : 'rgba(239,68,68,0.15)' }]}>
          <MaterialIcons name={order.type === 'buy' ? 'add-shopping-cart' : 'sell'} size={18} color={order.type === 'buy' ? '#22C55E' : '#EF4444'} />
        </View>
        <View style={{ flex: 1, alignItems: isRTL ? 'flex-end' : 'flex-start' }}>
          <Text style={[styles.resultTitle, { writingDirection: direction }]}>{order.clientName}</Text>
          <Text style={[styles.resultSubtitle, { writingDirection: direction }]}>
            {order.type === 'buy' ? buyLabel : sellLabel} • {order.karat} • {order.grams}g
          </Text>
        </View>
        <View style={{ alignItems: 'flex-end' }}>
          <Text style={styles.resultAmount}>${order.totalAmount.toLocaleString()}</Text>
          <View style={[styles.statusBadge, { backgroundColor: getStatusColor(order.status) + '20' }]}>
            <Text style={[styles.statusText, { color: getStatusColor(order.status) }]}>{order.status}</Text>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );

  const renderClientResult = (client: TraderClient) => (
    <TouchableOpacity
      key={client.id}
      style={styles.resultItem}
      onPress={() => onNavigate?.('trader-clients')}
      activeOpacity={0.7}
    >
      <View style={[styles.resultRow, { flexDirection: flexDir }]}>
        <View style={[styles.resultIcon, { backgroundColor: 'rgba(197,160,33,0.15)' }]}>
          <MaterialIcons name="person" size={18} color="#C5A021" />
        </View>
        <View style={{ flex: 1, alignItems: isRTL ? 'flex-end' : 'flex-start' }}>
          <Text style={[styles.resultTitle, { writingDirection: direction }]}>{client.name}</Text>
          <Text style={[styles.resultSubtitle, { writingDirection: direction }]}>{client.email}</Text>
        </View>
        <View style={[styles.clientStatusBadge, { backgroundColor: client.status === 'active' ? 'rgba(34,197,94,0.15)' : 'rgba(108,115,127,0.15)' }]}>
          <View style={[styles.statusDot, { backgroundColor: client.status === 'active' ? '#22C55E' : '#6C737F' }]} />
          <Text style={[styles.clientStatusText, { color: client.status === 'active' ? '#22C55E' : '#6C737F' }]}>
            {client.status}
          </Text>
        </View>
      </View>
    </TouchableOpacity>
  );

  const renderConversationResult = (conv: Conversation) => (
    <TouchableOpacity
      key={conv.id}
      style={styles.resultItem}
      onPress={() => onNavigate?.('chat', { conversationId: conv.id })}
      activeOpacity={0.7}
    >
      <View style={[styles.resultRow, { flexDirection: flexDir }]}>
        <View style={[styles.resultIcon, { backgroundColor: 'rgba(59,130,246,0.15)' }]}>
          <MaterialIcons name="chat" size={18} color="#3B82F6" />
        </View>
        <View style={{ flex: 1, alignItems: isRTL ? 'flex-end' : 'flex-start' }}>
          <Text style={[styles.resultTitle, { writingDirection: direction }]}>{conv.clientName}</Text>
          <Text style={[styles.resultSubtitle, { writingDirection: direction }]} numberOfLines={1}>{conv.lastMessage}</Text>
        </View>
        {conv.unreadCount > 0 && (
          <View style={styles.unreadBadge}>
            <Text style={styles.unreadText}>{conv.unreadCount}</Text>
          </View>
        )}
      </View>
    </TouchableOpacity>
  );

  const renderPriceResult = (price: GoldPrice) => (
    <TouchableOpacity
      key={price.karat}
      style={styles.resultItem}
      onPress={() => onNavigate?.('prices')}
      activeOpacity={0.7}
    >
      <View style={[styles.resultRow, { flexDirection: flexDir }]}>
        <View style={[styles.resultIcon, { backgroundColor: 'rgba(197,160,33,0.15)' }]}>
          <MaterialIcons name="diamond" size={18} color="#C5A021" />
        </View>
        <View style={{ flex: 1, alignItems: isRTL ? 'flex-end' : 'flex-start' }}>
          <Text style={[styles.resultTitle, { writingDirection: direction }]}>{price.karatLabel}</Text>
          <Text style={[styles.resultSubtitle, { writingDirection: direction }]}>
            {lang === 'ar' ? 'شراء' : lang === 'fr' ? 'Achat' : 'Buy'}: ${price.buyPrice.toFixed(2)} | {lang === 'ar' ? 'بيع' : lang === 'fr' ? 'Vente' : 'Sell'}: ${price.sellPrice.toFixed(2)}
          </Text>
        </View>
        <Text style={[styles.changeText, { color: price.change >= 0 ? '#22C55E' : '#EF4444' }]}>
          {price.change >= 0 ? '+' : ''}{price.change.toFixed(2)}%
        </Text>
      </View>
    </TouchableOpacity>
  );

  const renderPurchaseResult = (purchase: Purchase) => (
    <TouchableOpacity
      key={purchase.id}
      style={styles.resultItem}
      onPress={() => onNavigate?.('purchases')}
      activeOpacity={0.7}
    >
      <View style={[styles.resultRow, { flexDirection: flexDir }]}>
        <View style={[styles.resultIcon, { backgroundColor: 'rgba(34,197,94,0.15)' }]}>
          <MaterialIcons name="shopping-bag" size={18} color="#22C55E" />
        </View>
        <View style={{ flex: 1, alignItems: isRTL ? 'flex-end' : 'flex-start' }}>
          <Text style={[styles.resultTitle, { writingDirection: direction }]}>{purchase.name}</Text>
          <Text style={[styles.resultSubtitle, { writingDirection: direction }]}>{purchase.date}</Text>
        </View>
        <Text style={styles.resultAmount}>${purchase.price.toLocaleString()}</Text>
      </View>
    </TouchableOpacity>
  );

  const renderSection = (title: string, icon: string, items: React.ReactNode[], categoryKey: SearchCategory) => {
    if (items.length === 0) return null;
    if (category !== 'all' && category !== categoryKey) return null;
    return (
      <View key={categoryKey} style={styles.section}>
        <View style={[styles.sectionHeader, { flexDirection: flexDir }]}>
          <Text style={[styles.sectionCount, { writingDirection: direction }]}>({items.length})</Text>
          <View style={[styles.sectionTitleRow, { flexDirection: flexDir }]}>
            <MaterialIcons name={icon as any} size={18} color="#C5A021" style={isRTL ? { marginLeft: 6 } : { marginRight: 6 }} />
            <Text style={[styles.sectionTitle, { writingDirection: direction }]}>{title}</Text>
          </View>
        </View>
        <GoldCard style={{ padding: 0, overflow: 'hidden' }}>
          {items.slice(0, category === 'all' ? 3 : undefined)}
        </GoldCard>
        {category === 'all' && items.length > 3 && (
          <TouchableOpacity
            style={styles.showMoreBtn}
            onPress={() => setCategory(categoryKey)}
            activeOpacity={0.7}
          >
            <Text style={styles.showMoreText}>
              {lang === 'ar' ? `عرض الكل (${items.length})` : lang === 'fr' ? `Voir tout (${items.length})` : `Show all (${items.length})`}
            </Text>
            <MaterialIcons name={isRTL ? 'chevron-left' : 'chevron-right'} size={16} color="#C5A021" />
          </TouchableOpacity>
        )}
      </View>
    );
  };

  return (
    <View style={styles.screen}>
      <SafeAreaView style={styles.safeArea} edges={['top']}>
        {/* App Bar */}
        <View style={styles.appBar}>
          <TouchableOpacity
            onPress={() => onNavigate?.(isTrader ? 'trader-home' : 'home')}
            style={styles.backBtn}
            activeOpacity={0.7}
          >
            <MaterialIcons name={isRTL ? 'chevron-right' : 'chevron-left'} size={28} color="#F8F9FA" />
          </TouchableOpacity>
          <Text style={[styles.appBarTitle, { writingDirection: direction }]}>{searchTitle}</Text>
          <TouchableOpacity onPress={onOpenDrawer} style={styles.menuBtn} activeOpacity={0.7}>
            <MaterialIcons name="menu" size={24} color="#F8F9FA" />
          </TouchableOpacity>
        </View>

        {/* Search Input */}
        <View style={styles.searchContainer}>
          <View style={[styles.searchInputRow, { flexDirection: flexDir }]}>
            <MaterialIcons name="search" size={22} color="#6C737F" style={isRTL ? { marginLeft: 8 } : { marginRight: 8 }} />
            <TextInput
              style={[styles.searchInput, { textAlign: isRTL ? 'right' : 'left', writingDirection: direction }]}
              placeholder={searchPlaceholder}
              placeholderTextColor="#6C737F"
              value={query}
              onChangeText={setQuery}
              autoFocus
              returnKeyType="search"
              onSubmitEditing={() => Keyboard.dismiss()}
            />
            {query.length > 0 && (
              <TouchableOpacity onPress={() => setQuery('')} activeOpacity={0.7}>
                <MaterialIcons name="close" size={20} color="#6C737F" />
              </TouchableOpacity>
            )}
          </View>
        </View>

        {/* Category Tabs */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.categoryTabs}>
          {visibleCategories.map(cat => (
            <TouchableOpacity
              key={cat.key}
              style={[styles.categoryTab, category === cat.key && styles.categoryTabActive]}
              onPress={() => setCategory(cat.key)}
              activeOpacity={0.7}
            >
              <MaterialIcons name={cat.icon as any} size={16} color={category === cat.key ? '#C5A021' : '#6C737F'} />
              <Text style={[styles.categoryTabText, category === cat.key && styles.categoryTabTextActive]}>{cat.label}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        {/* Results */}
        <ScrollView style={styles.results} contentContainerStyle={styles.resultsContent} showsVerticalScrollIndicator={false}>
          {!query.trim() ? (
            <View style={styles.emptyState}>
              <MaterialIcons name="search" size={64} color="rgba(197,160,33,0.3)" />
              <Text style={[styles.emptyText, { writingDirection: direction }]}>{startSearch}</Text>
            </View>
          ) : !hasResults ? (
            <View style={styles.emptyState}>
              <MaterialIcons name="search-off" size={64} color="rgba(108,115,127,0.3)" />
              <Text style={[styles.emptyText, { writingDirection: direction }]}>{noResults}</Text>
            </View>
          ) : (
            <>
              {(isTrader || isAdmin) && renderSection(ordersLabel, 'receipt-long', filteredOrders.map(renderOrderResult), 'orders')}
              {(isTrader || isAdmin) && renderSection(clientsLabel, 'people', filteredClients.map(renderClientResult), 'clients')}
              {(isTrader || isAdmin) && renderSection(messagesLabel, 'chat', filteredConversations.map(renderConversationResult), 'messages')}
              {renderSection(pricesLabel, 'trending-up', filteredPrices.map(renderPriceResult), 'prices')}
              {renderSection(purchasesLabel, 'shopping-bag', filteredPurchases.map(renderPurchaseResult), 'purchases')}
            </>
          )}
          <View style={{ height: 40 }} />
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#001F3F' },
  safeArea: { flex: 1 },
  appBar: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: 'rgba(248,249,250,0.08)',
  },
  appBarTitle: { fontSize: 18, fontWeight: '700', color: '#F8F9FA' },
  menuBtn: { padding: 8 },
  backBtn: { padding: 4 },
  // Search
  searchContainer: { paddingHorizontal: 16, paddingVertical: 12 },
  searchInputRow: {
    alignItems: 'center', backgroundColor: 'rgba(248,249,250,0.08)', borderRadius: 12,
    paddingHorizontal: 14, paddingVertical: Platform.OS === 'web' ? 12 : 10, borderWidth: 1, borderColor: 'rgba(197,160,33,0.2)',
  },
  searchInput: { flex: 1, fontSize: 15, color: '#F8F9FA', padding: 0 },
  // Categories
  categoryTabs: { paddingHorizontal: 16, paddingBottom: 12, gap: 8 },
  categoryTab: {
    flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 14, paddingVertical: 8,
    borderRadius: 20, backgroundColor: 'rgba(248,249,250,0.06)', borderWidth: 1, borderColor: 'rgba(248,249,250,0.1)',
  },
  categoryTabActive: { backgroundColor: 'rgba(197,160,33,0.15)', borderColor: '#C5A021' },
  categoryTabText: { fontSize: 13, color: '#6C737F', fontWeight: '500' },
  categoryTabTextActive: { color: '#C5A021', fontWeight: '600' },
  // Results
  results: { flex: 1 },
  resultsContent: { paddingHorizontal: 16 },
  section: { marginBottom: 16 },
  sectionHeader: { alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 },
  sectionTitleRow: { alignItems: 'center' },
  sectionTitle: { fontSize: 15, fontWeight: '700', color: '#F8F9FA' },
  sectionCount: { fontSize: 12, color: '#6C737F' },
  // Result Item
  resultItem: { paddingHorizontal: 14, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#E6E8EA' },
  resultRow: { alignItems: 'center', gap: 12 },
  resultIcon: { width: 36, height: 36, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  resultTitle: { fontSize: 14, fontWeight: '600', color: '#1A1A1B' },
  resultSubtitle: { fontSize: 12, color: '#6C737F', marginTop: 2 },
  resultAmount: { fontSize: 14, fontWeight: '700', color: '#C5A021' },
  changeText: { fontSize: 13, fontWeight: '600' },
  // Status
  statusBadge: { paddingHorizontal: 8, paddingVertical: 2, borderRadius: 6, marginTop: 4 },
  statusText: { fontSize: 10, fontWeight: '600', textTransform: 'capitalize' },
  clientStatusBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8 },
  statusDot: { width: 6, height: 6, borderRadius: 3 },
  clientStatusText: { fontSize: 11, fontWeight: '500', textTransform: 'capitalize' },
  unreadBadge: { backgroundColor: '#C5A021', width: 22, height: 22, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  unreadText: { fontSize: 11, fontWeight: '700', color: '#001F3F' },
  // Show More
  showMoreBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 8, gap: 4 },
  showMoreText: { fontSize: 13, color: '#C5A021', fontWeight: '600' },
  // Empty State
  emptyState: { alignItems: 'center', justifyContent: 'center', paddingTop: 80, gap: 16 },
  emptyText: { fontSize: 15, color: '#6C737F', textAlign: 'center' },
});
