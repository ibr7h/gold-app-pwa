import React, { useState, useMemo } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, KeyboardAvoidingView, Platform, TextInput } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { GoldCard } from '@/components/gold/GoldCard';
import { GoldButton } from '@/components/gold/GoldButton';
import { useI18n } from '@/i18n';
import { useSettings } from '@/contexts/SettingsContext';
import { useTraderData, type OrderType } from '@/contexts/TraderDataContext';
import { useGoldPrice } from '@/hooks/useGoldPrice';

interface NewOrderScreenProps {
  onOpenDrawer: () => void;
  onNavigate?: (screen: string) => void;
}

export default function NewOrderScreen({ onOpenDrawer, onNavigate }: NewOrderScreenProps) {
  const { isRTL, textAlign, direction, flexDir, lang } = useI18n();
  const { settings } = useSettings();
  const { clients, addOrder } = useTraderData();
  const { data: goldData } = useGoldPrice();

  const [orderType, setOrderType] = useState<OrderType>('buy');
  const [selectedClientId, setSelectedClientId] = useState('');
  const [karat, setKarat] = useState('24');
  const [grams, setGrams] = useState('');
  const [pricePerGram, setPricePerGram] = useState('');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  // Translations
  const titleLabel = lang === 'ar' ? 'طلب جديد' : lang === 'fr' ? 'Nouvelle commande' : 'New Order';
  const backLabel = lang === 'ar' ? 'رجوع' : lang === 'fr' ? 'Retour' : 'Back';
  const orderTypeLabel = lang === 'ar' ? 'نوع الطلب' : lang === 'fr' ? 'Type de commande' : 'Order Type';
  const buyLabel = lang === 'ar' ? 'شراء' : lang === 'fr' ? 'Achat' : 'Buy';
  const sellLabel = lang === 'ar' ? 'بيع' : lang === 'fr' ? 'Vente' : 'Sell';
  const clientLabel = lang === 'ar' ? 'العميل' : lang === 'fr' ? 'Client' : 'Client';
  const selectClient = lang === 'ar' ? 'اختر العميل' : lang === 'fr' ? 'Sélectionner client' : 'Select Client';
  const karatLabel = lang === 'ar' ? 'العيار' : lang === 'fr' ? 'Carat' : 'Karat';
  const gramsInputLabel = lang === 'ar' ? 'الوزن (غرام)' : lang === 'fr' ? 'Poids (grammes)' : 'Weight (grams)';
  const priceLabel = lang === 'ar' ? 'السعر لكل غرام' : lang === 'fr' ? 'Prix par gramme' : 'Price per gram';
  const totalLabel = lang === 'ar' ? 'الإجمالي' : lang === 'fr' ? 'Total' : 'Total';
  const notesLabel = lang === 'ar' ? 'ملاحظات (اختياري)' : lang === 'fr' ? 'Notes (optionnel)' : 'Notes (optional)';
  const submitLabel = lang === 'ar' ? 'إنشاء الطلب' : lang === 'fr' ? 'Créer la commande' : 'Create Order';
  const successMsg = lang === 'ar' ? 'تم إنشاء الطلب بنجاح!' : lang === 'fr' ? 'Commande créée avec succès !' : 'Order created successfully!';
  const requiredField = lang === 'ar' ? 'هذا الحقل مطلوب' : lang === 'fr' ? 'Champ requis' : 'Required field';
  const invalidNumber = lang === 'ar' ? 'رقم غير صالح' : lang === 'fr' ? 'Nombre invalide' : 'Invalid number';

  const currencySymbol = settings.preferredCurrency === 'USD' ? '$' : settings.preferredCurrency === 'EUR' ? '€' : settings.preferredCurrency === 'SAR' ? 'ر.س' : settings.preferredCurrency === 'AED' ? 'د.إ' : settings.preferredCurrency === 'EGP' ? 'ج.م' : '$';

  const karatOptions = ['24', '22', '21', '18', '14'];

  // Auto-calculate price based on karat and gold price
  const suggestedPrice = useMemo(() => {
    if (!goldData?.pricePerOunce) return 0;
    const pricePerGramBase = goldData.pricePerOunce / 31.1035;
    const karatMultiplier = parseInt(karat) / 24;
    return pricePerGramBase * karatMultiplier;
  }, [goldData, karat]);

  const totalAmount = useMemo(() => {
    const g = parseFloat(grams) || 0;
    const p = parseFloat(pricePerGram) || 0;
    return g * p;
  }, [grams, pricePerGram]);

  const selectedClient = clients.find(c => c.id === selectedClientId);

  const validate = (): boolean => {
    const newErrors: Record<string, string> = {};
    if (!selectedClientId) newErrors.client = requiredField;
    if (!grams || parseFloat(grams) <= 0) newErrors.grams = invalidNumber;
    if (!pricePerGram || parseFloat(pricePerGram) <= 0) newErrors.price = invalidNumber;
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async () => {
    if (!validate()) return;
    setIsSubmitting(true);

    const now = new Date();
    const client = clients.find(c => c.id === selectedClientId);

    await addOrder({
      clientId: selectedClientId,
      clientName: client?.name || '',
      type: orderType,
      karat,
      grams: parseFloat(grams),
      pricePerGram: parseFloat(pricePerGram),
      totalAmount,
      status: 'pending',
      date: now.toISOString().split('T')[0],
      time: `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`,
      notes: notes || undefined,
    });

    setIsSubmitting(false);
    setShowSuccess(true);
  };

  if (showSuccess) {
    return (
      <View style={styles.screen}>
        <SafeAreaView style={styles.safeArea} edges={['top']}>
          <View style={styles.successContainer}>
            <View style={styles.successIcon}>
              <MaterialIcons name="check-circle" size={64} color="#22C55E" />
            </View>
            <Text style={styles.successText}>{successMsg}</Text>
            <Text style={styles.successAmount}>{currencySymbol} {totalAmount.toLocaleString()}</Text>
            <View style={styles.successActions}>
              <TouchableOpacity
                style={styles.successBtn}
                onPress={() => {
                  setShowSuccess(false);
                  setGrams('');
                  setPricePerGram('');
                  setNotes('');
                  setSelectedClientId('');
                }}
                activeOpacity={0.7}
              >
                <MaterialIcons name="add" size={20} color="#C5A021" />
                <Text style={styles.successBtnText}>
                  {lang === 'ar' ? 'طلب آخر' : lang === 'fr' ? 'Autre commande' : 'Another Order'}
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.successBtn}
                onPress={() => onNavigate?.('trader-orders')}
                activeOpacity={0.7}
              >
                <MaterialIcons name="list" size={20} color="#C5A021" />
                <Text style={styles.successBtnText}>
                  {lang === 'ar' ? 'عرض الطلبات' : lang === 'fr' ? 'Voir commandes' : 'View Orders'}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </SafeAreaView>
      </View>
    );
  }

  return (
    <View style={styles.screen}>
      <SafeAreaView style={styles.safeArea} edges={['top']}>
        {/* App Bar */}
        <View style={styles.appBar}>
          <View style={{ width: 40 }} />
          <Text style={[styles.appBarTitle, { writingDirection: direction }]}>{titleLabel}</Text>
          <TouchableOpacity onPress={() => onNavigate?.('trader-orders')} style={styles.menuBtn} activeOpacity={0.7}>
            <MaterialIcons name="arrow-forward" size={24} color="#F8F9FA" />
          </TouchableOpacity>
        </View>

        <KeyboardAvoidingView
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          style={{ flex: 1 }}
        >
          <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
            {/* Order Type */}
            <Text style={[styles.label, { textAlign, writingDirection: direction }]}>{orderTypeLabel}</Text>
            <View style={[styles.typeRow, { flexDirection: flexDir }]}>
              <TouchableOpacity
                style={[styles.typeBtn, orderType === 'buy' && styles.typeBtnActive,
                  orderType === 'buy' && { borderColor: '#22C55E' }]}
                onPress={() => setOrderType('buy')}
                activeOpacity={0.7}
              >
                <MaterialIcons name="add-shopping-cart" size={20} color={orderType === 'buy' ? '#22C55E' : '#6C737F'} />
                <Text style={[styles.typeBtnText, orderType === 'buy' && { color: '#22C55E' }]}>{buyLabel}</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.typeBtn, orderType === 'sell' && styles.typeBtnActive,
                  orderType === 'sell' && { borderColor: '#EF4444' }]}
                onPress={() => setOrderType('sell')}
                activeOpacity={0.7}
              >
                <MaterialIcons name="sell" size={20} color={orderType === 'sell' ? '#EF4444' : '#6C737F'} />
                <Text style={[styles.typeBtnText, orderType === 'sell' && { color: '#EF4444' }]}>{sellLabel}</Text>
              </TouchableOpacity>
            </View>

            {/* Client Selection */}
            <Text style={[styles.label, { textAlign, writingDirection: direction }]}>{clientLabel}</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.clientScroll}>
              <View style={[styles.clientRow, { flexDirection: flexDir }]}>
                {clients.filter(c => c.status === 'active').map(client => (
                  <TouchableOpacity
                    key={client.id}
                    style={[styles.clientChip, selectedClientId === client.id && styles.clientChipActive]}
                    onPress={() => setSelectedClientId(client.id)}
                    activeOpacity={0.7}
                  >
                    <View style={styles.clientChipAvatar}>
                      <Text style={styles.clientChipAvatarText}>{client.name.charAt(0)}</Text>
                    </View>
                    <Text style={[styles.clientChipText, selectedClientId === client.id && styles.clientChipTextActive]}>
                      {client.name}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </ScrollView>
            {errors.client && <Text style={styles.errorText}>{errors.client}</Text>}

            {/* Karat */}
            <Text style={[styles.label, { textAlign, writingDirection: direction }]}>{karatLabel}</Text>
            <View style={[styles.karatRow, { flexDirection: flexDir }]}>
              {karatOptions.map(k => (
                <TouchableOpacity
                  key={k}
                  style={[styles.karatBtn, karat === k && styles.karatBtnActive]}
                  onPress={() => {
                    setKarat(k);
                    // Auto-update suggested price
                    if (goldData?.pricePerOunce) {
                      const pricePerGramBase = goldData.pricePerOunce / 31.1035;
                      const karatMultiplier = parseInt(k) / 24;
                      setPricePerGram((pricePerGramBase * karatMultiplier).toFixed(2));
                    }
                  }}
                  activeOpacity={0.7}
                >
                  <Text style={[styles.karatBtnText, karat === k && styles.karatBtnTextActive]}>{k}K</Text>
                </TouchableOpacity>
              ))}
            </View>

            {/* Grams */}
            <Text style={[styles.label, { textAlign, writingDirection: direction }]}>{gramsInputLabel}</Text>
            <View style={styles.inputContainer}>
              <TextInput
                style={[styles.input, { textAlign: isRTL ? 'right' : 'left', writingDirection: direction }]}
                value={grams}
                onChangeText={setGrams}
                keyboardType="decimal-pad"
                placeholder="0.00"
                placeholderTextColor="#6C737F"
              />
            </View>
            {errors.grams && <Text style={styles.errorText}>{errors.grams}</Text>}

            {/* Price per gram */}
            <Text style={[styles.label, { textAlign, writingDirection: direction }]}>{priceLabel}</Text>
            <View style={styles.inputContainer}>
              <TextInput
                style={[styles.input, { textAlign: isRTL ? 'right' : 'left', writingDirection: direction }]}
                value={pricePerGram}
                onChangeText={setPricePerGram}
                keyboardType="decimal-pad"
                placeholder={suggestedPrice > 0 ? suggestedPrice.toFixed(2) : '0.00'}
                placeholderTextColor="#6C737F"
              />
              {suggestedPrice > 0 && !pricePerGram && (
                <TouchableOpacity
                  style={styles.suggestBtn}
                  onPress={() => setPricePerGram(suggestedPrice.toFixed(2))}
                  activeOpacity={0.7}
                >
                  <Text style={styles.suggestBtnText}>
                    {lang === 'ar' ? 'سعر السوق' : lang === 'fr' ? 'Prix marché' : 'Market Price'}
                  </Text>
                </TouchableOpacity>
              )}
            </View>
            {errors.price && <Text style={styles.errorText}>{errors.price}</Text>}

            {/* Total */}
            {totalAmount > 0 && (
              <GoldCard>
                <View style={[styles.totalRow, { flexDirection: flexDir }]}>
                  <Text style={styles.totalAmount}>{currencySymbol} {totalAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</Text>
                  <Text style={[styles.totalLabel, { writingDirection: direction }]}>{totalLabel}</Text>
                </View>
              </GoldCard>
            )}

            {/* Notes */}
            <Text style={[styles.label, { textAlign, writingDirection: direction }]}>{notesLabel}</Text>
            <View style={styles.inputContainer}>
              <TextInput
                style={[styles.input, styles.notesInput, { textAlign: isRTL ? 'right' : 'left', writingDirection: direction }]}
                value={notes}
                onChangeText={setNotes}
                multiline
                numberOfLines={3}
                placeholder={lang === 'ar' ? 'أضف ملاحظات...' : lang === 'fr' ? 'Ajouter des notes...' : 'Add notes...'}
                placeholderTextColor="#6C737F"
              />
            </View>

            {/* Submit */}
            <View style={styles.submitContainer}>
              <GoldButton
                title={submitLabel}
                onPress={handleSubmit}
                loading={isSubmitting}
              />
            </View>

            <View style={{ height: 40 }} />
          </ScrollView>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#001F3F' },
  safeArea: { flex: 1 },
  appBar: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 12,
    borderBottomWidth: 1, borderBottomColor: 'rgba(248,249,250,0.08)',
  },
  appBarTitle: { fontSize: 18, fontWeight: '700', color: '#F8F9FA' },
  menuBtn: { padding: 8 },
  scrollContent: { paddingHorizontal: 16, paddingTop: 16 },

  // Labels
  label: { fontSize: 14, fontWeight: '600', color: '#F8F9FA', marginBottom: 8, marginTop: 16 },

  // Order Type
  typeRow: { gap: 12 },
  typeBtn: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8,
    paddingVertical: 14, borderRadius: 14,
    backgroundColor: 'rgba(248,249,250,0.06)',
    borderWidth: 1.5, borderColor: 'rgba(248,249,250,0.1)',
  },
  typeBtnActive: { backgroundColor: 'rgba(248,249,250,0.1)' },
  typeBtnText: { fontSize: 15, fontWeight: '600', color: '#6C737F' },

  // Client
  clientScroll: { maxHeight: 60 },
  clientRow: { gap: 8, paddingVertical: 4 },
  clientChip: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20,
    backgroundColor: 'rgba(248,249,250,0.06)',
    borderWidth: 1, borderColor: 'rgba(248,249,250,0.1)',
  },
  clientChipActive: {
    backgroundColor: 'rgba(197,160,33,0.15)', borderColor: '#C5A021',
  },
  clientChipAvatar: {
    width: 28, height: 28, borderRadius: 14,
    backgroundColor: 'rgba(197,160,33,0.2)',
    alignItems: 'center', justifyContent: 'center',
  },
  clientChipAvatarText: { fontSize: 12, fontWeight: '700', color: '#C5A021' },
  clientChipText: { fontSize: 13, fontWeight: '500', color: '#9BA1A6' },
  clientChipTextActive: { color: '#C5A021', fontWeight: '600' },

  // Karat
  karatRow: { gap: 8 },
  karatBtn: {
    flex: 1, alignItems: 'center', paddingVertical: 12, borderRadius: 12,
    backgroundColor: 'rgba(248,249,250,0.06)',
    borderWidth: 1, borderColor: 'rgba(248,249,250,0.1)',
  },
  karatBtnActive: {
    backgroundColor: 'rgba(197,160,33,0.15)', borderColor: '#C5A021',
  },
  karatBtnText: { fontSize: 14, fontWeight: '600', color: '#6C737F' },
  karatBtnTextActive: { color: '#C5A021' },

  // Input
  inputContainer: { position: 'relative' },
  input: {
    backgroundColor: 'rgba(248,249,250,0.06)',
    borderWidth: 1, borderColor: 'rgba(248,249,250,0.1)',
    borderRadius: 12, paddingHorizontal: 16, paddingVertical: 14,
    fontSize: 16, color: '#F8F9FA', fontWeight: '500',
  },
  notesInput: { minHeight: 80, textAlignVertical: 'top' },
  suggestBtn: {
    position: 'absolute', right: 12, top: 12,
    backgroundColor: 'rgba(197,160,33,0.15)',
    paddingHorizontal: 10, paddingVertical: 6, borderRadius: 8,
  },
  suggestBtnText: { fontSize: 11, fontWeight: '600', color: '#C5A021' },

  // Total
  totalRow: { justifyContent: 'space-between', alignItems: 'center' },
  totalLabel: { fontSize: 15, fontWeight: '600', color: '#1A1A1B' },
  totalAmount: { fontSize: 24, fontWeight: '800', color: '#C5A021' },

  // Error
  errorText: { fontSize: 12, color: '#EF4444', marginTop: 4 },

  // Submit
  submitContainer: { marginTop: 24 },

  // Success
  successContainer: {
    flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 32,
  },
  successIcon: { marginBottom: 16 },
  successText: { fontSize: 20, fontWeight: '700', color: '#F8F9FA', marginBottom: 8 },
  successAmount: { fontSize: 28, fontWeight: '800', color: '#C5A021', marginBottom: 32 },
  successActions: { flexDirection: 'row', gap: 16 },
  successBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    backgroundColor: 'rgba(197,160,33,0.15)',
    paddingHorizontal: 20, paddingVertical: 12, borderRadius: 12,
    borderWidth: 1, borderColor: '#C5A021',
  },
  successBtnText: { fontSize: 14, fontWeight: '600', color: '#C5A021' },
});
