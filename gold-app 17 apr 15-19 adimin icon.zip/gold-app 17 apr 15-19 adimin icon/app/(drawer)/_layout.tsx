import React, { useState, useRef, useCallback } from 'react';
import { View, Animated, Dimensions, TouchableOpacity, StyleSheet, Platform } from 'react-native';
import { useAuth } from '@/contexts/AuthContext';
import { DrawerContent } from '@/components/gold/DrawerContent';
import { useI18n } from '@/i18n';
import { APP_VARIANT, currentVariantConfig } from '@/constants/appVariant';
import LoginScreen from '../login';
import HomeScreen from './home';
import PricesScreen from './prices';
import PortfolioScreen from './portfolio';
import PurchasesScreen from './purchases';
import AlertsScreen from './alerts';
import AdminScreen from './admin';
import SettingsScreen from './settings';
import ProfileScreen from './profile';
import TraderHomeScreen from './trader-home';
import TraderOrdersScreen from './trader-orders';
import TraderClientsScreen from './trader-clients';
import NewOrderScreen from './new-order';
import NewClientScreen from './new-client';
import TraderNotificationsScreen from './trader-notifications';
import TraderReportsScreen from './trader-reports';
import OrderDetailScreen from './order-detail';
import AdminUsersScreen from './admin-users';
import AdminStatsScreen from './admin-stats';
import AdminInvitesScreen from './admin-invites';
import AdminPermissionsScreen from './admin-permissions';
import TraderMessagesScreen from './trader-messages';
import ChatScreen from './chat';
import SearchScreen from './search';
import FAQSupportScreen from './faq-support';
import TraderLocationScreen from './trader-location';
import NearbyTradersScreen from './nearby-traders';
import AdminSettingsScreen from './admin-settings';
import { OfflineBanner } from '@/components/gold/OfflineBanner';

const SCREEN_WIDTH = Dimensions.get('window').width;
const DRAWER_WIDTH = Math.min(SCREEN_WIDTH * 0.78, 320);

export default function DrawerLayout() {
  const { isLoggedIn, user } = useAuth();
  const { isRTL } = useI18n();
  const [activeScreen, setActiveScreen] = useState(currentVariantConfig.defaultScreen);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const translateX = useRef(new Animated.Value(0)).current;

  const openDrawer = useCallback(() => {
    setDrawerOpen(true);
    Animated.timing(translateX, {
      toValue: isRTL ? -DRAWER_WIDTH : DRAWER_WIDTH,
      duration: 280,
      useNativeDriver: true,
    }).start();
  }, [translateX, isRTL]);

  const closeDrawer = useCallback(() => {
    Animated.timing(translateX, {
      toValue: 0,
      duration: 250,
      useNativeDriver: true,
    }).start(() => {
      setDrawerOpen(false);
    });
  }, [translateX]);

  const [screenParams, setScreenParams] = useState<any>(null);

  const handleNavigate = useCallback((screen: string, params?: any) => {
    if (params) setScreenParams(params);
    else setScreenParams(null);
    setActiveScreen(screen);
  }, []);

  if (!isLoggedIn) {
    return <LoginScreen />;
  }

  const renderScreen = () => {
    switch (activeScreen) {
      // User screens
      case 'home': return <HomeScreen onOpenDrawer={openDrawer} onNavigate={handleNavigate} />;
      case 'prices': return <PricesScreen onOpenDrawer={openDrawer} />;
      case 'portfolio': return <PortfolioScreen onOpenDrawer={openDrawer} />;
      case 'purchases': return <PurchasesScreen onOpenDrawer={openDrawer} />;
      case 'alerts': return <AlertsScreen onOpenDrawer={openDrawer} />;
      case 'settings': return <SettingsScreen onOpenDrawer={openDrawer} />;
      case 'profile': return <ProfileScreen onOpenDrawer={openDrawer} />;
      case 'search': return <SearchScreen onOpenDrawer={openDrawer} onNavigate={handleNavigate} />;
      case 'faq-support': return <FAQSupportScreen onOpenDrawer={openDrawer} />;
      case 'trader-location': return <TraderLocationScreen onOpenDrawer={openDrawer} onNavigate={handleNavigate} />;
      case 'nearby-traders': return <NearbyTradersScreen onOpenDrawer={openDrawer} onNavigate={handleNavigate} />;
      // Trader screens
      case 'trader-home': return <TraderHomeScreen onOpenDrawer={openDrawer} onNavigate={handleNavigate} />;
      case 'trader-orders': return <TraderOrdersScreen onOpenDrawer={openDrawer} onNavigate={handleNavigate} />;
      case 'trader-clients': return <TraderClientsScreen onOpenDrawer={openDrawer} onNavigate={handleNavigate} />;
      case 'new-order': return <NewOrderScreen onOpenDrawer={openDrawer} onNavigate={handleNavigate} />;
      case 'new-client': return <NewClientScreen onOpenDrawer={openDrawer} onNavigate={handleNavigate} />;
      case 'trader-notifications': return <TraderNotificationsScreen onOpenDrawer={openDrawer} onNavigate={handleNavigate} />;
      case 'trader-reports': return <TraderReportsScreen onOpenDrawer={openDrawer} onNavigate={handleNavigate} />;
      case 'order-detail': return <OrderDetailScreen onOpenDrawer={openDrawer} onNavigate={handleNavigate} orderId={screenParams?.orderId} />;
      case 'trader-messages': return <TraderMessagesScreen onOpenDrawer={openDrawer} onNavigate={handleNavigate} />;
      case 'chat': return <ChatScreen onOpenDrawer={openDrawer} onNavigate={handleNavigate} conversationId={screenParams?.conversationId} />;
      // Admin screens
      case 'admin': return <AdminScreen onOpenDrawer={openDrawer} onNavigate={handleNavigate} />;
      case 'admin-users': return <AdminUsersScreen onOpenDrawer={openDrawer} onNavigate={handleNavigate} />;
      case 'admin-stats': return <AdminStatsScreen onOpenDrawer={openDrawer} onNavigate={handleNavigate} />;
      case 'admin-invites': return <AdminInvitesScreen onOpenDrawer={openDrawer} onNavigate={handleNavigate} />;
      case 'admin-permissions': return <AdminPermissionsScreen onOpenDrawer={openDrawer} onNavigate={handleNavigate} />;
      case 'admin-settings': return <AdminSettingsScreen onOpenDrawer={openDrawer} onNavigate={handleNavigate} />;
      // Default: go to variant's default screen
      default: {
        if (APP_VARIANT === 'trader') return <TraderHomeScreen onOpenDrawer={openDrawer} onNavigate={handleNavigate} />;
        if (APP_VARIANT === 'admin') return <AdminScreen onOpenDrawer={openDrawer} onNavigate={handleNavigate} />;
        return <HomeScreen onOpenDrawer={openDrawer} onNavigate={handleNavigate} />;
      }
    }
  };

  return (
    <View style={styles.container}>
      {/* Drawer */}
      {drawerOpen && (
        <View style={[
          styles.drawerContainer,
          { width: DRAWER_WIDTH },
          isRTL ? { right: 0 } : { left: 0 },
        ]}>
          <DrawerContent
            activeScreen={activeScreen}
            onNavigate={handleNavigate}
            onClose={closeDrawer}
          />
        </View>
      )}

      {/* Main Content */}
      <Animated.View
        style={[
          styles.mainContent,
          { transform: [{ translateX }] },
        ]}
      >
        <OfflineBanner />
        {renderScreen()}

        {drawerOpen && (
          <TouchableOpacity
            style={styles.overlay}
            activeOpacity={1}
            onPress={closeDrawer}
          />
        )}
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#001F3F',
    flexDirection: 'row',
  },
  drawerContainer: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    zIndex: 10,
    backgroundColor: '#001F3F',
    ...Platform.select({
      web: {
        boxShadow: '4px 0 20px rgba(0,31,63,0.5)',
      },
      default: {
        elevation: 16,
        shadowColor: '#000',
        shadowOffset: { width: 4, height: 0 },
        shadowOpacity: 0.4,
        shadowRadius: 20,
      },
    }),
  },
  mainContent: {
    flex: 1,
    backgroundColor: '#001F3F',
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,31,63,0.5)',
    zIndex: 5,
  },
});
