import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet,
  KeyboardAvoidingView, Platform, TextInput, ActivityIndicator, Alert, Switch,
  Dimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { GoldButton } from '@/components/gold/GoldButton';
import { useI18n } from '@/i18n';
import { useAuth } from '@/contexts/AuthContext';
import { getApiBaseUrl } from '@/constants/oauth';
import * as Auth from '@/lib/_core/auth';

const SCREEN_WIDTH = Dimensions.get('window').width;

// Default location (Riyadh, Saudi Arabia)
const DEFAULT_LAT = 24.7136;
const DEFAULT_LNG = 46.6753;

interface TraderLocationScreenProps {
  onOpenDrawer: () => void;
  onNavigate?: (screen: string) => void;
}

interface LocationData {
  shopName: string;
  address: string;
  city: string;
  latitude: number;
  longitude: number;
  phone: string;
  whatsapp: string;
  workingHours: string;
  isVisible: boolean;
}

async function getAuthHeaders(): Promise<Record<string, string>> {
  const token = await Auth.getSessionToken();
  if (token) return { Authorization: `Bearer ${token}` };
  return {};
}

async function apiCall(path: string, method: 'GET' | 'POST' = 'GET', body?: any) {
  const baseUrl = getApiBaseUrl();
  const url = `${baseUrl}/api/trpc/${path}`;
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(await getAuthHeaders()),
  };
  const options: RequestInit = { method, headers, credentials: 'include' as any };
  if (body && method === 'POST') {
    options.body = JSON.stringify({ json: body });
  }
  const response = await fetch(url, options);
  const data = await response.json();
  if (data?.error) throw new Error(data.error.message || 'API error');
  return data?.result?.data?.json;
}

export default function TraderLocationScreen({ onOpenDrawer, onNavigate }: TraderLocationScreenProps) {
  const { user } = useAuth();
  const { isRTL, textAlign, direction, flexDir, lang } = useI18n();

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [hasExisting, setHasExisting] = useState(false);

  // Form state
  const [shopName, setShopName] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [latitude, setLatitude] = useState(DEFAULT_LAT);
  const [longitude, setLongitude] = useState(DEFAULT_LNG);
  const [phone, setPhone] = useState('');
  const [whatsapp, setWhatsapp] = useState('');
  const [workingHours, setWorkingHours] = useState('');
  const [isVisible, setIsVisible] = useState(true);

  // Coordinate input mode
  const [latInput, setLatInput] = useState(String(DEFAULT_LAT));
  const [lngInput, setLngInput] = useState(String(DEFAULT_LNG));

  // Errors
  const [errors, setErrors] = useState<Record<string, string>>({});

  // Translations
  const tr = {
    title: lang === 'ar' ? 'موقع المحل' : lang === 'fr' ? 'Emplacement du magasin' : 'Shop Location',
    subtitle: lang === 'ar' ? 'حدد موقع محلك ليتمكن العملاء من زيارتك' : lang === 'fr' ? 'Définissez l\'emplacement de votre magasin' : 'Set your shop location for customers to visit',
    shopNameLabel: lang === 'ar' ? 'اسم المحل' : lang === 'fr' ? 'Nom du magasin' : 'Shop Name',
    shopNamePlaceholder: lang === 'ar' ? 'مثال: محل الذهب الملكي' : lang === 'fr' ? 'Ex: Bijouterie Royale' : 'e.g. Royal Gold Shop',
    addressLabel: lang === 'ar' ? 'العنوان' : lang === 'fr' ? 'Adresse' : 'Address',
    addressPlaceholder: lang === 'ar' ? 'العنوان الكامل للمحل' : lang === 'fr' ? 'Adresse complète' : 'Full shop address',
    cityLabel: lang === 'ar' ? 'المدينة' : lang === 'fr' ? 'Ville' : 'City',
    cityPlaceholder: lang === 'ar' ? 'مثال: الرياض' : lang === 'fr' ? 'Ex: Riyad' : 'e.g. Riyadh',
    phoneLabel: lang === 'ar' ? 'رقم الهاتف' : lang === 'fr' ? 'Téléphone' : 'Phone Number',
    phonePlaceholder: lang === 'ar' ? '+966 5x xxx xxxx' : '+966 5x xxx xxxx',
    whatsappLabel: lang === 'ar' ? 'واتساب' : 'WhatsApp',
    whatsappPlaceholder: lang === 'ar' ? '+966 5x xxx xxxx' : '+966 5x xxx xxxx',
    workingHoursLabel: lang === 'ar' ? 'ساعات العمل' : lang === 'fr' ? 'Heures d\'ouverture' : 'Working Hours',
    workingHoursPlaceholder: lang === 'ar' ? 'مثال: 9 صباحاً - 10 مساءً' : lang === 'fr' ? 'Ex: 9h - 22h' : 'e.g. 9 AM - 10 PM',
    locationLabel: lang === 'ar' ? 'الإحداثيات' : lang === 'fr' ? 'Coordonnées' : 'Coordinates',
    latLabel: lang === 'ar' ? 'خط العرض' : lang === 'fr' ? 'Latitude' : 'Latitude',
    lngLabel: lang === 'ar' ? 'خط الطول' : lang === 'fr' ? 'Longitude' : 'Longitude',
    visibilityLabel: lang === 'ar' ? 'ظاهر للعملاء' : lang === 'fr' ? 'Visible aux clients' : 'Visible to Customers',
    visibilityDesc: lang === 'ar' ? 'عند التفعيل، سيظهر محلك في قائمة التجار القريبين' : lang === 'fr' ? 'Si activé, votre magasin apparaîtra dans la liste des commerçants' : 'When enabled, your shop will appear in nearby traders list',
    saveBtn: lang === 'ar' ? 'حفظ الموقع' : lang === 'fr' ? 'Enregistrer' : 'Save Location',
    updateBtn: lang === 'ar' ? 'تحديث الموقع' : lang === 'fr' ? 'Mettre à jour' : 'Update Location',
    savedSuccess: lang === 'ar' ? 'تم حفظ الموقع بنجاح' : lang === 'fr' ? 'Emplacement enregistré' : 'Location saved successfully',
    updatedSuccess: lang === 'ar' ? 'تم تحديث الموقع بنجاح' : lang === 'fr' ? 'Emplacement mis à jour' : 'Location updated successfully',
    required: lang === 'ar' ? 'هذا الحقل مطلوب' : lang === 'fr' ? 'Champ obligatoire' : 'This field is required',
    invalidCoord: lang === 'ar' ? 'إحداثيات غير صالحة' : lang === 'fr' ? 'Coordonnées invalides' : 'Invalid coordinates',
    useCurrentLocation: lang === 'ar' ? 'استخدم موقعي الحالي' : lang === 'fr' ? 'Utiliser ma position' : 'Use My Location',
    gettingLocation: lang === 'ar' ? 'جاري تحديد الموقع...' : lang === 'fr' ? 'Localisation en cours...' : 'Getting location...',
    locationError: lang === 'ar' ? 'تعذر تحديد الموقع' : lang === 'fr' ? 'Impossible de localiser' : 'Could not get location',
    locationPermDenied: lang === 'ar' ? 'تم رفض إذن الموقع' : lang === 'fr' ? 'Permission de localisation refusée' : 'Location permission denied',
    shopInfo: lang === 'ar' ? 'معلومات المحل' : lang === 'fr' ? 'Informations du magasin' : 'Shop Information',
    contactInfo: lang === 'ar' ? 'معلومات الاتصال' : lang === 'fr' ? 'Coordonnées de contact' : 'Contact Information',
    optional: lang === 'ar' ? 'اختياري' : lang === 'fr' ? 'Optionnel' : 'Optional',
  };

  // Load existing location
  const loadLocation = useCallback(async () => {
    setLoading(true);
    try {
      const data = await apiCall('location.myLocation');
      if (data) {
        setShopName(data.shopName || '');
        setAddress(data.address || '');
        setCity(data.city || '');
        setLatitude(Number(data.latitude));
        setLongitude(Number(data.longitude));
        setLatInput(String(data.latitude));
        setLngInput(String(data.longitude));
        setPhone(data.phone || '');
        setWhatsapp(data.whatsapp || '');
        setWorkingHours(data.workingHours || '');
        setIsVisible(data.isVisible !== false);
        setHasExisting(true);
      }
    } catch (e) {
      console.error('[TraderLocation] Failed to load:', e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadLocation(); }, [loadLocation]);

  // Get current location
  const [gettingLoc, setGettingLoc] = useState(false);

  const getCurrentLocation = async () => {
    setGettingLoc(true);
    try {
      // Dynamic import to avoid issues on web
      const Location = await import('expo-location');
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        if (Platform.OS !== 'web') {
          Alert.alert('', tr.locationPermDenied);
        }
        setGettingLoc(false);
        return;
      }
      const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
      setLatitude(loc.coords.latitude);
      setLongitude(loc.coords.longitude);
      setLatInput(String(loc.coords.latitude.toFixed(7)));
      setLngInput(String(loc.coords.longitude.toFixed(7)));
    } catch (e) {
      console.error('[TraderLocation] Location error:', e);
      if (Platform.OS !== 'web') {
        Alert.alert('', tr.locationError);
      }
    } finally {
      setGettingLoc(false);
    }
  };

  // Update coordinates from text input
  const handleLatChange = (text: string) => {
    setLatInput(text);
    const num = parseFloat(text);
    if (!isNaN(num) && num >= -90 && num <= 90) {
      setLatitude(num);
      setErrors(prev => ({ ...prev, latitude: '' }));
    }
  };

  const handleLngChange = (text: string) => {
    setLngInput(text);
    const num = parseFloat(text);
    if (!isNaN(num) && num >= -180 && num <= 180) {
      setLongitude(num);
      setErrors(prev => ({ ...prev, longitude: '' }));
    }
  };

  // Validate and save
  const validate = (): boolean => {
    const newErrors: Record<string, string> = {};
    if (!shopName.trim()) newErrors.shopName = tr.required;
    if (!address.trim()) newErrors.address = tr.required;

    const lat = parseFloat(latInput);
    const lng = parseFloat(lngInput);
    if (isNaN(lat) || lat < -90 || lat > 90) newErrors.latitude = tr.invalidCoord;
    if (isNaN(lng) || lng < -180 || lng > 180) newErrors.longitude = tr.invalidCoord;

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = async () => {
    if (!validate()) return;
    setSaving(true);
    try {
      await apiCall('location.setLocation', 'POST', {
        shopName: shopName.trim(),
        address: address.trim(),
        city: city.trim() || undefined,
        latitude: parseFloat(latInput),
        longitude: parseFloat(lngInput),
        phone: phone.trim() || undefined,
        whatsapp: whatsapp.trim() || undefined,
        workingHours: workingHours.trim() || undefined,
      });

      setHasExisting(true);
      if (Platform.OS !== 'web') {
        Alert.alert('', hasExisting ? tr.updatedSuccess : tr.savedSuccess);
      }
    } catch (e) {
      console.error('[TraderLocation] Save error:', e);
      if (Platform.OS !== 'web') {
        Alert.alert('', String(e));
      }
    } finally {
      setSaving(false);
    }
  };

  const handleToggleVisibility = async () => {
    if (!hasExisting) {
      setIsVisible(!isVisible);
      return;
    }
    try {
      const result = await apiCall('location.toggleVisibility', 'POST', {});
      setIsVisible(result.isVisible);
    } catch (e) {
      console.error('[TraderLocation] Toggle error:', e);
    }
  };

  if (loading) {
    return (
      <View style={styles.screen}>
        <SafeAreaView style={styles.safeArea} edges={['top']}>
          <View style={[styles.header, { flexDirection: flexDir }]}>
            <TouchableOpacity onPress={onOpenDrawer} style={styles.menuButton}>
              <MaterialIcons name={isRTL ? 'menu' : 'menu'} size={24} color="#C5A021" />
            </TouchableOpacity>
            <View style={[styles.headerTitleContainer, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
              <Text style={[styles.headerTitle, { textAlign, writingDirection: direction }]}>{tr.title}</Text>
            </View>
          </View>
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color="#C5A021" />
          </View>
        </SafeAreaView>
      </View>
    );
  }

  return (
    <View style={styles.screen}>
      <SafeAreaView style={styles.safeArea} edges={['top']}>
        {/* Header */}
        <View style={[styles.header, { flexDirection: flexDir }]}>
          <TouchableOpacity onPress={onOpenDrawer} style={styles.menuButton}>
            <MaterialIcons name="menu" size={24} color="#C5A021" />
          </TouchableOpacity>
          <View style={[styles.headerTitleContainer, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
            <Text style={[styles.headerTitle, { textAlign, writingDirection: direction }]}>{tr.title}</Text>
            <Text style={[styles.headerSubtitle, { textAlign, writingDirection: direction }]}>{tr.subtitle}</Text>
          </View>
        </View>

        <KeyboardAvoidingView
          style={{ flex: 1 }}
          behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        >
          <ScrollView
            style={styles.content}
            contentContainerStyle={styles.scrollContent}
            showsVerticalScrollIndicator={false}
          >
            {/* Shop Information Section */}
            <View style={styles.sectionHeader}>
              <MaterialIcons name="storefront" size={20} color="#C5A021" />
              <Text style={[styles.sectionTitle, { textAlign, writingDirection: direction }]}>{tr.shopInfo}</Text>
            </View>

            <View style={styles.card}>
              {/* Shop Name */}
              <View style={styles.inputGroup}>
                <Text style={[styles.inputLabel, { textAlign, writingDirection: direction }]}>{tr.shopNameLabel}</Text>
                <TextInput
                  value={shopName}
                  onChangeText={(t) => { setShopName(t); setErrors(prev => ({ ...prev, shopName: '' })); }}
                  placeholder={tr.shopNamePlaceholder}
                  placeholderTextColor="#6C737F"
                  style={[styles.input, { textAlign, writingDirection: direction }, errors.shopName ? styles.inputError : null]}
                  returnKeyType="next"
                />
                {errors.shopName ? <Text style={[styles.errorText, { textAlign, writingDirection: direction }]}>{errors.shopName}</Text> : null}
              </View>

              {/* Address */}
              <View style={styles.inputGroup}>
                <Text style={[styles.inputLabel, { textAlign, writingDirection: direction }]}>{tr.addressLabel}</Text>
                <TextInput
                  value={address}
                  onChangeText={(t) => { setAddress(t); setErrors(prev => ({ ...prev, address: '' })); }}
                  placeholder={tr.addressPlaceholder}
                  placeholderTextColor="#6C737F"
                  style={[styles.input, styles.multilineInput, { textAlign, writingDirection: direction }, errors.address ? styles.inputError : null]}
                  multiline
                  numberOfLines={2}
                  returnKeyType="next"
                />
                {errors.address ? <Text style={[styles.errorText, { textAlign, writingDirection: direction }]}>{errors.address}</Text> : null}
              </View>

              {/* City */}
              <View style={styles.inputGroup}>
                <View style={[styles.labelRow, { flexDirection: flexDir }]}>
                  <Text style={[styles.inputLabel, { textAlign, writingDirection: direction }]}>{tr.cityLabel}</Text>
                  <Text style={styles.optionalBadge}>{tr.optional}</Text>
                </View>
                <TextInput
                  value={city}
                  onChangeText={setCity}
                  placeholder={tr.cityPlaceholder}
                  placeholderTextColor="#6C737F"
                  style={[styles.input, { textAlign, writingDirection: direction }]}
                  returnKeyType="next"
                />
              </View>

              {/* Working Hours */}
              <View style={styles.inputGroup}>
                <View style={[styles.labelRow, { flexDirection: flexDir }]}>
                  <Text style={[styles.inputLabel, { textAlign, writingDirection: direction }]}>{tr.workingHoursLabel}</Text>
                  <Text style={styles.optionalBadge}>{tr.optional}</Text>
                </View>
                <TextInput
                  value={workingHours}
                  onChangeText={setWorkingHours}
                  placeholder={tr.workingHoursPlaceholder}
                  placeholderTextColor="#6C737F"
                  style={[styles.input, { textAlign, writingDirection: direction }]}
                  returnKeyType="done"
                />
              </View>
            </View>

            {/* Location Section */}
            <View style={styles.sectionHeader}>
              <MaterialIcons name="location-on" size={20} color="#C5A021" />
              <Text style={[styles.sectionTitle, { textAlign, writingDirection: direction }]}>{tr.locationLabel}</Text>
            </View>

            <View style={styles.card}>
              {/* Get Current Location Button */}
              <TouchableOpacity
                onPress={getCurrentLocation}
                disabled={gettingLoc}
                activeOpacity={0.7}
                style={[styles.locationBtn, { flexDirection: flexDir }]}
              >
                {gettingLoc ? (
                  <ActivityIndicator size="small" color="#C5A021" />
                ) : (
                  <MaterialIcons name="my-location" size={20} color="#C5A021" />
                )}
                <Text style={[styles.locationBtnText, { writingDirection: direction }, isRTL ? { marginRight: 8 } : { marginLeft: 8 }]}>
                  {gettingLoc ? tr.gettingLocation : tr.useCurrentLocation}
                </Text>
              </TouchableOpacity>

              {/* Coordinate Inputs */}
              <View style={[styles.coordRow, { flexDirection: flexDir }]}>
                <View style={styles.coordInput}>
                  <Text style={[styles.inputLabel, { textAlign, writingDirection: direction }]}>{tr.latLabel}</Text>
                  <TextInput
                    value={latInput}
                    onChangeText={handleLatChange}
                    placeholder="24.7136"
                    placeholderTextColor="#6C737F"
                    keyboardType="numeric"
                    style={[styles.input, { textAlign: 'left' }, errors.latitude ? styles.inputError : null]}
                    returnKeyType="next"
                  />
                  {errors.latitude ? <Text style={styles.errorText}>{errors.latitude}</Text> : null}
                </View>
                <View style={styles.coordInput}>
                  <Text style={[styles.inputLabel, { textAlign, writingDirection: direction }]}>{tr.lngLabel}</Text>
                  <TextInput
                    value={lngInput}
                    onChangeText={handleLngChange}
                    placeholder="46.6753"
                    placeholderTextColor="#6C737F"
                    keyboardType="numeric"
                    style={[styles.input, { textAlign: 'left' }, errors.longitude ? styles.inputError : null]}
                    returnKeyType="done"
                  />
                  {errors.longitude ? <Text style={styles.errorText}>{errors.longitude}</Text> : null}
                </View>
              </View>

              {/* Map Preview */}
              <View style={styles.mapPreview}>
                <MaterialIcons name="map" size={48} color="rgba(197,160,33,0.3)" />
                <Text style={styles.mapCoordText}>
                  {latitude.toFixed(5)}, {longitude.toFixed(5)}
                </Text>
              </View>
            </View>

            {/* Contact Information Section */}
            <View style={styles.sectionHeader}>
              <MaterialIcons name="phone" size={20} color="#C5A021" />
              <Text style={[styles.sectionTitle, { textAlign, writingDirection: direction }]}>{tr.contactInfo}</Text>
            </View>

            <View style={styles.card}>
              {/* Phone */}
              <View style={styles.inputGroup}>
                <View style={[styles.labelRow, { flexDirection: flexDir }]}>
                  <Text style={[styles.inputLabel, { textAlign, writingDirection: direction }]}>{tr.phoneLabel}</Text>
                  <Text style={styles.optionalBadge}>{tr.optional}</Text>
                </View>
                <TextInput
                  value={phone}
                  onChangeText={setPhone}
                  placeholder={tr.phonePlaceholder}
                  placeholderTextColor="#6C737F"
                  keyboardType="phone-pad"
                  style={[styles.input, { textAlign: 'left' }]}
                  returnKeyType="next"
                />
              </View>

              {/* WhatsApp */}
              <View style={styles.inputGroup}>
                <View style={[styles.labelRow, { flexDirection: flexDir }]}>
                  <Text style={[styles.inputLabel, { textAlign, writingDirection: direction }]}>{tr.whatsappLabel}</Text>
                  <Text style={styles.optionalBadge}>{tr.optional}</Text>
                </View>
                <TextInput
                  value={whatsapp}
                  onChangeText={setWhatsapp}
                  placeholder={tr.whatsappPlaceholder}
                  placeholderTextColor="#6C737F"
                  keyboardType="phone-pad"
                  style={[styles.input, { textAlign: 'left' }]}
                  returnKeyType="done"
                />
              </View>
            </View>

            {/* Visibility Toggle */}
            <View style={styles.card}>
              <View style={[styles.visibilityRow, { flexDirection: flexDir }]}>
                <View style={[styles.visibilityInfo, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
                  <Text style={[styles.visibilityLabel, { textAlign, writingDirection: direction }]}>{tr.visibilityLabel}</Text>
                  <Text style={[styles.visibilityDesc, { textAlign, writingDirection: direction }]}>{tr.visibilityDesc}</Text>
                </View>
                <Switch
                  value={isVisible}
                  onValueChange={handleToggleVisibility}
                  trackColor={{ false: 'rgba(248,249,250,0.15)', true: 'rgba(197,160,33,0.4)' }}
                  thumbColor={isVisible ? '#C5A021' : '#F8F9FA'}
                />
              </View>
            </View>

            {/* Save Button */}
            <View style={styles.saveContainer}>
              <GoldButton
                title={hasExisting ? tr.updateBtn : tr.saveBtn}
                onPress={handleSave}
                loading={saving}
              />
            </View>

            <View style={{ height: 40 }} />
          </ScrollView>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#001F3F' },
  safeArea: { flex: 1 },
  header: {
    alignItems: 'center', paddingHorizontal: 16, paddingVertical: 12,
    borderBottomWidth: 1, borderBottomColor: 'rgba(197,160,33,0.15)',
  },
  menuButton: { padding: 8 },
  headerTitleContainer: { flex: 1, marginHorizontal: 12 },
  headerTitle: { fontSize: 18, fontWeight: '700', color: '#C5A021' },
  headerSubtitle: { fontSize: 12, color: '#F8F9FA', opacity: 0.6, marginTop: 2 },
  content: { flex: 1 },
  scrollContent: { paddingHorizontal: 16, paddingTop: 16 },
  loadingContainer: { flex: 1, alignItems: 'center', justifyContent: 'center' },

  // Section
  sectionHeader: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    marginBottom: 12, marginTop: 8,
  },
  sectionTitle: { fontSize: 15, fontWeight: '700', color: '#C5A021' },

  // Card
  card: {
    backgroundColor: 'rgba(248,249,250,0.05)',
    borderRadius: 16, padding: 16, marginBottom: 16,
    borderWidth: 1, borderColor: 'rgba(248,249,250,0.08)',
  },

  // Input
  inputGroup: { marginBottom: 16 },
  labelRow: { alignItems: 'center', gap: 8, marginBottom: 8 },
  inputLabel: { fontSize: 13, fontWeight: '600', color: '#F8F9FA', marginBottom: 8 },
  optionalBadge: {
    fontSize: 10, fontWeight: '500', color: '#6C737F',
    backgroundColor: 'rgba(108,115,127,0.15)', paddingHorizontal: 6, paddingVertical: 2, borderRadius: 4,
  },
  input: {
    backgroundColor: 'rgba(248,249,250,0.06)',
    borderWidth: 1, borderColor: 'rgba(248,249,250,0.1)',
    borderRadius: 12, paddingHorizontal: 16, paddingVertical: 14,
    fontSize: 15, color: '#F8F9FA', fontWeight: '500',
  },
  multilineInput: { minHeight: 60, textAlignVertical: 'top', paddingTop: 14 },
  inputError: { borderColor: '#EF4444' },
  errorText: { fontSize: 12, color: '#EF4444', marginTop: 4 },

  // Location
  locationBtn: {
    alignItems: 'center', justifyContent: 'center',
    paddingVertical: 14, borderRadius: 12,
    backgroundColor: 'rgba(197,160,33,0.1)',
    borderWidth: 1, borderColor: 'rgba(197,160,33,0.3)',
    marginBottom: 16,
  },
  locationBtnText: { fontSize: 14, fontWeight: '600', color: '#C5A021' },

  coordRow: { gap: 12, marginBottom: 16 },
  coordInput: { flex: 1 },

  // Map Preview
  mapPreview: {
    height: 120, borderRadius: 12,
    backgroundColor: 'rgba(248,249,250,0.03)',
    borderWidth: 1, borderColor: 'rgba(248,249,250,0.06)',
    alignItems: 'center', justifyContent: 'center',
  },
  mapCoordText: { fontSize: 12, color: '#6C737F', marginTop: 8, fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace' },

  // Visibility
  visibilityRow: { alignItems: 'center', justifyContent: 'space-between' },
  visibilityInfo: { flex: 1, marginRight: 12 },
  visibilityLabel: { fontSize: 15, fontWeight: '600', color: '#F8F9FA' },
  visibilityDesc: { fontSize: 12, color: '#6C737F', marginTop: 4, lineHeight: 18 },

  // Save
  saveContainer: { marginTop: 8 },
});
