import React, { useState, useRef, useEffect } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, TextInput, KeyboardAvoidingView, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { useI18n } from '@/i18n';
import { useAuth } from '@/contexts/AuthContext';
import { useMessaging, type Message } from '@/contexts/MessagingContext';

interface ChatScreenProps {
  onOpenDrawer: () => void;
  onNavigate?: (screen: string, params?: any) => void;
  conversationId?: string;
}

export default function ChatScreen({ onOpenDrawer, onNavigate, conversationId }: ChatScreenProps) {
  const { isRTL, textAlign, direction, flexDir, lang } = useI18n();
  const { user } = useAuth();
  const { conversations, getConversationMessages, sendMessage, markConversationRead } = useMessaging();
  const [inputText, setInputText] = useState('');
  const flatListRef = useRef<FlatList>(null);

  const conversation = conversations.find(c => c.id === conversationId);
  const chatMessages = conversationId ? getConversationMessages(conversationId) : [];

  // Translations
  const sendLabel = lang === 'ar' ? 'إرسال' : lang === 'fr' ? 'Envoyer' : 'Send';
  const placeholder = lang === 'ar' ? 'اكتب رسالتك...' : lang === 'fr' ? 'Tapez votre message...' : 'Type your message...';
  const noConversation = lang === 'ar' ? 'لم يتم العثور على المحادثة' : lang === 'fr' ? 'Conversation introuvable' : 'Conversation not found';

  // Mark as read on open
  useEffect(() => {
    if (conversationId && conversation && conversation.unreadCount > 0) {
      markConversationRead(conversationId);
    }
  }, [conversationId]);

  const handleSend = () => {
    if (!inputText.trim() || !conversationId || !user) return;
    sendMessage(
      conversationId,
      inputText.trim(),
      user.email,
      user.name || user.email,
      user.role === 'trader' ? 'trader' : 'client'
    );
    setInputText('');
    setTimeout(() => {
      flatListRef.current?.scrollToEnd({ animated: true });
    }, 100);
  };

  const formatTime = (isoStr: string) => {
    const date = new Date(isoStr);
    return date.toLocaleTimeString(lang === 'ar' ? 'ar-SA' : lang === 'fr' ? 'fr-FR' : 'en-US', {
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const formatDate = (isoStr: string) => {
    const date = new Date(isoStr);
    const now = new Date();
    const diff = Math.floor((now.getTime() - date.getTime()) / 86400000);
    if (diff === 0) return lang === 'ar' ? 'اليوم' : lang === 'fr' ? "Aujourd'hui" : 'Today';
    if (diff === 1) return lang === 'ar' ? 'أمس' : lang === 'fr' ? 'Hier' : 'Yesterday';
    return date.toLocaleDateString(lang === 'ar' ? 'ar-SA' : lang === 'fr' ? 'fr-FR' : 'en-US', {
      month: 'short', day: 'numeric',
    });
  };

  // Group messages by date
  const groupedMessages: (Message | { type: 'date'; label: string; id: string })[] = [];
  let lastDate = '';
  chatMessages.forEach(msg => {
    const msgDate = new Date(msg.timestamp).toDateString();
    if (msgDate !== lastDate) {
      lastDate = msgDate;
      groupedMessages.push({ type: 'date', label: formatDate(msg.timestamp), id: `date-${msgDate}` });
    }
    groupedMessages.push(msg);
  });

  const isMyMessage = (msg: Message) => msg.senderId === user?.email;

  const renderItem = ({ item }: { item: Message | { type: 'date'; label: string; id: string } }) => {
    if ('type' in item && item.type === 'date') {
      return (
        <View style={styles.dateSeparator}>
          <Text style={styles.dateText}>{item.label}</Text>
        </View>
      );
    }

    const msg = item as Message;
    const isMine = isMyMessage(msg);

    return (
      <View style={[styles.msgRow, isMine ? styles.msgRowMine : styles.msgRowTheirs]}>
        <View style={[styles.msgBubble, isMine ? styles.msgBubbleMine : styles.msgBubbleTheirs]}>
          {!isMine && (
            <Text style={[styles.msgSender, { writingDirection: direction }]}>{msg.senderName}</Text>
          )}
          <Text style={[styles.msgText, isMine ? styles.msgTextMine : styles.msgTextTheirs, { writingDirection: direction }]}>
            {msg.text}
          </Text>
          <View style={[styles.msgMeta, { flexDirection: flexDir }]}>
            <Text style={[styles.msgTime, isMine && styles.msgTimeMine]}>{formatTime(msg.timestamp)}</Text>
            {isMine && (
              <MaterialIcons name={msg.read ? 'done-all' : 'done'} size={14} color={msg.read ? '#C5A021' : 'rgba(255,255,255,0.5)'} />
            )}
          </View>
        </View>
      </View>
    );
  };

  if (!conversation) {
    return (
      <View style={styles.screen}>
        <SafeAreaView style={styles.safeArea} edges={['top']}>
          <View style={styles.appBar}>
            <View style={{ width: 40 }} />
            <Text style={[styles.appBarTitle, { writingDirection: direction }]}>{noConversation}</Text>
            <TouchableOpacity onPress={() => onNavigate?.('trader-messages')} style={styles.menuBtn} activeOpacity={0.7}>
              <MaterialIcons name={isRTL ? 'arrow-forward' : 'arrow-back'} size={24} color="#F8F9FA" />
            </TouchableOpacity>
          </View>
          <View style={styles.emptyState}>
            <MaterialIcons name="chat-bubble-outline" size={48} color="#6C737F" />
            <Text style={[styles.emptyText, { writingDirection: direction }]}>{noConversation}</Text>
          </View>
        </SafeAreaView>
      </View>
    );
  }

  return (
    <View style={styles.screen}>
      <SafeAreaView style={styles.safeArea} edges={['top']}>
        {/* App Bar */}
        <View style={styles.appBar}>
          <View style={{ width: 40 }} />
          <View style={styles.appBarCenter}>
            <View style={styles.headerAvatar}>
              <Text style={styles.headerAvatarText}>{conversation.clientName.charAt(0)}</Text>
            </View>
            <Text style={[styles.appBarTitle, { writingDirection: direction }]}>{conversation.clientName}</Text>
          </View>
          <TouchableOpacity onPress={() => onNavigate?.('trader-messages')} style={styles.menuBtn} activeOpacity={0.7}>
            <MaterialIcons name={isRTL ? 'arrow-forward' : 'arrow-back'} size={24} color="#F8F9FA" />
          </TouchableOpacity>
        </View>

        {/* Messages */}
        <KeyboardAvoidingView
          style={styles.chatContainer}
          behavior={Platform.OS === 'ios' ? 'padding' : undefined}
          keyboardVerticalOffset={90}
        >
          <FlatList
            ref={flatListRef}
            data={groupedMessages}
            keyExtractor={item => item.id}
            renderItem={renderItem}
            contentContainerStyle={styles.messagesList}
            showsVerticalScrollIndicator={false}
            onContentSizeChange={() => flatListRef.current?.scrollToEnd({ animated: false })}
          />

          {/* Input Bar */}
          <View style={[styles.inputBar, { flexDirection: flexDir }]}>
            <TouchableOpacity
              onPress={handleSend}
              style={[styles.sendBtn, !inputText.trim() && styles.sendBtnDisabled]}
              activeOpacity={0.7}
              disabled={!inputText.trim()}
            >
              <MaterialIcons name="send" size={22} color={inputText.trim() ? '#001F3F' : '#6C737F'} style={isRTL ? { transform: [{ scaleX: -1 }] } : undefined} />
            </TouchableOpacity>
            <TextInput
              style={[styles.textInput, { textAlign, writingDirection: direction }]}
              value={inputText}
              onChangeText={setInputText}
              placeholder={placeholder}
              placeholderTextColor="#6C737F"
              multiline
              maxLength={500}
              returnKeyType="send"
              onSubmitEditing={handleSend}
              blurOnSubmit={false}
            />
          </View>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#001F3F' },
  safeArea: { flex: 1 },
  appBar: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 10,
    borderBottomWidth: 1, borderBottomColor: 'rgba(248,249,250,0.08)',
  },
  appBarCenter: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  appBarTitle: { fontSize: 16, fontWeight: '700', color: '#F8F9FA' },
  headerAvatar: {
    width: 32, height: 32, borderRadius: 16, backgroundColor: 'rgba(197,160,33,0.2)',
    alignItems: 'center', justifyContent: 'center',
  },
  headerAvatarText: { fontSize: 14, fontWeight: '700', color: '#C5A021' },
  menuBtn: { padding: 8 },

  chatContainer: { flex: 1 },
  messagesList: { paddingHorizontal: 16, paddingTop: 12, paddingBottom: 8 },

  // Date separator
  dateSeparator: { alignItems: 'center', marginVertical: 12 },
  dateText: {
    fontSize: 11, color: '#6C737F', backgroundColor: 'rgba(248,249,250,0.06)',
    paddingHorizontal: 12, paddingVertical: 4, borderRadius: 10,
  },

  // Message bubbles
  msgRow: { marginBottom: 6, maxWidth: '80%' },
  msgRowMine: { alignSelf: 'flex-end' },
  msgRowTheirs: { alignSelf: 'flex-start' },
  msgBubble: { borderRadius: 16, paddingHorizontal: 14, paddingVertical: 10, maxWidth: '100%' },
  msgBubbleMine: { backgroundColor: '#C5A021', borderBottomRightRadius: 4 },
  msgBubbleTheirs: { backgroundColor: 'rgba(248,249,250,0.1)', borderBottomLeftRadius: 4 },
  msgSender: { fontSize: 11, fontWeight: '600', color: '#C5A021', marginBottom: 4 },
  msgText: { fontSize: 14, lineHeight: 20 },
  msgTextMine: { color: '#001F3F' },
  msgTextTheirs: { color: '#F8F9FA' },
  msgMeta: { alignItems: 'center', gap: 4, marginTop: 4, justifyContent: 'flex-end' },
  msgTime: { fontSize: 10, color: 'rgba(248,249,250,0.5)' },
  msgTimeMine: { color: 'rgba(0,31,63,0.5)' },

  // Input bar
  inputBar: {
    alignItems: 'flex-end', gap: 10, paddingHorizontal: 16, paddingVertical: 10,
    borderTopWidth: 1, borderTopColor: 'rgba(248,249,250,0.08)',
    backgroundColor: 'rgba(0,31,63,0.95)',
  },
  textInput: {
    flex: 1, backgroundColor: 'rgba(248,249,250,0.08)', borderRadius: 20,
    paddingHorizontal: 16, paddingVertical: 10, color: '#F8F9FA',
    fontSize: 14, maxHeight: 100, minHeight: 40,
  },
  sendBtn: {
    width: 40, height: 40, borderRadius: 20, backgroundColor: '#C5A021',
    alignItems: 'center', justifyContent: 'center',
  },
  sendBtnDisabled: { backgroundColor: 'rgba(248,249,250,0.08)' },

  // Empty
  emptyState: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12 },
  emptyText: { fontSize: 15, color: '#6C737F' },
});
