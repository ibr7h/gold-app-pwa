import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, FlatList } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { GoldCard } from '@/components/gold/GoldCard';
import { useI18n } from '@/i18n';
import { useTraderData, type TraderNotification, type NotificationType } from '@/contexts/TraderDataContext';

interface TraderNotificationsScreenProps {
  onOpenDrawer: () => void;
  onNavigate?: (screen: string) => void;
}

export default function TraderNotificationsScreen({ onOpenDrawer, onNavigate }: TraderNotificationsScreenProps) {
  const { isRTL, textAlign, direction, flexDir, lang } = useI18n();
  const { notifications, unreadCount, markAsRead, markAllAsRead, clearNotifications } = useTraderData();

  // Translations
  const titleLabel = lang === 'ar' ? 'الإشعارات' : lang === 'fr' ? 'Notifications' : 'Notifications';
  const markAllRead = lang === 'ar' ? 'قراءة الكل' : lang === 'fr' ? 'Tout lire' : 'Mark All Read';
  const clearAll = lang === 'ar' ? 'مسح الكل' : lang === 'fr' ? 'Tout effacer' : 'Clear All';
  const noNotifications = lang === 'ar' ? 'لا توجد إشعارات' : lang === 'fr' ? 'Aucune notification' : 'No notifications';
  const justNow = lang === 'ar' ? 'الآن' : lang === 'fr' ? 'À l\'instant' : 'Just now';
  const minutesAgo = lang === 'ar' ? 'دقيقة' : lang === 'fr' ? 'min' : 'min ago';
  const hoursAgo = lang === 'ar' ? 'ساعة' : lang === 'fr' ? 'h' : 'h ago';
  const daysAgo = lang === 'ar' ? 'يوم' : lang === 'fr' ? 'j' : 'd ago';

  const getNotificationIcon = (type: NotificationType): { name: keyof typeof MaterialIcons.glyphMap; color: string } => {
    switch (type) {
      case 'new_order': return { name: 'add-shopping-cart', color: '#22C55E' };
      case 'order_status': return { name: 'autorenew', color: '#3B82F6' };
      case 'new_client': return { name: 'person-add', color: '#C5A021' };
      case 'system': return { name: 'info', color: '#6C737F' };
    }
  };

  const getTypeLabel = (type: NotificationType): string => {
    switch (type) {
      case 'new_order': return lang === 'ar' ? 'طلب جديد' : lang === 'fr' ? 'Nouvelle commande' : 'New Order';
      case 'order_status': return lang === 'ar' ? 'تحديث الحالة' : lang === 'fr' ? 'Mise à jour' : 'Status Update';
      case 'new_client': return lang === 'ar' ? 'عميل جديد' : lang === 'fr' ? 'Nouveau client' : 'New Client';
      case 'system': return lang === 'ar' ? 'النظام' : lang === 'fr' ? 'Système' : 'System';
    }
  };

  const getTimeAgo = (timestamp: number): string => {
    const diff = Date.now() - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) return justNow;
    if (minutes < 60) return `${minutes} ${minutesAgo}`;
    if (hours < 24) return `${hours} ${hoursAgo}`;
    return `${days} ${daysAgo}`;
  };

  const renderNotification = ({ item }: { item: TraderNotification }) => {
    const icon = getNotificationIcon(item.type);
    return (
      <TouchableOpacity
        activeOpacity={0.7}
        onPress={() => {
          if (!item.read) markAsRead(item.id);
          // Navigate to relevant screen
          if (item.orderId) onNavigate?.('trader-orders');
          if (item.clientId) onNavigate?.('trader-clients');
        }}
      >
        <GoldCard>
          <View style={[styles.notifRow, { flexDirection: flexDir }]}>
            {!item.read && <View style={styles.unreadDot} />}
            <View style={[styles.notifContent, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
              <View style={[styles.notifHeader, { flexDirection: flexDir }]}>
                <Text style={[styles.notifTime, { writingDirection: direction }]}>{getTimeAgo(item.createdAt)}</Text>
                <View style={[styles.notifTypeRow, { flexDirection: flexDir }]}>
                  <Text style={[styles.notifType, { writingDirection: direction }]}>{getTypeLabel(item.type)}</Text>
                </View>
              </View>
              <Text style={[styles.notifTitle, { writingDirection: direction, opacity: item.read ? 0.7 : 1 }]}>
                {item.title}
              </Text>
              <Text style={[styles.notifMessage, { writingDirection: direction, opacity: item.read ? 0.6 : 0.8 }]}>
                {item.message}
              </Text>
            </View>
            <View style={[styles.notifIcon, { backgroundColor: icon.color + '20' }]}>
              <MaterialIcons name={icon.name as any} size={22} color={icon.color} />
            </View>
          </View>
        </GoldCard>
      </TouchableOpacity>
    );
  };

  return (
    <View style={styles.screen}>
      <SafeAreaView style={styles.safeArea} edges={['top']}>
        {/* App Bar */}
        <View style={styles.appBar}>
          <View style={{ width: 40 }} />
          <Text style={[styles.appBarTitle, { writingDirection: direction }]}>
            {titleLabel} {unreadCount > 0 ? `(${unreadCount})` : ''}
          </Text>
          <TouchableOpacity onPress={onOpenDrawer} style={styles.menuBtn} activeOpacity={0.7}>
            <MaterialIcons name="menu" size={24} color="#F8F9FA" />
          </TouchableOpacity>
        </View>

        {/* Action Bar */}
        {notifications.length > 0 && (
          <View style={[styles.actionBar, { flexDirection: flexDir }]}>
            <TouchableOpacity onPress={clearNotifications} activeOpacity={0.7} style={styles.actionLink}>
              <MaterialIcons name="delete-sweep" size={16} color="#EF4444" />
              <Text style={[styles.actionLinkText, { color: '#EF4444' }]}>{clearAll}</Text>
            </TouchableOpacity>
            {unreadCount > 0 && (
              <TouchableOpacity onPress={markAllAsRead} activeOpacity={0.7} style={styles.actionLink}>
                <MaterialIcons name="done-all" size={16} color="#C5A021" />
                <Text style={styles.actionLinkText}>{markAllRead}</Text>
              </TouchableOpacity>
            )}
          </View>
        )}

        {/* Notifications List */}
        <FlatList
          data={notifications}
          keyExtractor={item => item.id}
          renderItem={renderNotification}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={
            <View style={styles.emptyState}>
              <MaterialIcons name="notifications-off" size={48} color="#6C737F" />
              <Text style={styles.emptyText}>{noNotifications}</Text>
            </View>
          }
        />
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#001F3F' },
  safeArea: { flex: 1 },
  appBar: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 12,
    borderBottomWidth: 1, borderBottomColor: 'rgba(248,249,250,0.08)',
  },
  appBarTitle: { fontSize: 18, fontWeight: '700', color: '#F8F9FA' },
  menuBtn: { padding: 8 },

  // Action Bar
  actionBar: {
    justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: 16, paddingVertical: 10,
    borderBottomWidth: 1, borderBottomColor: 'rgba(248,249,250,0.05)',
  },
  actionLink: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  actionLinkText: { fontSize: 13, fontWeight: '600', color: '#C5A021' },

  listContent: { paddingHorizontal: 16, paddingTop: 8, paddingBottom: 32 },

  // Notification Card
  notifRow: { justifyContent: 'space-between', alignItems: 'flex-start', gap: 12 },
  notifIcon: {
    width: 44, height: 44, borderRadius: 12,
    alignItems: 'center', justifyContent: 'center',
  },
  notifContent: { flex: 1 },
  notifHeader: { justifyContent: 'space-between', alignItems: 'center', marginBottom: 4, width: '100%' },
  notifTypeRow: { alignItems: 'center', gap: 4 },
  notifType: { fontSize: 11, fontWeight: '600', color: '#C5A021' },
  notifTime: { fontSize: 11, color: '#6C737F' },
  notifTitle: { fontSize: 15, fontWeight: '600', color: '#1A1A1B', marginBottom: 2 },
  notifMessage: { fontSize: 13, color: '#6C737F', lineHeight: 18 },
  unreadDot: {
    width: 8, height: 8, borderRadius: 4,
    backgroundColor: '#C5A021', marginTop: 6,
  },

  // Empty
  emptyState: { alignItems: 'center', paddingVertical: 80, gap: 12 },
  emptyText: { fontSize: 15, color: '#6C737F' },
});
