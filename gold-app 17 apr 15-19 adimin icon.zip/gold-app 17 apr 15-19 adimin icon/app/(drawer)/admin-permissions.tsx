import React, { useState, useCallback, useEffect } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Alert, Platform, ActivityIndicator, Switch } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { GoldCard } from '@/components/gold/GoldCard';
import { useI18n } from '@/i18n';
import { getApiBaseUrl } from '@/constants/oauth';
import * as Auth from '@/lib/_core/auth';

interface TraderPerms {
  canViewOrders: boolean;
  canCreateOrders: boolean;
  canEditOrders: boolean;
  canDeleteOrders: boolean;
  canViewClients: boolean;
  canCreateClients: boolean;
  canEditClients: boolean;
  canDeleteClients: boolean;
  canViewReports: boolean;
  canExportReports: boolean;
  canUseMessaging: boolean;
}

interface TraderWithPerms {
  traderId: number;
  traderName: string;
  traderEmail: string | null;
  isActive: boolean;
  permissions: TraderPerms;
}

interface AdminPermissionsScreenProps {
  onOpenDrawer: () => void;
  onNavigate?: (screen: string) => void;
}

async function getAuthHeaders(): Promise<Record<string, string>> {
  const token = await Auth.getSessionToken();
  if (token) {
    return { Authorization: `Bearer ${token}` };
  }
  return {};
}

async function apiCall(path: string, method: 'GET' | 'POST' = 'GET', body?: any) {
  const baseUrl = getApiBaseUrl();
  const url = `${baseUrl}/api/trpc/${path}`;
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(await getAuthHeaders()),
  };

  const options: RequestInit = { method, headers, credentials: 'include' as any };
  if (body && method === 'POST') {
    options.body = JSON.stringify({ json: body });
  }

  const response = await fetch(url, options);
  const data = await response.json();

  if (data?.error) {
    throw new Error(data.error.message || 'API error');
  }

  return data?.result?.data?.json;
}

// Permission keys grouped by category
const PERM_GROUPS = [
  {
    key: 'orders',
    icon: 'receipt-long' as const,
    perms: [
      { key: 'canViewOrders', action: 'view' },
      { key: 'canCreateOrders', action: 'create' },
      { key: 'canEditOrders', action: 'edit' },
      { key: 'canDeleteOrders', action: 'delete' },
    ],
  },
  {
    key: 'clients',
    icon: 'people' as const,
    perms: [
      { key: 'canViewClients', action: 'view' },
      { key: 'canCreateClients', action: 'create' },
      { key: 'canEditClients', action: 'edit' },
      { key: 'canDeleteClients', action: 'delete' },
    ],
  },
  {
    key: 'reports',
    icon: 'assessment' as const,
    perms: [
      { key: 'canViewReports', action: 'view' },
      { key: 'canExportReports', action: 'export' },
    ],
  },
  {
    key: 'messaging',
    icon: 'chat' as const,
    perms: [
      { key: 'canUseMessaging', action: 'use' },
    ],
  },
];

export default function AdminPermissionsScreen({ onOpenDrawer, onNavigate }: AdminPermissionsScreenProps) {
  const { isRTL, textAlign, direction, flexDir, lang, t } = useI18n();
  const [traders, setTraders] = useState<TraderWithPerms[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedTraderId, setSelectedTraderId] = useState<number | null>(null);
  const [updating, setUpdating] = useState<string | null>(null);

  const tr = t.permissions;

  const loadTraders = useCallback(async () => {
    try {
      const data = await apiCall('permissions.listTraders');
      setTraders(data || []);
    } catch (e) {
      console.error('[AdminPermissions] Failed to load traders:', e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadTraders();
  }, [loadTraders]);

  const handleTogglePermission = async (traderId: number, permKey: string, newValue: boolean) => {
    setUpdating(permKey);
    try {
      await apiCall('permissions.update', 'POST', {
        traderId,
        [permKey]: newValue,
      });

      // Update local state
      setTraders(prev => prev.map(t =>
        t.traderId === traderId
          ? { ...t, permissions: { ...t.permissions, [permKey]: newValue } }
          : t
      ));
    } catch (e) {
      console.error('[AdminPermissions] Failed to update permission:', e);
      if (Platform.OS !== 'web') {
        Alert.alert('Error', 'Failed to update permission');
      }
    } finally {
      setUpdating(null);
    }
  };

  const handleResetPermissions = async (traderId: number, traderName: string) => {
    const doReset = async () => {
      try {
        await apiCall('permissions.reset', 'POST', { traderId });
        await loadTraders();
        if (Platform.OS !== 'web') {
          Alert.alert(tr.permissionsReset);
        }
      } catch (e) {
        console.error('[AdminPermissions] Failed to reset permissions:', e);
      }
    };

    if (Platform.OS !== 'web') {
      Alert.alert(tr.resetDefaults, `${tr.resetConfirm}\n${traderName}`, [
        { text: t.cancel, style: 'cancel' },
        { text: tr.resetDefaults, style: 'destructive', onPress: doReset },
      ]);
    } else {
      doReset();
    }
  };

  const getActionLabel = (action: string): string => {
    const map: Record<string, string> = {
      view: tr.view,
      create: tr.create,
      edit: tr.edit,
      delete: tr.delete,
      export: tr.export,
      use: tr.use,
    };
    return map[action] || action;
  };

  const getCategoryLabel = (key: string): string => {
    const map: Record<string, string> = {
      orders: tr.orders,
      clients: tr.clients,
      reports: tr.reports,
      messaging: tr.messaging,
    };
    return map[key] || key;
  };

  const selectedTrader = traders.find(t => t.traderId === selectedTraderId);

  const countEnabled = (perms: TraderPerms): number => {
    return Object.values(perms).filter(v => v === true).length;
  };

  const totalPerms = 11; // total number of permission flags

  return (
    <View style={styles.screen}>
      <SafeAreaView style={styles.safeArea} edges={['top', 'left', 'right']}>
        {/* Header */}
        <View style={[styles.header, { flexDirection: flexDir }]}>
          <TouchableOpacity onPress={onOpenDrawer} style={styles.menuButton} activeOpacity={0.7}>
            <MaterialIcons name={isRTL ? 'arrow-forward' : 'arrow-back'} size={24} color="#C5A021" />
          </TouchableOpacity>
          <View style={[styles.headerTitleContainer, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
            <Text style={[styles.headerTitle, { writingDirection: direction }]}>{tr.title}</Text>
            <Text style={[styles.headerSubtitle, { writingDirection: direction }]}>{tr.managePermissionsDesc}</Text>
          </View>
          <TouchableOpacity
            onPress={() => {
              if (selectedTraderId) {
                setSelectedTraderId(null);
              } else {
                onNavigate?.('admin');
              }
            }}
            style={styles.backBtn}
            activeOpacity={0.7}
          >
            <MaterialIcons name={isRTL ? 'arrow-back' : 'arrow-forward'} size={20} color="#C5A021" />
          </TouchableOpacity>
        </View>

        <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
          {loading ? (
            <View style={styles.loadingContainer}>
              <ActivityIndicator size="large" color="#C5A021" />
            </View>
          ) : traders.length === 0 ? (
            <GoldCard>
              <View style={styles.emptyContainer}>
                <MaterialIcons name="people-outline" size={48} color="#6C737F" />
                <Text style={[styles.emptyTitle, { writingDirection: direction }]}>{tr.noTraders}</Text>
              </View>
            </GoldCard>
          ) : !selectedTraderId ? (
            /* Trader List */
            <>
              <Text style={[styles.sectionTitle, { textAlign, writingDirection: direction }]}>
                {tr.selectTrader}
              </Text>
              {traders.map((trader) => {
                const enabledCount = countEnabled(trader.permissions);
                return (
                  <TouchableOpacity
                    key={trader.traderId}
                    onPress={() => setSelectedTraderId(trader.traderId)}
                    activeOpacity={0.7}
                  >
                    <GoldCard>
                      <View style={[styles.traderRow, { flexDirection: flexDir }]}>
                        <View style={styles.traderAvatar}>
                          <MaterialIcons name="person" size={24} color="#C5A021" />
                        </View>
                        <View style={[styles.traderInfo, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
                          <Text style={[styles.traderName, { writingDirection: direction }]}>
                            {trader.traderName}
                          </Text>
                          {trader.traderEmail && (
                            <Text style={[styles.traderEmail, { writingDirection: direction }]}>
                              {trader.traderEmail}
                            </Text>
                          )}
                          <View style={[styles.permsSummary, { flexDirection: flexDir }]}>
                            <View style={[styles.permsBadge, {
                              backgroundColor: enabledCount === totalPerms
                                ? 'rgba(34,197,94,0.15)'
                                : 'rgba(197,160,33,0.15)',
                            }]}>
                              <Text style={[styles.permsBadgeText, {
                                color: enabledCount === totalPerms ? '#22C55E' : '#C5A021',
                              }]}>
                                {enabledCount}/{totalPerms} {tr.enabled}
                              </Text>
                            </View>
                            {!trader.isActive && (
                              <View style={[styles.permsBadge, { backgroundColor: 'rgba(239,68,68,0.15)' }]}>
                                <Text style={[styles.permsBadgeText, { color: '#EF4444' }]}>
                                  {tr.disabled}
                                </Text>
                              </View>
                            )}
                          </View>
                        </View>
                        <MaterialIcons
                          name={isRTL ? 'chevron-left' : 'chevron-right'}
                          size={24}
                          color="#6C737F"
                        />
                      </View>
                    </GoldCard>
                  </TouchableOpacity>
                );
              })}
            </>
          ) : selectedTrader ? (
            /* Permission Detail */
            <>
              {/* Trader Header */}
              <GoldCard>
                <View style={[styles.detailHeader, { flexDirection: flexDir }]}>
                  <View style={styles.traderAvatar}>
                    <MaterialIcons name="person" size={28} color="#C5A021" />
                  </View>
                  <View style={[styles.traderInfo, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
                    <Text style={[styles.traderNameLarge, { writingDirection: direction }]}>
                      {selectedTrader.traderName}
                    </Text>
                    {selectedTrader.traderEmail && (
                      <Text style={[styles.traderEmail, { writingDirection: direction }]}>
                        {selectedTrader.traderEmail}
                      </Text>
                    )}
                  </View>
                </View>
              </GoldCard>

              {/* Permission Groups */}
              {PERM_GROUPS.map((group) => (
                <GoldCard key={group.key}>
                  <View style={[styles.groupHeader, { flexDirection: flexDir }]}>
                    <MaterialIcons name={group.icon} size={20} color="#C5A021" />
                    <Text style={[styles.groupTitle, { writingDirection: direction, marginStart: 8 }]}>
                      {getCategoryLabel(group.key)}
                    </Text>
                  </View>
                  {group.perms.map((perm, idx) => {
                    const permValue = selectedTrader.permissions[perm.key as keyof TraderPerms];
                    const isUpdating = updating === perm.key;
                    return (
                      <View
                        key={perm.key}
                        style={[
                          styles.permRow,
                          { flexDirection: flexDir },
                          idx < group.perms.length - 1 && styles.permRowBorder,
                        ]}
                      >
                        <Text style={[styles.permLabel, { writingDirection: direction }]}>
                          {getActionLabel(perm.action)}
                        </Text>
                        {isUpdating ? (
                          <ActivityIndicator size="small" color="#C5A021" />
                        ) : (
                          <Switch
                            value={permValue}
                            onValueChange={(val) =>
                              handleTogglePermission(selectedTrader.traderId, perm.key, val)
                            }
                            trackColor={{ false: '#334155', true: 'rgba(197,160,33,0.4)' }}
                            thumbColor={permValue ? '#C5A021' : '#6C737F'}
                          />
                        )}
                      </View>
                    );
                  })}
                </GoldCard>
              ))}

              {/* Reset Button */}
              <TouchableOpacity
                onPress={() => handleResetPermissions(selectedTrader.traderId, selectedTrader.traderName)}
                style={styles.resetBtn}
                activeOpacity={0.7}
              >
                <MaterialIcons name="restore" size={18} color="#EF4444" />
                <Text style={styles.resetBtnText}>{tr.resetDefaults}</Text>
              </TouchableOpacity>
            </>
          ) : null}

          <View style={{ height: 40 }} />
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#001F3F' },
  safeArea: { flex: 1 },
  header: {
    alignItems: 'center', paddingHorizontal: 16, paddingVertical: 12,
    borderBottomWidth: 1, borderBottomColor: 'rgba(197,160,33,0.15)',
  },
  menuButton: { padding: 8 },
  headerTitleContainer: { flex: 1, marginHorizontal: 12 },
  headerTitle: { fontSize: 18, fontWeight: '700', color: '#C5A021' },
  headerSubtitle: { fontSize: 12, color: '#F8F9FA', opacity: 0.6, marginTop: 2 },
  backBtn: { padding: 8 },
  content: { flex: 1 },
  scrollContent: { paddingHorizontal: 16, paddingTop: 16 },

  // Loading & Empty
  loadingContainer: { paddingVertical: 60, alignItems: 'center' },
  emptyContainer: { alignItems: 'center', paddingVertical: 32 },
  emptyTitle: { fontSize: 16, fontWeight: '600', color: '#F8F9FA', marginTop: 16 },

  // Section
  sectionTitle: { fontSize: 14, fontWeight: '600', color: '#F8F9FA', opacity: 0.6, marginBottom: 12 },

  // Trader List
  traderRow: { alignItems: 'center', gap: 12 },
  traderAvatar: {
    width: 44, height: 44, borderRadius: 22,
    backgroundColor: 'rgba(197,160,33,0.15)',
    alignItems: 'center', justifyContent: 'center',
  },
  traderInfo: { flex: 1 },
  traderName: { fontSize: 15, fontWeight: '700', color: '#F8F9FA' },
  traderNameLarge: { fontSize: 18, fontWeight: '700', color: '#F8F9FA' },
  traderEmail: { fontSize: 12, color: '#F8F9FA', opacity: 0.5, marginTop: 2 },
  permsSummary: { gap: 6, marginTop: 6 },
  permsBadge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 10 },
  permsBadgeText: { fontSize: 11, fontWeight: '600' },

  // Detail Header
  detailHeader: { alignItems: 'center', gap: 12 },

  // Permission Groups
  groupHeader: { alignItems: 'center', marginBottom: 12 },
  groupTitle: { fontSize: 15, fontWeight: '700', color: '#C5A021' },
  permRow: {
    justifyContent: 'space-between', alignItems: 'center',
    paddingVertical: 12,
  },
  permRowBorder: {
    borderBottomWidth: 1, borderBottomColor: 'rgba(197,160,33,0.1)',
  },
  permLabel: { fontSize: 14, color: '#F8F9FA', fontWeight: '500' },

  // Reset
  resetBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: 8, paddingVertical: 14, marginTop: 8,
    borderRadius: 12, borderWidth: 1.5, borderColor: 'rgba(239,68,68,0.3)',
    backgroundColor: 'rgba(239,68,68,0.05)',
  },
  resetBtnText: { fontSize: 14, fontWeight: '600', color: '#EF4444' },
});
