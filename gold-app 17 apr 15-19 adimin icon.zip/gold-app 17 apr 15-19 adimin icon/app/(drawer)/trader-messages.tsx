import React from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { useI18n } from '@/i18n';
import { useMessaging, type Conversation } from '@/contexts/MessagingContext';
import { useTraderPermissions } from '@/hooks/useTraderPermissions';

interface TraderMessagesScreenProps {
  onOpenDrawer: () => void;
  onNavigate?: (screen: string, params?: any) => void;
}

export default function TraderMessagesScreen({ onOpenDrawer, onNavigate }: TraderMessagesScreenProps) {
  const { isRTL, textAlign, direction, flexDir, lang } = useI18n();
  const { conversations, deleteConversation, totalUnread } = useMessaging();
  const { permissions } = useTraderPermissions();

  // Translations
  const titleLabel = lang === 'ar' ? 'الرسائل' : lang === 'fr' ? 'Messages' : 'Messages';
  const noMessages = lang === 'ar' ? 'لا توجد محادثات' : lang === 'fr' ? 'Aucune conversation' : 'No conversations';
  const deleteLabel = lang === 'ar' ? 'حذف' : lang === 'fr' ? 'Supprimer' : 'Delete';
  const deleteConfirm = lang === 'ar' ? 'هل تريد حذف هذه المحادثة؟' : lang === 'fr' ? 'Supprimer cette conversation ?' : 'Delete this conversation?';
  const cancelLabel = lang === 'ar' ? 'إلغاء' : lang === 'fr' ? 'Annuler' : 'Cancel';

  const sortedConversations = [...conversations].sort(
    (a, b) => new Date(b.lastMessageTime).getTime() - new Date(a.lastMessageTime).getTime()
  );

  const formatTime = (isoStr: string) => {
    const date = new Date(isoStr);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const mins = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (mins < 1) return lang === 'ar' ? 'الآن' : lang === 'fr' ? 'Maintenant' : 'Now';
    if (mins < 60) return `${mins}${lang === 'ar' ? ' د' : lang === 'fr' ? ' min' : 'm'}`;
    if (hours < 24) return `${hours}${lang === 'ar' ? ' س' : lang === 'fr' ? ' h' : 'h'}`;
    if (days < 7) return `${days}${lang === 'ar' ? ' ي' : lang === 'fr' ? ' j' : 'd'}`;
    return date.toLocaleDateString(lang === 'ar' ? 'ar-SA' : lang === 'fr' ? 'fr-FR' : 'en-US', { month: 'short', day: 'numeric' });
  };

  const handleDelete = (conv: Conversation) => {
    Alert.alert(deleteLabel, deleteConfirm, [
      { text: cancelLabel, style: 'cancel' },
      { text: deleteLabel, style: 'destructive', onPress: () => deleteConversation(conv.id) },
    ]);
  };

  const renderConversation = ({ item }: { item: Conversation }) => (
    <TouchableOpacity
      style={[styles.convCard, item.unreadCount > 0 && styles.convCardUnread]}
      activeOpacity={0.7}
      onPress={() => onNavigate?.('chat', { conversationId: item.id })}
      onLongPress={() => handleDelete(item)}
    >
      <View style={[styles.convRow, { flexDirection: flexDir }]}>
        <View style={[styles.convTimeCol, { alignItems: isRTL ? 'flex-start' : 'flex-end' }]}>
          <Text style={styles.convTime}>{formatTime(item.lastMessageTime)}</Text>
          {item.unreadCount > 0 && (
            <View style={styles.unreadBadge}>
              <Text style={styles.unreadText}>{item.unreadCount}</Text>
            </View>
          )}
        </View>
        <View style={[styles.convInfo, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
          <View style={[styles.convNameRow, { flexDirection: flexDir }]}>
            <View style={styles.avatar}>
              <Text style={styles.avatarText}>{item.clientName.charAt(0)}</Text>
            </View>
            <Text style={[styles.convName, { writingDirection: direction }]}>{item.clientName}</Text>
          </View>
          <Text
            style={[styles.convLastMsg, item.unreadCount > 0 && styles.convLastMsgUnread, { writingDirection: direction }]}
            numberOfLines={1}
          >
            {item.lastMessage || (lang === 'ar' ? 'محادثة جديدة' : lang === 'fr' ? 'Nouvelle conversation' : 'New conversation')}
          </Text>
        </View>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.screen}>
      <SafeAreaView style={styles.safeArea} edges={['top']}>
        {/* App Bar */}
        <View style={styles.appBar}>
          <View style={{ width: 40 }} />
          <View style={[styles.appBarTitleRow, { flexDirection: flexDir }]}>
            <Text style={[styles.appBarTitle, { writingDirection: direction }]}>{titleLabel}</Text>
            {totalUnread > 0 && (
              <View style={styles.appBarBadge}>
                <Text style={styles.appBarBadgeText}>{totalUnread}</Text>
              </View>
            )}
          </View>
          <TouchableOpacity onPress={onOpenDrawer} style={styles.menuBtn} activeOpacity={0.7}>
            <MaterialIcons name="menu" size={24} color="#F8F9FA" />
          </TouchableOpacity>
        </View>

        {!permissions.canUseMessaging ? (
          <View style={styles.emptyState}>
            <MaterialIcons name="lock" size={48} color="#6C737F" />
            <Text style={[styles.emptyText, { writingDirection: direction }]}>
              {lang === 'ar' ? 'ليس لديك صلاحية للوصول إلى الرسائل' : lang === 'fr' ? 'Vous n\'avez pas accès aux messages' : 'You do not have permission to access messages'}
            </Text>
          </View>
        ) : sortedConversations.length === 0 ? (
          <View style={styles.emptyState}>
            <MaterialIcons name="chat-bubble-outline" size={48} color="#6C737F" />
            <Text style={[styles.emptyText, { writingDirection: direction }]}>{noMessages}</Text>
          </View>
        ) : (
          <FlatList
            data={sortedConversations}
            keyExtractor={item => item.id}
            renderItem={renderConversation}
            contentContainerStyle={styles.listContent}
            showsVerticalScrollIndicator={false}
          />
        )}
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#001F3F' },
  safeArea: { flex: 1 },
  appBar: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 12,
    borderBottomWidth: 1, borderBottomColor: 'rgba(248,249,250,0.08)',
  },
  appBarTitleRow: { alignItems: 'center', gap: 8 },
  appBarTitle: { fontSize: 18, fontWeight: '700', color: '#F8F9FA' },
  appBarBadge: {
    backgroundColor: '#EF4444', borderRadius: 10, minWidth: 20, height: 20,
    alignItems: 'center', justifyContent: 'center', paddingHorizontal: 6,
  },
  appBarBadgeText: { fontSize: 11, fontWeight: '700', color: '#FFF' },
  menuBtn: { padding: 8 },
  listContent: { paddingHorizontal: 16, paddingTop: 12, paddingBottom: 32 },

  convCard: {
    backgroundColor: 'rgba(248,249,250,0.06)', borderRadius: 14, padding: 16,
    marginBottom: 8, borderWidth: 1, borderColor: 'rgba(248,249,250,0.06)',
  },
  convCardUnread: { borderColor: 'rgba(197,160,33,0.3)', backgroundColor: 'rgba(197,160,33,0.06)' },
  convRow: { alignItems: 'flex-start', gap: 12 },
  convInfo: { flex: 1 },
  convNameRow: { alignItems: 'center', gap: 10, marginBottom: 6 },
  avatar: {
    width: 40, height: 40, borderRadius: 20, backgroundColor: 'rgba(197,160,33,0.15)',
    alignItems: 'center', justifyContent: 'center',
  },
  avatarText: { fontSize: 16, fontWeight: '700', color: '#C5A021' },
  convName: { fontSize: 15, fontWeight: '600', color: '#F8F9FA' },
  convLastMsg: { fontSize: 13, color: '#6C737F', marginStart: 50 },
  convLastMsgUnread: { color: '#F8F9FA', fontWeight: '500' },
  convTimeCol: { gap: 6 },
  convTime: { fontSize: 11, color: '#6C737F' },
  unreadBadge: {
    backgroundColor: '#C5A021', borderRadius: 10, minWidth: 20, height: 20,
    alignItems: 'center', justifyContent: 'center', paddingHorizontal: 5, alignSelf: 'center',
  },
  unreadText: { fontSize: 11, fontWeight: '700', color: '#001F3F' },

  emptyState: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12 },
  emptyText: { fontSize: 15, color: '#6C737F' },
});
