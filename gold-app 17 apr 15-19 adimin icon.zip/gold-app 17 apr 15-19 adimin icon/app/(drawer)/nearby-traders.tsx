import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet,
  ActivityIndicator, Alert, Platform, Linking, FlatList, RefreshControl,
  Dimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { useI18n } from '@/i18n';
import { getApiBaseUrl } from '@/constants/oauth';
import * as Auth from '@/lib/_core/auth';

const SCREEN_WIDTH = Dimensions.get('window').width;

interface NearbyTradersScreenProps {
  onOpenDrawer: () => void;
  onNavigate?: (screen: string) => void;
}

interface TraderLocationItem {
  id: number;
  traderId: number;
  shopName: string;
  address: string;
  city: string | null;
  latitude: string;
  longitude: string;
  phone: string | null;
  whatsapp: string | null;
  workingHours: string | null;
  traderName: string | null;
  distanceKm?: number;
}

async function getAuthHeaders(): Promise<Record<string, string>> {
  const token = await Auth.getSessionToken();
  if (token) return { Authorization: `Bearer ${token}` };
  return {};
}

async function apiCall(path: string, method: 'GET' | 'POST' = 'GET', body?: any) {
  const baseUrl = getApiBaseUrl();
  const url = `${baseUrl}/api/trpc/${path}`;
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(await getAuthHeaders()),
  };
  const options: RequestInit = { method, headers, credentials: 'include' as any };
  if (body && method === 'POST') {
    options.body = JSON.stringify({ json: body });
  }
  // For GET with input, encode as query parameter
  if (body && method === 'GET') {
    const encoded = encodeURIComponent(JSON.stringify({ json: body }));
    const response = await fetch(`${url}?input=${encoded}`, { method, headers, credentials: 'include' as any });
    const data = await response.json();
    if (data?.error) throw new Error(data.error.message || 'API error');
    return data?.result?.data?.json;
  }
  const response = await fetch(url, options);
  const data = await response.json();
  if (data?.error) throw new Error(data.error.message || 'API error');
  return data?.result?.data?.json;
}

export default function NearbyTradersScreen({ onOpenDrawer, onNavigate }: NearbyTradersScreenProps) {
  const { isRTL, textAlign, direction, flexDir, lang } = useI18n();

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [traders, setTraders] = useState<TraderLocationItem[]>([]);
  const [userLat, setUserLat] = useState<number | null>(null);
  const [userLng, setUserLng] = useState<number | null>(null);
  const [locationGranted, setLocationGranted] = useState(false);
  const [gettingLoc, setGettingLoc] = useState(false);
  const [selectedTrader, setSelectedTrader] = useState<TraderLocationItem | null>(null);

  // Translations
  const tr = {
    title: lang === 'ar' ? 'التجار القريبون' : lang === 'fr' ? 'Commerçants proches' : 'Nearby Traders',
    subtitle: lang === 'ar' ? 'اعثر على أقرب تجار الذهب إليك' : lang === 'fr' ? 'Trouvez les bijoutiers les plus proches' : 'Find the nearest gold traders to you',
    noTraders: lang === 'ar' ? 'لا يوجد تجار قريبون' : lang === 'fr' ? 'Aucun commerçant trouvé' : 'No nearby traders found',
    noTradersDesc: lang === 'ar' ? 'لم يتم العثور على تجار ذهب في منطقتك حالياً' : lang === 'fr' ? 'Aucun bijoutier trouvé dans votre zone' : 'No gold traders found in your area currently',
    enableLocation: lang === 'ar' ? 'تفعيل الموقع' : lang === 'fr' ? 'Activer la localisation' : 'Enable Location',
    enableLocationDesc: lang === 'ar' ? 'فعّل خدمة الموقع لعرض التجار القريبين مرتبين حسب المسافة' : lang === 'fr' ? 'Activez la localisation pour voir les commerçants triés par distance' : 'Enable location to see traders sorted by distance',
    gettingLocation: lang === 'ar' ? 'جاري تحديد موقعك...' : lang === 'fr' ? 'Localisation en cours...' : 'Getting your location...',
    permissionDenied: lang === 'ar' ? 'تم رفض إذن الموقع' : lang === 'fr' ? 'Permission refusée' : 'Location permission denied',
    km: lang === 'ar' ? 'كم' : 'km',
    call: lang === 'ar' ? 'اتصال' : lang === 'fr' ? 'Appeler' : 'Call',
    whatsapp: lang === 'ar' ? 'واتساب' : 'WhatsApp',
    directions: lang === 'ar' ? 'الاتجاهات' : lang === 'fr' ? 'Itinéraire' : 'Directions',
    workingHours: lang === 'ar' ? 'ساعات العمل' : lang === 'fr' ? 'Heures d\'ouverture' : 'Working Hours',
    showAll: lang === 'ar' ? 'عرض الكل بدون موقع' : lang === 'fr' ? 'Afficher tout sans localisation' : 'Show All Without Location',
    tradersCount: lang === 'ar' ? 'تاجر' : lang === 'fr' ? 'commerçant(s)' : 'trader(s)',
    refreshing: lang === 'ar' ? 'جاري التحديث...' : lang === 'fr' ? 'Actualisation...' : 'Refreshing...',
    close: lang === 'ar' ? 'إغلاق' : lang === 'fr' ? 'Fermer' : 'Close',
  };

  // Get user location
  const getUserLocation = async () => {
    setGettingLoc(true);
    try {
      const Location = await import('expo-location');
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        setLocationGranted(false);
        setGettingLoc(false);
        return false;
      }
      setLocationGranted(true);
      const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      setUserLat(loc.coords.latitude);
      setUserLng(loc.coords.longitude);
      setGettingLoc(false);
      return true;
    } catch (e) {
      console.error('[NearbyTraders] Location error:', e);
      setGettingLoc(false);
      return false;
    }
  };

  // Fetch traders
  const fetchTraders = useCallback(async (lat?: number | null, lng?: number | null) => {
    try {
      let data: TraderLocationItem[];
      if (lat != null && lng != null) {
        data = await apiCall('location.nearbyTraders', 'GET', {
          latitude: lat,
          longitude: lng,
          radiusKm: 500,
        });
      } else {
        data = await apiCall('location.allTraders');
      }
      setTraders(data || []);
    } catch (e) {
      console.error('[NearbyTraders] Fetch error:', e);
      setTraders([]);
    }
  }, []);

  // Initial load
  useEffect(() => {
    (async () => {
      setLoading(true);
      const gotLoc = await getUserLocation();
      if (gotLoc) {
        // Will be fetched after state updates
      } else {
        await fetchTraders(null, null);
      }
      setLoading(false);
    })();
  }, []);

  // Fetch when user location changes
  useEffect(() => {
    if (userLat != null && userLng != null) {
      fetchTraders(userLat, userLng);
    }
  }, [userLat, userLng, fetchTraders]);

  // Refresh
  const handleRefresh = async () => {
    setRefreshing(true);
    await fetchTraders(userLat, userLng);
    setRefreshing(false);
  };

  // Show all without location
  const handleShowAll = async () => {
    setLoading(true);
    await fetchTraders(null, null);
    setLoading(false);
  };

  // Open directions
  const openDirections = (lat: string, lng: string, name: string) => {
    const url = Platform.select({
      ios: `maps:0,0?q=${encodeURIComponent(name)}@${lat},${lng}`,
      android: `geo:${lat},${lng}?q=${lat},${lng}(${encodeURIComponent(name)})`,
      default: `https://www.google.com/maps/search/?api=1&query=${lat},${lng}`,
    });
    if (url) Linking.openURL(url).catch(() => {});
  };

  // Call phone
  const callPhone = (phone: string) => {
    Linking.openURL(`tel:${phone}`).catch(() => {});
  };

  // Open WhatsApp
  const openWhatsApp = (number: string) => {
    const cleaned = number.replace(/[^0-9+]/g, '');
    Linking.openURL(`https://wa.me/${cleaned.replace('+', '')}`).catch(() => {});
  };

  const renderTraderCard = ({ item }: { item: TraderLocationItem }) => {
    const isSelected = selectedTrader?.id === item.id;

    return (
      <TouchableOpacity
        activeOpacity={0.8}
        onPress={() => setSelectedTrader(isSelected ? null : item)}
        style={[styles.traderCard, isSelected && styles.traderCardSelected]}
      >
        {/* Header */}
        <View style={[styles.traderCardHeader, { flexDirection: flexDir }]}>
          <View style={styles.traderIconContainer}>
            <MaterialIcons name="storefront" size={24} color="#C5A021" />
          </View>
          <View style={[styles.traderInfo, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
            <Text style={[styles.traderName, { textAlign, writingDirection: direction }]} numberOfLines={1}>
              {item.shopName}
            </Text>
            {item.traderName && (
              <Text style={[styles.traderOwner, { textAlign, writingDirection: direction }]} numberOfLines={1}>
                {item.traderName}
              </Text>
            )}
          </View>
          {item.distanceKm != null && (
            <View style={styles.distanceBadge}>
              <MaterialIcons name="near-me" size={12} color="#C5A021" />
              <Text style={styles.distanceText}>{item.distanceKm} {tr.km}</Text>
            </View>
          )}
        </View>

        {/* Address */}
        <View style={[styles.traderDetailRow, { flexDirection: flexDir }]}>
          <MaterialIcons name="location-on" size={16} color="#6C737F" />
          <Text style={[styles.traderDetailText, { textAlign, writingDirection: direction }]} numberOfLines={2}>
            {item.address}{item.city ? ` - ${item.city}` : ''}
          </Text>
        </View>

        {/* Working Hours */}
        {item.workingHours && (
          <View style={[styles.traderDetailRow, { flexDirection: flexDir }]}>
            <MaterialIcons name="schedule" size={16} color="#6C737F" />
            <Text style={[styles.traderDetailText, { textAlign, writingDirection: direction }]}>
              {item.workingHours}
            </Text>
          </View>
        )}

        {/* Expanded Actions */}
        {isSelected && (
          <View style={styles.traderActions}>
            {/* Directions */}
            <TouchableOpacity
              onPress={() => openDirections(item.latitude, item.longitude, item.shopName)}
              activeOpacity={0.7}
              style={[styles.actionBtn, styles.actionBtnDirections]}
            >
              <MaterialIcons name="directions" size={18} color="#3B82F6" />
              <Text style={[styles.actionBtnText, { color: '#3B82F6' }]}>{tr.directions}</Text>
            </TouchableOpacity>

            {/* Call */}
            {item.phone && (
              <TouchableOpacity
                onPress={() => callPhone(item.phone!)}
                activeOpacity={0.7}
                style={[styles.actionBtn, styles.actionBtnCall]}
              >
                <MaterialIcons name="phone" size={18} color="#22C55E" />
                <Text style={[styles.actionBtnText, { color: '#22C55E' }]}>{tr.call}</Text>
              </TouchableOpacity>
            )}

            {/* WhatsApp */}
            {item.whatsapp && (
              <TouchableOpacity
                onPress={() => openWhatsApp(item.whatsapp!)}
                activeOpacity={0.7}
                style={[styles.actionBtn, styles.actionBtnWhatsapp]}
              >
                <MaterialIcons name="chat" size={18} color="#25D366" />
                <Text style={[styles.actionBtnText, { color: '#25D366' }]}>{tr.whatsapp}</Text>
              </TouchableOpacity>
            )}
          </View>
        )}
      </TouchableOpacity>
    );
  };

  if (loading) {
    return (
      <View style={styles.screen}>
        <SafeAreaView style={styles.safeArea} edges={['top']}>
          <View style={[styles.header, { flexDirection: flexDir }]}>
            <TouchableOpacity onPress={onOpenDrawer} style={styles.menuButton}>
              <MaterialIcons name="menu" size={24} color="#C5A021" />
            </TouchableOpacity>
            <View style={[styles.headerTitleContainer, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
              <Text style={[styles.headerTitle, { textAlign, writingDirection: direction }]}>{tr.title}</Text>
            </View>
          </View>
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color="#C5A021" />
            {gettingLoc && (
              <Text style={styles.loadingText}>{tr.gettingLocation}</Text>
            )}
          </View>
        </SafeAreaView>
      </View>
    );
  }

  return (
    <View style={styles.screen}>
      <SafeAreaView style={styles.safeArea} edges={['top']}>
        {/* Header */}
        <View style={[styles.header, { flexDirection: flexDir }]}>
          <TouchableOpacity onPress={onOpenDrawer} style={styles.menuButton}>
            <MaterialIcons name="menu" size={24} color="#C5A021" />
          </TouchableOpacity>
          <View style={[styles.headerTitleContainer, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
            <Text style={[styles.headerTitle, { textAlign, writingDirection: direction }]}>{tr.title}</Text>
            <Text style={[styles.headerSubtitle, { textAlign, writingDirection: direction }]}>{tr.subtitle}</Text>
          </View>
        </View>

        {/* Location Status Bar */}
        {!locationGranted && !gettingLoc && (
          <View style={styles.locationBar}>
            <View style={[styles.locationBarContent, { flexDirection: flexDir }]}>
              <MaterialIcons name="location-off" size={18} color="#F59E0B" />
              <Text style={[styles.locationBarText, { textAlign, writingDirection: direction }]} numberOfLines={1}>
                {tr.enableLocationDesc}
              </Text>
              <TouchableOpacity onPress={getUserLocation} activeOpacity={0.7} style={styles.locationBarBtn}>
                <Text style={styles.locationBarBtnText}>{tr.enableLocation}</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}

        {/* Count Badge */}
        <View style={[styles.countBar, { flexDirection: flexDir }]}>
          <Text style={[styles.countText, { writingDirection: direction }]}>
            {traders.length} {tr.tradersCount}
          </Text>
          {!locationGranted && traders.length > 0 && (
            <TouchableOpacity onPress={handleShowAll} activeOpacity={0.7}>
              <Text style={styles.showAllText}>{tr.showAll}</Text>
            </TouchableOpacity>
          )}
        </View>

        {/* Traders List */}
        {traders.length === 0 ? (
          <View style={styles.emptyContainer}>
            <MaterialIcons name="store" size={64} color="rgba(197,160,33,0.2)" />
            <Text style={[styles.emptyTitle, { writingDirection: direction }]}>{tr.noTraders}</Text>
            <Text style={[styles.emptyDesc, { writingDirection: direction }]}>{tr.noTradersDesc}</Text>
          </View>
        ) : (
          <FlatList
            data={traders}
            renderItem={renderTraderCard}
            keyExtractor={(item) => String(item.id)}
            contentContainerStyle={styles.listContent}
            showsVerticalScrollIndicator={false}
            refreshControl={
              <RefreshControl
                refreshing={refreshing}
                onRefresh={handleRefresh}
                tintColor="#C5A021"
                colors={['#C5A021']}
              />
            }
          />
        )}
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#001F3F' },
  safeArea: { flex: 1 },
  header: {
    alignItems: 'center', paddingHorizontal: 16, paddingVertical: 12,
    borderBottomWidth: 1, borderBottomColor: 'rgba(197,160,33,0.15)',
  },
  menuButton: { padding: 8 },
  headerTitleContainer: { flex: 1, marginHorizontal: 12 },
  headerTitle: { fontSize: 18, fontWeight: '700', color: '#C5A021' },
  headerSubtitle: { fontSize: 12, color: '#F8F9FA', opacity: 0.6, marginTop: 2 },
  loadingContainer: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  loadingText: { fontSize: 14, color: '#6C737F', marginTop: 12 },

  // Location bar
  locationBar: {
    backgroundColor: 'rgba(245,158,11,0.08)',
    borderBottomWidth: 1, borderBottomColor: 'rgba(245,158,11,0.15)',
    paddingHorizontal: 16, paddingVertical: 10,
  },
  locationBarContent: { alignItems: 'center', gap: 8 },
  locationBarText: { flex: 1, fontSize: 12, color: '#F59E0B' },
  locationBarBtn: {
    backgroundColor: 'rgba(245,158,11,0.15)',
    paddingHorizontal: 12, paddingVertical: 6, borderRadius: 8,
  },
  locationBarBtnText: { fontSize: 12, fontWeight: '600', color: '#F59E0B' },

  // Count bar
  countBar: {
    paddingHorizontal: 16, paddingVertical: 10,
    alignItems: 'center', justifyContent: 'space-between',
  },
  countText: { fontSize: 13, fontWeight: '600', color: '#6C737F' },
  showAllText: { fontSize: 12, fontWeight: '600', color: '#C5A021' },

  // List
  listContent: { paddingHorizontal: 16, paddingBottom: 24 },

  // Trader Card
  traderCard: {
    backgroundColor: 'rgba(248,249,250,0.05)',
    borderRadius: 16, padding: 16, marginBottom: 12,
    borderWidth: 1, borderColor: 'rgba(248,249,250,0.08)',
  },
  traderCardSelected: {
    borderColor: 'rgba(197,160,33,0.3)',
    backgroundColor: 'rgba(197,160,33,0.05)',
  },
  traderCardHeader: { alignItems: 'center', marginBottom: 10 },
  traderIconContainer: {
    width: 44, height: 44, borderRadius: 12,
    backgroundColor: 'rgba(197,160,33,0.12)',
    alignItems: 'center', justifyContent: 'center',
  },
  traderInfo: { flex: 1, marginHorizontal: 12 },
  traderName: { fontSize: 16, fontWeight: '700', color: '#F8F9FA' },
  traderOwner: { fontSize: 12, color: '#6C737F', marginTop: 2 },
  distanceBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: 'rgba(197,160,33,0.12)',
    paddingHorizontal: 10, paddingVertical: 5, borderRadius: 20,
  },
  distanceText: { fontSize: 12, fontWeight: '700', color: '#C5A021' },

  // Detail rows
  traderDetailRow: {
    alignItems: 'flex-start', gap: 8, marginTop: 8,
    paddingHorizontal: 4,
  },
  traderDetailText: { flex: 1, fontSize: 13, color: '#9BA1A6', lineHeight: 18 },

  // Actions
  traderActions: {
    flexDirection: 'row', flexWrap: 'wrap', gap: 8,
    marginTop: 14, paddingTop: 14,
    borderTopWidth: 1, borderTopColor: 'rgba(248,249,250,0.06)',
  },
  actionBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    paddingHorizontal: 14, paddingVertical: 10, borderRadius: 10,
  },
  actionBtnDirections: { backgroundColor: 'rgba(59,130,246,0.1)' },
  actionBtnCall: { backgroundColor: 'rgba(34,197,94,0.1)' },
  actionBtnWhatsapp: { backgroundColor: 'rgba(37,211,102,0.1)' },
  actionBtnText: { fontSize: 13, fontWeight: '600' },

  // Empty
  emptyContainer: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 32 },
  emptyTitle: { fontSize: 18, fontWeight: '700', color: '#F8F9FA', marginTop: 16 },
  emptyDesc: { fontSize: 14, color: '#6C737F', marginTop: 8, textAlign: 'center', lineHeight: 22 },
});
