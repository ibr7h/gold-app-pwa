// This file is needed for Expo Router to recognize the (drawer) group.
// The actual layout is handled by _layout.tsx
export { default } from './home';
