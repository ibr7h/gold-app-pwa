import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, TextInput, Alert, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { useAuth } from '@/contexts/AuthContext';
import { useAppData } from '@/contexts/AppDataContext';
import { useApiKeys } from '@/contexts/ApiKeyContext';
import { GoldCard } from '@/components/gold/GoldCard';
import { GoldButton } from '@/components/gold/GoldButton';
import { useI18n } from '@/i18n';

interface AdminScreenProps {
  onOpenDrawer: () => void;
  onNavigate?: (screen: string) => void;
}

export default function AdminScreen({ onOpenDrawer, onNavigate }: AdminScreenProps) {
  const { user } = useAuth();
  const { refreshPrices, pricesLoading } = useAppData();
  const { keys: apiKeys, addKey, removeKey, toggleKey, testKey, getActiveKey } = useApiKeys();
  const activeKey = getActiveKey();
  const { t, isRTL, textAlign, direction, flexDir, lang } = useI18n();
  const [updateSuccess, setUpdateSuccess] = useState(false);
  const [newKeyValue, setNewKeyValue] = useState('');
  const [newKeyLabel, setNewKeyLabel] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [testingKeyId, setTestingKeyId] = useState<string | null>(null);

  // Translations
  const apiKeysTitle = lang === 'ar' ? 'مفاتيح API' : lang === 'fr' ? 'Clés API' : 'API Keys';
  const apiKeysDesc = lang === 'ar' ? 'إدارة مفاتيح GoldAPI.io للحصول على أسعار حية' : lang === 'fr' ? 'Gérer les clés GoldAPI.io pour les prix en direct' : 'Manage GoldAPI.io keys for live pricing';
  const addKeyLabel = lang === 'ar' ? 'إضافة مفتاح' : lang === 'fr' ? 'Ajouter une clé' : 'Add Key';
  const keyNamePlaceholder = lang === 'ar' ? 'اسم المفتاح (اختياري)' : lang === 'fr' ? 'Nom de la clé (optionnel)' : 'Key name (optional)';
  const keyValuePlaceholder = lang === 'ar' ? 'أدخل مفتاح API' : lang === 'fr' ? 'Entrez la clé API' : 'Enter API key';
  const saveLabel = lang === 'ar' ? 'حفظ' : lang === 'fr' ? 'Enregistrer' : 'Save';
  const cancelLabel = lang === 'ar' ? 'إلغاء' : lang === 'fr' ? 'Annuler' : 'Cancel';
  const testLabel = lang === 'ar' ? 'اختبار' : lang === 'fr' ? 'Tester' : 'Test';
  const removeLabel = lang === 'ar' ? 'حذف' : lang === 'fr' ? 'Supprimer' : 'Remove';
  const enableLabel = lang === 'ar' ? 'تفعيل' : lang === 'fr' ? 'Activer' : 'Enable';
  const disableLabel = lang === 'ar' ? 'تعطيل' : lang === 'fr' ? 'Désactiver' : 'Disable';
  const activeLabel = lang === 'ar' ? 'نشط' : lang === 'fr' ? 'Actif' : 'Active';
  const disabledLabel = lang === 'ar' ? 'معطل' : lang === 'fr' ? 'Désactivé' : 'Disabled';
  const quotaExceeded = lang === 'ar' ? 'تجاوز الحد' : lang === 'fr' ? 'Quota dépassé' : 'Quota Exceeded';
  const invalidLabel = lang === 'ar' ? 'غير صالح' : lang === 'fr' ? 'Invalide' : 'Invalid';
  const readyLabel = lang === 'ar' ? 'جاهز' : lang === 'fr' ? 'Prêt' : 'Ready';
  const noKeysMsg = lang === 'ar' ? 'لا توجد مفاتيح API. أضف مفتاحاً للحصول على أسعار حية.' : lang === 'fr' ? 'Aucune clé API. Ajoutez une clé pour les prix en direct.' : 'No API keys. Add a key for live pricing.';

  const handleUpdatePrices = async () => {
    await refreshPrices();
    setUpdateSuccess(true);
    setTimeout(() => setUpdateSuccess(false), 3000);
  };

  const handleAddKey = () => {
    if (!newKeyValue.trim()) return;
    addKey(newKeyValue.trim(), newKeyLabel.trim() || 'API Key');
    setNewKeyValue('');
    setNewKeyLabel('');
    setShowAddForm(false);
  };

  const handleTestKey = async (keyId: string, keyValue: string) => {
    setTestingKeyId(keyId);
    const result = await testKey(keyValue);
    setTestingKeyId(null);
    const success = result.valid;
    if (Platform.OS !== 'web') {
      Alert.alert('', success ? (lang === 'ar' ? 'المفتاح يعمل بنجاح' : lang === 'fr' ? 'La clé fonctionne' : 'Key works successfully') : (lang === 'ar' ? 'المفتاح لا يعمل' : lang === 'fr' ? 'La clé ne fonctionne pas' : 'Key is not working'));
    }
  };

  const handleRemoveKey = (keyId: string) => {
    if (Platform.OS !== 'web') {
      Alert.alert(
        removeLabel,
        lang === 'ar' ? 'هل تريد حذف هذا المفتاح؟' : lang === 'fr' ? 'Voulez-vous supprimer cette clé ?' : 'Remove this key?',
        [
          { text: cancelLabel, style: 'cancel' },
          { text: removeLabel, style: 'destructive', onPress: () => removeKey(keyId) },
        ]
      );
    } else {
      removeKey(keyId);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return '#22C55E';
      case 'quota_exceeded': return '#F59E0B';
      case 'invalid': return '#EF4444';
      case 'disabled': return '#6C737F';
      default: return '#6C737F';
    }
  };

  const getStatusLabel = (status: string, enabled: boolean) => {
    if (!enabled) return disabledLabel;
    switch (status) {
      case 'active': return readyLabel;
      case 'quota_exceeded': return quotaExceeded;
      case 'invalid': return invalidLabel;
      default: return readyLabel;
    }
  };

  if (user?.role !== 'admin') {
    return (
      <View style={styles.screen}>
        <SafeAreaView style={styles.safeArea} edges={['top']}>
          <View style={styles.appBar}>
            <View style={{ width: 40 }} />
            <Text style={[styles.appBarTitle, { writingDirection: direction }]}>{t.admin.title}</Text>
            <TouchableOpacity onPress={onOpenDrawer} style={styles.menuBtn} activeOpacity={0.7}>
              <MaterialIcons name="menu" size={24} color="#F8F9FA" />
            </TouchableOpacity>
          </View>
          <View style={styles.accessDenied}>
            <MaterialIcons name="lock" size={48} color="#6C737F" />
            <Text style={[styles.accessDeniedText, { writingDirection: direction }]}>{t.admin.accessDenied}</Text>
          </View>
        </SafeAreaView>
      </View>
    );
  }

  return (
    <View style={styles.screen}>
      <SafeAreaView style={styles.safeArea} edges={['top']}>
        <View style={styles.appBar}>
          <View style={{ width: 40 }} />
          <Text style={[styles.appBarTitle, { writingDirection: direction }]}>{t.admin.title}</Text>
          <TouchableOpacity onPress={onOpenDrawer} style={styles.menuBtn} activeOpacity={0.7}>
            <MaterialIcons name="menu" size={24} color="#F8F9FA" />
          </TouchableOpacity>
        </View>

        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
          {/* Admin Info Card */}
          <GoldCard style={styles.adminInfoCard}>
            <View style={[styles.adminInfoRow, { flexDirection: flexDir }]}>
              <View style={[styles.adminInfoContent, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
                <Text style={[styles.adminInfoTitle, { writingDirection: direction }]}>{t.admin.adminPanel}</Text>
                <Text style={[styles.adminInfoDesc, { textAlign, writingDirection: direction }]}>{t.admin.adminDesc}</Text>
              </View>
              <View style={[styles.adminIcon, isRTL ? { marginLeft: 14 } : { marginRight: 14 }]}>
                <MaterialIcons name="admin-panel-settings" size={32} color="#C5A021" />
              </View>
            </View>
          </GoldCard>

          {/* API Keys Management */}
          <GoldCard>
            <View style={[styles.apiKeysHeader, { flexDirection: flexDir }]}>
              <TouchableOpacity
                onPress={() => setShowAddForm(!showAddForm)}
                style={styles.addKeyBtn}
                activeOpacity={0.7}
              >
                <MaterialIcons name={showAddForm ? 'close' : 'add'} size={20} color="#C5A021" />
              </TouchableOpacity>
              <View style={[styles.apiKeysTitleRow, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
                <Text style={[styles.apiKeysTitle, { writingDirection: direction }]}>{apiKeysTitle}</Text>
                <Text style={[styles.apiKeysDesc, { writingDirection: direction }]}>{apiKeysDesc}</Text>
              </View>
            </View>

            {/* Add Key Form */}
            {showAddForm && (
              <View style={styles.addKeyForm}>
                <TextInput
                  style={[styles.keyInput, { textAlign: isRTL ? 'right' : 'left', writingDirection: direction }]}
                  placeholder={keyNamePlaceholder}
                  placeholderTextColor="#6C737F"
                  value={newKeyLabel}
                  onChangeText={setNewKeyLabel}
                />
                <TextInput
                  style={[styles.keyInput, { textAlign: isRTL ? 'right' : 'left' }]}
                  placeholder={keyValuePlaceholder}
                  placeholderTextColor="#6C737F"
                  value={newKeyValue}
                  onChangeText={setNewKeyValue}
                  autoCapitalize="none"
                  autoCorrect={false}
                />
                <View style={[styles.addKeyActions, { flexDirection: flexDir }]}>
                  <TouchableOpacity onPress={() => setShowAddForm(false)} style={styles.cancelBtn} activeOpacity={0.7}>
                    <Text style={styles.cancelBtnText}>{cancelLabel}</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={handleAddKey}
                    style={[styles.saveBtn, !newKeyValue.trim() && styles.saveBtnDisabled]}
                    activeOpacity={0.7}
                    disabled={!newKeyValue.trim()}
                  >
                    <Text style={styles.saveBtnText}>{saveLabel}</Text>
                  </TouchableOpacity>
                </View>
              </View>
            )}

            {/* Keys List */}
            {apiKeys.length === 0 ? (
              <View style={styles.noKeysContainer}>
                <MaterialIcons name="vpn-key" size={32} color="#6C737F" />
                <Text style={[styles.noKeysText, { writingDirection: direction }]}>{noKeysMsg}</Text>
              </View>
            ) : (
              apiKeys.map((apiKey: typeof apiKeys[number], index: number) => {
                const isActive = activeKey ? apiKey.id === activeKey.id : false;
                return (
                  <View key={apiKey.id} style={[styles.keyCard, index > 0 && styles.keyCardBorder]}>
                    <View style={[styles.keyHeader, { flexDirection: flexDir }]}>
                      <View style={[styles.keyStatusBadge, { backgroundColor: getStatusColor(apiKey.enabled ? apiKey.status : 'disabled') + '20' }]}>
                        <View style={[styles.keyStatusDot, { backgroundColor: getStatusColor(apiKey.enabled ? apiKey.status : 'disabled') }]} />
                        <Text style={[styles.keyStatusText, { color: getStatusColor(apiKey.enabled ? apiKey.status : 'disabled') }]}>
                          {getStatusLabel(apiKey.status, apiKey.enabled)}
                        </Text>
                        {isActive && apiKey.enabled && (
                          <Text style={styles.activeIndicator}> ({activeLabel})</Text>
                        )}
                      </View>
                      <View style={[styles.keyInfo, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
                        <Text style={[styles.keyLabel, { writingDirection: direction }]}>{apiKey.label || 'API Key'}</Text>
                        <Text style={styles.keyValue}>{apiKey.key.substring(0, 12)}...{apiKey.key.slice(-4)}</Text>
                      </View>
                    </View>
                    {apiKey.lastUsed && (
                      <Text style={[styles.keyLastUsed, { textAlign }]}>
                        {lang === 'ar' ? 'آخر استخدام: ' : lang === 'fr' ? 'Dernière utilisation: ' : 'Last used: '}
                        {new Date(apiKey.lastUsed).toLocaleString(isRTL ? 'ar' : 'en')}
                      </Text>
                    )}
                    {apiKey.requestCount > 0 && (
                      <Text style={[styles.keyRequestCount, { textAlign }]}>
                        {lang === 'ar' ? `${apiKey.requestCount} طلب` : lang === 'fr' ? `${apiKey.requestCount} requêtes` : `${apiKey.requestCount} requests`}
                      </Text>
                    )}
                    <View style={[styles.keyActions, { flexDirection: flexDir }]}>
                      <TouchableOpacity onPress={() => handleRemoveKey(apiKey.id)} style={styles.keyActionBtn} activeOpacity={0.7}>
                        <MaterialIcons name="delete-outline" size={16} color="#EF4444" />
                        <Text style={[styles.keyActionText, { color: '#EF4444' }]}>{removeLabel}</Text>
                      </TouchableOpacity>
                      <TouchableOpacity
                        onPress={() => handleTestKey(apiKey.id, apiKey.key)}
                        style={styles.keyActionBtn}
                        activeOpacity={0.7}
                        disabled={testingKeyId === apiKey.id}
                      >
                        <MaterialIcons name="speed" size={16} color="#3B82F6" />
                        <Text style={[styles.keyActionText, { color: '#3B82F6' }]}>
                          {testingKeyId === apiKey.id ? '...' : testLabel}
                        </Text>
                      </TouchableOpacity>
                      <TouchableOpacity onPress={() => toggleKey(apiKey.id)} style={styles.keyActionBtn} activeOpacity={0.7}>
                        <MaterialIcons name={apiKey.enabled ? 'pause-circle-outline' : 'play-circle-outline'} size={16} color={apiKey.enabled ? '#F59E0B' : '#22C55E'} />
                        <Text style={[styles.keyActionText, { color: apiKey.enabled ? '#F59E0B' : '#22C55E' }]}>
                          {apiKey.enabled ? disableLabel : enableLabel}
                        </Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                );
              })
            )}
          </GoldCard>

          {/* User Management */}
          <GoldCard>
            <View style={[styles.adminInfoRow, { flexDirection: flexDir }]}>
              <View style={[styles.adminInfoContent, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
                <Text style={[styles.adminInfoTitle, { writingDirection: direction }]}>
                  {lang === 'ar' ? 'إدارة المستخدمين' : lang === 'fr' ? 'Gestion des utilisateurs' : 'User Management'}
                </Text>
                <Text style={[styles.adminInfoDesc, { textAlign, writingDirection: direction }]}>
                  {lang === 'ar' ? 'عرض وإدارة حسابات المستخدمين والتجار' : lang === 'fr' ? 'Gérer les comptes des utilisateurs et commerçants' : 'View and manage user and trader accounts'}
                </Text>
              </View>
              <View style={[styles.adminIcon, isRTL ? { marginLeft: 14 } : { marginRight: 14 }]}>
                <MaterialIcons name="people" size={32} color="#C5A021" />
              </View>
            </View>
            <GoldButton
              title={lang === 'ar' ? 'إدارة المستخدمين' : lang === 'fr' ? 'Gérer les utilisateurs' : 'Manage Users'}
              onPress={() => onNavigate?.('admin-users')}
              style={{ marginTop: 12 }}
            />
          </GoldCard>

          {/* Invite Codes Management */}
          <GoldCard>
            <View style={[styles.adminInfoRow, { flexDirection: flexDir }]}>
              <View style={[styles.adminInfoContent, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
                <Text style={[styles.adminInfoTitle, { writingDirection: direction }]}>
                  {lang === 'ar' ? 'أكواد الدعوة' : lang === 'fr' ? 'Codes d\'invitation' : 'Invite Codes'}
                </Text>
                <Text style={[styles.adminInfoDesc, { textAlign, writingDirection: direction }]}>
                  {lang === 'ar' ? 'إنشاء وإدارة أكواد دعوة التجار' : lang === 'fr' ? 'Créer et gérer les codes d\'invitation des commerçants' : 'Create and manage trader invite codes'}
                </Text>
              </View>
              <View style={[styles.adminIcon, isRTL ? { marginLeft: 14 } : { marginRight: 14 }]}>
                <MaterialIcons name="vpn-key" size={32} color="#C5A021" />
              </View>
            </View>
            <GoldButton
              title={lang === 'ar' ? 'إدارة الأكواد' : lang === 'fr' ? 'Gérer les codes' : 'Manage Codes'}
              onPress={() => onNavigate?.('admin-invites')}
              style={{ marginTop: 12 }}
            />
          </GoldCard>

          {/* Trader Permissions Management */}
          <GoldCard>
            <View style={[styles.adminInfoRow, { flexDirection: flexDir }]}>
              <View style={[styles.adminInfoContent, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
                <Text style={[styles.adminInfoTitle, { writingDirection: direction }]}>
                  {t.permissions.managePermissions}
                </Text>
                <Text style={[styles.adminInfoDesc, { textAlign, writingDirection: direction }]}>
                  {t.permissions.managePermissionsDesc}
                </Text>
              </View>
              <View style={[styles.adminIcon, isRTL ? { marginLeft: 14 } : { marginRight: 14 }]}>
                <MaterialIcons name="security" size={32} color="#C5A021" />
              </View>
            </View>
            <GoldButton
              title={t.permissions.managePermissions}
              onPress={() => onNavigate?.('admin-permissions')}
              style={{ marginTop: 12 }}
            />
          </GoldCard>

          {/* Advanced Statistics */}
          <GoldCard>
            <View style={[styles.adminInfoRow, { flexDirection: flexDir }]}>
              <View style={[styles.adminInfoContent, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
                <Text style={[styles.adminInfoTitle, { writingDirection: direction }]}>
                  {lang === 'ar' ? 'الإحصائيات المتقدمة' : lang === 'fr' ? 'Statistiques avancées' : 'Advanced Statistics'}
                </Text>
                <Text style={[styles.adminInfoDesc, { textAlign, writingDirection: direction }]}>
                  {lang === 'ar' ? 'عرض إحصائيات النظام والمبيعات ونمو المستخدمين' : lang === 'fr' ? 'Voir les statistiques système, ventes et croissance' : 'View system stats, sales and user growth'}
                </Text>
              </View>
              <View style={[styles.adminIcon, isRTL ? { marginLeft: 12 } : { marginRight: 12 }]}>
                <MaterialIcons name="analytics" size={28} color="#C5A021" />
              </View>
            </View>
            <GoldButton
              title={lang === 'ar' ? 'عرض الإحصائيات' : lang === 'fr' ? 'Voir les statistiques' : 'View Statistics'}
              onPress={() => onNavigate?.('admin-stats')}
              style={{ marginTop: 12 }}
            />
          </GoldCard>

          {/* Update Prices */}
          <GoldCard title={t.admin.updatePrices}>
            <Text style={[styles.cardDesc, { textAlign, writingDirection: direction }]}>{t.admin.updatePricesDesc}</Text>
            {updateSuccess && (
              <View style={[styles.successBanner, { flexDirection: flexDir }]}>
                <Text style={[styles.successText, { writingDirection: direction }, isRTL ? { marginLeft: 6 } : { marginRight: 6 }]}>{t.admin.pricesUpdated}</Text>
                <MaterialIcons name="check-circle" size={16} color="#22C55E" />
              </View>
            )}
            <GoldButton title={t.admin.updatePricesNow} onPress={handleUpdatePrices} loading={pricesLoading} style={{ marginTop: 12 }} />
          </GoldCard>

          {/* System Stats */}
          <GoldCard title={t.admin.systemStats}>
            <View style={[styles.statRow, { flexDirection: flexDir }]}>
              <Text style={styles.statValue}>{apiKeys.filter((k: typeof apiKeys[number]) => k.enabled).length}/{apiKeys.length}</Text>
              <Text style={[styles.statLabel, { writingDirection: direction }]}>{apiKeysTitle}</Text>
            </View>
            <View style={[styles.statRow, styles.statBorder, { flexDirection: flexDir }]}>
              <Text style={styles.statValue}>5</Text>
              <Text style={[styles.statLabel, { writingDirection: direction }]}>{t.admin.karatCount}</Text>
            </View>
            <View style={[styles.statRow, styles.statBorder, { flexDirection: flexDir }]}>
              <Text style={styles.statValue}>3</Text>
              <Text style={[styles.statLabel, { writingDirection: direction }]}>{t.admin.portfolioCount}</Text>
            </View>
            <View style={[styles.statRow, styles.statBorder, { flexDirection: flexDir }]}>
              <Text style={styles.statValue}>5</Text>
              <Text style={[styles.statLabel, { writingDirection: direction }]}>{t.admin.purchaseCount}</Text>
            </View>
            <View style={[styles.statRow, styles.statBorder, { flexDirection: flexDir }]}>
              <Text style={styles.statValue}>3</Text>
              <Text style={[styles.statLabel, { writingDirection: direction }]}>{t.admin.alertCount}</Text>
            </View>
          </GoldCard>

          {/* App Info */}
          <GoldCard title={t.admin.appInfo}>
            <View style={[styles.statRow, { flexDirection: flexDir }]}>
              <Text style={styles.statValue}>1.0.0</Text>
              <Text style={[styles.statLabel, { writingDirection: direction }]}>{t.admin.version}</Text>
            </View>
            <View style={[styles.statRow, styles.statBorder, { flexDirection: flexDir }]}>
              <Text style={styles.statValue}>Expo SDK 54</Text>
              <Text style={[styles.statLabel, { writingDirection: direction }]}>{t.admin.platform}</Text>
            </View>
            <View style={[styles.statRow, styles.statBorder, { flexDirection: flexDir }]}>
              <Text style={styles.statValue}>{isRTL ? 'RTL' : 'LTR'}</Text>
              <Text style={[styles.statLabel, { writingDirection: direction }]}>{t.admin.direction}</Text>
            </View>
          </GoldCard>

          <View style={{ height: 32 }} />
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#001F3F' },
  safeArea: { flex: 1 },
  appBar: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: 'rgba(248,249,250,0.08)',
  },
  appBarTitle: { fontSize: 18, fontWeight: '700', color: '#F8F9FA' },
  menuBtn: { padding: 8 },
  scrollContent: { paddingHorizontal: 16, paddingTop: 16 },
  accessDenied: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  accessDeniedText: { fontSize: 16, color: '#6C737F', marginTop: 16 },
  adminInfoCard: { marginBottom: 16, borderWidth: 1, borderColor: 'rgba(197,160,33,0.2)' },
  adminInfoRow: { alignItems: 'center' },
  adminIcon: {
    width: 56, height: 56, borderRadius: 14,
    backgroundColor: 'rgba(197,160,33,0.12)', alignItems: 'center', justifyContent: 'center',
  },
  adminInfoContent: { flex: 1 },
  adminInfoTitle: { fontSize: 17, fontWeight: '700', color: '#1A1A1B' },
  adminInfoDesc: { fontSize: 13, color: '#6C737F', marginTop: 4 },
  // API Keys
  apiKeysHeader: { alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 16 },
  apiKeysTitleRow: {},
  apiKeysTitle: { fontSize: 16, fontWeight: '700', color: '#1A1A1B' },
  apiKeysDesc: { fontSize: 12, color: '#6C737F', marginTop: 2 },
  addKeyBtn: {
    width: 36, height: 36, borderRadius: 10,
    backgroundColor: 'rgba(197,160,33,0.12)', alignItems: 'center', justifyContent: 'center',
  },
  // Add Form
  addKeyForm: { backgroundColor: 'rgba(0,31,63,0.04)', borderRadius: 10, padding: 14, marginBottom: 16, borderWidth: 1, borderColor: '#E6E8EA' },
  keyInput: {
    backgroundColor: '#FFFFFF', borderRadius: 8, paddingHorizontal: 14, paddingVertical: 10,
    fontSize: 14, color: '#1A1A1B', borderWidth: 1, borderColor: '#E6E8EA', marginBottom: 8,
  },
  addKeyActions: { justifyContent: 'flex-end', gap: 8, marginTop: 4 },
  cancelBtn: { paddingHorizontal: 16, paddingVertical: 8, borderRadius: 8 },
  cancelBtnText: { fontSize: 13, color: '#6C737F', fontWeight: '500' },
  saveBtn: { backgroundColor: '#C5A021', paddingHorizontal: 20, paddingVertical: 8, borderRadius: 8 },
  saveBtnDisabled: { opacity: 0.4 },
  saveBtnText: { fontSize: 13, color: '#FFFFFF', fontWeight: '600' },
  // No Keys
  noKeysContainer: { alignItems: 'center', paddingVertical: 24 },
  noKeysText: { fontSize: 13, color: '#6C737F', marginTop: 8, textAlign: 'center' },
  // Key Card
  keyCard: { paddingVertical: 14 },
  keyCardBorder: { borderTopWidth: 1, borderTopColor: '#E6E8EA' },
  keyHeader: { alignItems: 'center', justifyContent: 'space-between' },
  keyInfo: {},
  keyLabel: { fontSize: 14, fontWeight: '600', color: '#1A1A1B' },
  keyValue: { fontSize: 12, color: '#6C737F', marginTop: 2, fontFamily: Platform.OS === 'web' ? 'monospace' : undefined },
  keyStatusBadge: { flexDirection: 'row', alignItems: 'center', borderRadius: 8, paddingHorizontal: 8, paddingVertical: 4 },
  keyStatusDot: { width: 6, height: 6, borderRadius: 3, marginRight: 6 },
  keyStatusText: { fontSize: 11, fontWeight: '600' },
  activeIndicator: { fontSize: 10, color: '#22C55E', fontWeight: '700' },
  keyLastUsed: { fontSize: 11, color: '#6C737F', marginTop: 6 },
  keyRequestCount: { fontSize: 11, color: '#6C737F', marginTop: 2 },
  keyActions: { marginTop: 10, gap: 12 },
  keyActionBtn: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingVertical: 4 },
  keyActionText: { fontSize: 12, fontWeight: '500' },
  // Update Prices
  cardDesc: { fontSize: 13, color: '#6C737F', marginBottom: 4 },
  successBanner: {
    alignItems: 'center', justifyContent: 'center',
    backgroundColor: 'rgba(34,197,94,0.12)', borderRadius: 8, paddingVertical: 8, paddingHorizontal: 12, marginTop: 10,
  },
  successText: { fontSize: 13, color: '#22C55E' },
  statRow: { justifyContent: 'space-between', alignItems: 'center', paddingVertical: 12 },
  statBorder: { borderTopWidth: 1, borderTopColor: '#E6E8EA' },
  statLabel: { fontSize: 14, color: '#6C737F' },
  statValue: { fontSize: 14, fontWeight: '600', color: '#1A1A1B' },
});
