import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Alert, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { GoldCard } from '@/components/gold/GoldCard';
import { GoldButton } from '@/components/gold/GoldButton';
import { GoldInput } from '@/components/gold/GoldInput';
import { useAuth } from '@/contexts/AuthContext';
import { useI18n } from '@/i18n';

interface ProfileScreenProps {
  onOpenDrawer: () => void;
}

export default function ProfileScreen({ onOpenDrawer }: ProfileScreenProps) {
  const { t, isRTL, textAlign, direction, flexDir, lang } = useI18n();
  const { user, isLoading, error, clearError, updateName, changePassword } = useAuth();

  // Name editing state
  const [isEditingName, setIsEditingName] = useState(false);
  const [nameValue, setNameValue] = useState(user?.name || '');
  const [nameError, setNameError] = useState('');
  const [nameSuccess, setNameSuccess] = useState(false);

  // Password change state
  const [showPasswordForm, setShowPasswordForm] = useState(false);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [passwordSuccess, setPasswordSuccess] = useState(false);

  // Sync name when user changes
  useEffect(() => {
    if (user?.name) {
      setNameValue(user.name);
    }
  }, [user?.name]);

  // Get user display name
  const displayName = user?.name || user?.email?.split('@')[0] || '';
  const roleLabel = user?.role === 'admin'
    ? (lang === 'ar' ? 'مسؤول' : lang === 'fr' ? 'Administrateur' : 'Admin')
    : (lang === 'ar' ? 'مستخدم' : lang === 'fr' ? 'Utilisateur' : 'User');

  // Handle save name
  const handleSaveName = async () => {
    setNameError('');
    setNameSuccess(false);
    clearError();

    if (!nameValue.trim()) {
      setNameError(t.profile.errorNameRequired);
      return;
    }

    const success = await updateName(nameValue.trim());
    if (success) {
      setIsEditingName(false);
      setNameSuccess(true);
      setTimeout(() => setNameSuccess(false), 3000);
    }
  };

  // Handle change password
  const handleChangePassword = async () => {
    setPasswordError('');
    setPasswordSuccess(false);
    clearError();

    if (!currentPassword.trim()) {
      setPasswordError(t.profile.errorCurrentPasswordRequired);
      return;
    }
    if (!newPassword.trim()) {
      setPasswordError(t.profile.errorNewPasswordRequired);
      return;
    }
    if (newPassword.length < 6) {
      setPasswordError(t.profile.errorNewPasswordTooShort);
      return;
    }
    if (newPassword !== confirmNewPassword) {
      setPasswordError(t.profile.errorPasswordMismatch);
      return;
    }
    if (newPassword === currentPassword) {
      setPasswordError(t.profile.errorSamePassword);
      return;
    }

    const success = await changePassword(currentPassword, newPassword);
    if (success) {
      setPasswordSuccess(true);
      setCurrentPassword('');
      setNewPassword('');
      setConfirmNewPassword('');
      setShowPasswordForm(false);
      setTimeout(() => setPasswordSuccess(false), 3000);
    } else if (error === 'wrong_password') {
      setPasswordError(t.profile.errorCurrentPasswordWrong);
    }
  };

  // Map auth error to translated message for password
  useEffect(() => {
    if (error === 'wrong_password') {
      setPasswordError(t.profile.errorCurrentPasswordWrong);
    }
  }, [error, t]);

  return (
    <View style={styles.screen}>
      <SafeAreaView style={styles.safeArea} edges={['top']}>
        {/* App Bar */}
        <View style={styles.appBar}>
          <View style={{ width: 40 }} />
          <Text style={[styles.appBarTitle, { writingDirection: direction }]}>{t.profile.title}</Text>
          <TouchableOpacity onPress={onOpenDrawer} style={styles.menuBtn} activeOpacity={0.7}>
            <MaterialIcons name="menu" size={24} color="#F8F9FA" />
          </TouchableOpacity>
        </View>

        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
          {/* Avatar Section */}
          <View style={styles.avatarSection}>
            <View style={styles.avatarCircle}>
              <Text style={styles.avatarText}>
                {(user?.name || user?.email || 'U').charAt(0).toUpperCase()}
              </Text>
            </View>
            <Text style={[styles.displayName, { writingDirection: direction }]}>
              {displayName}
            </Text>
            <Text style={[styles.emailText, { writingDirection: direction }]}>
              {user?.email}
            </Text>
            <View style={styles.roleBadge}>
              <Text style={[styles.roleText, { writingDirection: direction }]}>{roleLabel}</Text>
            </View>
          </View>

          {/* Personal Info Card */}
          <GoldCard title={t.profile.personalInfo}>
            {/* Email (read-only) */}
            <View style={[styles.infoRow, { flexDirection: flexDir }]}>
              <Text style={[styles.infoValue, { writingDirection: direction }]} numberOfLines={1}>
                {user?.email}
              </Text>
              <View style={[styles.infoLabel, { flexDirection: flexDir }]}>
                <Text style={[styles.infoLabelText, { writingDirection: direction }]}>{t.profile.email}</Text>
                <MaterialIcons name="email" size={18} color="#C5A021" style={isRTL ? { marginLeft: 8 } : { marginRight: 8 }} />
              </View>
            </View>

            <View style={styles.divider} />

            {/* Role (read-only) */}
            <View style={[styles.infoRow, { flexDirection: flexDir }]}>
              <Text style={[styles.infoValue, { writingDirection: direction }]}>
                {roleLabel}
              </Text>
              <View style={[styles.infoLabel, { flexDirection: flexDir }]}>
                <Text style={[styles.infoLabelText, { writingDirection: direction }]}>{t.profile.role}</Text>
                <MaterialIcons name="badge" size={18} color="#C5A021" style={isRTL ? { marginLeft: 8 } : { marginRight: 8 }} />
              </View>
            </View>

            <View style={styles.divider} />

            {/* Name (editable) */}
            <View style={[styles.infoRow, { flexDirection: flexDir }]}>
              {!isEditingName ? (
                <TouchableOpacity
                  onPress={() => { setIsEditingName(true); setNameSuccess(false); }}
                  style={[styles.editBtn, { flexDirection: flexDir }]}
                  activeOpacity={0.7}
                >
                  <MaterialIcons name="edit" size={16} color="#C5A021" />
                  <Text style={styles.editBtnText}>{t.profile.editName}</Text>
                </TouchableOpacity>
              ) : (
                <View style={{ width: 24 }} />
              )}
              <View style={[styles.infoLabel, { flexDirection: flexDir }]}>
                <Text style={[styles.infoLabelText, { writingDirection: direction }]}>{t.profile.name}</Text>
                <MaterialIcons name="person" size={18} color="#C5A021" style={isRTL ? { marginLeft: 8 } : { marginRight: 8 }} />
              </View>
            </View>

            {!isEditingName ? (
              <Text style={[styles.nameDisplay, { textAlign, writingDirection: direction }]}>
                {displayName || '—'}
              </Text>
            ) : (
              <View style={styles.editNameSection}>
                <GoldInput
                  label=""
                  placeholder={t.profile.namePlaceholder}
                  value={nameValue}
                  onChangeText={(val) => { setNameValue(val); setNameError(''); clearError(); }}
                  autoCapitalize="words"
                  returnKeyType="done"
                  onSubmitEditing={handleSaveName}
                />
                {!!nameError && (
                  <Text style={styles.errorText}>{nameError}</Text>
                )}
                <View style={[styles.editActions, { flexDirection: flexDir }]}>
                  <GoldButton
                    title={isLoading ? t.profile.saving : t.profile.saveName}
                    onPress={handleSaveName}
                    loading={isLoading}
                    disabled={isLoading}
                    style={{ flex: 1 }}
                  />
                  <GoldButton
                    title={t.cancel}
                    onPress={() => { setIsEditingName(false); setNameValue(user?.name || ''); setNameError(''); }}
                    variant="outline"
                    style={{ flex: 1 }}
                  />
                </View>
              </View>
            )}

            {nameSuccess && (
              <View style={styles.successBanner}>
                <MaterialIcons name="check-circle" size={16} color="#22C55E" />
                <Text style={styles.successText}>{t.profile.nameSaved}</Text>
              </View>
            )}
          </GoldCard>

          {/* Change Password Card */}
          <GoldCard>
            <TouchableOpacity
              onPress={() => {
                setShowPasswordForm(!showPasswordForm);
                setPasswordError('');
                setPasswordSuccess(false);
                clearError();
                if (!showPasswordForm) {
                  setCurrentPassword('');
                  setNewPassword('');
                  setConfirmNewPassword('');
                }
              }}
              style={[styles.passwordHeader, { flexDirection: flexDir }]}
              activeOpacity={0.7}
            >
              <MaterialIcons
                name={showPasswordForm ? 'expand-less' : 'expand-more'}
                size={24}
                color="#6C737F"
              />
              <View style={[styles.passwordHeaderContent, { flexDirection: flexDir }]}>
                <Text style={[styles.passwordHeaderText, { writingDirection: direction }]}>
                  {t.profile.changePassword}
                </Text>
                <MaterialIcons name="lock" size={20} color="#C5A021" style={isRTL ? { marginLeft: 8 } : { marginRight: 8 }} />
              </View>
            </TouchableOpacity>

            {passwordSuccess && (
              <View style={styles.successBanner}>
                <MaterialIcons name="check-circle" size={16} color="#22C55E" />
                <Text style={styles.successText}>{t.profile.passwordChanged}</Text>
              </View>
            )}

            {showPasswordForm && (
              <View style={styles.passwordForm}>
                <GoldInput
                  label={t.profile.currentPassword}
                  placeholder={t.profile.currentPasswordPlaceholder}
                  value={currentPassword}
                  onChangeText={(val) => { setCurrentPassword(val); setPasswordError(''); clearError(); }}
                  secureTextEntry
                  returnKeyType="next"
                />

                <GoldInput
                  label={t.profile.newPassword}
                  placeholder={t.profile.newPasswordPlaceholder}
                  value={newPassword}
                  onChangeText={(val) => { setNewPassword(val); setPasswordError(''); clearError(); }}
                  secureTextEntry
                  returnKeyType="next"
                />

                <GoldInput
                  label={t.profile.confirmNewPassword}
                  placeholder={t.profile.confirmNewPasswordPlaceholder}
                  value={confirmNewPassword}
                  onChangeText={(val) => { setConfirmNewPassword(val); setPasswordError(''); clearError(); }}
                  secureTextEntry
                  returnKeyType="done"
                  onSubmitEditing={handleChangePassword}
                />

                {!!passwordError && (
                  <Text style={styles.errorText}>{passwordError}</Text>
                )}

                <GoldButton
                  title={isLoading ? t.profile.updating : t.profile.updatePassword}
                  onPress={handleChangePassword}
                  loading={isLoading}
                  disabled={isLoading}
                />
              </View>
            )}
          </GoldCard>

          <View style={{ height: 32 }} />
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#001F3F' },
  safeArea: { flex: 1 },
  appBar: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 12,
    borderBottomWidth: 1, borderBottomColor: 'rgba(248,249,250,0.08)',
  },
  appBarTitle: { fontSize: 18, fontWeight: '700', color: '#F8F9FA' },
  menuBtn: { padding: 8 },
  scrollContent: { paddingHorizontal: 16, paddingTop: 16 },

  // Avatar Section
  avatarSection: {
    alignItems: 'center',
    paddingVertical: 24,
    marginBottom: 8,
  },
  avatarCircle: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#C5A021',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
    borderWidth: 3,
    borderColor: 'rgba(197,160,33,0.4)',
  },
  avatarText: {
    fontSize: 32,
    fontWeight: '700',
    color: '#001F3F',
  },
  displayName: {
    fontSize: 20,
    fontWeight: '700',
    color: '#F8F9FA',
    marginBottom: 4,
  },
  emailText: {
    fontSize: 14,
    color: '#6C737F',
    marginBottom: 8,
  },
  roleBadge: {
    backgroundColor: 'rgba(197,160,33,0.2)',
    borderRadius: 8,
    paddingHorizontal: 14,
    paddingVertical: 4,
  },
  roleText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#C5A021',
  },

  // Info rows
  infoRow: {
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 4,
  },
  infoLabel: {
    alignItems: 'center',
  },
  infoLabelText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#1A1A1B',
  },
  infoValue: {
    fontSize: 14,
    color: '#6C737F',
    flex: 1,
  },
  divider: {
    height: 1,
    backgroundColor: '#E6E8EA',
    marginVertical: 12,
  },

  // Edit name
  editBtn: {
    alignItems: 'center',
    gap: 4,
  },
  editBtnText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#C5A021',
  },
  nameDisplay: {
    fontSize: 15,
    color: '#6C737F',
    marginTop: 4,
  },
  editNameSection: {
    marginTop: 8,
  },
  editActions: {
    gap: 10,
    marginTop: -4,
  },

  // Password
  passwordHeader: {
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  passwordHeaderContent: {
    alignItems: 'center',
    flex: 1,
  },
  passwordHeaderText: {
    fontSize: 15,
    fontWeight: '600',
    color: '#1A1A1B',
    flex: 1,
  },
  passwordForm: {
    marginTop: 16,
    borderTopWidth: 1,
    borderTopColor: '#E6E8EA',
    paddingTop: 16,
  },

  // Feedback
  errorText: {
    fontSize: 13,
    color: '#EF4444',
    textAlign: 'center',
    marginBottom: 8,
  },
  successBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    backgroundColor: 'rgba(34,197,94,0.1)',
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 12,
    marginTop: 12,
  },
  successText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#22C55E',
  },
});
