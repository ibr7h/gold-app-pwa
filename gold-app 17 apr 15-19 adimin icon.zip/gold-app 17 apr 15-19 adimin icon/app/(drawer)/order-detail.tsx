import React, { useState, useMemo } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, TextInput, Alert, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { GoldCard } from '@/components/gold/GoldCard';
import { GoldButton } from '@/components/gold/GoldButton';
import { useI18n } from '@/i18n';
import { useSettings } from '@/contexts/SettingsContext';
import { useTraderData, type OrderStatus } from '@/contexts/TraderDataContext';

interface OrderDetailScreenProps {
  onOpenDrawer: () => void;
  onNavigate?: (screen: string, params?: any) => void;
  orderId?: string;
}

export default function OrderDetailScreen({ onOpenDrawer, onNavigate, orderId }: OrderDetailScreenProps) {
  const { isRTL, textAlign, direction, flexDir, lang } = useI18n();
  const { settings } = useSettings();
  const { orders, updateOrderStatus, updateOrderNotes, deleteOrder } = useTraderData();

  const order = useMemo(() => orders.find(o => o.id === orderId), [orders, orderId]);

  const [editingNotes, setEditingNotes] = useState(false);
  const [notesText, setNotesText] = useState(order?.notes || '');
  const [saving, setSaving] = useState(false);

  // Translations
  const t = useMemo(() => ({
    title: lang === 'ar' ? 'تفاصيل الطلب' : lang === 'fr' ? 'Détails de la commande' : 'Order Details',
    orderNumber: lang === 'ar' ? 'رقم الطلب' : lang === 'fr' ? 'N° commande' : 'Order #',
    client: lang === 'ar' ? 'العميل' : lang === 'fr' ? 'Client' : 'Client',
    type: lang === 'ar' ? 'النوع' : lang === 'fr' ? 'Type' : 'Type',
    buy: lang === 'ar' ? 'شراء' : lang === 'fr' ? 'Achat' : 'Buy',
    sell: lang === 'ar' ? 'بيع' : lang === 'fr' ? 'Vente' : 'Sell',
    karat: lang === 'ar' ? 'العيار' : lang === 'fr' ? 'Carat' : 'Karat',
    weight: lang === 'ar' ? 'الوزن' : lang === 'fr' ? 'Poids' : 'Weight',
    grams: lang === 'ar' ? 'غرام' : lang === 'fr' ? 'grammes' : 'grams',
    pricePerGram: lang === 'ar' ? 'سعر الغرام' : lang === 'fr' ? 'Prix/gramme' : 'Price/gram',
    total: lang === 'ar' ? 'الإجمالي' : lang === 'fr' ? 'Total' : 'Total',
    status: lang === 'ar' ? 'الحالة' : lang === 'fr' ? 'Statut' : 'Status',
    date: lang === 'ar' ? 'التاريخ' : lang === 'fr' ? 'Date' : 'Date',
    time: lang === 'ar' ? 'الوقت' : lang === 'fr' ? 'Heure' : 'Time',
    notes: lang === 'ar' ? 'الملاحظات' : lang === 'fr' ? 'Notes' : 'Notes',
    noNotes: lang === 'ar' ? 'لا توجد ملاحظات' : lang === 'fr' ? 'Aucune note' : 'No notes',
    editNotes: lang === 'ar' ? 'تعديل الملاحظات' : lang === 'fr' ? 'Modifier les notes' : 'Edit Notes',
    saveNotes: lang === 'ar' ? 'حفظ الملاحظات' : lang === 'fr' ? 'Enregistrer' : 'Save Notes',
    cancelEdit: lang === 'ar' ? 'إلغاء' : lang === 'fr' ? 'Annuler' : 'Cancel',
    notesPlaceholder: lang === 'ar' ? 'أضف ملاحظات هنا...' : lang === 'fr' ? 'Ajouter des notes ici...' : 'Add notes here...',
    notesSaved: lang === 'ar' ? 'تم حفظ الملاحظات' : lang === 'fr' ? 'Notes enregistrées' : 'Notes saved',
    changeStatus: lang === 'ar' ? 'تغيير الحالة' : lang === 'fr' ? 'Changer le statut' : 'Change Status',
    deleteOrder: lang === 'ar' ? 'حذف الطلب' : lang === 'fr' ? 'Supprimer' : 'Delete Order',
    deleteConfirm: lang === 'ar' ? 'هل أنت متأكد من حذف هذا الطلب؟' : lang === 'fr' ? 'Êtes-vous sûr de vouloir supprimer cette commande ?' : 'Are you sure you want to delete this order?',
    orderDeleted: lang === 'ar' ? 'تم حذف الطلب' : lang === 'fr' ? 'Commande supprimée' : 'Order deleted',
    notFound: lang === 'ar' ? 'الطلب غير موجود' : lang === 'fr' ? 'Commande introuvable' : 'Order not found',
    back: lang === 'ar' ? 'رجوع' : lang === 'fr' ? 'Retour' : 'Back',
    pending: lang === 'ar' ? 'معلق' : lang === 'fr' ? 'En attente' : 'Pending',
    processing: lang === 'ar' ? 'قيد التنفيذ' : lang === 'fr' ? 'En cours' : 'Processing',
    completed: lang === 'ar' ? 'مكتمل' : lang === 'fr' ? 'Terminé' : 'Completed',
    cancelled: lang === 'ar' ? 'ملغي' : lang === 'fr' ? 'Annulé' : 'Cancelled',
    orderInfo: lang === 'ar' ? 'معلومات الطلب' : lang === 'fr' ? 'Informations' : 'Order Info',
    actions: lang === 'ar' ? 'الإجراءات' : lang === 'fr' ? 'Actions' : 'Actions',
  }), [lang]);

  const currencySymbol = settings.preferredCurrency === 'USD' ? '$' : settings.preferredCurrency === 'EUR' ? '€' : settings.preferredCurrency === 'SAR' ? 'ر.س' : settings.preferredCurrency === 'AED' ? 'د.إ' : settings.preferredCurrency === 'EGP' ? 'ج.م' : '$';

  const statusColors: Record<OrderStatus, string> = {
    pending: '#F59E0B',
    processing: '#3B82F6',
    completed: '#22C55E',
    cancelled: '#EF4444',
  };

  const statusLabels: Record<OrderStatus, string> = {
    pending: t.pending,
    processing: t.processing,
    completed: t.completed,
    cancelled: t.cancelled,
  };

  const handleSaveNotes = async () => {
    if (!order) return;
    setSaving(true);
    try {
      await updateOrderNotes(order.id, notesText.trim());
      setEditingNotes(false);
      if (Platform.OS !== 'web') {
        Alert.alert('', t.notesSaved);
      }
    } catch {
      // silently handle
    }
    setSaving(false);
  };

  const handleStatusChange = async (newStatus: OrderStatus) => {
    if (!order) return;
    await updateOrderStatus(order.id, newStatus);
  };

  const handleDelete = () => {
    if (!order) return;
    if (Platform.OS === 'web') {
      if (confirm(t.deleteConfirm)) {
        deleteOrder(order.id);
        onNavigate?.('trader-orders');
      }
    } else {
      Alert.alert(t.deleteOrder, t.deleteConfirm, [
        { text: t.cancelEdit, style: 'cancel' },
        {
          text: t.deleteOrder,
          style: 'destructive',
          onPress: () => {
            deleteOrder(order.id);
            onNavigate?.('trader-orders');
          },
        },
      ]);
    }
  };

  if (!order) {
    return (
      <View style={styles.container}>
        <SafeAreaView style={styles.safeArea} edges={['top', 'left', 'right']}>
          <View style={[styles.header, { flexDirection: flexDir }]}>
            <TouchableOpacity onPress={() => onNavigate?.('trader-orders')} style={styles.backBtn}>
              <MaterialIcons name={isRTL ? 'chevron-right' : 'chevron-left'} size={28} color="#C5A021" />
            </TouchableOpacity>
            <Text style={[styles.headerTitle, { textAlign, writingDirection: direction }]}>{t.title}</Text>
            <View style={{ width: 40 }} />
          </View>
          <View style={styles.emptyContainer}>
            <MaterialIcons name="error-outline" size={48} color="#6C737F" />
            <Text style={[styles.emptyText, { writingDirection: direction }]}>{t.notFound}</Text>
          </View>
        </SafeAreaView>
      </View>
    );
  }

  const availableStatuses: OrderStatus[] = ['pending', 'processing', 'completed', 'cancelled'].filter(
    s => s !== order.status
  ) as OrderStatus[];

  return (
    <View style={styles.container}>
      <SafeAreaView style={styles.safeArea} edges={['top', 'left', 'right']}>
        {/* Header */}
        <View style={[styles.header, { flexDirection: flexDir }]}>
          <TouchableOpacity onPress={() => onNavigate?.('trader-orders')} style={styles.backBtn}>
            <MaterialIcons name={isRTL ? 'chevron-right' : 'chevron-left'} size={28} color="#C5A021" />
          </TouchableOpacity>
          <Text style={[styles.headerTitle, { textAlign, writingDirection: direction }]}>{t.title}</Text>
          <TouchableOpacity onPress={onOpenDrawer} style={styles.menuBtn}>
            <MaterialIcons name="menu" size={26} color="#F8F9FA" />
          </TouchableOpacity>
        </View>

        <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
          {/* Order Status Banner */}
          <View style={[styles.statusBanner, { backgroundColor: statusColors[order.status] + '20' }]}>
            <View style={[styles.statusBannerContent, { flexDirection: flexDir }]}>
              <View style={[styles.statusDot, { backgroundColor: statusColors[order.status] }]} />
              <Text style={[styles.statusBannerText, { color: statusColors[order.status], writingDirection: direction }]}>
                {statusLabels[order.status]}
              </Text>
            </View>
            <Text style={[styles.orderIdText, { writingDirection: direction }]}>
              #{order.id.toUpperCase()}
            </Text>
          </View>

          {/* Order Type Badge */}
          <View style={[styles.typeBadgeRow, { flexDirection: flexDir }]}>
            <View style={[styles.typeBadge, { backgroundColor: order.type === 'buy' ? 'rgba(34,197,94,0.15)' : 'rgba(239,68,68,0.15)' }]}>
              <MaterialIcons
                name={order.type === 'buy' ? 'arrow-downward' : 'arrow-upward'}
                size={18}
                color={order.type === 'buy' ? '#22C55E' : '#EF4444'}
              />
              <Text style={[styles.typeBadgeText, { color: order.type === 'buy' ? '#22C55E' : '#EF4444', writingDirection: direction }]}>
                {order.type === 'buy' ? t.buy : t.sell}
              </Text>
            </View>
            <Text style={[styles.totalAmount, { writingDirection: direction }]}>
              {currencySymbol} {order.totalAmount.toLocaleString()}
            </Text>
          </View>

          {/* Order Info Card */}
          <GoldCard style={styles.infoCard}>
            <Text style={[styles.sectionTitle, { textAlign, writingDirection: direction }]}>{t.orderInfo}</Text>

            <View style={styles.infoGrid}>
              {/* Client */}
              <View style={[styles.infoRow, { flexDirection: flexDir }]}>
                <View style={[styles.infoIconBox, isRTL ? { marginLeft: 10 } : { marginRight: 10 }]}>
                  <MaterialIcons name="person" size={18} color="#C5A021" />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.infoLabel, { textAlign, writingDirection: direction }]}>{t.client}</Text>
                  <Text style={[styles.infoValue, { textAlign, writingDirection: direction }]}>{order.clientName}</Text>
                </View>
              </View>

              {/* Karat */}
              <View style={[styles.infoRow, { flexDirection: flexDir }]}>
                <View style={[styles.infoIconBox, isRTL ? { marginLeft: 10 } : { marginRight: 10 }]}>
                  <MaterialIcons name="diamond" size={18} color="#C5A021" />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.infoLabel, { textAlign, writingDirection: direction }]}>{t.karat}</Text>
                  <Text style={[styles.infoValue, { textAlign, writingDirection: direction }]}>{order.karat}K</Text>
                </View>
              </View>

              {/* Weight */}
              <View style={[styles.infoRow, { flexDirection: flexDir }]}>
                <View style={[styles.infoIconBox, isRTL ? { marginLeft: 10 } : { marginRight: 10 }]}>
                  <MaterialIcons name="scale" size={18} color="#C5A021" />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.infoLabel, { textAlign, writingDirection: direction }]}>{t.weight}</Text>
                  <Text style={[styles.infoValue, { textAlign, writingDirection: direction }]}>{order.grams} {t.grams}</Text>
                </View>
              </View>

              {/* Price per gram */}
              <View style={[styles.infoRow, { flexDirection: flexDir }]}>
                <View style={[styles.infoIconBox, isRTL ? { marginLeft: 10 } : { marginRight: 10 }]}>
                  <MaterialIcons name="attach-money" size={18} color="#C5A021" />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.infoLabel, { textAlign, writingDirection: direction }]}>{t.pricePerGram}</Text>
                  <Text style={[styles.infoValue, { textAlign, writingDirection: direction }]}>{currencySymbol} {order.pricePerGram.toLocaleString()}</Text>
                </View>
              </View>

              {/* Date & Time */}
              <View style={[styles.infoRow, { flexDirection: flexDir }]}>
                <View style={[styles.infoIconBox, isRTL ? { marginLeft: 10 } : { marginRight: 10 }]}>
                  <MaterialIcons name="schedule" size={18} color="#C5A021" />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.infoLabel, { textAlign, writingDirection: direction }]}>{t.date}</Text>
                  <Text style={[styles.infoValue, { textAlign, writingDirection: direction }]}>{order.date} • {order.time}</Text>
                </View>
              </View>
            </View>

            {/* Total */}
            <View style={[styles.totalRow, { flexDirection: flexDir }]}>
              <Text style={[styles.totalLabel, { writingDirection: direction }]}>{t.total}</Text>
              <Text style={[styles.totalValue, { writingDirection: direction }]}>
                {currencySymbol} {order.totalAmount.toLocaleString()}
              </Text>
            </View>
          </GoldCard>

          {/* Notes Card */}
          <GoldCard style={styles.notesCard}>
            <View style={[styles.notesTitleRow, { flexDirection: flexDir }]}>
              <Text style={[styles.sectionTitle, { textAlign, writingDirection: direction }]}>{t.notes}</Text>
              {!editingNotes && (
                <TouchableOpacity
                  onPress={() => { setNotesText(order.notes || ''); setEditingNotes(true); }}
                  style={styles.editNotesBtn}
                >
                  <MaterialIcons name="edit" size={18} color="#C5A021" />
                  <Text style={[styles.editNotesBtnText, { writingDirection: direction }]}>{t.editNotes}</Text>
                </TouchableOpacity>
              )}
            </View>

            {editingNotes ? (
              <View>
                <TextInput
                  style={[styles.notesInput, { textAlign, writingDirection: direction }]}
                  value={notesText}
                  onChangeText={setNotesText}
                  placeholder={t.notesPlaceholder}
                  placeholderTextColor="#6C737F"
                  multiline
                  numberOfLines={4}
                  textAlignVertical="top"
                />
                <View style={[styles.notesActions, { flexDirection: flexDir }]}>
                  <TouchableOpacity
                    onPress={() => setEditingNotes(false)}
                    style={styles.notesCancelBtn}
                  >
                    <Text style={[styles.notesCancelText, { writingDirection: direction }]}>{t.cancelEdit}</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={handleSaveNotes}
                    style={styles.notesSaveBtn}
                    disabled={saving}
                  >
                    <MaterialIcons name="check" size={18} color="#001F3F" />
                    <Text style={[styles.notesSaveText, { writingDirection: direction }]}>{saving ? '...' : t.saveNotes}</Text>
                  </TouchableOpacity>
                </View>
              </View>
            ) : (
              <Text style={[styles.notesContent, { textAlign, writingDirection: direction }]}>
                {order.notes || t.noNotes}
              </Text>
            )}
          </GoldCard>

          {/* Actions Card */}
          <GoldCard style={styles.actionsCard}>
            <Text style={[styles.sectionTitle, { textAlign, writingDirection: direction }]}>{t.changeStatus}</Text>
            <View style={styles.statusButtons}>
              {availableStatuses.map(status => (
                <TouchableOpacity
                  key={status}
                  onPress={() => handleStatusChange(status)}
                  style={[styles.statusBtn, { borderColor: statusColors[status] }]}
                  activeOpacity={0.7}
                >
                  <View style={[styles.statusBtnDot, { backgroundColor: statusColors[status] }]} />
                  <Text style={[styles.statusBtnText, { color: statusColors[status], writingDirection: direction }]}>
                    {statusLabels[status]}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>

            <View style={styles.divider} />

            <TouchableOpacity onPress={handleDelete} style={styles.deleteBtn} activeOpacity={0.7}>
              <MaterialIcons name="delete-outline" size={20} color="#EF4444" />
              <Text style={[styles.deleteBtnText, { writingDirection: direction }]}>{t.deleteOrder}</Text>
            </TouchableOpacity>
          </GoldCard>

          <View style={{ height: 100 }} />
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#001F3F' },
  safeArea: { flex: 1 },
  header: {
    alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 14,
    borderBottomWidth: 1, borderBottomColor: 'rgba(248,249,250,0.1)',
  },
  backBtn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  menuBtn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  headerTitle: { fontSize: 18, fontWeight: '700', color: '#F8F9FA', flex: 1 },
  content: { flex: 1, paddingHorizontal: 16 },

  // Status Banner
  statusBanner: {
    marginTop: 16, borderRadius: 16, padding: 16,
    alignItems: 'center',
  },
  statusBannerContent: { alignItems: 'center', marginBottom: 4 },
  statusDot: { width: 10, height: 10, borderRadius: 5, marginHorizontal: 8 },
  statusBannerText: { fontSize: 16, fontWeight: '700' },
  orderIdText: { fontSize: 13, color: '#6C737F', fontWeight: '500', marginTop: 4 },

  // Type Badge Row
  typeBadgeRow: {
    alignItems: 'center', justifyContent: 'space-between',
    marginTop: 16, paddingHorizontal: 4,
  },
  typeBadge: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20,
  },
  typeBadgeText: { fontSize: 14, fontWeight: '700', marginHorizontal: 6 },
  totalAmount: { fontSize: 22, fontWeight: '800', color: '#C5A021' },

  // Info Card
  infoCard: { marginTop: 16 },
  sectionTitle: { fontSize: 16, fontWeight: '700', color: '#F8F9FA', marginBottom: 16 },
  infoGrid: { gap: 12 },
  infoRow: { alignItems: 'center' },
  infoIconBox: {
    width: 36, height: 36, borderRadius: 10,
    backgroundColor: 'rgba(197,160,33,0.12)', alignItems: 'center', justifyContent: 'center',
  },
  infoLabel: { fontSize: 12, color: '#6C737F', fontWeight: '500' },
  infoValue: { fontSize: 15, color: '#F8F9FA', fontWeight: '600', marginTop: 2 },
  totalRow: {
    alignItems: 'center', justifyContent: 'space-between',
    marginTop: 16, paddingTop: 16,
    borderTopWidth: 1, borderTopColor: 'rgba(248,249,250,0.1)',
  },
  totalLabel: { fontSize: 15, color: '#6C737F', fontWeight: '600' },
  totalValue: { fontSize: 20, fontWeight: '800', color: '#C5A021' },

  // Notes Card
  notesCard: { marginTop: 16 },
  notesTitleRow: { alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 },
  editNotesBtn: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  editNotesBtnText: { fontSize: 13, color: '#C5A021', fontWeight: '600' },
  notesContent: { fontSize: 14, color: '#9BA1A6', lineHeight: 22 },
  notesInput: {
    backgroundColor: 'rgba(248,249,250,0.06)',
    borderWidth: 1, borderColor: 'rgba(197,160,33,0.3)',
    borderRadius: 12, padding: 14,
    color: '#F8F9FA', fontSize: 14, lineHeight: 22,
    minHeight: 100,
  },
  notesActions: { alignItems: 'center', justifyContent: 'flex-end', gap: 12, marginTop: 12 },
  notesCancelBtn: { paddingHorizontal: 16, paddingVertical: 10 },
  notesCancelText: { fontSize: 14, color: '#6C737F', fontWeight: '600' },
  notesSaveBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: '#C5A021', paddingHorizontal: 18, paddingVertical: 10, borderRadius: 10,
  },
  notesSaveText: { fontSize: 14, fontWeight: '700', color: '#001F3F' },

  // Actions Card
  actionsCard: { marginTop: 16 },
  statusButtons: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  statusBtn: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: 14, paddingVertical: 10,
    borderRadius: 10, borderWidth: 1.5,
    backgroundColor: 'rgba(248,249,250,0.04)',
  },
  statusBtnDot: { width: 8, height: 8, borderRadius: 4, marginRight: 8 },
  statusBtnText: { fontSize: 13, fontWeight: '700' },
  divider: { height: 1, backgroundColor: 'rgba(248,249,250,0.1)', marginVertical: 16 },
  deleteBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: 8, paddingVertical: 12, borderRadius: 10,
    backgroundColor: 'rgba(239,68,68,0.1)',
  },
  deleteBtnText: { fontSize: 14, fontWeight: '700', color: '#EF4444' },

  // Empty
  emptyContainer: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12 },
  emptyText: { fontSize: 16, color: '#6C737F', fontWeight: '500' },
});
