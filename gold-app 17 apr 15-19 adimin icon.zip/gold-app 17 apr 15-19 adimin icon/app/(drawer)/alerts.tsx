import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Modal, Platform, Alert as RNAlert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { useAppData } from '@/contexts/AppDataContext';
import { GoldCard } from '@/components/gold/GoldCard';
import { GoldButton } from '@/components/gold/GoldButton';
import { GoldInput } from '@/components/gold/GoldInput';
import { GoldSelect } from '@/components/gold/GoldSelect';
import { GoldToggle } from '@/components/gold/GoldToggle';
import { StateView } from '@/components/gold/StateView';
import { useI18n } from '@/i18n';
import { notificationService } from '@/services/NotificationService';

interface AlertsScreenProps {
  onOpenDrawer: () => void;
}

export default function AlertsScreen({ onOpenDrawer }: AlertsScreenProps) {
  const { alertsList, prices, addAlert, toggleAlert, deleteAlert } = useAppData();
  const { t, isRTL, textAlign, direction, flexDir } = useI18n();
  const [showForm, setShowForm] = useState(false);

  // Notification state
  const [notifPermission, setNotifPermission] = useState<'granted' | 'denied' | 'undetermined'>('undetermined');
  const [checking, setChecking] = useState(false);
  const [lastCheckResult, setLastCheckResult] = useState<string | null>(null);
  const [lastCheckTime, setLastCheckTime] = useState<string | null>(null);

  // Form state
  const [formTitle, setFormTitle] = useState('');
  const [formKarat, setFormKarat] = useState('24');
  const [formCurrency, setFormCurrency] = useState('SAR');
  const [formPrice, setFormPrice] = useState('');
  const [formCondition, setFormCondition] = useState('>=');
  const [formNote, setFormNote] = useState('');
  const [formError, setFormError] = useState('');

  // Check notification permission on mount
  useEffect(() => {
    checkPermission();
  }, []);

  const checkPermission = async () => {
    try {
      const status = await notificationService.getPermissionStatus();
      setNotifPermission(status);
    } catch {
      // Web or unsupported platform
    }
  };

  const requestPermission = async () => {
    try {
      const granted = await notificationService.requestPermissions();
      setNotifPermission(granted ? 'granted' : 'denied');
      if (!granted) {
        if (Platform.OS !== 'web') {
          RNAlert.alert(t.notifications.permissionRequired, t.notifications.permissionDenied);
        }
      }
    } catch {
      // Ignore on web
    }
  };

  const handleSendTest = async () => {
    if (notifPermission !== 'granted') {
      await requestPermission();
      return;
    }
    try {
      await notificationService.sendTestNotification(
        t.notifications.testNotification,
        t.notifications.testNotificationBody,
      );
      setLastCheckResult(t.notifications.testSent);
    } catch {
      // Ignore
    }
  };

  const handleCheckAlerts = async () => {
    if (notifPermission !== 'granted') {
      await requestPermission();
      return;
    }

    const activeAlerts = alertsList.filter(a => a.enabled && a.status === 'active');
    if (activeAlerts.length === 0) {
      setLastCheckResult(t.notifications.noActiveAlerts);
      return;
    }

    setChecking(true);
    try {
      const result = await notificationService.checkAlerts(
        alertsList,
        prices,
        t.notifications.priceAlert,
        (karat, price, currency) => t.notifications.priceAbove.replace('{{karat}}', karat).replace('{{price}}', price.toFixed(2)).replace('{{currency}}', currency),
        (karat, price, currency) => t.notifications.priceBelow.replace('{{karat}}', karat).replace('{{price}}', price.toFixed(2)).replace('{{currency}}', currency),
      );

      const now = new Date().toLocaleTimeString();
      setLastCheckTime(now);

      if (result.alertsTriggered > 0) {
        setLastCheckResult(`${t.notifications.alertTriggered} (${result.alertsTriggered})`);
      } else {
        setLastCheckResult(
          t.notifications.alertsChecked.replace('{{count}}', String(result.alertsChecked)) +
          ' - ' + t.notifications.noAlertsTriggered
        );
      }
    } catch {
      setLastCheckResult(t.error);
    } finally {
      setChecking(false);
    }
  };

  const resetForm = () => {
    setFormTitle(''); setFormKarat('24'); setFormCurrency('SAR');
    setFormPrice(''); setFormCondition('>='); setFormNote(''); setFormError('');
  };

  const handleAdd = () => {
    if (!formTitle.trim()) { setFormError(t.alerts.titleRequired); return; }
    if (!formPrice || isNaN(Number(formPrice))) { setFormError(t.alerts.invalidTargetPrice); return; }

    addAlert({
      title: formTitle.trim(),
      karat: formKarat,
      currency: formCurrency,
      targetPrice: Number(formPrice),
      condition: formCondition as '>=' | '<=',
      enabled: true,
      note: formNote.trim(),
    });

    setShowForm(false);
    resetForm();
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active': return { label: t.alerts.statusActive, color: '#22C55E', bg: 'rgba(34,197,94,0.12)' };
      case 'triggered': return { label: t.alerts.statusTriggered, color: '#C5A021', bg: 'rgba(197,160,33,0.12)' };
      case 'expired': return { label: t.alerts.statusExpired, color: '#6C737F', bg: 'rgba(108,115,127,0.12)' };
      default: return { label: status, color: '#6C737F', bg: 'rgba(108,115,127,0.12)' };
    }
  };

  const permissionColor = notifPermission === 'granted' ? '#22C55E' : notifPermission === 'denied' ? '#EF4444' : '#C5A021';
  const permissionLabel = notifPermission === 'granted' ? t.notifications.enabled : notifPermission === 'denied' ? t.notifications.disabled : t.notifications.permissionRequired;

  return (
    <View style={styles.screen}>
      <SafeAreaView style={styles.safeArea} edges={['top']}>
        <View style={styles.appBar}>
          <TouchableOpacity onPress={() => { resetForm(); setShowForm(true); }} style={styles.addBtn} activeOpacity={0.7}>
            <MaterialIcons name="add" size={24} color="#C5A021" />
          </TouchableOpacity>
          <Text style={[styles.appBarTitle, { writingDirection: direction }]}>{t.alerts.title}</Text>
          <TouchableOpacity onPress={onOpenDrawer} style={styles.menuBtn} activeOpacity={0.7}>
            <MaterialIcons name="menu" size={24} color="#F8F9FA" />
          </TouchableOpacity>
        </View>

        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
          {/* Notification Settings Card */}
          <GoldCard style={styles.notifCard}>
            <View style={[styles.notifHeader, { flexDirection: flexDir }]}>
              <View style={[styles.notifStatus, { backgroundColor: permissionColor + '1A' }]}>
                <MaterialIcons
                  name={notifPermission === 'granted' ? 'notifications-active' : 'notifications-off'}
                  size={16}
                  color={permissionColor}
                />
                <Text style={[styles.notifStatusText, { color: permissionColor, writingDirection: direction }]}>
                  {permissionLabel}
                </Text>
              </View>
              <View style={[styles.notifTitleRow, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
                <MaterialIcons name="notifications" size={22} color="#C5A021" />
                <Text style={[styles.notifTitle, { writingDirection: direction }]}>{t.notifications.notificationSettings}</Text>
              </View>
            </View>

            {notifPermission !== 'granted' && (
              <TouchableOpacity
                onPress={requestPermission}
                style={styles.enableBtn}
                activeOpacity={0.7}
              >
                <Text style={[styles.enableBtnText, { writingDirection: direction }]}>{t.notifications.enable}</Text>
                <MaterialIcons name="notifications" size={18} color="#001F3F" />
              </TouchableOpacity>
            )}

            {/* Action buttons */}
            <View style={[styles.notifActions, { flexDirection: flexDir }]}>
              <TouchableOpacity
                onPress={handleCheckAlerts}
                style={[styles.actionBtn, styles.checkBtn, checking && styles.actionBtnDisabled]}
                activeOpacity={0.7}
                disabled={checking}
              >
                <MaterialIcons name="price-check" size={18} color="#001F3F" />
                <Text style={[styles.actionBtnText, { writingDirection: direction }]}>
                  {checking ? t.notifications.checking : t.notifications.checkNow}
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={handleSendTest}
                style={[styles.actionBtn, styles.testBtn]}
                activeOpacity={0.7}
              >
                <MaterialIcons name="send" size={16} color="#C5A021" />
                <Text style={[styles.testBtnText, { writingDirection: direction }]}>{t.notifications.sendTest}</Text>
              </TouchableOpacity>
            </View>

            {/* Last check info */}
            {(lastCheckResult || lastCheckTime) && (
              <View style={styles.lastCheckInfo}>
                {lastCheckTime && (
                  <Text style={[styles.lastCheckText, { textAlign, writingDirection: direction }]}>
                    {t.notifications.lastCheck}: {lastCheckTime}
                  </Text>
                )}
                {lastCheckResult && (
                  <Text style={[styles.lastCheckResult, { textAlign, writingDirection: direction }]}>
                    {lastCheckResult}
                  </Text>
                )}
              </View>
            )}
          </GoldCard>

          {/* Alerts List */}
          {alertsList.length === 0 ? (
            <StateView type="empty" message={t.alerts.noAlerts} />
          ) : (
            alertsList.map(alert => {
              const statusBadge = getStatusBadge(alert.status);
              return (
                <GoldCard key={alert.id} style={styles.alertCard}>
                  <View style={[styles.alertHeader, { flexDirection: flexDir }]}>
                    <View style={styles.alertActions}>
                      <TouchableOpacity onPress={() => deleteAlert(alert.id)} style={styles.deleteBtn} activeOpacity={0.6}>
                        <MaterialIcons name="delete-outline" size={20} color="#EF4444" />
                      </TouchableOpacity>
                      <GoldToggle value={alert.enabled} onValueChange={() => toggleAlert(alert.id)} />
                    </View>
                    <View style={[styles.alertInfo, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
                      <Text style={[styles.alertTitle, { writingDirection: direction }]}>{alert.title}</Text>
                      <View style={[styles.statusBadge, { backgroundColor: statusBadge.bg }]}>
                        <Text style={[styles.statusText, { color: statusBadge.color }]}>{statusBadge.label}</Text>
                      </View>
                    </View>
                  </View>

                  <View style={[styles.alertDetails, { flexDirection: flexDir }]}>
                    <View style={styles.alertDetailItem}>
                      <Text style={styles.alertDetailValue}>{alert.lastUpdate}</Text>
                      <Text style={[styles.alertDetailLabel, { writingDirection: direction }]}>{t.home.lastUpdate}</Text>
                    </View>
                    <View style={styles.alertDetailItem}>
                      <Text style={styles.alertDetailValue}>{alert.condition} {alert.targetPrice.toFixed(2)}</Text>
                      <Text style={[styles.alertDetailLabel, { writingDirection: direction }]}>{t.alerts.condition}</Text>
                    </View>
                    <View style={styles.alertDetailItem}>
                      <Text style={[styles.alertDetailValue, { color: '#C5A021' }]}>{alert.targetPrice.toFixed(2)} {alert.currency}</Text>
                      <Text style={[styles.alertDetailLabel, { writingDirection: direction }]}>{t.alerts.targetPrice}</Text>
                    </View>
                  </View>

                  <View style={styles.alertMeta}>
                    <Text style={[styles.alertMetaText, { textAlign, writingDirection: direction }]}>{t.alerts.karat} {alert.karat} • {alert.currency}</Text>
                    {alert.note ? <Text style={[styles.alertNote, { textAlign, writingDirection: direction }]}>{alert.note}</Text> : null}
                  </View>
                </GoldCard>
              );
            })
          )}
          <View style={{ height: 32 }} />
        </ScrollView>

        <Modal visible={showForm} transparent animationType="fade">
          <View style={styles.overlay}>
            <View style={styles.modal}>
              <ScrollView showsVerticalScrollIndicator={false}>
                <View style={styles.modalHeader}>
                  <TouchableOpacity onPress={() => { setShowForm(false); resetForm(); }} activeOpacity={0.7}>
                    <MaterialIcons name="close" size={24} color="#6C737F" />
                  </TouchableOpacity>
                  <Text style={[styles.modalTitle, { writingDirection: direction }]}>{t.alerts.addAlert}</Text>
                </View>

                {formError ? (
                  <View style={styles.errorBanner}>
                    <Text style={[styles.errorText, { textAlign, writingDirection: direction }]}>{formError}</Text>
                  </View>
                ) : null}

                <GoldInput label={t.alerts.alertTitle} value={formTitle} onChangeText={(v) => { setFormTitle(v); setFormError(''); }} placeholder={t.alerts.alertTitlePlaceholder} />
                <GoldSelect
                  label={t.alerts.karat}
                  value={formKarat}
                  options={[
                    { label: t.karats.k24, value: '24' },
                    { label: t.karats.k22, value: '22' },
                    { label: t.karats.k21, value: '21' },
                    { label: t.karats.k18, value: '18' },
                    { label: t.karats.k14, value: '14' },
                  ]}
                  onSelect={setFormKarat}
                />
                <GoldSelect
                  label={t.home.currency}
                  value={formCurrency}
                  options={[
                    { label: t.portfolio.sarCurrency, value: 'SAR' },
                    { label: t.portfolio.usdCurrency, value: 'USD' },
                    { label: t.portfolio.eurCurrency, value: 'EUR' },
                  ]}
                  onSelect={setFormCurrency}
                />
                <GoldInput label={t.alerts.targetPrice} value={formPrice} onChangeText={(v) => { setFormPrice(v); setFormError(''); }} placeholder="0.00" keyboardType="decimal-pad" />
                <GoldSelect
                  label={t.alerts.condition}
                  value={formCondition}
                  options={[
                    { label: t.alerts.conditionGte, value: '>=' },
                    { label: t.alerts.conditionLte, value: '<=' },
                  ]}
                  onSelect={setFormCondition}
                />
                <GoldInput label={t.alerts.note} value={formNote} onChangeText={setFormNote} placeholder={t.alerts.notePlaceholder} multiline numberOfLines={2} />

                <GoldButton title={t.alerts.addAlert} onPress={handleAdd} style={{ marginTop: 8 }} />
              </ScrollView>
            </View>
          </View>
        </Modal>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#001F3F' },
  safeArea: { flex: 1 },
  appBar: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: 'rgba(248,249,250,0.08)',
  },
  appBarTitle: { fontSize: 18, fontWeight: '700', color: '#F8F9FA' },
  menuBtn: { padding: 8 },
  addBtn: { padding: 8 },
  scrollContent: { paddingHorizontal: 16, paddingTop: 16 },

  // Notification card
  notifCard: { marginBottom: 16 },
  notifHeader: { alignItems: 'flex-start', marginBottom: 12 },
  notifTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 8, flex: 1 },
  notifTitle: { fontSize: 16, fontWeight: '700', color: '#1A1A1B' },
  notifStatus: { borderRadius: 8, paddingHorizontal: 10, paddingVertical: 4, flexDirection: 'row', alignItems: 'center', gap: 4 },
  notifStatusText: { fontSize: 11, fontWeight: '600' },
  enableBtn: {
    backgroundColor: '#C5A021', borderRadius: 10, paddingVertical: 10, paddingHorizontal: 16,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, marginBottom: 12,
  },
  enableBtnText: { fontSize: 14, fontWeight: '600', color: '#001F3F' },
  notifActions: { gap: 8, marginTop: 4 },
  actionBtn: {
    flex: 1, borderRadius: 10, paddingVertical: 10, paddingHorizontal: 12,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6,
  },
  actionBtnDisabled: { opacity: 0.6 },
  checkBtn: { backgroundColor: '#C5A021' },
  actionBtnText: { fontSize: 13, fontWeight: '600', color: '#001F3F' },
  testBtn: { backgroundColor: 'rgba(197,160,33,0.12)', borderWidth: 1, borderColor: 'rgba(197,160,33,0.3)' },
  testBtnText: { fontSize: 13, fontWeight: '600', color: '#C5A021' },
  lastCheckInfo: { marginTop: 12, paddingTop: 10, borderTopWidth: 1, borderTopColor: '#E6E8EA' },
  lastCheckText: { fontSize: 11, color: '#6C737F' },
  lastCheckResult: { fontSize: 12, fontWeight: '600', color: '#1A1A1B', marginTop: 4 },

  // Alert cards
  alertCard: { marginBottom: 12 },
  alertHeader: { alignItems: 'flex-start' },
  alertInfo: { flex: 1 },
  alertTitle: { fontSize: 15, fontWeight: '600', color: '#1A1A1B', marginBottom: 6 },
  statusBadge: { borderRadius: 6, paddingHorizontal: 10, paddingVertical: 3 },
  statusText: { fontSize: 11, fontWeight: '600' },
  alertActions: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  deleteBtn: { padding: 4 },
  alertDetails: { marginTop: 14, paddingTop: 12, borderTopWidth: 1, borderTopColor: '#E6E8EA' },
  alertDetailItem: { flex: 1, alignItems: 'center' },
  alertDetailLabel: { fontSize: 11, color: '#6C737F', marginBottom: 4 },
  alertDetailValue: { fontSize: 13, fontWeight: '600', color: '#1A1A1B', fontVariant: ['tabular-nums'] },
  alertMeta: { marginTop: 10, paddingTop: 10, borderTopWidth: 1, borderTopColor: '#E6E8EA' },
  alertMetaText: { fontSize: 12, color: '#6C737F' },
  alertNote: { fontSize: 12, color: '#6C737F', marginTop: 4 },
  overlay: { flex: 1, backgroundColor: 'rgba(0,31,63,0.7)', justifyContent: 'center', padding: 16 },
  modal: { backgroundColor: '#F8F9FA', borderRadius: 16, padding: 24, maxHeight: '90%' },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  modalTitle: { fontSize: 18, fontWeight: '700', color: '#1A1A1B' },
  errorBanner: { backgroundColor: 'rgba(239,68,68,0.1)', borderRadius: 8, padding: 10, marginBottom: 12 },
  errorText: { fontSize: 13, color: '#EF4444' },
});
