import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Modal } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { useAppData } from '@/contexts/AppDataContext';
import { GoldCard } from '@/components/gold/GoldCard';
import { GoldButton } from '@/components/gold/GoldButton';
import { GoldInput } from '@/components/gold/GoldInput';
import { GoldSelect } from '@/components/gold/GoldSelect';
import { StateView } from '@/components/gold/StateView';
import { useI18n } from '@/i18n';
import type { Purchase } from '@/data/mock';

interface PurchasesScreenProps {
  onOpenDrawer: () => void;
}

export default function PurchasesScreen({ onOpenDrawer }: PurchasesScreenProps) {
  const { purchasesList, addPurchase, updatePurchase, deletePurchase, portfolios } = useAppData();
  const { t, isRTL, textAlign, direction, flexDir } = useI18n();
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState('');

  const [formName, setFormName] = useState('');
  const [formDesc, setFormDesc] = useState('');
  const [formCurrency, setFormCurrency] = useState('SAR');
  const [formPrice, setFormPrice] = useState('');
  const [formQty, setFormQty] = useState('');
  const [formDate, setFormDate] = useState('');
  const [formNotes, setFormNotes] = useState('');
  const [formPortfolio, setFormPortfolio] = useState('');
  const [formError, setFormError] = useState('');

  const resetForm = () => {
    setFormName(''); setFormDesc(''); setFormCurrency('SAR');
    setFormPrice(''); setFormQty(''); setFormDate('');
    setFormNotes(''); setFormPortfolio(''); setFormError('');
    setEditingId(null);
  };

  const openAddForm = () => {
    resetForm();
    setFormDate(new Date().toISOString().split('T')[0]);
    setShowForm(true);
  };

  const openEditForm = (purchase: Purchase) => {
    setEditingId(purchase.id);
    setFormName(purchase.name);
    setFormDesc(purchase.description);
    setFormCurrency(purchase.currency);
    setFormPrice(purchase.price.toString());
    setFormQty(purchase.quantity.toString());
    setFormDate(purchase.date);
    setFormNotes(purchase.notes);
    setFormPortfolio(purchase.portfolioId);
    setShowForm(true);
  };

  const handleSave = () => {
    if (!formName.trim()) { setFormError(t.purchases.nameRequired); return; }
    if (!formPrice || isNaN(Number(formPrice))) { setFormError(t.purchases.invalidPrice); return; }
    if (!formQty || isNaN(Number(formQty))) { setFormError(t.purchases.invalidQuantity); return; }
    if (!formDate) { setFormError(t.purchases.dateRequired); return; }

    const purchaseData = {
      name: formName.trim(),
      description: formDesc.trim(),
      currency: formCurrency,
      price: Number(formPrice),
      quantity: Number(formQty),
      date: formDate,
      notes: formNotes.trim(),
      portfolioId: formPortfolio,
    };

    if (editingId) {
      updatePurchase(editingId, purchaseData);
      setSuccessMsg(t.purchases.updatedSuccess);
    } else {
      addPurchase(purchaseData);
      setSuccessMsg(t.purchases.addedSuccess);
    }

    setShowForm(false);
    resetForm();
    setTimeout(() => setSuccessMsg(''), 3000);
  };

  return (
    <View style={styles.screen}>
      <SafeAreaView style={styles.safeArea} edges={['top']}>
        <View style={styles.appBar}>
          <TouchableOpacity onPress={openAddForm} style={styles.addBtn} activeOpacity={0.7}>
            <MaterialIcons name="add" size={24} color="#C5A021" />
          </TouchableOpacity>
          <Text style={[styles.appBarTitle, { writingDirection: direction }]}>{t.purchases.title}</Text>
          <TouchableOpacity onPress={onOpenDrawer} style={styles.menuBtn} activeOpacity={0.7}>
            <MaterialIcons name="menu" size={24} color="#F8F9FA" />
          </TouchableOpacity>
        </View>

        {successMsg ? (
          <View style={[styles.successBanner, { flexDirection: flexDir }]}>
            <Text style={[styles.successText, { writingDirection: direction }, isRTL ? { marginLeft: 8 } : { marginRight: 8 }]}>{successMsg}</Text>
            <MaterialIcons name="check-circle" size={18} color="#22C55E" />
          </View>
        ) : null}

        {purchasesList.length === 0 ? (
          <StateView type="empty" message={t.purchases.noPurchases} />
        ) : (
          <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
            {purchasesList.map(item => (
              <GoldCard key={item.id} style={styles.purchaseCard}>
                <View style={[styles.purchaseHeader, { flexDirection: flexDir }]}>
                  <View style={styles.purchaseActions}>
                    <TouchableOpacity onPress={() => deletePurchase(item.id)} style={styles.actionBtn} activeOpacity={0.6}>
                      <MaterialIcons name="delete-outline" size={20} color="#EF4444" />
                    </TouchableOpacity>
                    <TouchableOpacity onPress={() => openEditForm(item)} style={styles.actionBtn} activeOpacity={0.6}>
                      <MaterialIcons name="edit" size={20} color="#C5A021" />
                    </TouchableOpacity>
                  </View>
                  <View style={[styles.purchaseInfo, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
                    <Text style={[styles.purchaseName, { writingDirection: direction }]}>{item.name}</Text>
                    {item.description ? <Text style={[styles.purchaseDesc, { writingDirection: direction }]}>{item.description}</Text> : null}
                  </View>
                </View>
                <View style={[styles.purchaseDetails, { flexDirection: flexDir }]}>
                  <View style={styles.purchaseDetailItem}>
                    <Text style={styles.purchaseDetailValue}>{item.date}</Text>
                    <Text style={[styles.purchaseDetailLabel, { writingDirection: direction }]}>{t.purchases.date}</Text>
                  </View>
                  <View style={styles.purchaseDetailItem}>
                    <Text style={styles.purchaseDetailValue}>{item.quantity}</Text>
                    <Text style={[styles.purchaseDetailLabel, { writingDirection: direction }]}>{t.purchases.quantity}</Text>
                  </View>
                  <View style={styles.purchaseDetailItem}>
                    <Text style={[styles.purchaseDetailValue, { color: '#C5A021' }]}>{item.price.toFixed(2)}</Text>
                    <Text style={[styles.purchaseDetailLabel, { writingDirection: direction }]}>{t.purchases.price} ({item.currency})</Text>
                  </View>
                </View>
                {item.notes ? (
                  <View style={[styles.notesRow, { flexDirection: flexDir }]}>
                    <Text style={[styles.notesText, { textAlign, writingDirection: direction }]}>{item.notes}</Text>
                    <MaterialIcons name="notes" size={14} color="#6C737F" style={isRTL ? { marginLeft: 6 } : { marginRight: 6 }} />
                  </View>
                ) : null}
              </GoldCard>
            ))}
            <View style={{ height: 32 }} />
          </ScrollView>
        )}

        <Modal visible={showForm} transparent animationType="fade">
          <View style={styles.overlay}>
            <View style={styles.modal}>
              <ScrollView showsVerticalScrollIndicator={false}>
                <View style={styles.modalHeader}>
                  <TouchableOpacity onPress={() => { setShowForm(false); resetForm(); }} activeOpacity={0.7}>
                    <MaterialIcons name="close" size={24} color="#6C737F" />
                  </TouchableOpacity>
                  <Text style={[styles.modalTitle, { writingDirection: direction }]}>{editingId ? t.purchases.editPurchase : t.purchases.addPurchase}</Text>
                </View>

                {formError ? (
                  <View style={styles.errorBanner}>
                    <Text style={[styles.errorText, { textAlign, writingDirection: direction }]}>{formError}</Text>
                  </View>
                ) : null}

                <GoldInput label={t.purchases.name} value={formName} onChangeText={(v) => { setFormName(v); setFormError(''); }} placeholder={t.purchases.namePlaceholder} />
                <GoldInput label={t.purchases.description} value={formDesc} onChangeText={setFormDesc} placeholder={t.purchases.descriptionPlaceholder} multiline numberOfLines={2} />
                <GoldSelect
                  label={t.home.currency}
                  value={formCurrency}
                  options={[
                    { label: t.portfolio.sarCurrency, value: 'SAR' },
                    { label: t.portfolio.usdCurrency, value: 'USD' },
                    { label: t.portfolio.eurCurrency, value: 'EUR' },
                  ]}
                  onSelect={setFormCurrency}
                />
                <GoldInput label={t.purchases.price} value={formPrice} onChangeText={(v) => { setFormPrice(v); setFormError(''); }} placeholder="0.00" keyboardType="decimal-pad" />
                <GoldInput label={t.purchases.quantity} value={formQty} onChangeText={(v) => { setFormQty(v); setFormError(''); }} placeholder="1" keyboardType="number-pad" />
                <GoldInput label={t.purchases.date} value={formDate} onChangeText={(v) => { setFormDate(v); setFormError(''); }} placeholder="YYYY-MM-DD" />
                <GoldSelect
                  label={t.purchases.portfolioOptional}
                  value={formPortfolio}
                  options={[
                    { label: t.purchases.noPortfolio, value: '' },
                    ...portfolios.map(p => ({ label: p.name, value: p.id })),
                  ]}
                  onSelect={setFormPortfolio}
                />
                <GoldInput label={t.purchases.notes} value={formNotes} onChangeText={setFormNotes} placeholder={t.purchases.notesPlaceholder} multiline numberOfLines={2} />

                <GoldButton title={editingId ? t.update : t.save} onPress={handleSave} style={{ marginTop: 8 }} />
              </ScrollView>
            </View>
          </View>
        </Modal>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#001F3F' },
  safeArea: { flex: 1 },
  appBar: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: 'rgba(248,249,250,0.08)',
  },
  appBarTitle: { fontSize: 18, fontWeight: '700', color: '#F8F9FA' },
  menuBtn: { padding: 8 },
  addBtn: { padding: 8 },
  scrollContent: { paddingHorizontal: 16, paddingTop: 16 },
  successBanner: {
    alignItems: 'center', justifyContent: 'center',
    backgroundColor: 'rgba(34,197,94,0.12)', paddingVertical: 10, paddingHorizontal: 16,
    marginHorizontal: 16, marginTop: 8, borderRadius: 8,
  },
  successText: { fontSize: 13, color: '#22C55E' },
  purchaseCard: { marginBottom: 10 },
  purchaseHeader: { alignItems: 'flex-start' },
  purchaseInfo: { flex: 1 },
  purchaseName: { fontSize: 15, fontWeight: '600', color: '#1A1A1B' },
  purchaseDesc: { fontSize: 12, color: '#6C737F', marginTop: 2 },
  purchaseActions: { flexDirection: 'row', gap: 4 },
  actionBtn: { padding: 4 },
  purchaseDetails: { marginTop: 12, paddingTop: 10, borderTopWidth: 1, borderTopColor: '#E6E8EA' },
  purchaseDetailItem: { flex: 1, alignItems: 'center' },
  purchaseDetailLabel: { fontSize: 11, color: '#6C737F', marginBottom: 2 },
  purchaseDetailValue: { fontSize: 14, fontWeight: '600', color: '#1A1A1B', fontVariant: ['tabular-nums'] },
  notesRow: { alignItems: 'center', marginTop: 8, paddingTop: 8, borderTopWidth: 1, borderTopColor: '#E6E8EA' },
  notesText: { fontSize: 12, color: '#6C737F', flex: 1 },
  overlay: { flex: 1, backgroundColor: 'rgba(0,31,63,0.7)', justifyContent: 'center', padding: 16 },
  modal: { backgroundColor: '#F8F9FA', borderRadius: 16, padding: 24, maxHeight: '90%' },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  modalTitle: { fontSize: 18, fontWeight: '700', color: '#1A1A1B' },
  errorBanner: { backgroundColor: 'rgba(239,68,68,0.1)', borderRadius: 8, padding: 10, marginBottom: 12 },
  errorText: { fontSize: 13, color: '#EF4444' },
});
