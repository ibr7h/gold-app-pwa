import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Dimensions, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { GoldCard } from '@/components/gold/GoldCard';
import { useAuth } from '@/contexts/AuthContext';
import { useI18n } from '@/i18n';
import { useGoldPrice } from '@/hooks/useGoldPrice';
import { useSettings } from '@/contexts/SettingsContext';
import { useTraderData, type TraderOrder } from '@/contexts/TraderDataContext';

const SCREEN_WIDTH = Dimensions.get('window').width;

interface TraderHomeScreenProps {
  onOpenDrawer: () => void;
  onNavigate?: (screen: string) => void;
}

export default function TraderHomeScreen({ onOpenDrawer, onNavigate }: TraderHomeScreenProps) {
  const { user } = useAuth();
  const { t, isRTL, textAlign, direction, flexDir, lang } = useI18n();
  const { settings } = useSettings();
  const { data: goldData, loading: priceLoading, isLive, refresh, lastUpdated } = useGoldPrice();
  const { orders, stats, notifications, unreadCount, isLoading } = useTraderData();

  // Translations
  const traderDashboard = lang === 'ar' ? 'لوحة التاجر' : lang === 'fr' ? 'Tableau de bord' : 'Trader Dashboard';
  const todayStats = lang === 'ar' ? 'إحصائيات اليوم' : lang === 'fr' ? "Statistiques du jour" : "Today's Stats";
  const totalOrders = lang === 'ar' ? 'إجمالي الطلبات' : lang === 'fr' ? 'Total commandes' : 'Total Orders';
  const pendingOrders = lang === 'ar' ? 'طلبات معلقة' : lang === 'fr' ? 'En attente' : 'Pending';
  const completedToday = lang === 'ar' ? 'مكتملة اليوم' : lang === 'fr' ? "Terminées aujourd'hui" : 'Completed Today';
  const totalClients = lang === 'ar' ? 'إجمالي العملاء' : lang === 'fr' ? 'Total clients' : 'Total Clients';
  const revenueLabel = lang === 'ar' ? 'الإيرادات' : lang === 'fr' ? 'Revenus' : 'Revenue';
  const todayLabel = lang === 'ar' ? 'اليوم' : lang === 'fr' ? "Aujourd'hui" : 'Today';
  const thisWeek = lang === 'ar' ? 'هذا الأسبوع' : lang === 'fr' ? 'Cette semaine' : 'This Week';
  const recentOrders = lang === 'ar' ? 'آخر الطلبات' : lang === 'fr' ? 'Commandes récentes' : 'Recent Orders';
  const buyLabel = lang === 'ar' ? 'شراء' : lang === 'fr' ? 'Achat' : 'Buy';
  const sellLabel = lang === 'ar' ? 'بيع' : lang === 'fr' ? 'Vente' : 'Sell';
  const pendingLabel = lang === 'ar' ? 'معلق' : lang === 'fr' ? 'En attente' : 'Pending';
  const completedLabel = lang === 'ar' ? 'مكتمل' : lang === 'fr' ? 'Terminé' : 'Completed';
  const processingLabel = lang === 'ar' ? 'قيد التنفيذ' : lang === 'fr' ? 'En cours' : 'Processing';
  const goldPriceLabel = lang === 'ar' ? 'سعر الذهب الآن' : lang === 'fr' ? "Prix de l'or" : 'Gold Price Now';
  const quickActions = lang === 'ar' ? 'إجراءات سريعة' : lang === 'fr' ? 'Actions rapides' : 'Quick Actions';
  const newOrder = lang === 'ar' ? 'طلب جديد' : lang === 'fr' ? 'Nouvelle commande' : 'New Order';
  const addClient = lang === 'ar' ? 'عميل جديد' : lang === 'fr' ? 'Nouveau client' : 'New Client';
  const viewAll = lang === 'ar' ? 'عرض الكل' : lang === 'fr' ? 'Voir tout' : 'View All';
  const gramsLabel = lang === 'ar' ? 'غ' : lang === 'fr' ? 'g' : 'g';
  const notificationsLabel = lang === 'ar' ? 'الإشعارات' : lang === 'fr' ? 'Notifications' : 'Notifications';

  const currencySymbol = settings.preferredCurrency === 'USD' ? '$' : settings.preferredCurrency === 'EUR' ? '€' : settings.preferredCurrency === 'SAR' ? 'ر.س' : settings.preferredCurrency === 'AED' ? 'د.إ' : settings.preferredCurrency === 'EGP' ? 'ج.م' : '$';

  const recentOrdersList = orders.slice(0, 5);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return '#22C55E';
      case 'pending': return '#F59E0B';
      case 'processing': return '#3B82F6';
      default: return '#6C737F';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'completed': return completedLabel;
      case 'pending': return pendingLabel;
      case 'processing': return processingLabel;
      default: return status;
    }
  };

  if (isLoading) {
    return (
      <View style={[styles.screen, { justifyContent: 'center', alignItems: 'center' }]}>
        <ActivityIndicator size="large" color="#C5A021" />
      </View>
    );
  }

  return (
    <View style={styles.screen}>
      <SafeAreaView style={styles.safeArea} edges={['top']}>
        {/* App Bar */}
        <View style={styles.appBar}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
            {/* Search */}
            <TouchableOpacity
              onPress={() => onNavigate?.('search')}
              style={styles.menuBtn}
              activeOpacity={0.7}
            >
              <MaterialIcons name="search" size={24} color="#F8F9FA" />
            </TouchableOpacity>
            {/* Notification Bell */}
            <TouchableOpacity
              onPress={() => onNavigate?.('trader-notifications')}
              style={styles.menuBtn}
              activeOpacity={0.7}
            >
              <MaterialIcons name="notifications" size={24} color="#F8F9FA" />
              {unreadCount > 0 && (
                <View style={styles.badge}>
                  <Text style={styles.badgeText}>{unreadCount > 9 ? '9+' : unreadCount}</Text>
                </View>
              )}
            </TouchableOpacity>
          </View>
          <Text style={[styles.appBarTitle, { writingDirection: direction }]}>{traderDashboard}</Text>
          <TouchableOpacity onPress={onOpenDrawer} style={styles.menuBtn} activeOpacity={0.7}>
            <MaterialIcons name="menu" size={24} color="#F8F9FA" />
          </TouchableOpacity>
        </View>

        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
          {/* Welcome */}
          <View style={[styles.welcomeRow, { flexDirection: flexDir }]}>
            <View style={styles.welcomeBadge}>
              <MaterialIcons name="storefront" size={14} color="#C5A021" />
              <Text style={styles.welcomeBadgeText}>
                {lang === 'ar' ? 'تاجر' : lang === 'fr' ? 'Commerçant' : 'Trader'}
              </Text>
            </View>
            <Text style={[styles.welcomeText, { writingDirection: direction }]}>
              {t.home.welcome}، {user?.name || user?.email?.split('@')[0]}
            </Text>
          </View>

          {/* Gold Price Card */}
          <GoldCard>
            <View style={[styles.priceHeader, { flexDirection: flexDir }]}>
              <TouchableOpacity onPress={refresh} activeOpacity={0.7} style={styles.refreshBtn}>
                <MaterialIcons name="refresh" size={20} color="#C5A021" />
              </TouchableOpacity>
              <View style={[styles.priceLabel, { flexDirection: flexDir }]}>
                <Text style={[styles.priceLabelText, { writingDirection: direction }]}>{goldPriceLabel}</Text>
                <MaterialIcons name="show-chart" size={20} color="#C5A021" style={isRTL ? { marginLeft: 8 } : { marginRight: 8 }} />
              </View>
            </View>
            <Text style={[styles.priceValue, { textAlign }]}>
              {currencySymbol} {(goldData?.pricePerOunce ?? 0).toFixed(2)}
            </Text>
            {isLive && (
              <View style={styles.liveBadge}>
                <View style={styles.liveDot} />
                <Text style={styles.liveText}>LIVE</Text>
              </View>
            )}
          </GoldCard>

          {/* Stats Grid */}
          <Text style={[styles.sectionTitle, { textAlign, writingDirection: direction }]}>{todayStats}</Text>
          <View style={styles.statsGrid}>
            <View style={styles.statCard}>
              <MaterialIcons name="receipt-long" size={24} color="#C5A021" />
              <Text style={styles.statValue}>{stats.totalOrders}</Text>
              <Text style={[styles.statLabel, { writingDirection: direction }]}>{totalOrders}</Text>
            </View>
            <View style={styles.statCard}>
              <MaterialIcons name="pending-actions" size={24} color="#F59E0B" />
              <Text style={styles.statValue}>{stats.pendingOrders}</Text>
              <Text style={[styles.statLabel, { writingDirection: direction }]}>{pendingOrders}</Text>
            </View>
            <View style={styles.statCard}>
              <MaterialIcons name="check-circle" size={24} color="#22C55E" />
              <Text style={styles.statValue}>{stats.completedToday}</Text>
              <Text style={[styles.statLabel, { writingDirection: direction }]}>{completedToday}</Text>
            </View>
            <View style={styles.statCard}>
              <MaterialIcons name="people" size={24} color="#3B82F6" />
              <Text style={styles.statValue}>{stats.totalClients}</Text>
              <Text style={[styles.statLabel, { writingDirection: direction }]}>{totalClients}</Text>
            </View>
          </View>

          {/* Revenue Card */}
          <GoldCard title={revenueLabel}>
            <View style={[styles.revenueRow, { flexDirection: flexDir }]}>
              <View style={styles.revenueItem}>
                <Text style={[styles.revenueLabel, { writingDirection: direction }]}>{thisWeek}</Text>
                <Text style={styles.revenueValue}>{currencySymbol} {stats.weekRevenue.toLocaleString()}</Text>
              </View>
              <View style={[styles.revenueDivider]} />
              <View style={styles.revenueItem}>
                <Text style={[styles.revenueLabel, { writingDirection: direction }]}>{todayLabel}</Text>
                <Text style={styles.revenueValue}>{currencySymbol} {stats.todayRevenue.toLocaleString()}</Text>
              </View>
            </View>
          </GoldCard>

          {/* Quick Actions */}
          <Text style={[styles.sectionTitle, { textAlign, writingDirection: direction }]}>{quickActions}</Text>
          <View style={[styles.actionsRow, { flexDirection: flexDir }]}>
            <TouchableOpacity style={styles.actionCard} activeOpacity={0.7} onPress={() => onNavigate?.('new-order')}>
              <View style={[styles.actionIcon, { backgroundColor: 'rgba(34,197,94,0.15)' }]}>
                <MaterialIcons name="add-shopping-cart" size={24} color="#22C55E" />
              </View>
              <Text style={[styles.actionLabel, { writingDirection: direction }]}>{newOrder}</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.actionCard} activeOpacity={0.7} onPress={() => onNavigate?.('new-client')}>
              <View style={[styles.actionIcon, { backgroundColor: 'rgba(59,130,246,0.15)' }]}>
                <MaterialIcons name="person-add" size={24} color="#3B82F6" />
              </View>
              <Text style={[styles.actionLabel, { writingDirection: direction }]}>{addClient}</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.actionCard} activeOpacity={0.7} onPress={() => onNavigate?.('trader-notifications')}>
              <View style={[styles.actionIcon, { backgroundColor: 'rgba(197,160,33,0.15)' }]}>
                <MaterialIcons name="notifications" size={24} color="#C5A021" />
                {unreadCount > 0 && (
                  <View style={styles.actionBadge}>
                    <Text style={styles.actionBadgeText}>{unreadCount}</Text>
                  </View>
                )}
              </View>
              <Text style={[styles.actionLabel, { writingDirection: direction }]}>{notificationsLabel}</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.actionCard} activeOpacity={0.7} onPress={() => onNavigate?.('trader-reports')}>
              <View style={[styles.actionIcon, { backgroundColor: 'rgba(139,92,246,0.15)' }]}>
                <MaterialIcons name="bar-chart" size={24} color="#8B5CF6" />
              </View>
              <Text style={[styles.actionLabel, { writingDirection: direction }]}>
                {lang === 'ar' ? 'التقارير' : lang === 'fr' ? 'Rapports' : 'Reports'}
              </Text>
            </TouchableOpacity>
          </View>

          {/* Recent Orders */}
          <View style={[styles.sectionHeader, { flexDirection: flexDir }]}>
            <TouchableOpacity activeOpacity={0.7} onPress={() => onNavigate?.('trader-orders')}>
              <Text style={styles.viewAllText}>{viewAll}</Text>
            </TouchableOpacity>
            <Text style={[styles.sectionTitle, { writingDirection: direction }]}>{recentOrders}</Text>
          </View>

          {recentOrdersList.map((order) => (
            <GoldCard key={order.id}>
              <View style={[styles.orderRow, { flexDirection: flexDir }]}>
                <View style={[styles.orderStatus, { backgroundColor: getStatusColor(order.status) + '20' }]}>
                  <Text style={[styles.orderStatusText, { color: getStatusColor(order.status) }]}>
                    {getStatusLabel(order.status)}
                  </Text>
                </View>
                <View style={[styles.orderInfo, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
                  <Text style={[styles.orderClient, { writingDirection: direction }]}>{order.clientName}</Text>
                  <View style={[styles.orderDetails, { flexDirection: flexDir }]}>
                    <Text style={[styles.orderTime, { writingDirection: direction }]}>{order.time}</Text>
                    <Text style={styles.orderDot}>·</Text>
                    <Text style={[styles.orderType, { color: order.type === 'buy' ? '#22C55E' : '#EF4444' }]}>
                      {order.type === 'buy' ? buyLabel : sellLabel}
                    </Text>
                  </View>
                </View>
              </View>
              <View style={[styles.orderFooter, { flexDirection: flexDir }]}>
                <Text style={styles.orderAmount}>{currencySymbol} {order.totalAmount.toLocaleString()}</Text>
                <Text style={[styles.orderGrams, { writingDirection: direction }]}>
                  {order.grams} {gramsLabel} - {lang === 'ar' ? 'عيار' : lang === 'fr' ? 'Carat' : 'Karat'} {order.karat}
                </Text>
              </View>
            </GoldCard>
          ))}

          <View style={{ height: 32 }} />
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#001F3F' },
  safeArea: { flex: 1 },
  appBar: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 12,
    borderBottomWidth: 1, borderBottomColor: 'rgba(248,249,250,0.08)',
  },
  appBarTitle: { fontSize: 18, fontWeight: '700', color: '#F8F9FA' },
  menuBtn: { padding: 8, position: 'relative' },
  badge: {
    position: 'absolute', top: 2, right: 2,
    backgroundColor: '#EF4444', borderRadius: 10,
    minWidth: 18, height: 18, alignItems: 'center', justifyContent: 'center',
    paddingHorizontal: 4,
  },
  badgeText: { fontSize: 10, fontWeight: '700', color: '#FFF' },
  scrollContent: { paddingHorizontal: 16, paddingTop: 16 },

  // Welcome
  welcomeRow: { alignItems: 'center', marginBottom: 16, gap: 8 },
  welcomeText: { fontSize: 20, fontWeight: '700', color: '#F8F9FA' },
  welcomeBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: 'rgba(197,160,33,0.2)', borderRadius: 8,
    paddingHorizontal: 10, paddingVertical: 4,
  },
  welcomeBadgeText: { fontSize: 12, fontWeight: '600', color: '#C5A021' },

  // Price
  priceHeader: { alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 },
  priceLabel: { alignItems: 'center' },
  priceLabelText: { fontSize: 15, fontWeight: '600', color: '#1A1A1B' },
  priceValue: { fontSize: 28, fontWeight: '800', color: '#C5A021' },
  refreshBtn: { padding: 4 },
  liveBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 6 },
  liveDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: '#22C55E' },
  liveText: { fontSize: 10, fontWeight: '700', color: '#22C55E' },

  // Stats
  sectionTitle: { fontSize: 16, fontWeight: '700', color: '#F8F9FA', marginBottom: 12, marginTop: 8 },
  statsGrid: {
    flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 16,
  },
  statCard: {
    flex: 1, minWidth: (SCREEN_WIDTH - 52) / 2,
    backgroundColor: 'rgba(248,249,250,0.06)',
    borderRadius: 14, padding: 16, alignItems: 'center', gap: 6,
    borderWidth: 1, borderColor: 'rgba(248,249,250,0.08)',
  },
  statValue: { fontSize: 24, fontWeight: '800', color: '#F8F9FA' },
  statLabel: { fontSize: 12, fontWeight: '500', color: '#6C737F' },

  // Revenue
  revenueRow: { justifyContent: 'space-around', alignItems: 'center' },
  revenueItem: { alignItems: 'center', gap: 4 },
  revenueLabel: { fontSize: 13, color: '#6C737F' },
  revenueValue: { fontSize: 20, fontWeight: '700', color: '#C5A021' },
  revenueDivider: { width: 1, height: 40, backgroundColor: '#E6E8EA' },

  // Quick Actions
  actionsRow: { gap: 10, marginBottom: 16 },
  actionCard: {
    flex: 1, backgroundColor: 'rgba(248,249,250,0.06)',
    borderRadius: 14, padding: 16, alignItems: 'center', gap: 8,
    borderWidth: 1, borderColor: 'rgba(248,249,250,0.08)',
  },
  actionIcon: {
    width: 48, height: 48, borderRadius: 14, alignItems: 'center', justifyContent: 'center',
    position: 'relative',
  },
  actionLabel: { fontSize: 12, fontWeight: '600', color: '#F8F9FA' },
  actionBadge: {
    position: 'absolute', top: -4, right: -4,
    backgroundColor: '#EF4444', borderRadius: 8,
    minWidth: 16, height: 16, alignItems: 'center', justifyContent: 'center',
    paddingHorizontal: 3,
  },
  actionBadgeText: { fontSize: 9, fontWeight: '700', color: '#FFF' },

  // Section Header
  sectionHeader: { justifyContent: 'space-between', alignItems: 'center', marginBottom: 12, marginTop: 8 },
  viewAllText: { fontSize: 13, fontWeight: '600', color: '#C5A021' },

  // Orders
  orderRow: { justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  orderInfo: { flex: 1 },
  orderClient: { fontSize: 15, fontWeight: '600', color: '#1A1A1B' },
  orderDetails: { alignItems: 'center', gap: 6, marginTop: 2 },
  orderType: { fontSize: 13, fontWeight: '600' },
  orderDot: { fontSize: 13, color: '#6C737F' },
  orderTime: { fontSize: 12, color: '#6C737F' },
  orderStatus: { borderRadius: 8, paddingHorizontal: 10, paddingVertical: 4 },
  orderStatusText: { fontSize: 11, fontWeight: '600' },
  orderFooter: { justifyContent: 'space-between', alignItems: 'center', borderTopWidth: 1, borderTopColor: '#E6E8EA', paddingTop: 8 },
  orderGrams: { fontSize: 13, color: '#6C737F' },
  orderAmount: { fontSize: 15, fontWeight: '700', color: '#C5A021' },
});
