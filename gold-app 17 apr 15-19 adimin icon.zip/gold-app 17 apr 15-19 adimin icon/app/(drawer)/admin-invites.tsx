import React, { useState, useCallback, useEffect } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Alert, Platform, ActivityIndicator, Share } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { GoldCard } from '@/components/gold/GoldCard';
import { GoldButton } from '@/components/gold/GoldButton';
import { useI18n } from '@/i18n';
import { getApiBaseUrl } from '@/constants/oauth';
import * as Auth from '@/lib/_core/auth';
import * as Clipboard from 'expo-clipboard';

interface InviteCode {
  id: number;
  code: string;
  createdBy: number;
  createdByName: string;
  usedBy: number | null;
  usedByName: string | null;
  isUsed: boolean;
  isActive: boolean;
  note: string | null;
  createdAt: string;
  usedAt: string | null;
}

interface AdminInvitesScreenProps {
  onOpenDrawer: () => void;
  onNavigate?: (screen: string) => void;
}

async function getAuthHeaders(): Promise<Record<string, string>> {
  const token = await Auth.getSessionToken();
  if (token) {
    return { Authorization: `Bearer ${token}` };
  }
  return {};
}

async function apiCall(path: string, method: 'GET' | 'POST' = 'GET', body?: any) {
  const baseUrl = getApiBaseUrl();
  const url = `${baseUrl}/api/trpc/${path}`;
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(await getAuthHeaders()),
  };

  const options: RequestInit = { method, headers, credentials: 'include' as any };
  if (body && method === 'POST') {
    options.body = JSON.stringify({ json: body });
  }

  const response = await fetch(url, options);
  const data = await response.json();

  if (data?.error) {
    throw new Error(data.error.message || 'API error');
  }

  return data?.result?.data?.json;
}

export default function AdminInvitesScreen({ onOpenDrawer, onNavigate }: AdminInvitesScreenProps) {
  const { isRTL, textAlign, direction, flexDir, lang } = useI18n();
  const [codes, setCodes] = useState<InviteCode[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  // Translations
  const tr = {
    title: lang === 'ar' ? 'أكواد الدعوة' : lang === 'fr' ? 'Codes d\'invitation' : 'Invite Codes',
    subtitle: lang === 'ar' ? 'إدارة أكواد دعوة التجار' : lang === 'fr' ? 'Gérer les codes d\'invitation des commerçants' : 'Manage trader invite codes',
    createCode: lang === 'ar' ? 'إنشاء كود جديد' : lang === 'fr' ? 'Créer un nouveau code' : 'Create New Code',
    create5Codes: lang === 'ar' ? 'إنشاء 5 أكواد' : lang === 'fr' ? 'Créer 5 codes' : 'Create 5 Codes',
    noCodes: lang === 'ar' ? 'لا توجد أكواد دعوة بعد' : lang === 'fr' ? 'Aucun code d\'invitation' : 'No invite codes yet',
    noCodesDesc: lang === 'ar' ? 'أنشئ أكواد دعوة لتسجيل التجار الجدد' : lang === 'fr' ? 'Créez des codes pour enregistrer de nouveaux commerçants' : 'Create invite codes to register new traders',
    active: lang === 'ar' ? 'نشط' : lang === 'fr' ? 'Actif' : 'Active',
    used: lang === 'ar' ? 'مستخدم' : lang === 'fr' ? 'Utilisé' : 'Used',
    revoked: lang === 'ar' ? 'ملغي' : lang === 'fr' ? 'Révoqué' : 'Revoked',
    copy: lang === 'ar' ? 'نسخ' : lang === 'fr' ? 'Copier' : 'Copy',
    share: lang === 'ar' ? 'مشاركة' : lang === 'fr' ? 'Partager' : 'Share',
    revoke: lang === 'ar' ? 'إلغاء' : lang === 'fr' ? 'Révoquer' : 'Revoke',
    delete: lang === 'ar' ? 'حذف' : lang === 'fr' ? 'Supprimer' : 'Delete',
    createdBy: lang === 'ar' ? 'أنشأه' : lang === 'fr' ? 'Créé par' : 'Created by',
    usedBy: lang === 'ar' ? 'استخدمه' : lang === 'fr' ? 'Utilisé par' : 'Used by',
    copied: lang === 'ar' ? 'تم النسخ!' : lang === 'fr' ? 'Copié !' : 'Copied!',
    confirmRevoke: lang === 'ar' ? 'هل تريد إلغاء هذا الكود؟' : lang === 'fr' ? 'Voulez-vous révoquer ce code ?' : 'Revoke this invite code?',
    confirmDelete: lang === 'ar' ? 'هل تريد حذف هذا الكود نهائياً؟' : lang === 'fr' ? 'Supprimer définitivement ce code ?' : 'Permanently delete this invite code?',
    back: lang === 'ar' ? 'رجوع' : lang === 'fr' ? 'Retour' : 'Back',
    totalCodes: lang === 'ar' ? 'إجمالي الأكواد' : lang === 'fr' ? 'Total des codes' : 'Total Codes',
    activeCodes: lang === 'ar' ? 'أكواد نشطة' : lang === 'fr' ? 'Codes actifs' : 'Active Codes',
    usedCodes: lang === 'ar' ? 'أكواد مستخدمة' : lang === 'fr' ? 'Codes utilisés' : 'Used Codes',
  };

  const loadCodes = useCallback(async () => {
    try {
      const data = await apiCall('invite.list');
      setCodes(data || []);
    } catch (e) {
      console.error('[AdminInvites] Failed to load codes:', e);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    loadCodes();
  }, [loadCodes]);

  const handleCreateCode = async (count: number = 1) => {
    setCreating(true);
    try {
      const result = await apiCall('invite.create', 'POST', { count });
      if (result?.codes) {
        const codesStr = result.codes.join('\n');
        if (Platform.OS !== 'web') {
          Alert.alert(
            tr.createCode,
            `${result.codes.length > 1 ? `${result.codes.length} codes created:\n` : ''}${codesStr}`,
            [
              { text: tr.copy, onPress: () => copyToClipboard(codesStr) },
              { text: 'OK' },
            ]
          );
        }
      }
      await loadCodes();
    } catch (e) {
      console.error('[AdminInvites] Failed to create code:', e);
      if (Platform.OS !== 'web') {
        Alert.alert('Error', 'Failed to create invite code');
      }
    } finally {
      setCreating(false);
    }
  };

  const handleRevoke = async (id: number) => {
    const doRevoke = async () => {
      try {
        await apiCall('invite.revoke', 'POST', { id });
        await loadCodes();
      } catch (e) {
        console.error('[AdminInvites] Failed to revoke code:', e);
      }
    };

    if (Platform.OS !== 'web') {
      Alert.alert(tr.revoke, tr.confirmRevoke, [
        { text: tr.back, style: 'cancel' },
        { text: tr.revoke, style: 'destructive', onPress: doRevoke },
      ]);
    } else {
      doRevoke();
    }
  };

  const handleDelete = async (id: number) => {
    const doDelete = async () => {
      try {
        await apiCall('invite.delete', 'POST', { id });
        await loadCodes();
      } catch (e) {
        console.error('[AdminInvites] Failed to delete code:', e);
      }
    };

    if (Platform.OS !== 'web') {
      Alert.alert(tr.delete, tr.confirmDelete, [
        { text: tr.back, style: 'cancel' },
        { text: tr.delete, style: 'destructive', onPress: doDelete },
      ]);
    } else {
      doDelete();
    }
  };

  const copyToClipboard = async (text: string) => {
    try {
      await Clipboard.setStringAsync(text);
      if (Platform.OS !== 'web') {
        Alert.alert(tr.copied, text);
      }
    } catch {
      // Silently fail
    }
  };

  const handleShare = async (code: string) => {
    try {
      const message = lang === 'ar'
        ? `كود دعوة تطبيق ذهبي للتاجر: ${code}`
        : lang === 'fr'
        ? `Code d'invitation Dhahabi pour commerçant: ${code}`
        : `Dhahabi trader invite code: ${code}`;

      if (Platform.OS !== 'web') {
        await Share.share({ message });
      } else {
        await copyToClipboard(code);
      }
    } catch {
      // Silently fail
    }
  };

  const getStatusBadge = (code: InviteCode) => {
    if (code.isUsed) {
      return { label: tr.used, color: '#6C737F', bg: 'rgba(108,115,127,0.15)' };
    }
    if (!code.isActive) {
      return { label: tr.revoked, color: '#EF4444', bg: 'rgba(239,68,68,0.15)' };
    }
    return { label: tr.active, color: '#22C55E', bg: 'rgba(34,197,94,0.15)' };
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString(lang === 'ar' ? 'ar-SA' : lang === 'fr' ? 'fr-FR' : 'en-US', {
      year: 'numeric', month: 'short', day: 'numeric',
    });
  };

  const activeCodes = codes.filter(c => c.isActive && !c.isUsed);
  const usedCodes = codes.filter(c => c.isUsed);

  return (
    <View style={styles.screen}>
      <SafeAreaView style={styles.safeArea} edges={['top', 'left', 'right']}>
        {/* Header */}
        <View style={[styles.header, { flexDirection: flexDir }]}>
          <TouchableOpacity onPress={onOpenDrawer} style={styles.menuButton} activeOpacity={0.7}>
            <MaterialIcons name={isRTL ? 'arrow-forward' : 'arrow-back'} size={24} color="#C5A021" />
          </TouchableOpacity>
          <View style={[styles.headerTitleContainer, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
            <Text style={[styles.headerTitle, { writingDirection: direction }]}>{tr.title}</Text>
            <Text style={[styles.headerSubtitle, { writingDirection: direction }]}>{tr.subtitle}</Text>
          </View>
          <TouchableOpacity
            onPress={() => onNavigate?.('admin')}
            style={styles.backBtn}
            activeOpacity={0.7}
          >
            <MaterialIcons name={isRTL ? 'arrow-back' : 'arrow-forward'} size={20} color="#C5A021" />
          </TouchableOpacity>
        </View>

        <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
          {/* Stats Summary */}
          <GoldCard>
            <View style={[styles.statsRow, { flexDirection: flexDir }]}>
              <View style={styles.statItem}>
                <Text style={styles.statNumber}>{codes.length}</Text>
                <Text style={[styles.statLabel, { writingDirection: direction }]}>{tr.totalCodes}</Text>
              </View>
              <View style={[styles.statDivider]} />
              <View style={styles.statItem}>
                <Text style={[styles.statNumber, { color: '#22C55E' }]}>{activeCodes.length}</Text>
                <Text style={[styles.statLabel, { writingDirection: direction }]}>{tr.activeCodes}</Text>
              </View>
              <View style={[styles.statDivider]} />
              <View style={styles.statItem}>
                <Text style={[styles.statNumber, { color: '#6C737F' }]}>{usedCodes.length}</Text>
                <Text style={[styles.statLabel, { writingDirection: direction }]}>{tr.usedCodes}</Text>
              </View>
            </View>
          </GoldCard>

          {/* Create Buttons */}
          <View style={[styles.createRow, { flexDirection: flexDir }]}>
            <GoldButton
              title={tr.createCode}
              onPress={() => handleCreateCode(1)}
              loading={creating}
              style={{ flex: 1 }}
            />
            <TouchableOpacity
              onPress={() => handleCreateCode(5)}
              style={styles.create5Btn}
              activeOpacity={0.7}
              disabled={creating}
            >
              <Text style={styles.create5BtnText}>{tr.create5Codes}</Text>
            </TouchableOpacity>
          </View>

          {/* Codes List */}
          {loading ? (
            <View style={styles.loadingContainer}>
              <ActivityIndicator size="large" color="#C5A021" />
            </View>
          ) : codes.length === 0 ? (
            <GoldCard>
              <View style={styles.emptyContainer}>
                <MaterialIcons name="vpn-key" size={48} color="#6C737F" />
                <Text style={[styles.emptyTitle, { writingDirection: direction }]}>{tr.noCodes}</Text>
                <Text style={[styles.emptyDesc, { writingDirection: direction }]}>{tr.noCodesDesc}</Text>
              </View>
            </GoldCard>
          ) : (
            codes.map((code) => {
              const badge = getStatusBadge(code);
              return (
                <GoldCard key={code.id}>
                  <View style={[styles.codeHeader, { flexDirection: flexDir }]}>
                    <Text style={styles.codeText}>{code.code}</Text>
                    <View style={[styles.badge, { backgroundColor: badge.bg }]}>
                      <Text style={[styles.badgeText, { color: badge.color }]}>{badge.label}</Text>
                    </View>
                  </View>

                  {/* Meta info */}
                  <View style={styles.codeMeta}>
                    <Text style={[styles.codeMetaText, { textAlign, writingDirection: direction }]}>
                      {tr.createdBy}: {code.createdByName} • {formatDate(code.createdAt)}
                    </Text>
                    {code.isUsed && code.usedByName && (
                      <Text style={[styles.codeMetaText, { textAlign, writingDirection: direction, color: '#C5A021' }]}>
                        {tr.usedBy}: {code.usedByName} {code.usedAt ? `• ${formatDate(code.usedAt)}` : ''}
                      </Text>
                    )}
                    {code.note && (
                      <Text style={[styles.codeMetaText, { textAlign, writingDirection: direction, fontStyle: 'italic' }]}>
                        {code.note}
                      </Text>
                    )}
                  </View>

                  {/* Actions */}
                  {!code.isUsed && code.isActive && (
                    <View style={[styles.codeActions, { flexDirection: flexDir }]}>
                      <TouchableOpacity
                        onPress={() => copyToClipboard(code.code)}
                        style={[styles.actionBtn, styles.actionBtnCopy]}
                        activeOpacity={0.7}
                      >
                        <MaterialIcons name="content-copy" size={16} color="#C5A021" />
                        <Text style={[styles.actionBtnText, { color: '#C5A021' }]}>{tr.copy}</Text>
                      </TouchableOpacity>
                      <TouchableOpacity
                        onPress={() => handleShare(code.code)}
                        style={[styles.actionBtn, styles.actionBtnShare]}
                        activeOpacity={0.7}
                      >
                        <MaterialIcons name="share" size={16} color="#0A7EA4" />
                        <Text style={[styles.actionBtnText, { color: '#0A7EA4' }]}>{tr.share}</Text>
                      </TouchableOpacity>
                      <TouchableOpacity
                        onPress={() => handleRevoke(code.id)}
                        style={[styles.actionBtn, styles.actionBtnRevoke]}
                        activeOpacity={0.7}
                      >
                        <MaterialIcons name="block" size={16} color="#EF4444" />
                        <Text style={[styles.actionBtnText, { color: '#EF4444' }]}>{tr.revoke}</Text>
                      </TouchableOpacity>
                    </View>
                  )}

                  {(code.isUsed || !code.isActive) && (
                    <View style={[styles.codeActions, { flexDirection: flexDir }]}>
                      <TouchableOpacity
                        onPress={() => handleDelete(code.id)}
                        style={[styles.actionBtn, styles.actionBtnRevoke]}
                        activeOpacity={0.7}
                      >
                        <MaterialIcons name="delete" size={16} color="#EF4444" />
                        <Text style={[styles.actionBtnText, { color: '#EF4444' }]}>{tr.delete}</Text>
                      </TouchableOpacity>
                    </View>
                  )}
                </GoldCard>
              );
            })
          )}

          <View style={{ height: 40 }} />
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#001F3F' },
  safeArea: { flex: 1 },
  header: {
    alignItems: 'center', paddingHorizontal: 16, paddingVertical: 12,
    borderBottomWidth: 1, borderBottomColor: 'rgba(197,160,33,0.15)',
  },
  menuButton: { padding: 8 },
  headerTitleContainer: { flex: 1, marginHorizontal: 12 },
  headerTitle: { fontSize: 18, fontWeight: '700', color: '#C5A021' },
  headerSubtitle: { fontSize: 12, color: '#F8F9FA', opacity: 0.6, marginTop: 2 },
  backBtn: { padding: 8 },
  content: { flex: 1 },
  scrollContent: { paddingHorizontal: 16, paddingTop: 16 },

  // Stats
  statsRow: { justifyContent: 'space-around', alignItems: 'center', paddingVertical: 8 },
  statItem: { alignItems: 'center' },
  statNumber: { fontSize: 24, fontWeight: '800', color: '#C5A021' },
  statLabel: { fontSize: 11, color: '#F8F9FA', opacity: 0.6, marginTop: 4 },
  statDivider: { width: 1, height: 40, backgroundColor: 'rgba(197,160,33,0.2)' },

  // Create
  createRow: { gap: 10, marginBottom: 16, alignItems: 'center' },
  create5Btn: {
    paddingHorizontal: 16, paddingVertical: 12, borderRadius: 10,
    borderWidth: 1.5, borderColor: '#C5A021',
  },
  create5BtnText: { fontSize: 13, fontWeight: '600', color: '#C5A021' },

  // Loading
  loadingContainer: { paddingVertical: 60, alignItems: 'center' },

  // Empty
  emptyContainer: { alignItems: 'center', paddingVertical: 32 },
  emptyTitle: { fontSize: 16, fontWeight: '600', color: '#F8F9FA', marginTop: 16 },
  emptyDesc: { fontSize: 13, color: '#F8F9FA', opacity: 0.6, marginTop: 8, textAlign: 'center' },

  // Code card
  codeHeader: { justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  codeText: { fontSize: 20, fontWeight: '800', color: '#C5A021', letterSpacing: 2, fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace' },
  badge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12 },
  badgeText: { fontSize: 11, fontWeight: '700' },

  // Meta
  codeMeta: { marginBottom: 12 },
  codeMetaText: { fontSize: 12, color: '#F8F9FA', opacity: 0.5, lineHeight: 18 },

  // Actions
  codeActions: { gap: 8, marginTop: 4 },
  actionBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    paddingHorizontal: 12, paddingVertical: 8, borderRadius: 8,
  },
  actionBtnCopy: { backgroundColor: 'rgba(197,160,33,0.1)' },
  actionBtnShare: { backgroundColor: 'rgba(10,126,164,0.1)' },
  actionBtnRevoke: { backgroundColor: 'rgba(239,68,68,0.1)' },
  actionBtnText: { fontSize: 12, fontWeight: '600' },
});
