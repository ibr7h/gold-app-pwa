import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { GoldCard } from '@/components/gold/GoldCard';
import { PriceTag } from '@/components/gold/PriceTag';
import { StateView } from '@/components/gold/StateView';
import { useI18n } from '@/i18n';
import { useGoldPrice } from '@/hooks/useGoldPrice';
import { useSettings } from '@/contexts/SettingsContext';
import { SUPPORTED_CURRENCIES } from '@/services/GoldApiService';

interface PricesScreenProps {
  onOpenDrawer: () => void;
}

export default function PricesScreen({ onOpenDrawer }: PricesScreenProps) {
  const { t, isRTL, textAlign, direction, flexDir, lang } = useI18n();
  const { settings } = useSettings();
  const { data: goldData, loading, error, isLive, refresh, lastUpdated } = useGoldPrice();

  const currencyInfo = SUPPORTED_CURRENCIES.find(c => c.code === settings.preferredCurrency);
  const currencyName = lang === 'ar' ? currencyInfo?.nameAr : lang === 'fr' ? currencyInfo?.nameFr : currencyInfo?.nameEn;

  const formatTime = (ts: number | null) => {
    if (!ts) return '--';
    const d = new Date(ts);
    return d.toLocaleTimeString(isRTL ? 'ar' : 'en', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  };

  const formatDate = (ts: number | null) => {
    if (!ts) return '--';
    const d = new Date(ts);
    return d.toLocaleDateString(isRTL ? 'ar' : 'en', { year: 'numeric', month: 'short', day: 'numeric' });
  };

  return (
    <View style={styles.screen}>
      <SafeAreaView style={styles.safeArea} edges={['top']}>
        <View style={styles.appBar}>
          <TouchableOpacity onPress={refresh} style={styles.refreshBtn} activeOpacity={0.7} disabled={loading}>
            {loading ? (
              <ActivityIndicator size="small" color="#C5A021" />
            ) : (
              <MaterialIcons name="refresh" size={24} color="#C5A021" />
            )}
          </TouchableOpacity>
          <Text style={[styles.appBarTitle, { writingDirection: direction }]}>{t.prices.title}</Text>
          <TouchableOpacity onPress={onOpenDrawer} style={styles.menuBtn} activeOpacity={0.7}>
            <MaterialIcons name="menu" size={24} color="#F8F9FA" />
          </TouchableOpacity>
        </View>

        {error && !goldData ? (
          <StateView type="error" message={error} onRetry={refresh} />
        ) : loading && !goldData ? (
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color="#C5A021" />
          </View>
        ) : goldData ? (
          <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
            {/* Main Live Price Card */}
            <GoldCard style={styles.mainPriceCard}>
              <View style={[styles.mainPriceHeader, { flexDirection: flexDir }]}>
                <View style={[styles.liveBadge, { flexDirection: flexDir, backgroundColor: isLive ? 'rgba(34,197,94,0.12)' : 'rgba(245,158,11,0.12)' }]}>
                  <View style={[styles.liveDot, { backgroundColor: isLive ? '#22C55E' : '#F59E0B' }, isRTL ? { marginLeft: 6 } : { marginRight: 6 }]} />
                  <Text style={[styles.liveText, { color: isLive ? '#22C55E' : '#F59E0B' }]}>
                    {isLive ? t.prices.live : 'Offline'}
                  </Text>
                </View>
                <Text style={[styles.mainPriceTitle, { writingDirection: direction }]}>{t.prices.currentPrice} - 24K</Text>
              </View>
              <View style={[styles.mainPriceBody, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
                <PriceTag value={goldData.pricePerGram24K} change={goldData.change} changePercent={goldData.changePercent} size="large" />
              </View>
              <View style={[styles.mainPriceMeta, { flexDirection: flexDir }]}>
                <Text style={[styles.metaText, { writingDirection: direction }]}>{formatTime(lastUpdated)}</Text>
                <Text style={[styles.metaText, { writingDirection: direction }]}>{goldData.source} • {currencyName}</Text>
              </View>
              {/* High / Low / Open / Close */}
              <View style={[styles.statsRow, { flexDirection: flexDir }]}>
                <View style={styles.statItem}>
                  <Text style={styles.statValue}>{(goldData.high ?? 0).toFixed(2)}</Text>
                  <Text style={[styles.statLabel, { writingDirection: direction }]}>High</Text>
                </View>
                <View style={styles.statDivider} />
                <View style={styles.statItem}>
                  <Text style={styles.statValue}>{(goldData.low ?? 0).toFixed(2)}</Text>
                  <Text style={[styles.statLabel, { writingDirection: direction }]}>Low</Text>
                </View>
                <View style={styles.statDivider} />
                <View style={styles.statItem}>
                  <Text style={styles.statValue}>{(goldData.open ?? 0).toFixed(2)}</Text>
                  <Text style={[styles.statLabel, { writingDirection: direction }]}>Open</Text>
                </View>
                <View style={styles.statDivider} />
                <View style={styles.statItem}>
                  <Text style={styles.statValue}>{(goldData.prevClose ?? 0).toFixed(2)}</Text>
                  <Text style={[styles.statLabel, { writingDirection: direction }]}>Close</Text>
                </View>
              </View>
            </GoldCard>

            {/* Ask / Bid Card */}
            <GoldCard style={styles.askBidCard}>
              <View style={[styles.askBidRow, { flexDirection: flexDir }]}>
                <View style={styles.askBidItem}>
                  <Text style={[styles.askBidLabel, { writingDirection: direction }]}>{t.prices.sell} (Bid)</Text>
                  <Text style={[styles.askBidValue, { color: '#EF4444' }]}>{(goldData.bid ?? 0).toFixed(2)}</Text>
                </View>
                <View style={styles.askBidDivider} />
                <View style={styles.askBidItem}>
                  <Text style={[styles.askBidLabel, { writingDirection: direction }]}>{t.prices.buy} (Ask)</Text>
                  <Text style={[styles.askBidValue, { color: '#22C55E' }]}>{(goldData.ask ?? 0).toFixed(2)}</Text>
                </View>
              </View>
              <Text style={[styles.askBidCurrency, { textAlign }]}>{goldData.currency} / oz</Text>
            </GoldCard>

            {/* Karat Price Table */}
            <GoldCard title={t.prices.priceTable}>
              <View style={[styles.tableHeader, { flexDirection: flexDir }]}>
                <Text style={[styles.tableHeaderText, { flex: 1 }]}>{t.prices.sell}</Text>
                <Text style={[styles.tableHeaderText, { flex: 1 }]}>{t.prices.buy}</Text>
                <Text style={[styles.tableHeaderText, { flex: 0.8 }]}>{t.prices.karat}</Text>
              </View>
              {goldData.karatPrices.map((item, index) => (
                <View key={index} style={[styles.tableRow, { flexDirection: flexDir }, index < goldData.karatPrices.length - 1 && styles.tableBorder]}>
                  <Text style={[styles.tableCell, { flex: 1 }]}>{((item.pricePerGram ?? 0) * 0.98).toFixed(2)}</Text>
                  <Text style={[styles.tableCell, { flex: 1, color: '#C5A021', fontWeight: '600' }]}>{(item.pricePerGram ?? 0).toFixed(2)}</Text>
                  <Text style={[styles.tableCell, { flex: 0.8, fontWeight: '700' }]}>{item.karat}</Text>
                </View>
              ))}
            </GoldCard>

            {/* Individual Karat Cards */}
            {goldData.karatPrices.slice(0, 4).map((item, index) => (
              <GoldCard key={index} style={styles.priceCard}>
                <View style={[styles.priceCardHeader, { flexDirection: flexDir }]}>
                  <PriceTag value={item.pricePerGram} size="medium" />
                  <View style={[styles.priceCardInfo, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
                    <Text style={[styles.priceCardKarat, { writingDirection: direction }]}>{item.karat}</Text>
                    <Text style={[styles.priceCardSource, { writingDirection: direction }]}>{goldData.source} • {goldData.currency}/g</Text>
                  </View>
                </View>
                <View style={[styles.priceCardFooter, { flexDirection: flexDir }]}>
                  <Text style={[styles.priceCardUpdate, { writingDirection: direction }]}>{formatDate(lastUpdated)} {formatTime(lastUpdated)}</Text>
                  <View style={[styles.priceCardBuySell, { flexDirection: flexDir }]}>
                    <Text style={[styles.buySellLabel, { writingDirection: direction }]}>{t.prices.sell}: <Text style={styles.buySellValue}>{((item.pricePerGram ?? 0) * 0.98).toFixed(2)}</Text></Text>
                    <Text style={styles.buySellSep}>|</Text>
                    <Text style={[styles.buySellLabel, { writingDirection: direction }]}>{t.prices.buy}: <Text style={[styles.buySellValue, { color: '#C5A021' }]}>{(item.pricePerGram ?? 0).toFixed(2)}</Text></Text>
                  </View>
                </View>
              </GoldCard>
            ))}

            <View style={{ height: 32 }} />
          </ScrollView>
        ) : (
          <StateView type="empty" message={t.prices.noprices} />
        )}
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#001F3F' },
  safeArea: { flex: 1 },
  appBar: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: 'rgba(248,249,250,0.08)',
  },
  appBarTitle: { fontSize: 18, fontWeight: '700', color: '#F8F9FA' },
  menuBtn: { padding: 8 },
  refreshBtn: { padding: 8 },
  scrollContent: { paddingHorizontal: 16, paddingTop: 16 },
  loadingContainer: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  // Main Price Card
  mainPriceCard: { marginBottom: 16, borderWidth: 1, borderColor: 'rgba(197,160,33,0.25)' },
  mainPriceHeader: { alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 },
  mainPriceTitle: { fontSize: 15, fontWeight: '700', color: '#C5A021' },
  liveBadge: { alignItems: 'center', borderRadius: 12, paddingHorizontal: 10, paddingVertical: 4 },
  liveDot: { width: 6, height: 6, borderRadius: 3 },
  liveText: { fontSize: 11, fontWeight: '600' },
  mainPriceBody: { marginBottom: 12 },
  mainPriceMeta: { justifyContent: 'space-between', paddingTop: 12, borderTopWidth: 1, borderTopColor: '#E6E8EA' },
  metaText: { fontSize: 11, color: '#6C737F' },
  statsRow: { marginTop: 12, paddingTop: 12, borderTopWidth: 1, borderTopColor: '#E6E8EA', alignItems: 'center' },
  statItem: { flex: 1, alignItems: 'center' },
  statValue: { fontSize: 13, fontWeight: '600', color: '#1A1A1B', fontVariant: ['tabular-nums'] },
  statLabel: { fontSize: 10, color: '#6C737F', marginTop: 2 },
  statDivider: { width: 1, height: 28, backgroundColor: '#E6E8EA' },
  // Ask/Bid
  askBidCard: { marginBottom: 16 },
  askBidRow: { alignItems: 'center' },
  askBidItem: { flex: 1, alignItems: 'center' },
  askBidLabel: { fontSize: 12, color: '#6C737F', marginBottom: 4 },
  askBidValue: { fontSize: 18, fontWeight: '700', fontVariant: ['tabular-nums'] },
  askBidDivider: { width: 1, height: 36, backgroundColor: '#E6E8EA' },
  askBidCurrency: { fontSize: 11, color: '#6C737F', marginTop: 8 },
  // Table
  tableHeader: { paddingBottom: 10, borderBottomWidth: 1, borderBottomColor: '#E6E8EA' },
  tableHeaderText: { fontSize: 11, fontWeight: '600', color: '#6C737F', textAlign: 'center' },
  tableRow: { paddingVertical: 12 },
  tableBorder: { borderBottomWidth: 1, borderBottomColor: '#E6E8EA' },
  tableCell: { fontSize: 13, color: '#1A1A1B', textAlign: 'center', fontVariant: ['tabular-nums'] },
  // Price Cards
  priceCard: { marginBottom: 10 },
  priceCardHeader: { alignItems: 'center', justifyContent: 'space-between' },
  priceCardInfo: {},
  priceCardKarat: { fontSize: 16, fontWeight: '700', color: '#1A1A1B' },
  priceCardSource: { fontSize: 12, color: '#6C737F', marginTop: 2 },
  priceCardFooter: { justifyContent: 'space-between', alignItems: 'center', marginTop: 12, paddingTop: 12, borderTopWidth: 1, borderTopColor: '#E6E8EA' },
  priceCardUpdate: { fontSize: 11, color: '#6C737F' },
  priceCardBuySell: { alignItems: 'center' },
  buySellLabel: { fontSize: 12, color: '#6C737F' },
  buySellValue: { fontWeight: '600', color: '#1A1A1B' },
  buySellSep: { color: '#E6E8EA', marginHorizontal: 8 },
});
