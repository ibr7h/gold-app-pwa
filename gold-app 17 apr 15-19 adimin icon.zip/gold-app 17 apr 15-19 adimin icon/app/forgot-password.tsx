import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, TouchableOpacity, KeyboardAvoidingView, Platform, StyleSheet, Alert } from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { GoldButton, GoldInput, GoldCard } from '@/components/gold';
import { useAuth } from '@/contexts/AuthContext';
import { useI18n } from '@/i18n';
import { useRouter } from 'expo-router';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';

export default function ForgotPasswordScreen() {
  const { t, isRTL, textAlign, direction } = useI18n();
  const router = useRouter();
  const {
    isLoading,
    error,
    clearError,
    resetStep,
    resetEmail,
    resetCode,
    sendResetCode,
    verifyResetCode,
    resetPassword,
    resendResetCode,
    cancelReset,
  } = useAuth();

  const [email, setEmail] = useState('');
  const [code, setCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [localError, setLocalError] = useState('');
  const [showDemoCode, setShowDemoCode] = useState(false);

  useEffect(() => {
    clearError();
    return () => {
      cancelReset();
    };
  }, []);

  // Map auth errors to translated messages
  const getErrorMessage = () => {
    if (localError) return localError;
    if (!error) return '';
    switch (error) {
      case 'email_not_found': return t.forgotPassword.errorEmailNotFound;
      case 'invalid_code': return t.forgotPassword.errorInvalidCode;
      case 'reset_expired': return t.forgotPassword.errorEmailRequired;
      default: return t.error;
    }
  };

  // Step 1: Send code
  const handleSendCode = async () => {
    setLocalError('');
    clearError();

    if (!email.trim()) {
      setLocalError(t.forgotPassword.errorEmailRequired);
      return;
    }
    if (!email.includes('@')) {
      setLocalError(t.forgotPassword.errorInvalidEmail);
      return;
    }

    const success = await sendResetCode(email.trim());
    if (success) {
      setShowDemoCode(true);
    }
  };

  // Step 2: Verify code
  const handleVerifyCode = async () => {
    setLocalError('');
    clearError();

    if (!code.trim()) {
      setLocalError(t.forgotPassword.errorCodeRequired);
      return;
    }
    if (code.trim().length !== 6) {
      setLocalError(t.forgotPassword.errorInvalidCode);
      return;
    }

    await verifyResetCode(code.trim());
  };

  // Step 3: Reset password
  const handleResetPassword = async () => {
    setLocalError('');
    clearError();

    if (!newPassword.trim()) {
      setLocalError(t.forgotPassword.errorPasswordRequired);
      return;
    }
    if (newPassword.length < 6) {
      setLocalError(t.forgotPassword.errorPasswordTooShort);
      return;
    }
    if (newPassword !== confirmPassword) {
      setLocalError(t.forgotPassword.errorPasswordMismatch);
      return;
    }

    await resetPassword(newPassword);
  };

  // Handle resend
  const handleResend = async () => {
    setLocalError('');
    clearError();
    const success = await resendResetCode();
    if (success) {
      setShowDemoCode(true);
      Alert.alert(t.forgotPassword.codeSent);
    }
  };

  // Back to login
  const handleBackToLogin = () => {
    cancelReset();
    router.replace('/login');
  };

  // Step indicator
  const steps = [
    { key: 'email', label: t.forgotPassword.step1, icon: 'email' as const },
    { key: 'code', label: t.forgotPassword.step2, icon: 'verified-user' as const },
    { key: 'newPassword', label: t.forgotPassword.step3, icon: 'lock-reset' as const },
  ];

  const currentStepIndex = resetStep === 'email' ? 0 : resetStep === 'code' ? 1 : resetStep === 'newPassword' ? 2 : 2;

  const errorMsg = getErrorMessage();

  return (
    <ScreenContainer edges={['top', 'bottom', 'left', 'right']}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.flex}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
        >
          {/* Header with back button */}
          <View style={[styles.header, { flexDirection: isRTL ? 'row-reverse' : 'row' }]}>
            <TouchableOpacity
              onPress={handleBackToLogin}
              style={styles.backButton}
            >
              <MaterialIcons
                name={isRTL ? 'arrow-forward' : 'arrow-back'}
                size={24}
                color="#F8F9FA"
              />
            </TouchableOpacity>
            <Text style={[styles.headerTitle, { textAlign }]}>
              {t.forgotPassword.title}
            </Text>
            <View style={styles.backButton} />
          </View>

          {/* Step Indicator */}
          {resetStep !== 'success' && (
            <View style={[styles.stepsContainer, { flexDirection: isRTL ? 'row-reverse' : 'row' }]}>
              {steps.map((step, index) => {
                const isActive = index === currentStepIndex;
                const isCompleted = index < currentStepIndex;
                return (
                  <React.Fragment key={step.key}>
                    {index > 0 && (
                      <View style={[styles.stepLine, isCompleted && styles.stepLineCompleted]} />
                    )}
                    <View style={styles.stepItem}>
                      <View style={[
                        styles.stepCircle,
                        isActive && styles.stepCircleActive,
                        isCompleted && styles.stepCircleCompleted,
                      ]}>
                        {isCompleted ? (
                          <MaterialIcons name="check" size={16} color="#001F3F" />
                        ) : (
                          <MaterialIcons name={step.icon} size={16} color={isActive ? '#001F3F' : '#6C737F'} />
                        )}
                      </View>
                      <Text style={[
                        styles.stepLabel,
                        isActive && styles.stepLabelActive,
                        isCompleted && styles.stepLabelCompleted,
                      ]}>
                        {step.label}
                      </Text>
                    </View>
                  </React.Fragment>
                );
              })}
            </View>
          )}

          {/* Step Content */}
          <View style={styles.cardContainer}>
            <GoldCard>
              {/* Step 1: Email */}
              {resetStep === 'email' && (
                <View style={styles.stepContent}>
                  <MaterialIcons name="email" size={48} color="#C5A021" style={styles.stepIcon} />
                  <Text style={[styles.subtitle, { textAlign }]}>
                    {t.forgotPassword.subtitle}
                  </Text>

                  <GoldInput
                    label={t.forgotPassword.email}
                    placeholder={t.forgotPassword.emailPlaceholder}
                    value={email}
                    onChangeText={(val) => { setEmail(val); setLocalError(''); clearError(); }}
                    keyboardType="email-address"
                    autoCapitalize="none"
                    returnKeyType="done"
                    onSubmitEditing={handleSendCode}
                  />

                  {!!errorMsg && (
                    <Text style={styles.errorText}>{errorMsg}</Text>
                  )}

                  <GoldButton
                    title={isLoading ? t.forgotPassword.sending : t.forgotPassword.sendCode}
                    onPress={handleSendCode}
                    loading={isLoading}
                    disabled={isLoading}
                  />

                  {/* Demo hint */}
                  <View style={[styles.demoBox, { direction }]}>
                    <Text style={[styles.demoTitle, { textAlign }]}>{t.login.demoCredentials}</Text>
                    <Text style={[styles.demoText, { textAlign }]}>user@gold.app</Text>
                    <Text style={[styles.demoText, { textAlign }]}>admin@gold.app</Text>
                  </View>
                </View>
              )}

              {/* Step 2: Verification Code */}
              {resetStep === 'code' && (
                <View style={styles.stepContent}>
                  <MaterialIcons name="verified-user" size={48} color="#C5A021" style={styles.stepIcon} />
                  <Text style={[styles.subtitle, { textAlign }]}>
                    {t.forgotPassword.codeHint}
                  </Text>
                  <Text style={[styles.emailHint, { textAlign }]}>
                    {resetEmail}
                  </Text>

                  <GoldInput
                    label={t.forgotPassword.verificationCode}
                    placeholder={t.forgotPassword.codePlaceholder}
                    value={code}
                    onChangeText={(val) => { setCode(val); setLocalError(''); clearError(); }}
                    keyboardType="number-pad"
                    maxLength={6}
                    returnKeyType="done"
                    onSubmitEditing={handleVerifyCode}
                  />

                  {/* Demo: show the code */}
                  {showDemoCode && !!resetCode && (
                    <View style={styles.demoCodeBox}>
                      <Text style={[styles.demoCodeLabel, { textAlign }]}>
                        {'🔑 Demo Code:'}
                      </Text>
                      <Text style={styles.demoCodeValue}>{resetCode}</Text>
                    </View>
                  )}

                  {!!errorMsg && (
                    <Text style={styles.errorText}>{errorMsg}</Text>
                  )}

                  <GoldButton
                    title={isLoading ? t.forgotPassword.verifying : t.forgotPassword.verifyCode}
                    onPress={handleVerifyCode}
                    loading={isLoading}
                    disabled={isLoading}
                  />

                  <TouchableOpacity onPress={handleResend} disabled={isLoading}>
                    <Text style={styles.resendText}>{t.forgotPassword.resendCode}</Text>
                  </TouchableOpacity>
                </View>
              )}

              {/* Step 3: New Password */}
              {resetStep === 'newPassword' && (
                <View style={styles.stepContent}>
                  <MaterialIcons name="lock-reset" size={48} color="#C5A021" style={styles.stepIcon} />
                  <Text style={[styles.subtitle, { textAlign }]}>
                    {t.forgotPassword.newPassword}
                  </Text>

                  <GoldInput
                    label={t.forgotPassword.newPassword}
                    placeholder={t.forgotPassword.newPasswordPlaceholder}
                    value={newPassword}
                    onChangeText={(val) => { setNewPassword(val); setLocalError(''); clearError(); }}
                    secureTextEntry
                  />

                  <GoldInput
                    label={t.forgotPassword.confirmPassword}
                    placeholder={t.forgotPassword.confirmPasswordPlaceholder}
                    value={confirmPassword}
                    onChangeText={(val) => { setConfirmPassword(val); setLocalError(''); clearError(); }}
                    secureTextEntry
                    returnKeyType="done"
                    onSubmitEditing={handleResetPassword}
                  />

                  {!!errorMsg && (
                    <Text style={styles.errorText}>{errorMsg}</Text>
                  )}

                  <GoldButton
                    title={isLoading ? t.forgotPassword.resetting : t.forgotPassword.resetPassword}
                    onPress={handleResetPassword}
                    loading={isLoading}
                    disabled={isLoading}
                  />
                </View>
              )}

              {/* Success */}
              {resetStep === 'success' && (
                <View style={styles.stepContent}>
                  <View style={styles.successIcon}>
                    <MaterialIcons name="check-circle" size={64} color="#22C55E" />
                  </View>
                  <Text style={[styles.successTitle, { textAlign }]}>
                    {t.forgotPassword.success}
                  </Text>
                  <Text style={[styles.successSubtitle, { textAlign }]}>
                    {t.forgotPassword.successSubtitle}
                  </Text>

                  <GoldButton
                    title={t.forgotPassword.backToLogin}
                    onPress={handleBackToLogin}
                  />
                </View>
              )}
            </GoldCard>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  flex: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    paddingHorizontal: 20,
    paddingBottom: 40,
  },
  header: {
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 16,
    marginBottom: 8,
  },
  backButton: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#F8F9FA',
    flex: 1,
    textAlign: 'center',
  },
  stepsContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 24,
    paddingHorizontal: 16,
  },
  stepItem: {
    alignItems: 'center',
    gap: 6,
  },
  stepCircle: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#1A2A40',
    borderWidth: 2,
    borderColor: '#6C737F',
    alignItems: 'center',
    justifyContent: 'center',
  },
  stepCircleActive: {
    backgroundColor: '#C5A021',
    borderColor: '#C5A021',
  },
  stepCircleCompleted: {
    backgroundColor: '#C5A021',
    borderColor: '#C5A021',
  },
  stepLine: {
    flex: 1,
    height: 2,
    backgroundColor: '#6C737F',
    marginHorizontal: 4,
    marginBottom: 20,
  },
  stepLineCompleted: {
    backgroundColor: '#C5A021',
  },
  stepLabel: {
    fontSize: 11,
    color: '#6C737F',
    fontWeight: '500',
  },
  stepLabelActive: {
    color: '#C5A021',
    fontWeight: '700',
  },
  stepLabelCompleted: {
    color: '#C5A021',
  },
  cardContainer: {
    flex: 1,
    justifyContent: 'center',
  },
  stepContent: {
    gap: 16,
  },
  stepIcon: {
    alignSelf: 'center',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 14,
    color: '#6C737F',
    lineHeight: 22,
    marginBottom: 8,
  },
  emailHint: {
    fontSize: 15,
    fontWeight: '600',
    color: '#C5A021',
    marginBottom: 4,
  },
  errorText: {
    fontSize: 13,
    color: '#EF4444',
    textAlign: 'center',
    marginTop: -8,
  },
  demoBox: {
    backgroundColor: '#001F3F',
    borderRadius: 10,
    padding: 12,
    borderWidth: 1,
    borderColor: 'rgba(197, 160, 33, 0.3)',
    marginTop: 8,
  },
  demoTitle: {
    fontSize: 12,
    fontWeight: '600',
    color: '#C5A021',
    marginBottom: 6,
  },
  demoText: {
    fontSize: 13,
    color: '#F8F9FA',
    marginBottom: 2,
  },
  demoCodeBox: {
    backgroundColor: 'rgba(197, 160, 33, 0.15)',
    borderRadius: 10,
    padding: 14,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(197, 160, 33, 0.4)',
  },
  demoCodeLabel: {
    fontSize: 12,
    color: '#C5A021',
    marginBottom: 4,
  },
  demoCodeValue: {
    fontSize: 28,
    fontWeight: '800',
    color: '#C5A021',
    letterSpacing: 8,
  },
  resendText: {
    fontSize: 14,
    color: '#C5A021',
    textAlign: 'center',
    fontWeight: '600',
    marginTop: 4,
  },
  successIcon: {
    alignSelf: 'center',
    marginBottom: 8,
  },
  successTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: '#1A1A1B',
    marginBottom: 4,
  },
  successSubtitle: {
    fontSize: 14,
    color: '#6C737F',
    lineHeight: 22,
    marginBottom: 16,
  },
});
