import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, KeyboardAvoidingView, Platform, ScrollView, TouchableOpacity, ActivityIndicator, TextInput, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { useAuth } from '@/contexts/AuthContext';
import { GoldButton } from '@/components/gold/GoldButton';
import { useI18n } from '@/i18n';
import { LANGUAGE_LABELS, type Language } from '@/i18n';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { APP_VARIANT, currentVariantConfig } from '@/constants/appVariant';

const PENDING_INVITE_CODE_KEY = 'gold_pending_invite_code';

export default function LoginScreen() {
  const {
    login, isLoading, error, clearError,
    biometricType, biometricAvailable, biometricEnrolled, biometricEnabled,
    loginWithBiometric,
  } = useAuth();
  const { t, isRTL, textAlign, direction, setLanguage, lang } = useI18n();
  const [biometricLoading, setBiometricLoading] = useState(false);
  const [inviteCode, setInviteCode] = useState('');
  const [inviteCodeError, setInviteCodeError] = useState<string | null>(null);
  const [validatingCode, setValidatingCode] = useState(false);

  // If biometric is enabled, show biometric prompt first
  const canUseBiometric = biometricEnabled && biometricAvailable && biometricEnrolled;

  // Auto-attempt biometric on mount if enabled
  useEffect(() => {
    if (canUseBiometric) {
      handleBiometricLogin();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [canUseBiometric]);

  const handleOAuthLogin = async () => {
    clearError();
    setInviteCodeError(null);

    // Trader variant: validate invite code first
    if (APP_VARIANT === 'trader') {
      const code = inviteCode.trim().toUpperCase();
      if (!code) {
        setInviteCodeError(t.login.inviteCodeRequired);
        return;
      }

      setValidatingCode(true);
      try {
        const response = await fetch(getApiUrl('/api/trpc/invite.validate'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ json: { code } }),
        });
        const data = await response.json();
        const valid = data?.result?.data?.json?.valid;
        if (!valid) {
          setInviteCodeError(t.login.inviteCodeInvalid);
          setValidatingCode(false);
          return;
        }
      } catch (e) {
        console.error('[Login] Failed to validate invite code:', e);
        setInviteCodeError(t.login.inviteCodeInvalid);
        setValidatingCode(false);
        return;
      }
      setValidatingCode(false);

      // Store invite code for after OAuth completes
      await AsyncStorage.setItem(PENDING_INVITE_CODE_KEY, code);
    }

    // Start OAuth login flow
    login('', '');
  };

  const handleBiometricLogin = async () => {
    setBiometricLoading(true);
    clearError();
    try {
      await loginWithBiometric();
    } catch {
      // Silently handle
    }
    setBiometricLoading(false);
  };

  const biometricIcon = biometricType === 'face' ? 'face' as const : 'fingerprint' as const;

  const getBiometricLabel = (): string => {
    if (biometricType === 'face') return t.biometric.loginWithFaceId;
    if (biometricType === 'fingerprint') return t.biometric.loginWithFingerprint;
    return t.biometric.loginWithBiometric;
  };

  const getErrorMessage = (): string => {
    if (!error) return '';
    if (error === 'invalid_credentials') return t.login.errorInvalidCredentials;
    if (error === 'login_failed') return t.login.errorInvalidCredentials;
    if (error === 'biometric_failed') return t.biometric.authFailed;
    return error;
  };

  const languages: Language[] = ['ar', 'en', 'fr'];

  // Variant-specific subtitle
  const getVariantSubtitle = (): string => {
    if (APP_VARIANT === 'trader') {
      return lang === 'ar' ? 'نسخة التاجر' : lang === 'fr' ? 'Version Commerçant' : 'Trader Edition';
    }
    if (APP_VARIANT === 'admin') {
      return lang === 'ar' ? 'لوحة الإدارة' : lang === 'fr' ? 'Panneau d\'Administration' : 'Admin Panel';
    }
    return t.appSubtitle;
  };

  // Variant-specific icon
  const getVariantIcon = (): string => {
    if (APP_VARIANT === 'trader') return 'store';
    if (APP_VARIANT === 'admin') return 'admin-panel-settings';
    return 'ذ';
  };

  // Variant-specific login info text
  const getLoginInfoText = (): string => {
    if (APP_VARIANT === 'admin') {
      return lang === 'ar' ? 'سجّل دخولك بحساب المسؤول المعتمد' :
             lang === 'fr' ? 'Connectez-vous avec votre compte administrateur autorisé' :
             'Sign in with your authorized admin account';
    }
    if (APP_VARIANT === 'trader') {
      return t.login.traderLoginInfo;
    }
    return t.login.userLoginInfo;
  };

  return (
    <View style={styles.screen}>
      <SafeAreaView style={styles.safeArea}>
        <KeyboardAvoidingView
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          style={styles.flex}
        >
          <ScrollView
            contentContainerStyle={styles.scrollContent}
            keyboardShouldPersistTaps="handled"
          >
            {/* Language Switcher */}
            <View style={styles.langSwitcher}>
              {languages.map(l => (
                <TouchableOpacity
                  key={l}
                  onPress={() => setLanguage(l)}
                  style={[styles.langBtn, lang === l && styles.langBtnActive]}
                  activeOpacity={0.7}
                >
                  <Text style={[styles.langBtnText, lang === l && styles.langBtnTextActive]}>
                    {LANGUAGE_LABELS[l]}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>

            {/* Logo / Title */}
            <View style={styles.logoContainer}>
              <View style={[
                styles.logoCircle,
                APP_VARIANT === 'admin' && styles.logoCircleAdmin,
                APP_VARIANT === 'trader' && styles.logoCircleTrader,
              ]}>
                {APP_VARIANT === 'user' ? (
                  <Text style={styles.logoText}>ذ</Text>
                ) : (
                  <MaterialIcons
                    name={getVariantIcon() as any}
                    size={40}
                    color="#001F3F"
                  />
                )}
              </View>
              <Text style={styles.appTitle}>{currentVariantConfig.appName}</Text>
              <Text style={[styles.appSubtitle, { writingDirection: direction }]}>
                {getVariantSubtitle()}
              </Text>
            </View>

            {/* Login Card */}
            <View style={styles.card}>
              {/* Biometric Login Section */}
              {canUseBiometric && (
                <View style={styles.biometricSection}>
                  <TouchableOpacity
                    onPress={handleBiometricLogin}
                    style={styles.biometricButton}
                    activeOpacity={0.7}
                    disabled={biometricLoading}
                  >
                    <View style={styles.biometricIconCircle}>
                      <MaterialIcons name={biometricIcon} size={48} color="#001F3F" />
                    </View>
                    <Text style={[styles.biometricLabel, { writingDirection: direction }]}>
                      {biometricLoading ? t.loading : getBiometricLabel()}
                    </Text>
                    <Text style={[styles.biometricSubLabel, { writingDirection: direction }]}>
                      {t.biometric.subtitle}
                    </Text>
                  </TouchableOpacity>

                  {/* Divider */}
                  <View style={styles.dividerRow}>
                    <View style={styles.dividerLine} />
                    <Text style={[styles.dividerText, { writingDirection: direction }]}>
                      {t.biometric.orLoginWith}
                    </Text>
                    <View style={styles.dividerLine} />
                  </View>
                </View>
              )}

              {error && (
                <View style={styles.errorBanner}>
                  <Text style={[styles.errorBannerText, { textAlign, writingDirection: direction }]}>
                    {getErrorMessage()}
                  </Text>
                </View>
              )}

              {/* Invite Code for Trader variant */}
              {APP_VARIANT === 'trader' && (
                <View style={styles.inviteCodeSection}>
                  <Text style={[styles.inputLabel, { textAlign, writingDirection: direction }]}>
                    {t.login.inviteCode}
                  </Text>
                  <TextInput
                    style={[
                      styles.inviteCodeInput,
                      inviteCodeError && styles.inviteCodeInputError,
                      { textAlign: 'center' },
                    ]}
                    value={inviteCode}
                    onChangeText={(text) => {
                      setInviteCode(text.toUpperCase());
                      setInviteCodeError(null);
                    }}
                    placeholder={t.login.inviteCodePlaceholder}
                    placeholderTextColor="#9CA3AF"
                    autoCapitalize="characters"
                    autoCorrect={false}
                    returnKeyType="done"
                  />
                  {inviteCodeError && (
                    <Text style={[styles.inviteCodeErrorText, { textAlign, writingDirection: direction }]}>
                      {inviteCodeError}
                    </Text>
                  )}
                </View>
              )}

              {/* OAuth Login Button */}
              <GoldButton
                title={isLoading ? t.login.loggingIn : validatingCode ? t.login.validatingCode : t.login.button}
                onPress={handleOAuthLogin}
                loading={isLoading || validatingCode}
                style={{ marginTop: 4 }}
              />

              {isLoading && (
                <View style={styles.loadingHint}>
                  <ActivityIndicator size="small" color="#C5A021" />
                  <Text style={[styles.loadingHintText, { writingDirection: direction }]}>
                    {lang === 'ar' ? 'جاري التحويل لصفحة تسجيل الدخول...' :
                     lang === 'fr' ? 'Redirection vers la page de connexion...' :
                     'Redirecting to login page...'}
                  </Text>
                </View>
              )}

              <Text style={[styles.infoText, { textAlign, writingDirection: direction }]}>
                {getLoginInfoText()}
              </Text>
            </View>
          </ScrollView>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </View>
  );
}

// Helper to get API URL
function getApiUrl(path: string): string {
  const { Platform: RNPlatform } = require('react-native');
  if (RNPlatform.OS === 'web' && typeof window !== 'undefined') {
    const { protocol, hostname } = window.location;
    const apiHostname = hostname.replace(/^8081-/, '3000-');
    if (apiHostname !== hostname) {
      return `${protocol}//${apiHostname}${path}`;
    }
  }
  const apiBase = process.env.EXPO_PUBLIC_API_BASE_URL || '';
  if (apiBase) return `${apiBase.replace(/\/$/, '')}${path}`;
  return path;
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#001F3F' },
  safeArea: { flex: 1 },
  flex: { flex: 1 },
  scrollContent: { flexGrow: 1, justifyContent: 'center', paddingHorizontal: 24, paddingVertical: 32 },
  langSwitcher: { flexDirection: 'row', justifyContent: 'center', marginBottom: 24, gap: 8 },
  langBtn: {
    paddingHorizontal: 16, paddingVertical: 8, borderRadius: 20,
    backgroundColor: 'rgba(248,249,250,0.08)', borderWidth: 1, borderColor: 'rgba(248,249,250,0.15)',
  },
  langBtnActive: { backgroundColor: 'rgba(197,160,33,0.2)', borderColor: '#C5A021' },
  langBtnText: { fontSize: 13, color: '#F8F9FA', fontWeight: '500' },
  langBtnTextActive: { color: '#C5A021', fontWeight: '600' },
  logoContainer: { alignItems: 'center', marginBottom: 32 },
  logoCircle: {
    width: 80, height: 80, borderRadius: 40,
    backgroundColor: '#C5A021', alignItems: 'center', justifyContent: 'center', marginBottom: 16,
  },
  logoCircleAdmin: {
    backgroundColor: '#EF4444',
  },
  logoCircleTrader: {
    backgroundColor: '#C5A021',
  },
  logoText: { fontSize: 36, fontWeight: '800', color: '#001F3F' },
  appTitle: { fontSize: 28, fontWeight: '800', color: '#C5A021', letterSpacing: 1 },
  appSubtitle: { fontSize: 14, color: '#F8F9FA', marginTop: 4, opacity: 0.7 },
  card: {
    backgroundColor: '#F8F9FA', borderRadius: 16, padding: 24,
    borderWidth: 1, borderColor: '#E6E8EA',
  },
  errorBanner: {
    backgroundColor: 'rgba(239,68,68,0.1)', borderRadius: 8, padding: 12, marginBottom: 16,
    borderWidth: 1, borderColor: 'rgba(239,68,68,0.3)',
  },
  errorBannerText: { fontSize: 13, color: '#EF4444' },

  // Biometric section
  biometricSection: { alignItems: 'center', marginBottom: 16 },
  biometricButton: { alignItems: 'center', paddingVertical: 16 },
  biometricIconCircle: {
    width: 88, height: 88, borderRadius: 44,
    backgroundColor: 'rgba(197,160,33,0.15)', alignItems: 'center', justifyContent: 'center',
    borderWidth: 2, borderColor: '#C5A021', marginBottom: 16,
  },
  biometricLabel: { fontSize: 16, fontWeight: '700', color: '#1A1A1B', marginBottom: 4 },
  biometricSubLabel: { fontSize: 13, color: '#6C737F' },

  // Divider
  dividerRow: { flexDirection: 'row', alignItems: 'center', marginVertical: 20, width: '100%' },
  dividerLine: { flex: 1, height: 1, backgroundColor: '#E6E8EA' },
  dividerText: { paddingHorizontal: 12, fontSize: 12, color: '#6C737F' },

  // Invite code
  inviteCodeSection: { marginBottom: 16 },
  inputLabel: { fontSize: 14, fontWeight: '600', color: '#1A1A1B', marginBottom: 8 },
  inviteCodeInput: {
    backgroundColor: '#FFFFFF', borderRadius: 12, padding: 14,
    borderWidth: 1.5, borderColor: '#E6E8EA',
    fontSize: 18, fontWeight: '700', color: '#1A1A1B',
    letterSpacing: 2,
  },
  inviteCodeInputError: { borderColor: '#EF4444' },
  inviteCodeErrorText: { fontSize: 12, color: '#EF4444', marginTop: 6 },

  // Loading hint
  loadingHint: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: 8, marginTop: 16,
  },
  loadingHintText: { fontSize: 13, color: '#6C737F' },

  // Info text
  infoText: {
    fontSize: 12, color: '#9CA3AF', marginTop: 16, lineHeight: 18,
  },
});
