import { useState, useEffect, useCallback, useRef } from 'react';
import { fetchGoldPrice, GoldPriceData } from '@/services/GoldApiService';
import { useApiKeys } from '@/contexts/ApiKeyContext';
import { useSettings } from '@/contexts/SettingsContext';

interface UseGoldPriceResult {
  data: GoldPriceData | null;
  loading: boolean;
  error: string | null;
  isLive: boolean;
  lastUpdated: number | null;
  refresh: () => Promise<void>;
}

export function useGoldPrice(currencyOverride?: string): UseGoldPriceResult {
  const [data, setData] = useState<GoldPriceData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { keys, getActiveKey, markKeyStatus, rotateToNextKey } = useApiKeys();
  const { settings } = useSettings();
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const mountedRef = useRef(true);

  const currency = currencyOverride || settings.preferredCurrency;

  const fetchData = useCallback(async (forceRefresh = false) => {
    if (!mountedRef.current) return;
    setLoading(true);
    setError(null);

    try {
      const activeKey = getActiveKey();
      const result = await fetchGoldPrice({
        currency,
        forceRefresh,
        apiKey: activeKey?.key,
        onKeyFailed: (failedKey, err) => {
          const entry = keys.find(k => k.key === failedKey);
          if (entry) {
            const status = err.includes('quota') ? 'quota_exceeded' as const
              : err.includes('invalid') || err.includes('401') ? 'invalid' as const
              : 'unknown' as const;
            markKeyStatus(entry.id, status, err);
          }
        },
        getNextKey: () => {
          const activeEntry = keys.find(k => k.key === getActiveKey()?.key);
          if (!activeEntry) return null;
          const next = rotateToNextKey(activeEntry.id);
          return next?.key || null;
        },
      });

      if (mountedRef.current) {
        setData(result);
        if (!result.isLive) {
          setError('offline');
        }
        // Mark successful key
        if (result.isLive) {
          const activeEntry = getActiveKey();
          if (activeEntry) {
            markKeyStatus(activeEntry.id, 'active');
          }
        }
      }
    } catch (e: any) {
      if (mountedRef.current) {
        setError(e.message || 'Failed to fetch prices');
      }
    } finally {
      if (mountedRef.current) {
        setLoading(false);
      }
    }
  }, [currency, keys, getActiveKey, markKeyStatus, rotateToNextKey]);

  // Initial fetch
  useEffect(() => {
    mountedRef.current = true;
    fetchData();
    return () => { mountedRef.current = false; };
  }, [currency]);

  // Auto-refresh
  useEffect(() => {
    if (settings.autoRefreshInterval > 0) {
      intervalRef.current = setInterval(() => {
        fetchData(true);
      }, settings.autoRefreshInterval * 1000);
    }
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [settings.autoRefreshInterval, fetchData]);

  const refresh = useCallback(async () => {
    await fetchData(true);
  }, [fetchData]);

  return {
    data,
    loading,
    error,
    isLive: data?.isLive ?? false,
    lastUpdated: data?.timestamp ?? null,
    refresh,
  };
}
