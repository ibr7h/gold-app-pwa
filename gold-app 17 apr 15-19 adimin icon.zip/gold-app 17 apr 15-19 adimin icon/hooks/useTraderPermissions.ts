import { useState, useEffect, useCallback } from 'react';
import { getApiBaseUrl } from '@/constants/oauth';
import * as Auth from '@/lib/_core/auth';
import { useAuth } from '@/contexts/AuthContext';

export interface TraderPermissions {
  canViewOrders: boolean;
  canCreateOrders: boolean;
  canEditOrders: boolean;
  canDeleteOrders: boolean;
  canViewClients: boolean;
  canCreateClients: boolean;
  canEditClients: boolean;
  canDeleteClients: boolean;
  canViewReports: boolean;
  canExportReports: boolean;
  canUseMessaging: boolean;
}

const ALL_PERMISSIONS: TraderPermissions = {
  canViewOrders: true,
  canCreateOrders: true,
  canEditOrders: true,
  canDeleteOrders: true,
  canViewClients: true,
  canCreateClients: true,
  canEditClients: true,
  canDeleteClients: true,
  canViewReports: true,
  canExportReports: true,
  canUseMessaging: true,
};

const DEFAULT_PERMISSIONS: TraderPermissions = {
  canViewOrders: true,
  canCreateOrders: true,
  canEditOrders: true,
  canDeleteOrders: false,
  canViewClients: true,
  canCreateClients: true,
  canEditClients: true,
  canDeleteClients: false,
  canViewReports: true,
  canExportReports: true,
  canUseMessaging: true,
};

export function useTraderPermissions() {
  const { user } = useAuth();
  const [permissions, setPermissions] = useState<TraderPermissions>(
    user?.role === 'admin' ? ALL_PERMISSIONS : DEFAULT_PERMISSIONS
  );
  const [loading, setLoading] = useState(true);

  const fetchPermissions = useCallback(async () => {
    // Admins always get all permissions
    if (user?.role === 'admin') {
      setPermissions(ALL_PERMISSIONS);
      setLoading(false);
      return;
    }

    // Only traders need to fetch permissions from server
    if (user?.role !== 'trader') {
      setPermissions(DEFAULT_PERMISSIONS);
      setLoading(false);
      return;
    }

    try {
      const token = await Auth.getSessionToken();
      const baseUrl = getApiBaseUrl();
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
      };
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }

      const response = await fetch(`${baseUrl}/api/trpc/permissions.my`, {
        method: 'GET',
        headers,
        credentials: 'include' as any,
      });

      const data = await response.json();
      if (data?.result?.data?.json) {
        setPermissions(data.result.data.json);
      }
    } catch (e) {
      console.error('[useTraderPermissions] Failed to fetch permissions:', e);
      // Fall back to defaults on error
    } finally {
      setLoading(false);
    }
  }, [user?.role]);

  useEffect(() => {
    fetchPermissions();
  }, [fetchPermissions]);

  const checkPermission = useCallback((key: keyof TraderPermissions): boolean => {
    return permissions[key] === true;
  }, [permissions]);

  return {
    permissions,
    loading,
    checkPermission,
    refresh: fetchPermissions,
  };
}
