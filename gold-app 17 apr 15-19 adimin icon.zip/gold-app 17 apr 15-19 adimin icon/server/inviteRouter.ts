import { eq, desc, and } from "drizzle-orm";
import { z } from "zod";
import { adminProcedure, publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { getDb, validateInviteCode, useInviteCode } from "./db";
import { inviteCodes, users, notifications } from "../drizzle/schema";
import { TRPCError } from "@trpc/server";
import crypto from "crypto";

function generateCode(): string {
  // Generate a readable 8-character code like "GOLD-XXXX"
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // no I, O, 0, 1 to avoid confusion
  let code = "GOLD-";
  for (let i = 0; i < 6; i++) {
    code += chars[crypto.randomInt(chars.length)];
  }
  return code;
}

// Helper: send notification to all admin users
async function notifyAdmins(title: string, message: string, referenceId?: number) {
  const db = await getDb();
  if (!db) return;

  const adminUsers = await db.select().from(users).where(eq(users.role, "admin"));

  for (const admin of adminUsers) {
    await db.insert(notifications).values({
      userId: admin.id,
      type: "system",
      title,
      message,
      referenceId: referenceId ?? null,
    });
  }
}

export const inviteRouter = router({
  // ===== Public: Validate an invite code (before login) =====
  validate: publicProcedure
    .input(z.object({ code: z.string().min(1) }))
    .mutation(async ({ input }) => {
      const result = await validateInviteCode(input.code.toUpperCase().trim());
      return { valid: result.valid };
    }),

  // ===== Protected: Claim an invite code after OAuth login =====
  claim: protectedProcedure
    .input(z.object({ code: z.string().min(1) }))
    .mutation(async ({ ctx, input }) => {
      const code = input.code.toUpperCase().trim();
      const result = await validateInviteCode(code);

      if (!result.valid || !result.codeId) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Invalid or expired invite code" });
      }

      // Update user role to trader
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

      await db.update(users)
        .set({ role: "trader" })
        .where(eq(users.id, ctx.user.id));

      // Mark invite code as used
      await useInviteCode(result.codeId, ctx.user.id);

      // Create default trader permissions (all enabled)
      try {
        const { traderPermissions } = await import("../drizzle/schema");
        const existing = await db.select().from(traderPermissions)
          .where(eq(traderPermissions.traderId, ctx.user.id)).limit(1);
        if (existing.length === 0) {
          await db.insert(traderPermissions).values({
            traderId: ctx.user.id,
          });
        }
      } catch {
        // traderPermissions table may not exist yet, skip silently
      }

      // Notify all admins about the new trader registration
      const traderName = ctx.user.name || ctx.user.email || `User #${ctx.user.id}`;
      await notifyAdmins(
        "تاجر جديد | New Trader",
        `${traderName} registered as a trader using invite code: ${code}`,
        ctx.user.id,
      );

      return { success: true, role: "trader" as const };
    }),

  // ===== Admin: List all invite codes =====
  list: adminProcedure.query(async () => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

    const codes = await db.select().from(inviteCodes).orderBy(desc(inviteCodes.createdAt));

    // Enrich with user names
    const allUsers = await db.select().from(users);
    const userMap = new Map(allUsers.map(u => [u.id, u]));

    return codes.map(c => ({
      id: c.id,
      code: c.code,
      createdBy: c.createdBy,
      createdByName: userMap.get(c.createdBy)?.name || userMap.get(c.createdBy)?.email || `User #${c.createdBy}`,
      usedBy: c.usedBy,
      usedByName: c.usedBy ? (userMap.get(c.usedBy)?.name || userMap.get(c.usedBy)?.email || `User #${c.usedBy}`) : null,
      isUsed: c.isUsed,
      isActive: c.isActive,
      note: c.note,
      createdAt: c.createdAt,
      usedAt: c.usedAt,
    }));
  }),

  // ===== Admin: Create a new invite code =====
  create: adminProcedure
    .input(z.object({
      note: z.string().optional(),
      count: z.number().min(1).max(20).default(1),
    }).optional())
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

      const count = input?.count ?? 1;
      const createdCodes: string[] = [];

      for (let i = 0; i < count; i++) {
        const code = generateCode();
        await db.insert(inviteCodes).values({
          code,
          createdBy: ctx.user.id,
          note: input?.note || null,
        });
        createdCodes.push(code);
      }

      return { codes: createdCodes };
    }),

  // ===== Admin: Revoke (deactivate) an invite code =====
  revoke: adminProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

      await db.update(inviteCodes)
        .set({ isActive: false })
        .where(eq(inviteCodes.id, input.id));

      return { success: true };
    }),

  // ===== Admin: Delete an invite code =====
  delete: adminProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

      await db.delete(inviteCodes).where(eq(inviteCodes.id, input.id));

      return { success: true };
    }),
});
