import { z } from "zod";
import { router, protectedProcedure, adminProcedure } from "./_core/trpc";
import { getDb } from "./db";
import { traderLocations, users, adminSettings } from "../drizzle/schema";
import { eq } from "drizzle-orm";
import { TRPCError } from "@trpc/server";

function dbOrThrow(db: Awaited<ReturnType<typeof getDb>>) {
  if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });
  return db;
}

export const locationRouter = router({
  // ===== Trader endpoints =====

  // Get my shop location (trader only)
  myLocation: protectedProcedure.query(async ({ ctx }) => {
    const db = dbOrThrow(await getDb());
    const [location] = await db
      .select()
      .from(traderLocations)
      .where(eq(traderLocations.traderId, ctx.user.id))
      .limit(1);
    return location ?? null;
  }),

  // Set or update my shop location (trader only)
  setLocation: protectedProcedure
    .input(
      z.object({
        shopName: z.string().min(1).max(255),
        address: z.string().min(1),
        city: z.string().max(100).optional(),
        latitude: z.number().min(-90).max(90),
        longitude: z.number().min(-180).max(180),
        phone: z.string().max(20).optional(),
        whatsapp: z.string().max(20).optional(),
        workingHours: z.string().max(255).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = dbOrThrow(await getDb());
      const [existing] = await db
        .select()
        .from(traderLocations)
        .where(eq(traderLocations.traderId, ctx.user.id))
        .limit(1);

      if (existing) {
        await db
          .update(traderLocations)
          .set({
            shopName: input.shopName,
            address: input.address,
            city: input.city ?? null,
            latitude: String(input.latitude),
            longitude: String(input.longitude),
            phone: input.phone ?? null,
            whatsapp: input.whatsapp ?? null,
            workingHours: input.workingHours ?? null,
          })
          .where(eq(traderLocations.traderId, ctx.user.id));
        return { success: true, action: "updated" as const };
      } else {
        await db.insert(traderLocations).values({
          traderId: ctx.user.id,
          shopName: input.shopName,
          address: input.address,
          city: input.city ?? null,
          latitude: String(input.latitude),
          longitude: String(input.longitude),
          phone: input.phone ?? null,
          whatsapp: input.whatsapp ?? null,
          workingHours: input.workingHours ?? null,
        });
        return { success: true, action: "created" as const };
      }
    }),

  // Toggle visibility of my shop location
  toggleVisibility: protectedProcedure.mutation(async ({ ctx }) => {
    const db = dbOrThrow(await getDb());
    const [location] = await db
      .select()
      .from(traderLocations)
      .where(eq(traderLocations.traderId, ctx.user.id))
      .limit(1);

    if (!location) throw new TRPCError({ code: "NOT_FOUND", message: "No location set" });

    await db
      .update(traderLocations)
      .set({ isVisible: !location.isVisible })
      .where(eq(traderLocations.traderId, ctx.user.id));

    return { isVisible: !location.isVisible };
  }),

  // ===== User endpoints =====

  // Get all visible trader locations (for users to find nearby traders)
  nearbyTraders: protectedProcedure
    .input(
      z.object({
        latitude: z.number().min(-90).max(90),
        longitude: z.number().min(-180).max(180),
        radiusKm: z.number().min(1).max(500).default(50),
      })
    )
    .query(async ({ input }) => {
      const db = dbOrThrow(await getDb());
      const locations = await db
        .select({
          id: traderLocations.id,
          traderId: traderLocations.traderId,
          shopName: traderLocations.shopName,
          address: traderLocations.address,
          city: traderLocations.city,
          latitude: traderLocations.latitude,
          longitude: traderLocations.longitude,
          phone: traderLocations.phone,
          whatsapp: traderLocations.whatsapp,
          workingHours: traderLocations.workingHours,
          traderName: users.name,
        })
        .from(traderLocations)
        .innerJoin(users, eq(traderLocations.traderId, users.id))
        .where(eq(traderLocations.isVisible, true));

      // Calculate distance using Haversine formula
      const R = 6371;
      const toRad = (deg: number) => (deg * Math.PI) / 180;

      type LocRow = (typeof locations)[number];
      const withDistance = locations.map((loc: LocRow) => {
        const lat1 = toRad(input.latitude);
        const lat2 = toRad(Number(loc.latitude));
        const dLat = toRad(Number(loc.latitude) - input.latitude);
        const dLon = toRad(Number(loc.longitude) - input.longitude);

        const a =
          Math.sin(dLat / 2) * Math.sin(dLat / 2) +
          Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        const distance = R * c;

        return { ...loc, distanceKm: Math.round(distance * 10) / 10 };
      });

      type LocWithDist = (typeof withDistance)[number];
      return withDistance
        .filter((loc: LocWithDist) => loc.distanceKm <= input.radiusKm)
        .sort((a: LocWithDist, b: LocWithDist) => a.distanceKm - b.distanceKm);
    }),

  // Get all visible trader locations (list view, no user location needed)
  allTraders: protectedProcedure.query(async () => {
    const db = dbOrThrow(await getDb());
    const locations = await db
      .select({
        id: traderLocations.id,
        traderId: traderLocations.traderId,
        shopName: traderLocations.shopName,
        address: traderLocations.address,
        city: traderLocations.city,
        latitude: traderLocations.latitude,
        longitude: traderLocations.longitude,
        phone: traderLocations.phone,
        whatsapp: traderLocations.whatsapp,
        workingHours: traderLocations.workingHours,
        traderName: users.name,
      })
      .from(traderLocations)
      .innerJoin(users, eq(traderLocations.traderId, users.id))
      .where(eq(traderLocations.isVisible, true));

    return locations;
  }),

  // ===== Admin endpoints =====

  // Get all trader locations (admin sees everything including hidden)
  adminAllLocations: adminProcedure.query(async () => {
    const db = dbOrThrow(await getDb());
    const locations = await db
      .select({
        id: traderLocations.id,
        traderId: traderLocations.traderId,
        shopName: traderLocations.shopName,
        address: traderLocations.address,
        city: traderLocations.city,
        latitude: traderLocations.latitude,
        longitude: traderLocations.longitude,
        phone: traderLocations.phone,
        whatsapp: traderLocations.whatsapp,
        workingHours: traderLocations.workingHours,
        isVisible: traderLocations.isVisible,
        traderName: users.name,
        traderEmail: users.email,
      })
      .from(traderLocations)
      .innerJoin(users, eq(traderLocations.traderId, users.id));

    return locations;
  }),

  // Admin toggle trader location visibility
  adminToggleVisibility: adminProcedure
    .input(z.object({ traderId: z.number() }))
    .mutation(async ({ input }) => {
      const db = dbOrThrow(await getDb());
      const [location] = await db
        .select()
        .from(traderLocations)
        .where(eq(traderLocations.traderId, input.traderId))
        .limit(1);

      if (!location) throw new TRPCError({ code: "NOT_FOUND", message: "Location not found" });

      await db
        .update(traderLocations)
        .set({ isVisible: !location.isVisible })
        .where(eq(traderLocations.traderId, input.traderId));

      return { isVisible: !location.isVisible };
    }),

  // Admin delete trader location
  adminDeleteLocation: adminProcedure
    .input(z.object({ traderId: z.number() }))
    .mutation(async ({ input }) => {
      const db = dbOrThrow(await getDb());
      await db
        .delete(traderLocations)
        .where(eq(traderLocations.traderId, input.traderId));
      return { success: true };
    }),
});

// ===== Admin Settings Router =====
export const settingsRouter = router({
  // Get all settings
  getAll: adminProcedure.query(async () => {
    const db = dbOrThrow(await getDb());
    const settings = await db.select().from(adminSettings);
    return settings;
  }),

  // Get a single setting by key
  get: protectedProcedure
    .input(z.object({ key: z.string() }))
    .query(async ({ input }) => {
      const db = dbOrThrow(await getDb());
      const [setting] = await db
        .select()
        .from(adminSettings)
        .where(eq(adminSettings.key, input.key))
        .limit(1);
      return setting ?? null;
    }),

  // Set a setting (admin only)
  set: adminProcedure
    .input(
      z.object({
        key: z.string().min(1).max(100),
        value: z.string(),
        label: z.string().max(255).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = dbOrThrow(await getDb());
      const [existing] = await db
        .select()
        .from(adminSettings)
        .where(eq(adminSettings.key, input.key))
        .limit(1);

      if (existing) {
        await db
          .update(adminSettings)
          .set({
            value: input.value,
            label: input.label ?? existing.label,
            updatedBy: ctx.user.id,
          })
          .where(eq(adminSettings.key, input.key));
      } else {
        await db.insert(adminSettings).values({
          key: input.key,
          value: input.value,
          label: input.label ?? null,
          updatedBy: ctx.user.id,
        });
      }
      return { success: true };
    }),

  // Delete a setting (admin only)
  delete: adminProcedure
    .input(z.object({ key: z.string() }))
    .mutation(async ({ input }) => {
      const db = dbOrThrow(await getDb());
      await db.delete(adminSettings).where(eq(adminSettings.key, input.key));
      return { success: true };
    }),
});
