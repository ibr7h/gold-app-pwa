import { eq, and, desc, sql, like, or, between } from "drizzle-orm";
import { z } from "zod";
import { protectedProcedure, router } from "./_core/trpc";
import { getDb } from "./db";
import {
  traderOrders,
  traderClients,
  notifications,
} from "../drizzle/schema";
import { TRPCError } from "@trpc/server";

// ===== Helper: ensure trader role =====
function ensureTrader(role: string) {
  if (role !== "trader" && role !== "admin") {
    throw new TRPCError({ code: "FORBIDDEN", message: "Trader access required" });
  }
}

// ===== Clients Router =====
const clientsRouter = router({
  list: protectedProcedure
    .input(z.object({
      search: z.string().optional(),
      status: z.enum(["active", "inactive"]).optional(),
    }).optional())
    .query(async ({ ctx, input }) => {
      ensureTrader(ctx.user.role);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

      let query = db.select().from(traderClients)
        .where(eq(traderClients.traderId, ctx.user.id))
        .orderBy(desc(traderClients.createdAt));

      const results = await query;

      let filtered = results;
      if (input?.status) {
        filtered = filtered.filter(c => c.status === input.status);
      }
      if (input?.search) {
        const s = input.search.toLowerCase();
        filtered = filtered.filter(c =>
          c.name.toLowerCase().includes(s) ||
          (c.email && c.email.toLowerCase().includes(s)) ||
          (c.phone && c.phone.includes(s))
        );
      }
      return filtered;
    }),

  getById: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ ctx, input }) => {
      ensureTrader(ctx.user.role);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

      const result = await db.select().from(traderClients)
        .where(and(eq(traderClients.id, input.id), eq(traderClients.traderId, ctx.user.id)))
        .limit(1);

      if (!result[0]) throw new TRPCError({ code: "NOT_FOUND", message: "Client not found" });
      return result[0];
    }),

  create: protectedProcedure
    .input(z.object({
      name: z.string().min(1),
      email: z.string().email().optional(),
      phone: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      ensureTrader(ctx.user.role);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

      const [result] = await db.insert(traderClients).values({
        traderId: ctx.user.id,
        name: input.name,
        email: input.email ?? null,
        phone: input.phone ?? null,
        status: "active",
      }).$returningId();

      // Create notification
      await db.insert(notifications).values({
        userId: ctx.user.id,
        type: "new_client",
        title: "عميل جديد",
        message: input.name,
        referenceId: result.id,
      });

      const client = await db.select().from(traderClients).where(eq(traderClients.id, result.id)).limit(1);
      return client[0]!;
    }),

  update: protectedProcedure
    .input(z.object({
      id: z.number(),
      name: z.string().min(1).optional(),
      email: z.string().email().optional().nullable(),
      phone: z.string().optional().nullable(),
      status: z.enum(["active", "inactive"]).optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      ensureTrader(ctx.user.role);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

      const { id, ...data } = input;
      const updateData: Record<string, unknown> = {};
      if (data.name !== undefined) updateData.name = data.name;
      if (data.email !== undefined) updateData.email = data.email;
      if (data.phone !== undefined) updateData.phone = data.phone;
      if (data.status !== undefined) updateData.status = data.status;

      await db.update(traderClients)
        .set(updateData)
        .where(and(eq(traderClients.id, id), eq(traderClients.traderId, ctx.user.id)));

      const updated = await db.select().from(traderClients).where(eq(traderClients.id, id)).limit(1);
      return updated[0]!;
    }),

  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      ensureTrader(ctx.user.role);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

      await db.delete(traderClients)
        .where(and(eq(traderClients.id, input.id), eq(traderClients.traderId, ctx.user.id)));

      return { success: true };
    }),
});

// ===== Orders Router =====
const ordersRouter = router({
  list: protectedProcedure
    .input(z.object({
      search: z.string().optional(),
      status: z.enum(["pending", "processing", "completed", "cancelled"]).optional(),
      dateFilter: z.enum(["today", "week", "month", "all"]).optional(),
    }).optional())
    .query(async ({ ctx, input }) => {
      ensureTrader(ctx.user.role);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

      const results = await db.select().from(traderOrders)
        .where(eq(traderOrders.traderId, ctx.user.id))
        .orderBy(desc(traderOrders.createdAt));

      let filtered = results;

      if (input?.status) {
        filtered = filtered.filter(o => o.status === input.status);
      }

      if (input?.dateFilter && input.dateFilter !== "all") {
        const now = new Date();
        let cutoff: Date;
        if (input.dateFilter === "today") {
          cutoff = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        } else if (input.dateFilter === "week") {
          cutoff = new Date(now.getTime() - 7 * 86400000);
        } else {
          cutoff = new Date(now.getTime() - 30 * 86400000);
        }
        filtered = filtered.filter(o => new Date(o.createdAt).getTime() >= cutoff.getTime());
      }

      if (input?.search) {
        const s = input.search.toLowerCase();
        filtered = filtered.filter(o =>
          o.clientName.toLowerCase().includes(s) ||
          o.id.toString().includes(s) ||
          o.totalAmount.toString().includes(s)
        );
      }

      return filtered;
    }),

  getById: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ ctx, input }) => {
      ensureTrader(ctx.user.role);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

      const result = await db.select().from(traderOrders)
        .where(and(eq(traderOrders.id, input.id), eq(traderOrders.traderId, ctx.user.id)))
        .limit(1);

      if (!result[0]) throw new TRPCError({ code: "NOT_FOUND", message: "Order not found" });
      return result[0];
    }),

  create: protectedProcedure
    .input(z.object({
      clientId: z.number(),
      clientName: z.string(),
      type: z.enum(["buy", "sell"]),
      karat: z.string(),
      grams: z.number().positive(),
      pricePerGram: z.number().positive(),
      totalAmount: z.number().positive(),
      notes: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      ensureTrader(ctx.user.role);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

      const [result] = await db.insert(traderOrders).values({
        traderId: ctx.user.id,
        clientId: input.clientId,
        clientName: input.clientName,
        type: input.type,
        karat: input.karat,
        grams: input.grams.toString(),
        pricePerGram: input.pricePerGram.toString(),
        totalAmount: input.totalAmount.toString(),
        status: "pending",
        notes: input.notes ?? null,
      }).$returningId();

      // Create notification
      await db.insert(notifications).values({
        userId: ctx.user.id,
        type: "new_order",
        title: input.type === "buy" ? "طلب شراء جديد" : "طلب بيع جديد",
        message: `${input.clientName} - ${input.grams} غرام عيار ${input.karat}`,
        referenceId: result.id,
      });

      const order = await db.select().from(traderOrders).where(eq(traderOrders.id, result.id)).limit(1);
      return order[0]!;
    }),

  updateStatus: protectedProcedure
    .input(z.object({
      id: z.number(),
      status: z.enum(["pending", "processing", "completed", "cancelled"]),
    }))
    .mutation(async ({ ctx, input }) => {
      ensureTrader(ctx.user.role);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

      // Get order first for notification
      const existing = await db.select().from(traderOrders)
        .where(and(eq(traderOrders.id, input.id), eq(traderOrders.traderId, ctx.user.id)))
        .limit(1);

      if (!existing[0]) throw new TRPCError({ code: "NOT_FOUND", message: "Order not found" });

      await db.update(traderOrders)
        .set({ status: input.status })
        .where(eq(traderOrders.id, input.id));

      // Create status change notification
      await db.insert(notifications).values({
        userId: ctx.user.id,
        type: "order_status",
        title: "تحديث حالة الطلب",
        message: `${existing[0].clientName} - ${input.status}`,
        referenceId: input.id,
      });

      const updated = await db.select().from(traderOrders).where(eq(traderOrders.id, input.id)).limit(1);
      return updated[0]!;
    }),

  updateNotes: protectedProcedure
    .input(z.object({
      id: z.number(),
      notes: z.string(),
    }))
    .mutation(async ({ ctx, input }) => {
      ensureTrader(ctx.user.role);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

      await db.update(traderOrders)
        .set({ notes: input.notes })
        .where(and(eq(traderOrders.id, input.id), eq(traderOrders.traderId, ctx.user.id)));

      return { success: true };
    }),

  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      ensureTrader(ctx.user.role);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

      await db.delete(traderOrders)
        .where(and(eq(traderOrders.id, input.id), eq(traderOrders.traderId, ctx.user.id)));

      return { success: true };
    }),

  // Stats for trader dashboard
  stats: protectedProcedure.query(async ({ ctx }) => {
    ensureTrader(ctx.user.role);
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

    const allOrders = await db.select().from(traderOrders)
      .where(eq(traderOrders.traderId, ctx.user.id));

    const allClients = await db.select().from(traderClients)
      .where(eq(traderClients.traderId, ctx.user.id));

    const todayStr = new Date().toISOString().split("T")[0];
    const weekAgo = Date.now() - 7 * 86400000;

    const todayOrders = allOrders.filter(o => {
      const d = new Date(o.createdAt).toISOString().split("T")[0];
      return d === todayStr;
    });

    const weekOrders = allOrders.filter(o => new Date(o.createdAt).getTime() >= weekAgo);

    return {
      totalOrders: allOrders.length,
      pendingOrders: allOrders.filter(o => o.status === "pending").length,
      completedToday: todayOrders.filter(o => o.status === "completed").length,
      totalClients: allClients.length,
      todayRevenue: todayOrders
        .filter(o => o.status === "completed")
        .reduce((sum, o) => sum + parseFloat(o.totalAmount), 0),
      weekRevenue: weekOrders
        .filter(o => o.status === "completed")
        .reduce((sum, o) => sum + parseFloat(o.totalAmount), 0),
    };
  }),
});

// ===== Combined Trader Router =====
export const traderRouter = router({
  clients: clientsRouter,
  orders: ordersRouter,
});
