import { eq, desc, sql, and, count } from "drizzle-orm";
import { z } from "zod";
import { adminProcedure, router } from "./_core/trpc";
import { getDb } from "./db";
import {
  users,
  traderOrders,
  traderClients,
} from "../drizzle/schema";
import { TRPCError } from "@trpc/server";

export const adminRouter = router({
  // ===== User Management =====
  users: router({
    list: adminProcedure
      .input(z.object({
        search: z.string().optional(),
        role: z.enum(["user", "admin", "trader"]).optional(),
      }).optional())
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

        const results = await db.select().from(users).orderBy(desc(users.createdAt));

        let filtered = results;
        if (input?.role) {
          filtered = filtered.filter(u => u.role === input.role);
        }
        if (input?.search) {
          const s = input.search.toLowerCase();
          filtered = filtered.filter(u =>
            (u.name && u.name.toLowerCase().includes(s)) ||
            (u.email && u.email.toLowerCase().includes(s)) ||
            (u.phone && u.phone.includes(s))
          );
        }

        // Don't return sensitive data
        return filtered.map(u => ({
          id: u.id,
          openId: u.openId,
          name: u.name,
          email: u.email,
          phone: u.phone,
          role: u.role,
          isActive: u.isActive,
          createdAt: u.createdAt,
          lastSignedIn: u.lastSignedIn,
        }));
      }),

    updateRole: adminProcedure
      .input(z.object({
        id: z.number(),
        role: z.enum(["user", "admin", "trader"]),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

        await db.update(users)
          .set({ role: input.role })
          .where(eq(users.id, input.id));

        return { success: true };
      }),

    toggleActive: adminProcedure
      .input(z.object({
        id: z.number(),
        isActive: z.boolean(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

        await db.update(users)
          .set({ isActive: input.isActive })
          .where(eq(users.id, input.id));

        return { success: true };
      }),

    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

        // Prevent self-deletion
        if (input.id === ctx.user.id) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Cannot delete your own account" });
        }

        await db.delete(users).where(eq(users.id, input.id));
        return { success: true };
      }),
  }),

  // ===== Platform Stats =====
  stats: adminProcedure.query(async () => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

    const allUsers = await db.select().from(users);
    const allOrders = await db.select().from(traderOrders);
    const allClients = await db.select().from(traderClients);

    const now = new Date();
    const todayStr = now.toISOString().split("T")[0];
    const weekAgo = now.getTime() - 7 * 86400000;
    const monthAgo = now.getTime() - 30 * 86400000;

    // User stats
    const totalUsers = allUsers.length;
    const activeUsers = allUsers.filter(u => u.isActive).length;
    const traders = allUsers.filter(u => u.role === "trader").length;
    const admins = allUsers.filter(u => u.role === "admin").length;
    const regularUsers = allUsers.filter(u => u.role === "user").length;

    // New users this week
    const newUsersWeek = allUsers.filter(u => new Date(u.createdAt).getTime() >= weekAgo).length;
    const newUsersMonth = allUsers.filter(u => new Date(u.createdAt).getTime() >= monthAgo).length;

    // Order stats
    const totalOrders = allOrders.length;
    const completedOrders = allOrders.filter(o => o.status === "completed").length;
    const pendingOrders = allOrders.filter(o => o.status === "pending").length;
    const cancelledOrders = allOrders.filter(o => o.status === "cancelled").length;

    // Revenue
    const totalRevenue = allOrders
      .filter(o => o.status === "completed")
      .reduce((sum, o) => sum + parseFloat(o.totalAmount), 0);

    const weekRevenue = allOrders
      .filter(o => o.status === "completed" && new Date(o.createdAt).getTime() >= weekAgo)
      .reduce((sum, o) => sum + parseFloat(o.totalAmount), 0);

    const monthRevenue = allOrders
      .filter(o => o.status === "completed" && new Date(o.createdAt).getTime() >= monthAgo)
      .reduce((sum, o) => sum + parseFloat(o.totalAmount), 0);

    // Daily revenue for last 7 days
    const dailyRevenue: { date: string; revenue: number }[] = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date(now.getTime() - i * 86400000);
      const dateStr = d.toISOString().split("T")[0];
      const dayRevenue = allOrders
        .filter(o => o.status === "completed" && new Date(o.createdAt).toISOString().split("T")[0] === dateStr)
        .reduce((sum, o) => sum + parseFloat(o.totalAmount), 0);
      dailyRevenue.push({ date: dateStr, revenue: dayRevenue });
    }

    // Top traders by revenue
    const traderRevenues: Record<number, { id: number; name: string; revenue: number; orders: number }> = {};
    for (const order of allOrders.filter(o => o.status === "completed")) {
      if (!traderRevenues[order.traderId]) {
        const trader = allUsers.find(u => u.id === order.traderId);
        traderRevenues[order.traderId] = {
          id: order.traderId,
          name: trader?.name || trader?.email || `Trader #${order.traderId}`,
          revenue: 0,
          orders: 0,
        };
      }
      traderRevenues[order.traderId].revenue += parseFloat(order.totalAmount);
      traderRevenues[order.traderId].orders += 1;
    }
    const topTraders = Object.values(traderRevenues)
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 10);

    return {
      users: {
        total: totalUsers,
        active: activeUsers,
        traders,
        admins,
        regularUsers,
        newThisWeek: newUsersWeek,
        newThisMonth: newUsersMonth,
      },
      orders: {
        total: totalOrders,
        completed: completedOrders,
        pending: pendingOrders,
        cancelled: cancelledOrders,
      },
      revenue: {
        total: totalRevenue,
        thisWeek: weekRevenue,
        thisMonth: monthRevenue,
        daily: dailyRevenue,
      },
      clients: {
        total: allClients.length,
        active: allClients.filter(c => c.status === "active").length,
      },
      topTraders,
    };
  }),
});
