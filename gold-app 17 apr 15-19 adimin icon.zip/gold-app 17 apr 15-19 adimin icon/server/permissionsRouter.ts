import { eq } from "drizzle-orm";
import { z } from "zod";
import { adminProcedure, protectedProcedure, router } from "./_core/trpc";
import { getDb } from "./db";
import { traderPermissions, users } from "../drizzle/schema";
import { TRPCError } from "@trpc/server";

// Default permissions for a new trader
const DEFAULT_PERMISSIONS = {
  canViewOrders: true,
  canCreateOrders: true,
  canEditOrders: true,
  canDeleteOrders: false,
  canViewClients: true,
  canCreateClients: true,
  canEditClients: true,
  canDeleteClients: false,
  canViewReports: true,
  canExportReports: true,
  canUseMessaging: true,
};

export const permissionsRouter = router({
  // ===== Protected: Get my own permissions (for trader) =====
  my: protectedProcedure.query(async ({ ctx }) => {
    // Admins get all permissions
    if (ctx.user.role === "admin") {
      return {
        ...DEFAULT_PERMISSIONS,
        canDeleteOrders: true,
        canDeleteClients: true,
      };
    }

    // Non-traders get default user permissions (limited)
    if (ctx.user.role !== "trader") {
      return DEFAULT_PERMISSIONS;
    }

    const db = await getDb();
    if (!db) return DEFAULT_PERMISSIONS;

    const result = await db.select().from(traderPermissions)
      .where(eq(traderPermissions.traderId, ctx.user.id))
      .limit(1);

    if (result.length === 0) {
      // Create default permissions if none exist
      await db.insert(traderPermissions).values({
        traderId: ctx.user.id,
        ...DEFAULT_PERMISSIONS,
      });
      return DEFAULT_PERMISSIONS;
    }

    const p = result[0];
    return {
      canViewOrders: p.canViewOrders,
      canCreateOrders: p.canCreateOrders,
      canEditOrders: p.canEditOrders,
      canDeleteOrders: p.canDeleteOrders,
      canViewClients: p.canViewClients,
      canCreateClients: p.canCreateClients,
      canEditClients: p.canEditClients,
      canDeleteClients: p.canDeleteClients,
      canViewReports: p.canViewReports,
      canExportReports: p.canExportReports,
      canUseMessaging: p.canUseMessaging,
    };
  }),

  // ===== Admin: Get permissions for a specific trader =====
  getForTrader: adminProcedure
    .input(z.object({ traderId: z.number() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

      // Verify the user is a trader
      const user = await db.select().from(users)
        .where(eq(users.id, input.traderId)).limit(1);

      if (!user[0] || user[0].role !== "trader") {
        throw new TRPCError({ code: "BAD_REQUEST", message: "User is not a trader" });
      }

      const result = await db.select().from(traderPermissions)
        .where(eq(traderPermissions.traderId, input.traderId))
        .limit(1);

      if (result.length === 0) {
        // Create default permissions
        await db.insert(traderPermissions).values({
          traderId: input.traderId,
          ...DEFAULT_PERMISSIONS,
        });
        return {
          traderId: input.traderId,
          traderName: user[0].name || user[0].email || `Trader #${input.traderId}`,
          ...DEFAULT_PERMISSIONS,
        };
      }

      const p = result[0];
      return {
        traderId: input.traderId,
        traderName: user[0].name || user[0].email || `Trader #${input.traderId}`,
        canViewOrders: p.canViewOrders,
        canCreateOrders: p.canCreateOrders,
        canEditOrders: p.canEditOrders,
        canDeleteOrders: p.canDeleteOrders,
        canViewClients: p.canViewClients,
        canCreateClients: p.canCreateClients,
        canEditClients: p.canEditClients,
        canDeleteClients: p.canDeleteClients,
        canViewReports: p.canViewReports,
        canExportReports: p.canExportReports,
        canUseMessaging: p.canUseMessaging,
      };
    }),

  // ===== Admin: List all traders with their permissions =====
  listTraders: adminProcedure.query(async () => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

    const traders = await db.select().from(users).where(eq(users.role, "trader"));
    const allPerms = await db.select().from(traderPermissions);
    const permsMap = new Map(allPerms.map(p => [p.traderId, p]));

    return traders.map(t => {
      const p = permsMap.get(t.id);
      return {
        traderId: t.id,
        traderName: t.name || t.email || `Trader #${t.id}`,
        traderEmail: t.email,
        isActive: t.isActive,
        permissions: p ? {
          canViewOrders: p.canViewOrders,
          canCreateOrders: p.canCreateOrders,
          canEditOrders: p.canEditOrders,
          canDeleteOrders: p.canDeleteOrders,
          canViewClients: p.canViewClients,
          canCreateClients: p.canCreateClients,
          canEditClients: p.canEditClients,
          canDeleteClients: p.canDeleteClients,
          canViewReports: p.canViewReports,
          canExportReports: p.canExportReports,
          canUseMessaging: p.canUseMessaging,
        } : DEFAULT_PERMISSIONS,
      };
    });
  }),

  // ===== Admin: Update permissions for a trader =====
  update: adminProcedure
    .input(z.object({
      traderId: z.number(),
      canViewOrders: z.boolean().optional(),
      canCreateOrders: z.boolean().optional(),
      canEditOrders: z.boolean().optional(),
      canDeleteOrders: z.boolean().optional(),
      canViewClients: z.boolean().optional(),
      canCreateClients: z.boolean().optional(),
      canEditClients: z.boolean().optional(),
      canDeleteClients: z.boolean().optional(),
      canViewReports: z.boolean().optional(),
      canExportReports: z.boolean().optional(),
      canUseMessaging: z.boolean().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

      const { traderId, ...permUpdates } = input;

      // Check if permissions row exists
      const existing = await db.select().from(traderPermissions)
        .where(eq(traderPermissions.traderId, traderId)).limit(1);

      if (existing.length === 0) {
        // Create with defaults + overrides
        await db.insert(traderPermissions).values({
          traderId,
          ...DEFAULT_PERMISSIONS,
          ...permUpdates,
        });
      } else {
        // Update only provided fields
        const updateSet: Record<string, boolean> = {};
        for (const [key, value] of Object.entries(permUpdates)) {
          if (value !== undefined) {
            updateSet[key] = value;
          }
        }
        if (Object.keys(updateSet).length > 0) {
          await db.update(traderPermissions)
            .set(updateSet)
            .where(eq(traderPermissions.traderId, traderId));
        }
      }

      return { success: true };
    }),

  // ===== Admin: Reset permissions to defaults =====
  reset: adminProcedure
    .input(z.object({ traderId: z.number() }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

      const existing = await db.select().from(traderPermissions)
        .where(eq(traderPermissions.traderId, input.traderId)).limit(1);

      if (existing.length === 0) {
        await db.insert(traderPermissions).values({
          traderId: input.traderId,
          ...DEFAULT_PERMISSIONS,
        });
      } else {
        await db.update(traderPermissions)
          .set(DEFAULT_PERMISSIONS)
          .where(eq(traderPermissions.traderId, input.traderId));
      }

      return { success: true };
    }),
});
