import { eq, and, desc, or } from "drizzle-orm";
import { z } from "zod";
import { protectedProcedure, router } from "./_core/trpc";
import { getDb } from "./db";
import {
  conversations,
  messages,
  notifications,
} from "../drizzle/schema";
import { TRPCError } from "@trpc/server";

// ===== Notifications Router =====
export const notificationsRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

    return db.select().from(notifications)
      .where(eq(notifications.userId, ctx.user.id))
      .orderBy(desc(notifications.createdAt));
  }),

  unreadCount: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

    const all = await db.select().from(notifications)
      .where(and(eq(notifications.userId, ctx.user.id), eq(notifications.isRead, false)));

    return { count: all.length };
  }),

  markAsRead: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

      await db.update(notifications)
        .set({ isRead: true })
        .where(and(eq(notifications.id, input.id), eq(notifications.userId, ctx.user.id)));

      return { success: true };
    }),

  markAllAsRead: protectedProcedure.mutation(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

    await db.update(notifications)
      .set({ isRead: true })
      .where(eq(notifications.userId, ctx.user.id));

    return { success: true };
  }),

  clear: protectedProcedure.mutation(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

    await db.delete(notifications).where(eq(notifications.userId, ctx.user.id));
    return { success: true };
  }),
});

// ===== Messaging Router =====
export const messagingRouter = router({
  conversations: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

      return db.select().from(conversations)
        .where(eq(conversations.traderId, ctx.user.id))
        .orderBy(desc(conversations.lastMessageAt));
    }),

    start: protectedProcedure
      .input(z.object({
        clientId: z.number(),
        clientName: z.string(),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

        // Check if conversation already exists
        const existing = await db.select().from(conversations)
          .where(and(
            eq(conversations.traderId, ctx.user.id),
            eq(conversations.clientId, input.clientId),
          ))
          .limit(1);

        if (existing[0]) return existing[0];

        const [result] = await db.insert(conversations).values({
          traderId: ctx.user.id,
          clientId: input.clientId,
          clientName: input.clientName,
        }).$returningId();

        const conv = await db.select().from(conversations).where(eq(conversations.id, result.id)).limit(1);
        return conv[0]!;
      }),

    markRead: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

        await db.update(conversations)
          .set({ traderUnread: 0 })
          .where(and(eq(conversations.id, input.id), eq(conversations.traderId, ctx.user.id)));

        // Mark all messages in conversation as read
        await db.update(messages)
          .set({ isRead: true })
          .where(eq(messages.conversationId, input.id));

        return { success: true };
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

        // Delete messages first
        await db.delete(messages).where(eq(messages.conversationId, input.id));
        // Delete conversation
        await db.delete(conversations)
          .where(and(eq(conversations.id, input.id), eq(conversations.traderId, ctx.user.id)));

        return { success: true };
      }),
  }),

  messages: router({
    list: protectedProcedure
      .input(z.object({ conversationId: z.number() }))
      .query(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

        return db.select().from(messages)
          .where(eq(messages.conversationId, input.conversationId))
          .orderBy(messages.createdAt);
      }),

    send: protectedProcedure
      .input(z.object({
        conversationId: z.number(),
        content: z.string().min(1),
        senderRole: z.enum(["trader", "client", "admin"]),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

        const senderName = ctx.user.name || ctx.user.email || "Unknown";

        const [result] = await db.insert(messages).values({
          conversationId: input.conversationId,
          senderId: ctx.user.id,
          senderName,
          senderRole: input.senderRole,
          content: input.content,
        }).$returningId();

        // Update conversation last message
        const unreadField = input.senderRole === "trader"
          ? { clientUnread: 1 }  // Increment client unread (simplified)
          : { traderUnread: 1 }; // Increment trader unread

        await db.update(conversations)
          .set({
            lastMessage: input.content,
            lastMessageAt: new Date(),
            ...unreadField,
          })
          .where(eq(conversations.id, input.conversationId));

        // Create notification for new message
        const conv = await db.select().from(conversations)
          .where(eq(conversations.id, input.conversationId)).limit(1);

        if (conv[0] && input.senderRole === "client") {
          await db.insert(notifications).values({
            userId: conv[0].traderId,
            type: "new_message",
            title: "رسالة جديدة",
            message: `${conv[0].clientName}: ${input.content.substring(0, 100)}`,
            referenceId: input.conversationId,
          });
        }

        const msg = await db.select().from(messages).where(eq(messages.id, result.id)).limit(1);
        return msg[0]!;
      }),
  }),

  totalUnread: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

    const convs = await db.select().from(conversations)
      .where(eq(conversations.traderId, ctx.user.id));

    const total = convs.reduce((sum, c) => sum + c.traderUnread, 0);
    return { count: total };
  }),
});
