import { eq, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, inviteCodes } from "../drizzle/schema";
import { ENV } from "./_core/env";

// Admin emails that are automatically assigned admin role
const ADMIN_EMAILS: string[] = [
  "sam.elqari@icloud.com",
  "d.alneami@gmail.com",
];

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    } else if (user.email && ADMIN_EMAILS.includes(user.email.toLowerCase())) {
      // Auto-assign admin role for designated admin emails
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ===== Invite Code Functions =====

export async function validateInviteCode(code: string): Promise<{ valid: boolean; codeId?: number }> {
  const db = await getDb();
  if (!db) return { valid: false };

  const result = await db.select().from(inviteCodes)
    .where(and(
      eq(inviteCodes.code, code),
      eq(inviteCodes.isUsed, false),
      eq(inviteCodes.isActive, true),
    ))
    .limit(1);

  if (result.length === 0) return { valid: false };
  return { valid: true, codeId: result[0].id };
}

export async function useInviteCode(codeId: number, userId: number): Promise<void> {
  const db = await getDb();
  if (!db) return;

  await db.update(inviteCodes)
    .set({ isUsed: true, usedBy: userId, usedAt: new Date() })
    .where(eq(inviteCodes.id, codeId));
}

export async function isAdminEmail(email: string): Promise<boolean> {
  return ADMIN_EMAILS.includes(email.toLowerCase());
}
