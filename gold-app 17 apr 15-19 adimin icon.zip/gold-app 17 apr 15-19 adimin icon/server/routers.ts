import { COOKIE_NAME } from "../shared/const.js";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { traderRouter } from "./traderRouter";
import { messagingRouter, notificationsRouter } from "./messagingRouter";
import { adminRouter } from "./adminRouter";
import { inviteRouter } from "./inviteRouter";
import { permissionsRouter } from "./permissionsRouter";
import { locationRouter, settingsRouter } from "./locationRouter";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Feature routers
  trader: traderRouter,
  messaging: messagingRouter,
  notifications: notificationsRouter,
  admin: adminRouter,
  invite: inviteRouter,
  permissions: permissionsRouter,
  location: locationRouter,
  settings: settingsRouter,
});

export type AppRouter = typeof appRouter;
