import dotenv from 'dotenv';
dotenv.config();

// Simulate the load-env mapping
const mappings = {
  VITE_APP_ID: 'EXPO_PUBLIC_APP_ID',
  VITE_OAUTH_PORTAL_URL: 'EXPO_PUBLIC_OAUTH_PORTAL_URL',
  OAUTH_SERVER_URL: 'EXPO_PUBLIC_OAUTH_SERVER_URL',
  OWNER_OPEN_ID: 'EXPO_PUBLIC_OWNER_OPEN_ID',
  OWNER_NAME: 'EXPO_PUBLIC_OWNER_NAME',
};
for (const [systemVar, expoVar] of Object.entries(mappings)) {
  if (process.env[systemVar] && !process.env[expoVar]) {
    process.env[expoVar] = process.env[systemVar];
  }
}

console.log('=== Environment Variables ===');
console.log('EXPO_PUBLIC_APP_ID:', process.env.EXPO_PUBLIC_APP_ID || 'EMPTY');
console.log('EXPO_PUBLIC_OAUTH_PORTAL_URL:', process.env.EXPO_PUBLIC_OAUTH_PORTAL_URL || 'EMPTY');
console.log('EXPO_PUBLIC_API_BASE_URL:', process.env.EXPO_PUBLIC_API_BASE_URL || 'EMPTY');

// Simulate getLoginUrl for WEB
const portal = process.env.EXPO_PUBLIC_OAUTH_PORTAL_URL || '';
const appId = process.env.EXPO_PUBLIC_APP_ID || '';
const apiBase = process.env.EXPO_PUBLIC_API_BASE_URL || '';
const redirectUri = apiBase + '/api/oauth/callback';
const state = Buffer.from(redirectUri).toString('base64');
const url = new URL(portal + '/app-auth');
url.searchParams.set('appId', appId);
url.searchParams.set('redirectUri', redirectUri);
url.searchParams.set('state', state);
url.searchParams.set('type', 'signIn');
console.log('\n=== Web Login URL ===');
console.log('redirectUri:', redirectUri);
console.log('state (decoded):', Buffer.from(state, 'base64').toString('utf-8'));
console.log('Full URL:', url.toString());

// Simulate getLoginUrl for MOBILE
const mobileRedirect = 'manus20260317035145:///oauth/callback';
const mobileState = Buffer.from(mobileRedirect).toString('base64');
const mobileUrl = new URL(portal + '/app-auth');
mobileUrl.searchParams.set('appId', appId);
mobileUrl.searchParams.set('redirectUri', mobileRedirect);
mobileUrl.searchParams.set('state', mobileState);
mobileUrl.searchParams.set('type', 'signIn');
console.log('\n=== Mobile Login URL ===');
console.log('redirectUri:', mobileRedirect);
console.log('state (decoded):', Buffer.from(mobileState, 'base64').toString('utf-8'));
console.log('Full URL:', mobileUrl.toString());

// Check for potential issues
console.log('\n=== Potential Issues ===');
if (!appId) console.log('ERROR: appId is empty - OAuth portal will reject the request');
if (!portal) console.log('ERROR: portal URL is empty - cannot construct login URL');
if (!apiBase) console.log('WARNING: API base URL is empty - web redirect will be relative');
