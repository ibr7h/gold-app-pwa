import React, { createContext, useContext, useState, useCallback, useEffect, useMemo } from 'react';
import { useAuth } from './AuthContext';
import * as Auth from '@/lib/_core/auth';
import { getApiBaseUrl } from '@/constants/oauth';
import { Platform } from 'react-native';

export interface Message {
  id: string;
  conversationId: string;
  senderId: string;
  senderName: string;
  senderRole: 'trader' | 'client';
  text: string;
  timestamp: string;
  read: boolean;
}

export interface Conversation {
  id: string;
  traderId: string;
  traderName: string;
  clientId: string;
  clientName: string;
  lastMessage: string;
  lastMessageTime: string;
  unreadCount: number;
  orderId?: string;
}

interface MessagingContextType {
  conversations: Conversation[];
  messages: Message[];
  totalUnread: number;
  getConversationMessages: (conversationId: string) => Message[];
  getConversationByClient: (clientId: string) => Conversation | undefined;
  sendMessage: (conversationId: string, text: string, senderId: string, senderName: string, senderRole: 'trader' | 'client') => void;
  startConversation: (traderId: string, traderName: string, clientId: string, clientName: string, orderId?: string) => string;
  markConversationRead: (conversationId: string) => void;
  deleteConversation: (conversationId: string) => void;
}

const MessagingContext = createContext<MessagingContextType | null>(null);

// ===== API Helper =====
async function trpcCall<T>(path: string, input?: any, method: 'query' | 'mutation' = 'query'): Promise<T> {
  const baseUrl = getApiBaseUrl();
  const url = `${baseUrl}/api/trpc/${path}`;

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };

  if (Platform.OS !== 'web') {
    const token = await Auth.getSessionToken();
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
  }

  try {
    if (method === 'query') {
      const queryUrl = input !== undefined
        ? `${url}?input=${encodeURIComponent(JSON.stringify(input))}`
        : url;
      const response = await fetch(queryUrl, {
        method: 'GET',
        headers,
        credentials: 'include',
      });
      if (!response.ok) {
        const errText = await response.text();
        throw new Error(`tRPC query failed: ${response.status} ${errText}`);
      }
      const data = await response.json();
      return (data?.result?.data?.json ?? data?.result?.data ?? data) as T;
    } else {
      const response = await fetch(url, {
        method: 'POST',
        headers,
        credentials: 'include',
        body: JSON.stringify(input !== undefined ? { json: input } : {}),
      });
      if (!response.ok) {
        const errText = await response.text();
        throw new Error(`tRPC mutation failed: ${response.status} ${errText}`);
      }
      const data = await response.json();
      return (data?.result?.data?.json ?? data?.result?.data ?? data) as T;
    }
  } catch (e) {
    console.error(`[Messaging] tRPC call failed (${path}):`, e);
    throw e;
  }
}

// ===== Helpers to convert server data to client types =====

function serverConversationToClient(c: any): Conversation {
  return {
    id: String(c.id),
    traderId: String(c.traderId),
    traderName: '', // Server doesn't store trader name in conversation
    clientId: String(c.clientId),
    clientName: c.clientName || '',
    lastMessage: c.lastMessage || '',
    lastMessageTime: c.lastMessageAt ? new Date(c.lastMessageAt).toISOString() : new Date().toISOString(),
    unreadCount: c.traderUnread || 0,
  };
}

function serverMessageToClient(m: any): Message {
  return {
    id: String(m.id),
    conversationId: String(m.conversationId),
    senderId: String(m.senderId),
    senderName: m.senderName || '',
    senderRole: (m.senderRole === 'admin' ? 'trader' : m.senderRole) as 'trader' | 'client',
    text: m.content || '',
    timestamp: m.createdAt ? new Date(m.createdAt).toISOString() : new Date().toISOString(),
    read: !!m.isRead,
  };
}

export function MessagingProvider({ children }: { children: React.ReactNode }) {
  const { user, isLoggedIn } = useAuth();
  const isTrader = user?.role === 'trader' || user?.role === 'admin';

  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [loaded, setLoaded] = useState(false);

  // Load from server
  useEffect(() => {
    if (!isLoggedIn || !isTrader) {
      setLoaded(true);
      return;
    }

    (async () => {
      try {
        const serverConvs = await trpcCall<any[]>('messaging.conversations.list').catch(() => []);
        const convs = (serverConvs || []).map(serverConversationToClient);
        setConversations(convs);

        // Load messages for all conversations
        const allMessages: Message[] = [];
        for (const conv of convs) {
          try {
            const serverMsgs = await trpcCall<any[]>('messaging.messages.list', { conversationId: parseInt(conv.id, 10) });
            allMessages.push(...(serverMsgs || []).map(serverMessageToClient));
          } catch {
            // Skip failed conversation
          }
        }
        setMessages(allMessages);
      } catch (e) {
        console.warn('[Messaging] Failed to load from server:', e);
      }
      setLoaded(true);
    })();
  }, [isLoggedIn, isTrader]);

  const totalUnread = useMemo(() => conversations.reduce((sum, c) => sum + c.unreadCount, 0), [conversations]);

  const getConversationMessages = useCallback((conversationId: string) => {
    return messages.filter(m => m.conversationId === conversationId).sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
  }, [messages]);

  const getConversationByClient = useCallback((clientId: string) => {
    return conversations.find(c => c.clientId === clientId);
  }, [conversations]);

  const sendMessage = useCallback(async (conversationId: string, text: string, senderId: string, senderName: string, senderRole: 'trader' | 'client') => {
    // Optimistic update
    const newMsg: Message = {
      id: `msg-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      conversationId,
      senderId,
      senderName,
      senderRole,
      text,
      timestamp: new Date().toISOString(),
      read: false,
    };
    setMessages(prev => [...prev, newMsg]);
    setConversations(prev => prev.map(c =>
      c.id === conversationId
        ? { ...c, lastMessage: text, lastMessageTime: newMsg.timestamp, unreadCount: c.unreadCount + (senderRole === 'client' ? 1 : 0) }
        : c
    ));

    // Send to server
    try {
      const result = await trpcCall<any>('messaging.messages.send', {
        conversationId: parseInt(conversationId, 10),
        content: text,
        senderRole,
      }, 'mutation');

      // Update the optimistic message with real ID
      if (result?.id) {
        setMessages(prev => prev.map(m =>
          m.id === newMsg.id ? { ...m, id: String(result.id) } : m
        ));
      }
    } catch (e) {
      console.error('[Messaging] Failed to send message:', e);
      // Keep the optimistic message for UX
    }
  }, []);

  const startConversation = useCallback((traderId: string, traderName: string, clientId: string, clientName: string, orderId?: string) => {
    const existing = conversations.find(c => c.clientId === clientId && c.traderId === traderId);
    if (existing) return existing.id;

    // Optimistic local creation
    const tempId = `conv-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const newConv: Conversation = {
      id: tempId,
      traderId,
      traderName,
      clientId,
      clientName,
      lastMessage: '',
      lastMessageTime: new Date().toISOString(),
      unreadCount: 0,
      orderId,
    };
    setConversations(prev => [newConv, ...prev]);

    // Create on server in background
    (async () => {
      try {
        const result = await trpcCall<any>('messaging.conversations.start', {
          clientId: parseInt(clientId, 10),
          clientName,
        }, 'mutation');

        if (result?.id) {
          // Update the temp ID with real server ID
          setConversations(prev => prev.map(c =>
            c.id === tempId ? { ...c, id: String(result.id) } : c
          ));
          // Update messages that reference the temp ID
          setMessages(prev => prev.map(m =>
            m.conversationId === tempId ? { ...m, conversationId: String(result.id) } : m
          ));
        }
      } catch (e) {
        console.error('[Messaging] Failed to create conversation on server:', e);
      }
    })();

    return tempId;
  }, [conversations]);

  const markConversationRead = useCallback(async (conversationId: string) => {
    // Optimistic update
    setConversations(prev => prev.map(c =>
      c.id === conversationId ? { ...c, unreadCount: 0 } : c
    ));
    setMessages(prev => prev.map(m =>
      m.conversationId === conversationId ? { ...m, read: true } : m
    ));

    // Server call
    try {
      await trpcCall('messaging.conversations.markRead', {
        id: parseInt(conversationId, 10),
      }, 'mutation');
    } catch (e) {
      console.error('[Messaging] Failed to mark conversation read:', e);
    }
  }, []);

  const deleteConversation = useCallback(async (conversationId: string) => {
    // Optimistic update
    setConversations(prev => prev.filter(c => c.id !== conversationId));
    setMessages(prev => prev.filter(m => m.conversationId !== conversationId));

    // Server call
    try {
      await trpcCall('messaging.conversations.delete', {
        id: parseInt(conversationId, 10),
      }, 'mutation');
    } catch (e) {
      console.error('[Messaging] Failed to delete conversation:', e);
    }
  }, []);

  const value = useMemo(() => ({
    conversations,
    messages,
    totalUnread,
    getConversationMessages,
    getConversationByClient,
    sendMessage,
    startConversation,
    markConversationRead,
    deleteConversation,
  }), [conversations, messages, totalUnread, getConversationMessages, getConversationByClient, sendMessage, startConversation, markConversationRead, deleteConversation]);

  return (
    <MessagingContext.Provider value={value}>
      {children}
    </MessagingContext.Provider>
  );
}

export function useMessaging() {
  const ctx = useContext(MessagingContext);
  if (!ctx) throw new Error('useMessaging must be used within MessagingProvider');
  return ctx;
}
