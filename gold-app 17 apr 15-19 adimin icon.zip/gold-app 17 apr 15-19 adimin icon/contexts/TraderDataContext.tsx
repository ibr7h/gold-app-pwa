import React, { createContext, useContext, useState, useCallback, useEffect, useMemo } from 'react';
import { useAuth } from './AuthContext';
import * as Auth from '@/lib/_core/auth';
import { getApiBaseUrl } from '@/constants/oauth';
import { Platform } from 'react-native';

// ===== Types =====

export type OrderStatus = 'pending' | 'processing' | 'completed' | 'cancelled';
export type OrderType = 'buy' | 'sell';

export interface TraderOrder {
  id: string;
  clientId: string;
  clientName: string;
  type: OrderType;
  karat: string;
  grams: number;
  pricePerGram: number;
  totalAmount: number;
  status: OrderStatus;
  date: string;
  time: string;
  notes?: string;
  createdAt: number;
}

export interface TraderClient {
  id: string;
  name: string;
  email: string;
  phone: string;
  status: 'active' | 'inactive';
  createdAt: number;
}

export type NotificationType = 'new_order' | 'order_status' | 'new_client' | 'system';

export interface TraderNotification {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  orderId?: string;
  clientId?: string;
  read: boolean;
  createdAt: number;
}

export interface TraderStats {
  totalOrders: number;
  pendingOrders: number;
  completedToday: number;
  totalClients: number;
  todayRevenue: number;
  weekRevenue: number;
}

// ===== Context Interface =====

interface TraderDataContextType {
  // Orders
  orders: TraderOrder[];
  addOrder: (order: Omit<TraderOrder, 'id' | 'createdAt'>) => Promise<TraderOrder>;
  updateOrderStatus: (orderId: string, status: OrderStatus) => Promise<void>;
  updateOrderNotes: (orderId: string, notes: string) => Promise<void>;
  deleteOrder: (orderId: string) => Promise<void>;
  // Clients
  clients: TraderClient[];
  addClient: (client: Omit<TraderClient, 'id' | 'createdAt'>) => Promise<TraderClient>;
  updateClient: (clientId: string, data: Partial<TraderClient>) => Promise<void>;
  deleteClient: (clientId: string) => Promise<void>;
  // Notifications
  notifications: TraderNotification[];
  unreadCount: number;
  markAsRead: (notificationId: string) => Promise<void>;
  markAllAsRead: () => Promise<void>;
  clearNotifications: () => Promise<void>;
  // Stats
  stats: TraderStats;
  // Loading
  isLoading: boolean;
  refreshData: () => Promise<void>;
}

const TraderDataContext = createContext<TraderDataContextType | null>(null);

// ===== API Helper =====
async function trpcCall<T>(path: string, input?: any, method: 'query' | 'mutation' = 'query'): Promise<T> {
  const baseUrl = getApiBaseUrl();
  const url = `${baseUrl}/api/trpc/${path}`;

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };

  // Add auth header for native
  if (Platform.OS !== 'web') {
    const token = await Auth.getSessionToken();
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
  }

  try {
    if (method === 'query') {
      const queryUrl = input !== undefined
        ? `${url}?input=${encodeURIComponent(JSON.stringify(input))}`
        : url;
      const response = await fetch(queryUrl, {
        method: 'GET',
        headers,
        credentials: 'include',
      });
      if (!response.ok) {
        const errText = await response.text();
        throw new Error(`tRPC query failed: ${response.status} ${errText}`);
      }
      const data = await response.json();
      // tRPC wraps result in { result: { data: { json: ... } } }
      return (data?.result?.data?.json ?? data?.result?.data ?? data) as T;
    } else {
      const response = await fetch(url, {
        method: 'POST',
        headers,
        credentials: 'include',
        body: JSON.stringify(input !== undefined ? { json: input } : {}),
      });
      if (!response.ok) {
        const errText = await response.text();
        throw new Error(`tRPC mutation failed: ${response.status} ${errText}`);
      }
      const data = await response.json();
      return (data?.result?.data?.json ?? data?.result?.data ?? data) as T;
    }
  } catch (e) {
    console.error(`[TraderData] tRPC call failed (${path}):`, e);
    throw e;
  }
}

// ===== Helpers to convert server data to client types =====

function serverOrderToClient(o: any): TraderOrder {
  const createdAt = o.createdAt ? new Date(o.createdAt).getTime() : Date.now();
  const dateObj = o.orderDate ? new Date(o.orderDate) : new Date(createdAt);
  return {
    id: String(o.id),
    clientId: String(o.clientId),
    clientName: o.clientName || '',
    type: o.type as OrderType,
    karat: o.karat || '',
    grams: parseFloat(o.grams) || 0,
    pricePerGram: parseFloat(o.pricePerGram) || 0,
    totalAmount: parseFloat(o.totalAmount) || 0,
    status: o.status as OrderStatus,
    date: dateObj.toISOString().split('T')[0],
    time: dateObj.toTimeString().substring(0, 5),
    notes: o.notes || undefined,
    createdAt,
  };
}

function serverClientToClient(c: any): TraderClient {
  return {
    id: String(c.id),
    name: c.name || '',
    email: c.email || '',
    phone: c.phone || '',
    status: c.status || 'active',
    createdAt: c.createdAt ? new Date(c.createdAt).getTime() : Date.now(),
  };
}

function serverNotificationToClient(n: any): TraderNotification {
  return {
    id: String(n.id),
    type: (n.type || 'system') as NotificationType,
    title: n.title || '',
    message: n.message || '',
    orderId: n.referenceId ? String(n.referenceId) : undefined,
    read: !!n.isRead,
    createdAt: n.createdAt ? new Date(n.createdAt).getTime() : Date.now(),
  };
}

// ===== Provider =====

export function TraderDataProvider({ children }: { children: React.ReactNode }) {
  const { user, isLoggedIn } = useAuth();
  const isTrader = user?.role === 'trader' || user?.role === 'admin';

  const [orders, setOrders] = useState<TraderOrder[]>([]);
  const [clients, setClients] = useState<TraderClient[]>([]);
  const [notifications, setNotifications] = useState<TraderNotification[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  // ===== Load data from server =====
  const loadData = useCallback(async () => {
    if (!isLoggedIn || !isTrader) return;

    setIsLoading(true);
    try {
      const [serverOrders, serverClients, serverNotifications] = await Promise.all([
        trpcCall<any[]>('trader.orders.list').catch(() => []),
        trpcCall<any[]>('trader.clients.list').catch(() => []),
        trpcCall<any[]>('notifications.list').catch(() => []),
      ]);

      setOrders((serverOrders || []).map(serverOrderToClient));
      setClients((serverClients || []).map(serverClientToClient));
      setNotifications((serverNotifications || []).map(serverNotificationToClient));
    } catch (e) {
      console.warn('[TraderData] Failed to load from server:', e);
    }
    setIsLoading(false);
  }, [isLoggedIn, isTrader]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // ===== Orders =====

  const addOrder = useCallback(async (orderData: Omit<TraderOrder, 'id' | 'createdAt'>): Promise<TraderOrder> => {
    const input = {
      clientId: parseInt(orderData.clientId, 10),
      clientName: orderData.clientName,
      type: orderData.type,
      karat: orderData.karat,
      grams: orderData.grams,
      pricePerGram: orderData.pricePerGram,
      totalAmount: orderData.totalAmount,
      notes: orderData.notes || undefined,
    };

    const result = await trpcCall<any>('trader.orders.create', input, 'mutation');
    const newOrder = serverOrderToClient(result);

    // Refresh data to get updated lists
    await loadData();
    return newOrder;
  }, [loadData]);

  const updateOrderStatus = useCallback(async (orderId: string, status: OrderStatus) => {
    await trpcCall('trader.orders.updateStatus', {
      id: parseInt(orderId, 10),
      status,
    }, 'mutation');

    // Optimistic update
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status } : o));

    // Refresh to get notifications
    await loadData();
  }, [loadData]);

  const updateOrderNotes = useCallback(async (orderId: string, notes: string) => {
    await trpcCall('trader.orders.updateNotes', {
      id: parseInt(orderId, 10),
      notes,
    }, 'mutation');

    // Optimistic update
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, notes } : o));
  }, []);

  const deleteOrder = useCallback(async (orderId: string) => {
    await trpcCall('trader.orders.delete', {
      id: parseInt(orderId, 10),
    }, 'mutation');

    // Optimistic update
    setOrders(prev => prev.filter(o => o.id !== orderId));
  }, []);

  // ===== Clients =====

  const addClient = useCallback(async (clientData: Omit<TraderClient, 'id' | 'createdAt'>): Promise<TraderClient> => {
    const result = await trpcCall<any>('trader.clients.create', {
      name: clientData.name,
      email: clientData.email || undefined,
      phone: clientData.phone || undefined,
    }, 'mutation');

    const newClient = serverClientToClient(result);
    await loadData();
    return newClient;
  }, [loadData]);

  const updateClient = useCallback(async (clientId: string, data: Partial<TraderClient>) => {
    const input: any = { id: parseInt(clientId, 10) };
    if (data.name !== undefined) input.name = data.name;
    if (data.email !== undefined) input.email = data.email || null;
    if (data.phone !== undefined) input.phone = data.phone || null;
    if (data.status !== undefined) input.status = data.status;

    await trpcCall('trader.clients.update', input, 'mutation');

    // Optimistic update
    setClients(prev => prev.map(c => c.id === clientId ? { ...c, ...data } : c));
  }, []);

  const deleteClient = useCallback(async (clientId: string) => {
    await trpcCall('trader.clients.delete', {
      id: parseInt(clientId, 10),
    }, 'mutation');

    // Optimistic update
    setClients(prev => prev.filter(c => c.id !== clientId));
  }, []);

  // ===== Notifications =====

  const unreadCount = useMemo(() => notifications.filter(n => !n.read).length, [notifications]);

  const markAsRead = useCallback(async (notificationId: string) => {
    await trpcCall('notifications.markAsRead', {
      id: parseInt(notificationId, 10),
    }, 'mutation');

    // Optimistic update
    setNotifications(prev => prev.map(n => n.id === notificationId ? { ...n, read: true } : n));
  }, []);

  const markAllAsRead = useCallback(async () => {
    await trpcCall('notifications.markAllAsRead', undefined, 'mutation');

    // Optimistic update
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  }, []);

  const clearNotifications = useCallback(async () => {
    await trpcCall('notifications.clear', undefined, 'mutation');
    setNotifications([]);
  }, []);

  // ===== Stats =====

  const stats = useMemo((): TraderStats => {
    const todayStr = new Date().toISOString().split('T')[0];
    const weekAgo = Date.now() - 7 * 86400000;

    const todayOrders = orders.filter(o => o.date === todayStr);
    const weekOrders = orders.filter(o => o.createdAt >= weekAgo);

    return {
      totalOrders: orders.length,
      pendingOrders: orders.filter(o => o.status === 'pending').length,
      completedToday: todayOrders.filter(o => o.status === 'completed').length,
      totalClients: clients.length,
      todayRevenue: todayOrders.filter(o => o.status === 'completed').reduce((sum, o) => sum + o.totalAmount, 0),
      weekRevenue: weekOrders.filter(o => o.status === 'completed').reduce((sum, o) => sum + o.totalAmount, 0),
    };
  }, [orders, clients]);

  const refreshData = useCallback(async () => {
    await loadData();
  }, [loadData]);

  const value = useMemo(() => ({
    orders, addOrder, updateOrderStatus, updateOrderNotes, deleteOrder,
    clients, addClient, updateClient, deleteClient,
    notifications, unreadCount, markAsRead, markAllAsRead, clearNotifications,
    stats, isLoading, refreshData,
  }), [
    orders, addOrder, updateOrderStatus, updateOrderNotes, deleteOrder,
    clients, addClient, updateClient, deleteClient,
    notifications, unreadCount, markAsRead, markAllAsRead, clearNotifications,
    stats, isLoading, refreshData,
  ]);

  return (
    <TraderDataContext.Provider value={value}>
      {children}
    </TraderDataContext.Provider>
  );
}

export function useTraderData() {
  const ctx = useContext(TraderDataContext);
  if (!ctx) throw new Error('useTraderData must be used within TraderDataProvider');
  return ctx;
}
