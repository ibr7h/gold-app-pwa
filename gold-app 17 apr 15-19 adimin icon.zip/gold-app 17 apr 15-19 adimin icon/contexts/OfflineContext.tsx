import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Network from 'expo-network';
import { Platform, AppState } from 'react-native';

// ===== Types =====

interface CachedData {
  goldPrices: any | null;
  portfolio: any[] | null;
  purchases: any[] | null;
  orders: any[] | null;
  clients: any[] | null;
  lastCachedAt: number | null;
}

interface OfflineContextType {
  isOnline: boolean;
  isInternetReachable: boolean;
  lastOnlineAt: number | null;
  cachedData: CachedData;
  cacheData: (key: keyof Omit<CachedData, 'lastCachedAt'>, data: any) => Promise<void>;
  getCachedData: <T>(key: keyof Omit<CachedData, 'lastCachedAt'>) => T | null;
  clearCache: () => Promise<void>;
  checkConnection: () => Promise<boolean>;
}

const OfflineContext = createContext<OfflineContextType | null>(null);

const CACHE_PREFIX = '@offline_cache_';
const LAST_ONLINE_KEY = '@offline_last_online';

const DEFAULT_CACHED: CachedData = {
  goldPrices: null,
  portfolio: null,
  purchases: null,
  orders: null,
  clients: null,
  lastCachedAt: null,
};

export function OfflineProvider({ children }: { children: React.ReactNode }) {
  const [isOnline, setIsOnline] = useState(true);
  const [isInternetReachable, setIsInternetReachable] = useState(true);
  const [lastOnlineAt, setLastOnlineAt] = useState<number | null>(null);
  const [cachedData, setCachedData] = useState<CachedData>(DEFAULT_CACHED);
  const checkInterval = useRef<ReturnType<typeof setInterval> | null>(null);

  // Check network status
  const checkConnection = useCallback(async (): Promise<boolean> => {
    try {
      if (Platform.OS === 'web') {
        const online = typeof navigator !== 'undefined' ? navigator.onLine : true;
        setIsOnline(online);
        setIsInternetReachable(online);
        if (online) {
          const now = Date.now();
          setLastOnlineAt(now);
          await AsyncStorage.setItem(LAST_ONLINE_KEY, now.toString());
        }
        return online;
      }

      const state = await Network.getNetworkStateAsync();
      const online = state.isConnected ?? false;
      const reachable = state.isInternetReachable ?? false;

      setIsOnline(online);
      setIsInternetReachable(reachable);

      if (online && reachable) {
        const now = Date.now();
        setLastOnlineAt(now);
        await AsyncStorage.setItem(LAST_ONLINE_KEY, now.toString());
      }

      return online && reachable;
    } catch {
      return true; // Assume online if check fails
    }
  }, []);

  // Load cached data from storage
  const loadCache = useCallback(async () => {
    try {
      const keys = ['goldPrices', 'portfolio', 'purchases', 'orders', 'clients'] as const;
      const loaded: Partial<CachedData> = {};

      for (const key of keys) {
        const stored = await AsyncStorage.getItem(CACHE_PREFIX + key);
        if (stored) {
          loaded[key] = JSON.parse(stored);
        }
      }

      const lastOnline = await AsyncStorage.getItem(LAST_ONLINE_KEY);
      if (lastOnline) {
        setLastOnlineAt(parseInt(lastOnline, 10));
      }

      const lastCachedStr = await AsyncStorage.getItem(CACHE_PREFIX + 'lastCachedAt');
      loaded.lastCachedAt = lastCachedStr ? parseInt(lastCachedStr, 10) : null;

      setCachedData(prev => ({ ...prev, ...loaded }));
    } catch {
      // Silently fail
    }
  }, []);

  // Cache data to storage
  const cacheData = useCallback(async (key: keyof Omit<CachedData, 'lastCachedAt'>, data: any) => {
    try {
      await AsyncStorage.setItem(CACHE_PREFIX + key, JSON.stringify(data));
      const now = Date.now();
      await AsyncStorage.setItem(CACHE_PREFIX + 'lastCachedAt', now.toString());
      setCachedData(prev => ({ ...prev, [key]: data, lastCachedAt: now }));
    } catch {
      // Silently fail
    }
  }, []);

  // Get cached data
  const getCachedData = useCallback(<T,>(key: keyof Omit<CachedData, 'lastCachedAt'>): T | null => {
    return cachedData[key] as T | null;
  }, [cachedData]);

  // Clear all cached data
  const clearCache = useCallback(async () => {
    try {
      const keys = ['goldPrices', 'portfolio', 'purchases', 'orders', 'clients', 'lastCachedAt'];
      await Promise.all(keys.map(k => AsyncStorage.removeItem(CACHE_PREFIX + k)));
      setCachedData(DEFAULT_CACHED);
    } catch {
      // Silently fail
    }
  }, []);

  // Initialize
  useEffect(() => {
    loadCache();
    checkConnection();

    // Periodic check every 30 seconds
    checkInterval.current = setInterval(checkConnection, 30000);

    // Web online/offline events
    if (Platform.OS === 'web' && typeof window !== 'undefined') {
      const handleOnline = () => { setIsOnline(true); setIsInternetReachable(true); };
      const handleOffline = () => { setIsOnline(false); setIsInternetReachable(false); };
      window.addEventListener('online', handleOnline);
      window.addEventListener('offline', handleOffline);
      return () => {
        window.removeEventListener('online', handleOnline);
        window.removeEventListener('offline', handleOffline);
        if (checkInterval.current) clearInterval(checkInterval.current);
      };
    }

    // App state changes (check on foreground)
    const sub = AppState.addEventListener('change', (state) => {
      if (state === 'active') checkConnection();
    });

    return () => {
      sub.remove();
      if (checkInterval.current) clearInterval(checkInterval.current);
    };
  }, [checkConnection, loadCache]);

  return (
    <OfflineContext.Provider value={{
      isOnline,
      isInternetReachable,
      lastOnlineAt,
      cachedData,
      cacheData,
      getCachedData,
      clearCache,
      checkConnection,
    }}>
      {children}
    </OfflineContext.Provider>
  );
}

export function useOffline() {
  const ctx = useContext(OfflineContext);
  if (!ctx) throw new Error('useOffline must be used within OfflineProvider');
  return ctx;
}
