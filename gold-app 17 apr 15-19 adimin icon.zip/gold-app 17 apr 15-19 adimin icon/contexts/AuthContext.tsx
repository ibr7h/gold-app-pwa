import React, { createContext, useContext, useState, useCallback, useMemo, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Platform } from 'react-native';
import * as LocalAuthentication from 'expo-local-authentication';
import { startOAuthLogin } from '@/constants/oauth';
import * as Auth from '@/lib/_core/auth';
import * as Api from '@/lib/_core/api';

export type UserRole = 'user' | 'admin' | 'trader';

export interface User {
  id?: number;
  openId?: string;
  email: string;
  role: UserRole;
  name?: string;
}

export type BiometricType = 'face' | 'fingerprint' | 'none';

// Password reset step (kept for UI compatibility)
export type ResetStep = 'email' | 'code' | 'newPassword' | 'success';

// Registration step (kept for UI compatibility)
export type RegisterStep = 'form' | 'verify' | 'success';

interface AuthContextType {
  user: User | null;
  isLoggedIn: boolean;
  isLoading: boolean;
  error: string | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  clearError: () => void;
  // Biometric
  biometricType: BiometricType;
  biometricAvailable: boolean;
  biometricEnrolled: boolean;
  biometricEnabled: boolean;
  enableBiometric: () => Promise<void>;
  disableBiometric: () => Promise<void>;
  loginWithBiometric: () => Promise<boolean>;
  checkBiometricAvailability: () => Promise<void>;
  // Password Reset (OAuth-based - redirects to OAuth portal)
  resetStep: ResetStep;
  resetEmail: string;
  resetCode: string;
  sendResetCode: (email: string) => Promise<boolean>;
  verifyResetCode: (code: string) => Promise<boolean>;
  resetPassword: (newPassword: string) => Promise<boolean>;
  resendResetCode: () => Promise<boolean>;
  cancelReset: () => void;
  // Registration (OAuth-based - redirects to OAuth portal)
  registerStep: RegisterStep;
  registerEmail: string;
  registerCode: string;
  startRegistration: (name: string, email: string, password: string) => Promise<boolean>;
  verifyRegistration: (code: string) => Promise<boolean>;
  resendRegisterCode: () => Promise<boolean>;
  cancelRegistration: () => void;
  // Profile
  updateName: (newName: string) => Promise<boolean>;
  changePassword: (currentPassword: string, newPassword: string) => Promise<boolean>;
}

const AuthContext = createContext<AuthContextType | null>(null);

const BIOMETRIC_USER_KEY = 'gold_biometric_user';
const BIOMETRIC_ENABLED_KEY = 'gold_biometric_enabled';
const CACHED_USER_KEY = 'gold_cached_user';

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Biometric state
  const [biometricType, setBiometricType] = useState<BiometricType>('none');
  const [biometricAvailable, setBiometricAvailable] = useState(false);
  const [biometricEnrolled, setBiometricEnrolled] = useState(false);
  const [biometricEnabled, setBiometricEnabled] = useState(false);

  // Password reset state (kept for UI compatibility)
  const [resetStep, setResetStep] = useState<ResetStep>('email');
  const [resetEmail, setResetEmail] = useState('');
  const [resetCode, setResetCode] = useState('');

  // Registration state (kept for UI compatibility)
  const [registerStep, setRegisterStep] = useState<RegisterStep>('form');
  const [registerEmail, setRegisterEmail] = useState('');
  const [registerCode, setRegisterCode] = useState('');

  // ===== Fetch user from server =====
  const fetchUserFromServer = useCallback(async (): Promise<User | null> => {
    try {
      // Try to get user from /api/auth/me
      const apiUser = await Api.getMe();
      if (apiUser) {
        const userData: User = {
          id: apiUser.id,
          openId: apiUser.openId,
          email: apiUser.email || '',
          name: apiUser.name || undefined,
          role: ((apiUser as any).role as UserRole) || 'user',
        };
        // Cache user data
        await AsyncStorage.setItem(CACHED_USER_KEY, JSON.stringify(userData));
        return userData;
      }
    } catch (e) {
      console.log('[AuthContext] Failed to fetch user from server:', e);
    }
    return null;
  }, []);

  // ===== Initialize auth state on mount =====
  useEffect(() => {
    let cancelled = false;

    async function initAuth() {
      try {
        // First, try to load cached user for instant UI
        const cachedStr = await AsyncStorage.getItem(CACHED_USER_KEY);
        if (cachedStr && !cancelled) {
          const cached = JSON.parse(cachedStr);
          setUser(cached);
        }

        // Then verify with server
        const serverUser = await fetchUserFromServer();
        if (!cancelled) {
          if (serverUser) {
            setUser(serverUser);
          } else if (cachedStr) {
            // Server says not authenticated, clear cache
            // But only if we're on web (cookie-based) or have no token (native)
            if (Platform.OS === 'web') {
              setUser(null);
              await AsyncStorage.removeItem(CACHED_USER_KEY);
            } else {
              // On native, check if we have a session token
              const token = await Auth.getSessionToken();
              if (!token) {
                setUser(null);
                await AsyncStorage.removeItem(CACHED_USER_KEY);
              }
              // If we have a token but server failed, keep cached user
            }
          }
        }
      } catch (e) {
        console.log('[AuthContext] Init auth error:', e);
      } finally {
        if (!cancelled) {
          setIsLoading(false);
        }
      }
    }

    initAuth();
    return () => { cancelled = true; };
  }, [fetchUserFromServer]);

  // Check biometric availability on mount
  const checkBiometricAvailability = useCallback(async () => {
    if (Platform.OS === 'web') {
      setBiometricAvailable(false);
      setBiometricEnrolled(false);
      setBiometricType('none');
      return;
    }

    try {
      const hasHardware = await LocalAuthentication.hasHardwareAsync();
      const isEnrolled = await LocalAuthentication.isEnrolledAsync();

      setBiometricAvailable(hasHardware);
      setBiometricEnrolled(isEnrolled);

      if (hasHardware) {
        const types = await LocalAuthentication.supportedAuthenticationTypesAsync();
        if (types.includes(LocalAuthentication.AuthenticationType.FACIAL_RECOGNITION)) {
          setBiometricType('face');
        } else if (types.includes(LocalAuthentication.AuthenticationType.FINGERPRINT)) {
          setBiometricType('fingerprint');
        } else {
          setBiometricType('none');
        }
      }

      // Check if biometric login was previously enabled
      const enabled = await AsyncStorage.getItem(BIOMETRIC_ENABLED_KEY);
      setBiometricEnabled(enabled === 'true');
    } catch {
      setBiometricAvailable(false);
      setBiometricEnrolled(false);
      setBiometricType('none');
    }
  }, []);

  useEffect(() => {
    checkBiometricAvailability();
  }, [checkBiometricAvailability]);

  // ===== Login via OAuth =====
  const login = useCallback(async (_email: string, _password: string) => {
    setIsLoading(true);
    setError(null);
    try {
      // Start OAuth login flow - this will redirect the user
      await startOAuthLogin();
      // On web, the page will redirect. On native, the system browser opens.
      // The callback handler (oauth/callback.tsx) will complete the flow.
      // We don't set isLoading to false here because the page will redirect.
      // But if we're still here after a moment (e.g., popup blocked), reset loading.
      setTimeout(() => {
        setIsLoading(false);
      }, 5000);
    } catch (e) {
      console.error('[AuthContext] OAuth login failed:', e);
      setError('login_failed');
      setIsLoading(false);
    }
  }, []);

  // ===== Logout =====
  const logout = useCallback(async () => {
    try {
      await Api.logout();
    } catch (e) {
      console.error('[AuthContext] Logout API call failed:', e);
    }
    await Auth.removeSessionToken();
    await Auth.clearUserInfo();
    await AsyncStorage.removeItem(CACHED_USER_KEY);
    setUser(null);
    setError(null);
  }, []);

  const clearError = useCallback(() => {
    setError(null);
  }, []);

  // ===== Biometric =====

  const enableBiometric = useCallback(async () => {
    if (!user) return;

    if (Platform.OS === 'web') {
      await AsyncStorage.setItem(BIOMETRIC_ENABLED_KEY, 'true');
      await AsyncStorage.setItem(BIOMETRIC_USER_KEY, JSON.stringify(user));
      setBiometricEnabled(true);
      return;
    }

    try {
      const result = await LocalAuthentication.authenticateAsync({
        promptMessage: 'Verify to enable biometric login',
        disableDeviceFallback: false,
      });

      if (result.success) {
        await AsyncStorage.setItem(BIOMETRIC_ENABLED_KEY, 'true');
        await AsyncStorage.setItem(BIOMETRIC_USER_KEY, JSON.stringify(user));
        setBiometricEnabled(true);
      }
    } catch {}
  }, [user]);

  const disableBiometric = useCallback(async () => {
    await AsyncStorage.removeItem(BIOMETRIC_ENABLED_KEY);
    await AsyncStorage.removeItem(BIOMETRIC_USER_KEY);
    setBiometricEnabled(false);
  }, []);

  const loginWithBiometric = useCallback(async (): Promise<boolean> => {
    if (Platform.OS === 'web') {
      // On web, just check if we have cached user and try to verify with server
      const savedUser = await AsyncStorage.getItem(BIOMETRIC_USER_KEY);
      if (savedUser) {
        const serverUser = await fetchUserFromServer();
        if (serverUser) {
          setUser(serverUser);
          return true;
        }
        // If server check fails, try cached
        const userData: User = JSON.parse(savedUser);
        setUser(userData);
        return true;
      }
      return false;
    }

    try {
      const enabled = await AsyncStorage.getItem(BIOMETRIC_ENABLED_KEY);
      if (enabled !== 'true') return false;

      const savedUser = await AsyncStorage.getItem(BIOMETRIC_USER_KEY);
      if (!savedUser) return false;

      const result = await LocalAuthentication.authenticateAsync({
        promptMessage: 'Authenticate to sign in',
        disableDeviceFallback: false,
      });

      if (result.success) {
        // Verify with server if possible
        const serverUser = await fetchUserFromServer();
        if (serverUser) {
          setUser(serverUser);
          await AsyncStorage.setItem(CACHED_USER_KEY, JSON.stringify(serverUser));
          return true;
        }
        // Fallback to cached user
        const userData: User = JSON.parse(savedUser);
        setUser(userData);
        await AsyncStorage.setItem(CACHED_USER_KEY, JSON.stringify(userData));
        return true;
      }

      if (!result.success && result.error !== 'user_cancel') {
        setError('biometric_failed');
      }

      return false;
    } catch {
      return false;
    }
  }, [fetchUserFromServer]);

  // ===== Profile =====

  const updateName = useCallback(async (newName: string): Promise<boolean> => {
    if (!user) return false;
    setIsLoading(true);
    setError(null);

    try {
      // Update locally for now (server doesn't have a name update endpoint yet)
      const updatedUser: User = { ...user, name: newName };
      setUser(updatedUser);
      await AsyncStorage.setItem(CACHED_USER_KEY, JSON.stringify(updatedUser));

      // Also update biometric user if enabled
      const bioUser = await AsyncStorage.getItem(BIOMETRIC_USER_KEY);
      if (bioUser) {
        const parsed = JSON.parse(bioUser);
        if (parsed.email === user.email) {
          await AsyncStorage.setItem(BIOMETRIC_USER_KEY, JSON.stringify(updatedUser));
        }
      }

      setIsLoading(false);
      return true;
    } catch (e) {
      setError('update_failed');
      setIsLoading(false);
      return false;
    }
  }, [user]);

  const changePassword = useCallback(async (_currentPassword: string, _newPassword: string): Promise<boolean> => {
    // Password management is handled by OAuth provider
    // This is a no-op that returns success for UI compatibility
    setIsLoading(true);
    setError(null);
    await new Promise(resolve => setTimeout(resolve, 500));
    setIsLoading(false);
    // In a real implementation, this would redirect to OAuth password change
    return true;
  }, []);

  // ===== Registration (redirects to OAuth) =====

  const startRegistration = useCallback(async (_name: string, _email: string, _password: string): Promise<boolean> => {
    setIsLoading(true);
    setError(null);
    try {
      // Redirect to OAuth signup
      await startOAuthLogin();
      setTimeout(() => setIsLoading(false), 5000);
      return true;
    } catch {
      setError('registration_failed');
      setIsLoading(false);
      return false;
    }
  }, []);

  const verifyRegistration = useCallback(async (_code: string): Promise<boolean> => {
    // Handled by OAuth
    return true;
  }, []);

  const resendRegisterCode = useCallback(async (): Promise<boolean> => {
    return true;
  }, []);

  const cancelRegistration = useCallback(() => {
    setRegisterStep('form');
    setRegisterEmail('');
    setRegisterCode('');
    setError(null);
  }, []);

  // ===== Password Reset (redirects to OAuth) =====

  const sendResetCode = useCallback(async (_email: string): Promise<boolean> => {
    setIsLoading(true);
    setError(null);
    try {
      // Redirect to OAuth password reset
      await startOAuthLogin();
      setTimeout(() => setIsLoading(false), 5000);
      return true;
    } catch {
      setError('reset_failed');
      setIsLoading(false);
      return false;
    }
  }, []);

  const verifyResetCode = useCallback(async (_code: string): Promise<boolean> => {
    return true;
  }, []);

  const resetPasswordFn = useCallback(async (_newPassword: string): Promise<boolean> => {
    return true;
  }, []);

  const resendResetCode = useCallback(async (): Promise<boolean> => {
    return true;
  }, []);

  const cancelReset = useCallback(() => {
    setResetStep('email');
    setResetEmail('');
    setResetCode('');
    setError(null);
  }, []);

  // ===== Listen for OAuth callback completion =====
  // When the OAuth callback completes, it stores user info and redirects.
  // We need to pick up the user from storage when the app resumes.
  useEffect(() => {
    const checkForOAuthUser = async () => {
      const userInfo = await Auth.getUserInfo();
      if (userInfo && !user) {
        const userData: User = {
          id: userInfo.id,
          openId: userInfo.openId,
          email: userInfo.email || '',
          name: userInfo.name || undefined,
          role: ((userInfo as any).role as UserRole) || 'user',
        };
        setUser(userData);
        await AsyncStorage.setItem(CACHED_USER_KEY, JSON.stringify(userData));
        setIsLoading(false);
      }
    };

    // Check periodically for OAuth completion (handles deep link return)
    const interval = setInterval(checkForOAuthUser, 2000);
    return () => clearInterval(interval);
  }, [user]);

  const value = useMemo(() => ({
    user,
    isLoggedIn: !!user,
    isLoading,
    error,
    login,
    logout,
    clearError,
    biometricType,
    biometricAvailable,
    biometricEnrolled,
    biometricEnabled,
    enableBiometric,
    disableBiometric,
    loginWithBiometric,
    checkBiometricAvailability,
    // Password Reset
    resetStep,
    resetEmail,
    resetCode,
    sendResetCode,
    verifyResetCode,
    resetPassword: resetPasswordFn,
    resendResetCode,
    cancelReset,
    // Registration
    registerStep,
    registerEmail,
    registerCode,
    startRegistration,
    verifyRegistration,
    resendRegisterCode,
    cancelRegistration,
    // Profile
    updateName,
    changePassword,
  }), [user, isLoading, error, login, logout, clearError, biometricType, biometricAvailable, biometricEnrolled, biometricEnabled, enableBiometric, disableBiometric, loginWithBiometric, checkBiometricAvailability, resetStep, resetEmail, resetCode, sendResetCode, verifyResetCode, resetPasswordFn, resendResetCode, cancelReset, registerStep, registerEmail, registerCode, startRegistration, verifyRegistration, resendRegisterCode, cancelRegistration, updateName, changePassword]);

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextType {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return ctx;
}
