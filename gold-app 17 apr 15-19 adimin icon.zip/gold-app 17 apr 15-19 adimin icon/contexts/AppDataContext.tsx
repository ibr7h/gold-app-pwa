import React, { createContext, useContext, useState, useCallback, useMemo } from 'react';
import {
  goldPrices as initialPrices,
  portfolioItems as initialPortfolios,
  purchases as initialPurchases,
  alerts as initialAlerts,
  type GoldPrice,
  type PortfolioItem,
  type Purchase,
  type Alert,
} from '@/data/mock';

interface AppDataContextType {
  // Prices
  prices: GoldPrice[];
  pricesLoading: boolean;
  pricesError: string | null;
  refreshPrices: () => Promise<void>;

  // Portfolio
  portfolios: PortfolioItem[];
  addPortfolio: (name: string, currency: string) => void;
  deletePortfolio: (id: string) => void;

  // Purchases
  purchasesList: Purchase[];
  addPurchase: (purchase: Omit<Purchase, 'id'>) => void;
  updatePurchase: (id: string, purchase: Partial<Purchase>) => void;
  deletePurchase: (id: string) => void;

  // Alerts
  alertsList: Alert[];
  addAlert: (alert: Omit<Alert, 'id' | 'status' | 'lastUpdate'>) => void;
  toggleAlert: (id: string) => void;
  deleteAlert: (id: string) => void;
}

const AppDataContext = createContext<AppDataContextType | null>(null);

export function AppDataProvider({ children }: { children: React.ReactNode }) {
  const [prices, setPrices] = useState<GoldPrice[]>(initialPrices);
  const [pricesLoading, setPricesLoading] = useState(false);
  const [pricesError, setPricesError] = useState<string | null>(null);
  const [portfolios, setPortfolios] = useState<PortfolioItem[]>(initialPortfolios);
  const [purchasesList, setPurchasesList] = useState<Purchase[]>(initialPurchases);
  const [alertsList, setAlertsList] = useState<Alert[]>(initialAlerts);

  const refreshPrices = useCallback(async () => {
    setPricesLoading(true);
    setPricesError(null);
    await new Promise(resolve => setTimeout(resolve, 1200));
    // Simulate slight price changes
    setPrices(prev => prev.map(p => ({
      ...p,
      buyPrice: p.buyPrice + (Math.random() - 0.5) * 2,
      sellPrice: p.sellPrice + (Math.random() - 0.5) * 2,
      change: +(Math.random() * 4 - 2).toFixed(2),
      changePercent: +(Math.random() * 2 - 1).toFixed(2),
      lastUpdate: new Date().toLocaleString('ar-SA'),
    })));
    setPricesLoading(false);
  }, []);

  const addPortfolio = useCallback((name: string, currency: string) => {
    const newItem: PortfolioItem = {
      id: Date.now().toString(),
      name,
      currency,
      totalValue: 0,
      totalCost: 0,
      profitLoss: 0,
      profitLossPercent: 0,
      lastUpdate: new Date().toISOString().split('T')[0],
      purchaseCount: 0,
    };
    setPortfolios(prev => [...prev, newItem]);
  }, []);

  const deletePortfolio = useCallback((id: string) => {
    setPortfolios(prev => prev.filter(p => p.id !== id));
  }, []);

  const addPurchase = useCallback((purchase: Omit<Purchase, 'id'>) => {
    const newPurchase: Purchase = { ...purchase, id: Date.now().toString() };
    setPurchasesList(prev => [...prev, newPurchase]);
  }, []);

  const updatePurchase = useCallback((id: string, updates: Partial<Purchase>) => {
    setPurchasesList(prev => prev.map(p => p.id === id ? { ...p, ...updates } : p));
  }, []);

  const deletePurchase = useCallback((id: string) => {
    setPurchasesList(prev => prev.filter(p => p.id !== id));
  }, []);

  const addAlert = useCallback((alert: Omit<Alert, 'id' | 'status' | 'lastUpdate'>) => {
    const newAlert: Alert = {
      ...alert,
      id: Date.now().toString(),
      status: 'active',
      lastUpdate: new Date().toLocaleString('ar-SA'),
    };
    setAlertsList(prev => [...prev, newAlert]);
  }, []);

  const toggleAlert = useCallback((id: string) => {
    setAlertsList(prev => prev.map(a => a.id === id ? { ...a, enabled: !a.enabled } : a));
  }, []);

  const deleteAlert = useCallback((id: string) => {
    setAlertsList(prev => prev.filter(a => a.id !== id));
  }, []);

  const value = useMemo(() => ({
    prices, pricesLoading, pricesError, refreshPrices,
    portfolios, addPortfolio, deletePortfolio,
    purchasesList, addPurchase, updatePurchase, deletePurchase,
    alertsList, addAlert, toggleAlert, deleteAlert,
  }), [prices, pricesLoading, pricesError, refreshPrices, portfolios, addPortfolio, deletePortfolio, purchasesList, addPurchase, updatePurchase, deletePurchase, alertsList, addAlert, toggleAlert, deleteAlert]);

  return (
    <AppDataContext.Provider value={value}>
      {children}
    </AppDataContext.Provider>
  );
}

export function useAppData(): AppDataContextType {
  const ctx = useContext(AppDataContext);
  if (!ctx) {
    throw new Error('useAppData must be used within AppDataProvider');
  }
  return ctx;
}
