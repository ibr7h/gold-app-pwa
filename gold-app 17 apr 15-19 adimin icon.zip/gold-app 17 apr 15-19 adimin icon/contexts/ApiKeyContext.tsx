import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

export interface ApiKeyEntry {
  id: string;
  key: string;
  label: string;
  enabled: boolean;
  status: 'active' | 'quota_exceeded' | 'invalid' | 'unknown';
  lastUsed: number | null;
  lastError: string | null;
  requestCount: number;
  addedAt: number;
}

interface ApiKeyContextType {
  keys: ApiKeyEntry[];
  addKey: (key: string, label: string) => void;
  removeKey: (id: string) => void;
  updateKey: (id: string, updates: Partial<Pick<ApiKeyEntry, 'key' | 'label' | 'enabled'>>) => void;
  toggleKey: (id: string) => void;
  getActiveKey: () => ApiKeyEntry | null;
  markKeyStatus: (id: string, status: ApiKeyEntry['status'], error?: string) => void;
  rotateToNextKey: (failedKeyId: string) => ApiKeyEntry | null;
  testKey: (key: string) => Promise<{ valid: boolean; error?: string }>;
  refreshAllStatuses: () => Promise<void>;
}

const ApiKeyContext = createContext<ApiKeyContextType | undefined>(undefined);

const STORAGE_KEY = 'goldapp_api_keys';

function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

export function ApiKeyProvider({ children }: { children: React.ReactNode }) {
  const [keys, setKeys] = useState<ApiKeyEntry[]>([]);
  const currentKeyIndex = useRef(0);

  // Load keys from storage
  useEffect(() => {
    (async () => {
      try {
        const stored = await AsyncStorage.getItem(STORAGE_KEY);
        if (stored) {
          const parsed = JSON.parse(stored);
          setKeys(parsed);
        } else {
          // Initialize with default keys
          const defaultKeys: ApiKeyEntry[] = [
            {
              id: generateId(),
              key: 'goldapi-qnm0smn8qbvsb-io',
              label: 'Key 1',
              enabled: true,
              status: 'unknown',
              lastUsed: null,
              lastError: null,
              requestCount: 0,
              addedAt: Date.now(),
            },
            {
              id: generateId(),
              key: 'goldapi-1da202slw1qvww2-io',
              label: 'Key 2',
              enabled: true,
              status: 'unknown',
              lastUsed: null,
              lastError: null,
              requestCount: 0,
              addedAt: Date.now(),
            },
            {
              id: generateId(),
              key: 'goldapi-2iskrsmmnldp2f-io',
              label: 'Key 3',
              enabled: true,
              status: 'unknown',
              lastUsed: null,
              lastError: null,
              requestCount: 0,
              addedAt: Date.now(),
            },
          ];
          setKeys(defaultKeys);
          await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(defaultKeys));
        }
      } catch (e) {
        console.error('Failed to load API keys:', e);
      }
    })();
  }, []);

  // Persist keys
  const persistKeys = useCallback(async (newKeys: ApiKeyEntry[]) => {
    try {
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(newKeys));
    } catch (e) {
      console.error('Failed to persist API keys:', e);
    }
  }, []);

  const addKey = useCallback((key: string, label: string) => {
    setKeys(prev => {
      const newEntry: ApiKeyEntry = {
        id: generateId(),
        key,
        label,
        enabled: true,
        status: 'unknown',
        lastUsed: null,
        lastError: null,
        requestCount: 0,
        addedAt: Date.now(),
      };
      const updated = [...prev, newEntry];
      persistKeys(updated);
      return updated;
    });
  }, [persistKeys]);

  const removeKey = useCallback((id: string) => {
    setKeys(prev => {
      const updated = prev.filter(k => k.id !== id);
      persistKeys(updated);
      return updated;
    });
  }, [persistKeys]);

  const updateKey = useCallback((id: string, updates: Partial<Pick<ApiKeyEntry, 'key' | 'label' | 'enabled'>>) => {
    setKeys(prev => {
      const updated = prev.map(k => k.id === id ? { ...k, ...updates } : k);
      persistKeys(updated);
      return updated;
    });
  }, [persistKeys]);

  const toggleKey = useCallback((id: string) => {
    setKeys(prev => {
      const updated = prev.map(k => k.id === id ? { ...k, enabled: !k.enabled } : k);
      persistKeys(updated);
      return updated;
    });
  }, [persistKeys]);

  const getActiveKey = useCallback((): ApiKeyEntry | null => {
    const enabledKeys = keys.filter(k => k.enabled && k.status !== 'quota_exceeded' && k.status !== 'invalid');
    if (enabledKeys.length === 0) {
      // Fallback: try any enabled key even if quota_exceeded (might have reset)
      const anyEnabled = keys.filter(k => k.enabled);
      if (anyEnabled.length === 0) return null;
      const idx = currentKeyIndex.current % anyEnabled.length;
      return anyEnabled[idx];
    }
    const idx = currentKeyIndex.current % enabledKeys.length;
    return enabledKeys[idx];
  }, [keys]);

  const markKeyStatus = useCallback((id: string, status: ApiKeyEntry['status'], error?: string) => {
    setKeys(prev => {
      const updated = prev.map(k =>
        k.id === id
          ? {
              ...k,
              status,
              lastUsed: Date.now(),
              lastError: error || null,
              requestCount: k.requestCount + 1,
            }
          : k
      );
      persistKeys(updated);
      return updated;
    });
  }, [persistKeys]);

  const rotateToNextKey = useCallback((failedKeyId: string): ApiKeyEntry | null => {
    currentKeyIndex.current += 1;
    const enabledKeys = keys.filter(k => k.enabled && k.id !== failedKeyId && k.status !== 'invalid');
    if (enabledKeys.length === 0) return null;
    const idx = currentKeyIndex.current % enabledKeys.length;
    return enabledKeys[idx];
  }, [keys]);

  const testKey = useCallback(async (key: string): Promise<{ valid: boolean; error?: string }> => {
    try {
      const response = await fetch('https://www.goldapi.io/api/XAU/USD', {
        headers: {
          'x-access-token': key,
          'Content-Type': 'application/json',
        },
      });

      if (response.status === 200) {
        const data = await response.json();
        if (data.price) return { valid: true };
        return { valid: false, error: 'Invalid response format' };
      } else if (response.status === 403) {
        const data = await response.json();
        if (data.error?.includes('quota')) {
          return { valid: true, error: 'quota_exceeded' };
        }
        return { valid: false, error: data.error || 'Access denied' };
      } else if (response.status === 401) {
        return { valid: false, error: 'Invalid API key' };
      }
      return { valid: false, error: `HTTP ${response.status}` };
    } catch (e: any) {
      return { valid: false, error: e.message || 'Network error' };
    }
  }, []);

  const refreshAllStatuses = useCallback(async () => {
    const updatedKeys = [...keys];
    for (let i = 0; i < updatedKeys.length; i++) {
      const k = updatedKeys[i];
      const result = await testKey(k.key);
      if (result.valid && !result.error) {
        updatedKeys[i] = { ...k, status: 'active', lastError: null, lastUsed: Date.now() };
      } else if (result.error === 'quota_exceeded') {
        updatedKeys[i] = { ...k, status: 'quota_exceeded', lastError: 'Quota exceeded', lastUsed: Date.now() };
      } else {
        updatedKeys[i] = { ...k, status: 'invalid', lastError: result.error || 'Unknown error', lastUsed: Date.now() };
      }
    }
    setKeys(updatedKeys);
    await persistKeys(updatedKeys);
  }, [keys, testKey, persistKeys]);

  return (
    <ApiKeyContext.Provider
      value={{
        keys,
        addKey,
        removeKey,
        updateKey,
        toggleKey,
        getActiveKey,
        markKeyStatus,
        rotateToNextKey,
        testKey,
        refreshAllStatuses,
      }}
    >
      {children}
    </ApiKeyContext.Provider>
  );
}

export function useApiKeys() {
  const context = useContext(ApiKeyContext);
  if (!context) throw new Error('useApiKeys must be used within ApiKeyProvider');
  return context;
}
