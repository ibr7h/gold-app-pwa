import * as Linking from "expo-linking";
import * as ReactNative from "react-native";

// Extract scheme from bundle ID (last segment timestamp, prefixed with "manus")
const bundleId = "space.manus.gold.app.t20260317035145";
const timestamp = bundleId.split(".").pop()?.replace(/^t/, "") ?? "";
const schemeFromBundleId = `manus${timestamp}`;

// App variant suffix for unique deep link schemes per variant
// Must match the scheme logic in app.config.ts
const appVariant = process.env.EXPO_PUBLIC_APP_VARIANT ?? 'user';
const variantSuffix = appVariant === 'trader' ? 'trader' : appVariant === 'admin' ? 'admin' : '';
const variantScheme = schemeFromBundleId + variantSuffix;

const env = {
  portal: process.env.EXPO_PUBLIC_OAUTH_PORTAL_URL ?? "",
  server: process.env.EXPO_PUBLIC_OAUTH_SERVER_URL ?? "",
  appId: process.env.EXPO_PUBLIC_APP_ID ?? "",
  ownerId: process.env.EXPO_PUBLIC_OWNER_OPEN_ID ?? "",
  ownerName: process.env.EXPO_PUBLIC_OWNER_NAME ?? "",
  apiBaseUrl: process.env.EXPO_PUBLIC_API_BASE_URL ?? "",
  deepLinkScheme: variantScheme,
};

export const OAUTH_PORTAL_URL = env.portal;
export const OAUTH_SERVER_URL = env.server;
export const APP_ID = env.appId;
export const OWNER_OPEN_ID = env.ownerId;
export const OWNER_NAME = env.ownerName;
export const API_BASE_URL = env.apiBaseUrl;

/**
 * Get the API base URL, deriving from current hostname if not set.
 * Metro runs on 8081, API server runs on 3000.
 */
export function getApiBaseUrl(): string {
  if (API_BASE_URL) {
    return API_BASE_URL.replace(/\/$/, "");
  }

  if (ReactNative.Platform.OS === "web" && typeof window !== "undefined" && window.location) {
    const { protocol, hostname } = window.location;
    const apiHostname = hostname.replace(/^8081-/, "3000-");
    if (apiHostname !== hostname) {
      return `${protocol}//${apiHostname}`;
    }
  }

  return "";
}

export const SESSION_TOKEN_KEY = "app_session_token";
export const USER_INFO_KEY = "manus-runtime-user-info";

const encodeState = (value: string) => {
  if (typeof globalThis.btoa === "function") {
    return globalThis.btoa(value);
  }
  const BufferImpl = (globalThis as Record<string, any>).Buffer;
  if (BufferImpl) {
    return BufferImpl.from(value, "utf-8").toString("base64");
  }
  return value;
};

/**
 * Get the redirect URI for OAuth callback.
 * 
 * Both web and native use the server's /api/oauth/callback endpoint as redirectUri.
 * This ensures the redirectUri is always an https:// URL accepted by Manus OAuth portal.
 * 
 * For native: after the server processes the callback, it redirects to the app
 * via deep link using the scheme encoded in the state parameter.
 */
export const getRedirectUri = () => {
  return `${getApiBaseUrl()}/api/oauth/callback`;
};

/**
 * Build the state parameter for OAuth.
 * 
 * The state encodes the redirectUri (required by Manus OAuth) and optionally
 * a deep link URI for native apps. Format:
 * - Web: base64(redirectUri)
 * - Native: base64(redirectUri|deeplink:manus*:///oauth/callback)
 * 
 * The server decodes this to know where to redirect after auth.
 */
const buildState = (redirectUri: string) => {
  if (ReactNative.Platform.OS !== "web") {
    // Encode both the redirectUri and the deep link in state
    const deepLink = `${env.deepLinkScheme}:///oauth/callback`;
    return encodeState(`${redirectUri}|deeplink:${deepLink}`);
  }
  return encodeState(redirectUri);
};

export const getLoginUrl = () => {
  const redirectUri = getRedirectUri();
  const state = buildState(redirectUri);

  const url = new URL(`${OAUTH_PORTAL_URL}/app-auth`);
  url.searchParams.set("appId", APP_ID);
  url.searchParams.set("redirectUri", redirectUri);
  url.searchParams.set("state", state);
  url.searchParams.set("type", "signIn");

  return url.toString();
};

/**
 * Start OAuth login flow.
 *
 * On native: opens system browser → Manus OAuth → our server callback → deep link back to app
 * On web: redirects to Manus OAuth → our server callback → redirects to /oauth/callback page
 */
export async function startOAuthLogin(): Promise<string | null> {
  const loginUrl = getLoginUrl();

  if (ReactNative.Platform.OS === "web") {
    if (typeof window !== "undefined") {
      window.location.href = loginUrl;
    }
    return null;
  }

  const supported = await Linking.canOpenURL(loginUrl);
  if (!supported) {
    console.warn("[OAuth] Cannot open login URL: URL scheme not supported");
    return null;
  }

  try {
    await Linking.openURL(loginUrl);
  } catch (error) {
    console.error("[OAuth] Failed to open login URL:", error);
  }

  return null;
}
