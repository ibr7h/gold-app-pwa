/**
 * App Variant System
 * 
 * Controls which version of the app is being built/run:
 * - 'user'   → Dhahabi (ذهبي) - Regular user app
 * - 'trader' → Dhahabi Trader (ذهبي تاجر) - Trader app with invite code
 * - 'admin'  → Dhahabi Admin (ذهبي إدارة) - Admin management app
 * 
 * Set via EXPO_PUBLIC_APP_VARIANT environment variable.
 * Defaults to 'user' if not set.
 */

export type AppVariant = 'user' | 'trader' | 'admin';

const rawVariant = process.env.EXPO_PUBLIC_APP_VARIANT ?? 'user';

export const APP_VARIANT: AppVariant = 
  rawVariant === 'trader' ? 'trader' :
  rawVariant === 'admin' ? 'admin' :
  'user';

export const VARIANT_CONFIG: Record<AppVariant, {
  appName: string;
  appNameEn: string;
  defaultScreen: string;
  requiredRole: string;
}> = {
  user: {
    appName: 'ذهبي',
    appNameEn: 'Dhahabi',
    defaultScreen: 'home',
    requiredRole: 'user',
  },
  trader: {
    appName: 'ذهبي تاجر',
    appNameEn: 'Dhahabi Trader',
    defaultScreen: 'trader-home',
    requiredRole: 'trader',
  },
  admin: {
    appName: 'ذهبي إدارة',
    appNameEn: 'Dhahabi Admin',
    defaultScreen: 'admin',
    requiredRole: 'admin',
  },
};

export const currentVariantConfig = VARIANT_CONFIG[APP_VARIANT];
