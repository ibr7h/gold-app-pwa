// Load environment variables with proper priority (system > .env)
import "./scripts/load-env.js";
import type { ExpoConfig } from "expo/config";

// Bundle ID format: space.manus.<project_name_dots>.<timestamp>
// e.g., "my-app" created at 2024-01-15 10:30:45 -> "space.manus.my.app.t20240115103045"
// Bundle ID can only contain letters, numbers, and dots
// Android requires each dot-separated segment to start with a letter
const rawBundleId = "space.manus.gold.app.t20260317035145";
const bundleId =
  rawBundleId
    .replace(/[-_]/g, ".") // Replace hyphens/underscores with dots
    .replace(/[^a-zA-Z0-9.]/g, "") // Remove invalid chars
    .replace(/\.+/g, ".") // Collapse consecutive dots
    .replace(/^\.+|\.+$/g, "") // Trim leading/trailing dots
    .toLowerCase()
    .split(".")
    .map((segment) => {
      // Android requires each segment to start with a letter
      // Prefix with 'x' if segment starts with a digit
      return /^[a-zA-Z]/.test(segment) ? segment : "x" + segment;
    })
    .join(".") || "space.manus.app";
// Extract timestamp from bundle ID and prefix with "manus" for deep link scheme
// e.g., "space.manus.my.app.t20240115103045" -> "manus20240115103045"
const timestamp = bundleId.split(".").pop()?.replace(/^t/, "") ?? "";
const schemeFromBundleId = `manus${timestamp}`;

// App variant: 'user' | 'trader' | 'admin'
const appVariant = (process.env.EXPO_PUBLIC_APP_VARIANT ?? 'user') as string;

const variantNames: Record<string, string> = {
  user: 'ذهبي',
  trader: 'ذهبي تاجر',
  admin: 'ذهبي إدارة',
};

const variantIcons: Record<string, string> = {
  user: './assets/images/icon.png',
  trader: './assets/images/trader-icon.png',
  admin: './assets/images/admin-icon.png',
};

// Android adaptive icon foreground per variant
const variantAndroidForeground: Record<string, string> = {
  user: './assets/images/android-icon-foreground.png',
  trader: './assets/images/trader-icon.png',
  admin: './assets/images/admin-icon.png',
};

// Splash icon per variant
const variantSplashIcons: Record<string, string> = {
  user: './assets/images/splash-icon.png',
  trader: './assets/images/trader-icon.png',
  admin: './assets/images/admin-icon.png',
};

// Favicon per variant
const variantFavicons: Record<string, string> = {
  user: './assets/images/favicon.png',
  trader: './assets/images/trader-icon.png',
  admin: './assets/images/admin-icon.png',
};

const variantLogos: Record<string, string> = {
  user: 'https://d2xsxph8kpxj0f.cloudfront.net/113213009/ePdHZxQusFeQdV5h42cbmw/gold-app-royal-icon-hH985hjk3HGwLprm4y8Pyj.png',
  trader: 'https://d2xsxph8kpxj0f.cloudfront.net/113213009/ePdHZxQusFeQdV5h42cbmw/dhahabi-trader-icon-MRuFKpsHKhWBGQdUF56Tuc.png',
  admin: 'https://d2xsxph8kpxj0f.cloudfront.net/113213009/ePdHZxQusFeQdV5h42cbmw/dhahabi-admin-icon-m6SUyDNiHMpp3sk8NYA58M.png',
};

// Variant-specific suffixes for unique package names (allows side-by-side installation)
const variantPackageSuffix: Record<string, string> = {
  user: '',
  trader: '.trader',
  admin: '.admin',
};

// Build variant-specific bundle ID and package name
const suffix = variantPackageSuffix[appVariant] || '';
const variantBundleId = bundleId + suffix;
const variantScheme = schemeFromBundleId + (suffix ? suffix.replace('.', '') : '');

const env = {
  // App branding - variant-specific name
  appName: variantNames[appVariant] || 'ذهبي',
  appSlug: "gold-app",
  // S3 URL of the app logo
  logoUrl: variantLogos[appVariant] || variantLogos.user,
  scheme: variantScheme,
  iosBundleId: variantBundleId,
  androidPackage: variantBundleId,
};

const config: ExpoConfig = {
  name: env.appName,
  slug: env.appSlug,
  version: "1.0.0",
  orientation: "portrait",
  icon: variantIcons[appVariant] || variantIcons.user,
  scheme: env.scheme,
  userInterfaceStyle: "automatic",
  newArchEnabled: true,
  ios: {
    supportsTablet: true,
    bundleIdentifier: env.iosBundleId,
    "infoPlist": {
        "ITSAppUsesNonExemptEncryption": false
      }
  },
  android: {
    adaptiveIcon: {
      backgroundColor: "#0F1115",
      foregroundImage: variantAndroidForeground[appVariant] || variantAndroidForeground.user,
      backgroundImage: "./assets/images/android-icon-background.png",
      monochromeImage: "./assets/images/android-icon-monochrome.png",
    },
    edgeToEdgeEnabled: true,
    predictiveBackGestureEnabled: false,
    package: env.androidPackage,
    permissions: ["POST_NOTIFICATIONS"],
    intentFilters: [
      {
        action: "VIEW",
        autoVerify: true,
        data: [
          {
            scheme: env.scheme,
            host: "*",
          },
        ],
        category: ["BROWSABLE", "DEFAULT"],
      },
    ],
  },
  web: {
    bundler: "metro",
    output: "static",
    favicon: variantFavicons[appVariant] || variantFavicons.user,
  },
  plugins: [
    "expo-router",
    [
      "expo-notifications",
      {
        color: "#C5A021",
        defaultChannel: "gold-price-alerts",
      },
    ],
    [
      "expo-local-authentication",
      {
        faceIDPermission: "Allow $(PRODUCT_NAME) to use Face ID for secure login."
      }
    ],
    [
      "expo-audio",
      {
        microphonePermission: "Allow $(PRODUCT_NAME) to access your microphone.",
      },
    ],
    [
      "expo-video",
      {
        supportsBackgroundPlayback: true,
        supportsPictureInPicture: true,
      },
    ],
    [
      "expo-splash-screen",
      {
        image: variantSplashIcons[appVariant] || variantSplashIcons.user,
        imageWidth: 200,
        resizeMode: "contain",
        backgroundColor: "#0F1115",
        dark: {
          backgroundColor: "#0F1115",
        },
      },
    ],
    [
      "expo-build-properties",
      {
        android: {
          buildArchs: ["armeabi-v7a", "arm64-v8a"],
          minSdkVersion: 24,
        },
      },
    ],
  ],
  experiments: {
    typedRoutes: true,
    reactCompiler: true,
  },
};

export default config;
