import * as FileSystem from 'expo-file-system/legacy';
import * as Sharing from 'expo-sharing';
import { Platform, Alert } from 'react-native';

interface ExportColumn {
  key: string;
  header: string;
}

/**
 * Export data as CSV file with sharing support
 */
export async function exportToCSV(
  data: Record<string, any>[],
  columns: ExportColumn[],
  fileName: string,
  title?: string,
): Promise<boolean> {
  try {
    // Build CSV content with BOM for Excel UTF-8 support
    const BOM = '\uFEFF';
    const headers = columns.map(c => `"${c.header}"`).join(',');
    const rows = data.map(row =>
      columns.map(c => {
        const val = row[c.key];
        if (val === null || val === undefined) return '""';
        const str = String(val).replace(/"/g, '""');
        return `"${str}"`;
      }).join(',')
    );
    const csv = BOM + headers + '\n' + rows.join('\n');

    if (Platform.OS === 'web') {
      // Web: download directly
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName;
      a.click();
      URL.revokeObjectURL(url);
      return true;
    }

    // Native: save to file system and share
    const filePath = `${FileSystem.documentDirectory}${fileName}`;
    await FileSystem.writeAsStringAsync(filePath, csv, {
      encoding: FileSystem.EncodingType.UTF8,
    });

    const canShare = await Sharing.isAvailableAsync();
    if (canShare) {
      await Sharing.shareAsync(filePath, {
        mimeType: 'text/csv',
        dialogTitle: title || fileName,
        UTI: 'public.comma-separated-values-text',
      });
    }

    return true;
  } catch (error) {
    console.warn('[ExportService] CSV export failed:', error);
    return false;
  }
}

/**
 * Export orders data
 */
export function exportOrders(
  orders: any[],
  lang: string,
  currencySymbol: string,
): Promise<boolean> {
  const columns: ExportColumn[] = lang === 'ar' ? [
    { key: 'id', header: 'المعرف' },
    { key: 'clientName', header: 'العميل' },
    { key: 'type', header: 'النوع' },
    { key: 'karat', header: 'العيار' },
    { key: 'grams', header: 'الوزن (جرام)' },
    { key: 'pricePerGram', header: 'سعر الجرام' },
    { key: 'totalAmount', header: 'الإجمالي' },
    { key: 'status', header: 'الحالة' },
    { key: 'date', header: 'التاريخ' },
    { key: 'notes', header: 'ملاحظات' },
  ] : lang === 'fr' ? [
    { key: 'id', header: 'ID' },
    { key: 'clientName', header: 'Client' },
    { key: 'type', header: 'Type' },
    { key: 'karat', header: 'Carat' },
    { key: 'grams', header: 'Poids (g)' },
    { key: 'pricePerGram', header: 'Prix/g' },
    { key: 'totalAmount', header: 'Total' },
    { key: 'status', header: 'Statut' },
    { key: 'date', header: 'Date' },
    { key: 'notes', header: 'Notes' },
  ] : [
    { key: 'id', header: 'ID' },
    { key: 'clientName', header: 'Client' },
    { key: 'type', header: 'Type' },
    { key: 'karat', header: 'Karat' },
    { key: 'grams', header: 'Weight (g)' },
    { key: 'pricePerGram', header: 'Price/g' },
    { key: 'totalAmount', header: 'Total' },
    { key: 'status', header: 'Status' },
    { key: 'date', header: 'Date' },
    { key: 'notes', header: 'Notes' },
  ];

  const statusLabels: Record<string, Record<string, string>> = {
    ar: { pending: 'معلق', processing: 'قيد التنفيذ', completed: 'مكتمل', cancelled: 'ملغي' },
    fr: { pending: 'En attente', processing: 'En cours', completed: 'Terminé', cancelled: 'Annulé' },
    en: { pending: 'Pending', processing: 'Processing', completed: 'Completed', cancelled: 'Cancelled' },
  };

  const typeLabels: Record<string, Record<string, string>> = {
    ar: { buy: 'شراء', sell: 'بيع' },
    fr: { buy: 'Achat', sell: 'Vente' },
    en: { buy: 'Buy', sell: 'Sell' },
  };

  const formattedData = orders.map(o => ({
    ...o,
    type: typeLabels[lang]?.[o.type] || o.type,
    status: statusLabels[lang]?.[o.status] || o.status,
    karat: `${o.karat}K`,
    pricePerGram: `${currencySymbol} ${o.pricePerGram?.toLocaleString() || ''}`,
    totalAmount: `${currencySymbol} ${o.totalAmount?.toLocaleString() || ''}`,
  }));

  const fileName = `orders-${Date.now()}.csv`;
  const title = lang === 'ar' ? 'تصدير الطلبات' : lang === 'fr' ? 'Export des commandes' : 'Export Orders';

  return exportToCSV(formattedData, columns, fileName, title);
}

/**
 * Export clients data
 */
export function exportClients(
  clients: any[],
  lang: string,
  currencySymbol: string,
): Promise<boolean> {
  const columns: ExportColumn[] = lang === 'ar' ? [
    { key: 'id', header: 'المعرف' },
    { key: 'name', header: 'الاسم' },
    { key: 'email', header: 'البريد الإلكتروني' },
    { key: 'phone', header: 'الهاتف' },
    { key: 'totalOrders', header: 'عدد الطلبات' },
    { key: 'totalSpent', header: 'إجمالي الإنفاق' },
    { key: 'status', header: 'الحالة' },
    { key: 'joinDate', header: 'تاريخ الانضمام' },
  ] : lang === 'fr' ? [
    { key: 'id', header: 'ID' },
    { key: 'name', header: 'Nom' },
    { key: 'email', header: 'Email' },
    { key: 'phone', header: 'Téléphone' },
    { key: 'totalOrders', header: 'Commandes' },
    { key: 'totalSpent', header: 'Total dépensé' },
    { key: 'status', header: 'Statut' },
    { key: 'joinDate', header: 'Date d\'inscription' },
  ] : [
    { key: 'id', header: 'ID' },
    { key: 'name', header: 'Name' },
    { key: 'email', header: 'Email' },
    { key: 'phone', header: 'Phone' },
    { key: 'totalOrders', header: 'Orders' },
    { key: 'totalSpent', header: 'Total Spent' },
    { key: 'status', header: 'Status' },
    { key: 'joinDate', header: 'Join Date' },
  ];

  const statusLabels: Record<string, Record<string, string>> = {
    ar: { active: 'نشط', inactive: 'غير نشط' },
    fr: { active: 'Actif', inactive: 'Inactif' },
    en: { active: 'Active', inactive: 'Inactive' },
  };

  const formattedData = clients.map(c => ({
    ...c,
    status: statusLabels[lang]?.[c.status] || c.status,
    totalSpent: `${currencySymbol} ${c.totalSpent?.toLocaleString() || ''}`,
  }));

  const fileName = `clients-${Date.now()}.csv`;
  const title = lang === 'ar' ? 'تصدير العملاء' : lang === 'fr' ? 'Export des clients' : 'Export Clients';

  return exportToCSV(formattedData, columns, fileName, title);
}
