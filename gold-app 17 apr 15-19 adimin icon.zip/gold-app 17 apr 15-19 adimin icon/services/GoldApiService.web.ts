import AsyncStorage from '@react-native-async-storage/async-storage';

export interface GoldApiResponse {
  timestamp: number;
  metal: string;
  currency: string;
  exchange: string;
  symbol: string;
  prev_close_price: number;
  open_price: number;
  low_price: number;
  high_price: number;
  open_time: number;
  price: number;
  ch: number;
  chp: number;
  ask: number;
  bid: number;
  price_gram_24k: number;
  price_gram_22k: number;
  price_gram_21k: number;
  price_gram_20k: number;
  price_gram_18k: number;
  price_gram_16k: number;
  price_gram_14k: number;
  price_gram_10k: number;
}

export interface KaratPrice {
  karat: string;
  pricePerGram: number;
}

export interface GoldPriceData {
  pricePerOunce: number;
  pricePerGram24K: number;
  currency: string;
  change: number;
  changePercent: number;
  high: number;
  low: number;
  open: number;
  prevClose: number;
  ask: number;
  bid: number;
  timestamp: number;
  karatPrices: KaratPrice[];
  source: string;
  isLive: boolean;
}

export interface FetchOptions {
  currency?: string;
  forceRefresh?: boolean;
  apiKey?: string;
  onKeyFailed?: (key: string, error: string) => void;
  getNextKey?: () => string | null;
}

const CACHE_KEY='gold_pwa_backend_price';
const API='https://gold-app-api-u8dl.onrender.com';
const OZ_GRAMS=31.1034768;
const KARATS=[24,22,21,20,18,16,14,10];

async function latest(currency:string,karat:number){
  const r=await fetch(API+'/prices/latest?currency='+encodeURIComponent(currency)+'&karat='+karat,{cache:'no-store'});
  if(!r.ok) throw new Error('Backend price unavailable: '+r.status);
  const row=await r.json();
  const price=Number(row?.buyPrice);
  if(!Number.isFinite(price)||price<=0) throw new Error('Backend price is invalid');
  return row;
}

export async function fetchGoldPrice(options:FetchOptions={}):Promise<GoldPriceData>{
  const currency=(options.currency||'SAR').toUpperCase();
  if(!['SAR','USD'].includes(currency)) throw new Error('Unsupported backend price currency: '+currency);
  try{
    const base=await latest(currency,24);
    const gram24=Number(base.buyPrice);
    const kp=(k:number)=>gram24*(k/24);
    const ts=Date.parse(base.timestamp);
    const data:GoldPriceData={
      pricePerOunce:gram24*OZ_GRAMS,
      pricePerGram24K:gram24,
      currency,
      change:0,
      changePercent:0,
      high:gram24*OZ_GRAMS,
      low:gram24*OZ_GRAMS,
      open:gram24*OZ_GRAMS,
      prevClose:gram24*OZ_GRAMS,
      ask:Number(base.sellPrice)||gram24,
      bid:gram24,
      timestamp:Number.isFinite(ts)?ts:Date.now(),
      karatPrices:KARATS.map(k=>({karat:k+'K',pricePerGram:kp(k)})),
      source:String(base.source||'Dhahabi Backend'),
      isLive:true,
    };
    await AsyncStorage.setItem(CACHE_KEY+'_'+currency,JSON.stringify(data));
    return data;
  }catch(e){
    const cached=await AsyncStorage.getItem(CACHE_KEY+'_'+currency);
    if(cached) return {...JSON.parse(cached),isLive:false,source:'Cached backend'};
    throw e;
  }
}

export async function clearCache():Promise<void>{
  for(const code of ['SAR','USD']) await AsyncStorage.removeItem(CACHE_KEY+'_'+code);
}

export const SUPPORTED_CURRENCIES=[
  {code:'SAR',nameAr:'ريال سعودي',nameEn:'Saudi Riyal',nameFr:'Riyal saoudien',symbol:'ر.س'},
  {code:'USD',nameAr:'دولار أمريكي',nameEn:'US Dollar',nameFr:'Dollar américain',symbol:'$'},
];
export const KARAT_OPTIONS=['24K','22K','21K','18K'];
