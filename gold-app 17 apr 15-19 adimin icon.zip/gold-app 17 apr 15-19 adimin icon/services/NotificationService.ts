import { Platform } from 'react-native';
import * as Notifications from 'expo-notifications';
import AsyncStorage from '@react-native-async-storage/async-storage';
import type { Alert, GoldPrice } from '@/data/mock';

const NOTIFICATION_SETTINGS_KEY = '@gold_notification_settings';

export interface NotificationSettings {
  enabled: boolean;
  newOrders: boolean;
  statusChanges: boolean;
  newMessages: boolean;
  priceAlerts: boolean;
}

const DEFAULT_SETTINGS: NotificationSettings = {
  enabled: true,
  newOrders: true,
  statusChanges: true,
  newMessages: true,
  priceAlerts: true,
};

// Configure notification handler for foreground display
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

// Android notification channel
const CHANNEL_ID = 'gold-price-alerts';

export interface NotificationResult {
  alertsChecked: number;
  alertsTriggered: number;
  triggeredAlerts: string[];
}

class NotificationService {
  private initialized = false;
  private settings: NotificationSettings = DEFAULT_SETTINGS;

  /** Initialize notification channel (Android) */
  async init(): Promise<void> {
    if (this.initialized) return;
    if (Platform.OS === 'android') {
      await Notifications.setNotificationChannelAsync(CHANNEL_ID, {
        name: 'Gold Price Alerts',
        description: 'Notifications when gold prices reach your target',
        importance: Notifications.AndroidImportance.HIGH,
        vibrationPattern: [0, 250, 250, 250],
        lightColor: '#C5A021',
        sound: 'default',
      });

      await Notifications.setNotificationChannelAsync('orders', {
        name: 'Orders',
        importance: Notifications.AndroidImportance.HIGH,
        vibrationPattern: [0, 250, 250, 250],
        lightColor: '#C5A021',
      });

      await Notifications.setNotificationChannelAsync('messages', {
        name: 'Messages',
        importance: Notifications.AndroidImportance.HIGH,
        vibrationPattern: [0, 200],
        lightColor: '#3B82F6',
      });
    }
    await this.loadSettings();
    this.initialized = true;
  }

  /** Load notification settings from storage */
  async loadSettings(): Promise<NotificationSettings> {
    try {
      const stored = await AsyncStorage.getItem(NOTIFICATION_SETTINGS_KEY);
      if (stored) {
        this.settings = { ...DEFAULT_SETTINGS, ...JSON.parse(stored) };
      }
    } catch {
      this.settings = DEFAULT_SETTINGS;
    }
    return this.settings;
  }

  /** Save notification settings */
  async saveSettings(update: Partial<NotificationSettings>): Promise<void> {
    this.settings = { ...this.settings, ...update };
    await AsyncStorage.setItem(NOTIFICATION_SETTINGS_KEY, JSON.stringify(this.settings));
  }

  /** Get current settings */
  getSettings(): NotificationSettings {
    return this.settings;
  }

  // === Trader Event Notifications ===

  /** Notify trader of a new order */
  async notifyNewOrder(orderId: string, clientName: string, amount: number, currency: string): Promise<void> {
    if (!this.settings.enabled || !this.settings.newOrders) return;
    if (Platform.OS === 'web') return;
    await this.init();
    await Notifications.scheduleNotificationAsync({
      content: {
        title: '\uD83D\uDCE6 \u0637\u0644\u0628 \u062C\u062F\u064A\u062F | New Order',
        body: `${clientName} - ${currency}${amount.toLocaleString()}`,
        data: { type: 'new_order', orderId },
        ...(Platform.OS === 'android' ? { channelId: 'orders' } : {}),
      },
      trigger: null,
    });
  }

  /** Notify trader of order status change */
  async notifyOrderStatusChange(orderId: string, clientName: string, newStatus: string): Promise<void> {
    if (!this.settings.enabled || !this.settings.statusChanges) return;
    if (Platform.OS === 'web') return;
    await this.init();
    const statusLabels: Record<string, string> = {
      pending: '\u23F3 \u0645\u0639\u0644\u0642 | Pending',
      processing: '\uD83D\uDD04 \u0642\u064A\u062F \u0627\u0644\u062A\u0646\u0641\u064A\u0630 | Processing',
      completed: '\u2705 \u0645\u0643\u062A\u0645\u0644 | Completed',
      cancelled: '\u274C \u0645\u0644\u063A\u064A | Cancelled',
    };
    await Notifications.scheduleNotificationAsync({
      content: {
        title: '\uD83D\uDCCB \u062A\u062D\u062F\u064A\u062B \u062D\u0627\u0644\u0629 \u0627\u0644\u0637\u0644\u0628 | Order Update',
        body: `${clientName}: ${statusLabels[newStatus] || newStatus}`,
        data: { type: 'order_status', orderId, status: newStatus },
        ...(Platform.OS === 'android' ? { channelId: 'orders' } : {}),
      },
      trigger: null,
    });
  }

  /** Notify trader of a new message */
  async notifyNewMessage(senderName: string, messagePreview: string, conversationId: string): Promise<void> {
    if (!this.settings.enabled || !this.settings.newMessages) return;
    if (Platform.OS === 'web') return;
    await this.init();
    await Notifications.scheduleNotificationAsync({
      content: {
        title: `\uD83D\uDCAC ${senderName}`,
        body: messagePreview.length > 80 ? messagePreview.substring(0, 80) + '...' : messagePreview,
        data: { type: 'new_message', conversationId },
        ...(Platform.OS === 'android' ? { channelId: 'messages' } : {}),
      },
      trigger: null,
    });
  }

  /** Request notification permissions */
  async requestPermissions(): Promise<boolean> {
    const { status: existingStatus } = await Notifications.getPermissionsAsync();
    if (existingStatus === 'granted') return true;

    const { status } = await Notifications.requestPermissionsAsync();
    return status === 'granted';
  }

  /** Check current permission status */
  async getPermissionStatus(): Promise<'granted' | 'denied' | 'undetermined'> {
    const { status } = await Notifications.getPermissionsAsync();
    return status;
  }

  /** Send a test notification */
  async sendTestNotification(title: string, body: string): Promise<void> {
    await this.init();
    await Notifications.scheduleNotificationAsync({
      content: {
        title,
        body,
        sound: 'default',
        data: { type: 'test' },
      },
      trigger: {
        type: Notifications.SchedulableTriggerInputTypes.TIME_INTERVAL,
        seconds: 1,
      },
    });
  }

  /** Send a price alert notification */
  async sendPriceAlertNotification(
    alertTitle: string,
    body: string,
    alertId: string,
  ): Promise<void> {
    await this.init();
    await Notifications.scheduleNotificationAsync({
      content: {
        title: alertTitle,
        body,
        sound: 'default',
        data: { type: 'price_alert', alertId },
      },
      trigger: {
        type: Notifications.SchedulableTriggerInputTypes.TIME_INTERVAL,
        seconds: 1,
      },
    });
  }

  /** Check alerts against current prices and send notifications for triggered alerts */
  async checkAlerts(
    alerts: Alert[],
    prices: GoldPrice[],
    notificationTitle: string,
    formatAbove: (karat: string, price: number, currency: string) => string,
    formatBelow: (karat: string, price: number, currency: string) => string,
  ): Promise<NotificationResult> {
    await this.init();

    const activeAlerts = alerts.filter(a => a.enabled && a.status === 'active');
    const result: NotificationResult = {
      alertsChecked: activeAlerts.length,
      alertsTriggered: 0,
      triggeredAlerts: [],
    };

    for (const alert of activeAlerts) {
      const priceData = prices.find(p => p.karat === alert.karat);
      if (!priceData) continue;

      const currentPrice = priceData.buyPrice;
      let triggered = false;

      if (alert.condition === '>=' && currentPrice >= alert.targetPrice) {
        triggered = true;
      } else if (alert.condition === '<=' && currentPrice <= alert.targetPrice) {
        triggered = true;
      }

      if (triggered) {
        const body = alert.condition === '>='
          ? formatAbove(priceData.karatLabel, alert.targetPrice, alert.currency)
          : formatBelow(priceData.karatLabel, alert.targetPrice, alert.currency);

        await this.sendPriceAlertNotification(notificationTitle, body, alert.id);
        result.alertsTriggered++;
        result.triggeredAlerts.push(alert.id);
      }
    }

    return result;
  }

  /** Cancel all scheduled notifications */
  async cancelAll(): Promise<void> {
    await Notifications.cancelAllScheduledNotificationsAsync();
  }

  /** Get count of scheduled notifications */
  async getScheduledCount(): Promise<number> {
    const scheduled = await Notifications.getAllScheduledNotificationsAsync();
    return scheduled.length;
  }

  /** Set badge count */
  async setBadge(count: number): Promise<void> {
    await Notifications.setBadgeCountAsync(count);
  }

  /** Add listener for received notifications */
  addNotificationReceivedListener(
    callback: (notification: Notifications.Notification) => void,
  ): Notifications.EventSubscription {
    return Notifications.addNotificationReceivedListener(callback);
  }

  /** Add listener for notification responses (taps) */
  addNotificationResponseListener(
    callback: (response: Notifications.NotificationResponse) => void,
  ): Notifications.EventSubscription {
    return Notifications.addNotificationResponseReceivedListener(callback);
  }
}

// Singleton instance
export const notificationService = new NotificationService();
