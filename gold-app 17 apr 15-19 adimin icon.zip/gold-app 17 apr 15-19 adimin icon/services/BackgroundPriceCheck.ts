import { Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { fetchGoldPrice, GoldPriceData } from './GoldApiService';

// Background task name
export const BACKGROUND_PRICE_CHECK_TASK = 'BACKGROUND_PRICE_CHECK';

const ALERTS_STORAGE_KEY = 'goldapp_alerts';
const API_KEYS_STORAGE_KEY = 'goldapp_api_keys';

interface StoredAlert {
  id: string;
  karat: string;
  condition: 'gte' | 'lte';
  targetPrice: number;
  currency: string;
  active: boolean;
}

interface StoredApiKey {
  id: string;
  key: string;
  enabled: boolean;
  status: string;
}

async function getActiveApiKey(): Promise<string | null> {
  try {
    const stored = await AsyncStorage.getItem(API_KEYS_STORAGE_KEY);
    if (!stored) return null;
    const keys: StoredApiKey[] = JSON.parse(stored);
    const active = keys.find(k => k.enabled && k.status !== 'invalid');
    return active?.key || null;
  } catch {
    return null;
  }
}

async function getActiveAlerts(): Promise<StoredAlert[]> {
  try {
    const stored = await AsyncStorage.getItem(ALERTS_STORAGE_KEY);
    if (!stored) return [];
    const alerts: StoredAlert[] = JSON.parse(stored);
    return alerts.filter(a => a.active);
  } catch {
    return [];
  }
}

function checkAlertsAgainstPrices(alerts: StoredAlert[], priceData: GoldPriceData): StoredAlert[] {
  const triggered: StoredAlert[] = [];

  for (const alert of alerts) {
    const karatPrice = priceData.karatPrices.find(k => k.karat === alert.karat);
    if (!karatPrice) continue;

    const price = karatPrice.pricePerGram;
    if (alert.condition === 'gte' && price >= alert.targetPrice) {
      triggered.push(alert);
    } else if (alert.condition === 'lte' && price <= alert.targetPrice) {
      triggered.push(alert);
    }
  }

  return triggered;
}

// This function is called by the background task
export async function performBackgroundPriceCheck(): Promise<{
  triggered: StoredAlert[];
  priceData: GoldPriceData | null;
}> {
  try {
    const apiKey = await getActiveApiKey();
    const alerts = await getActiveAlerts();

    if (alerts.length === 0) {
      return { triggered: [], priceData: null };
    }

    const currency = alerts[0]?.currency || 'USD';
    const priceData = await fetchGoldPrice({
      currency,
      forceRefresh: true,
      apiKey: apiKey || undefined,
    });

    const triggered = checkAlertsAgainstPrices(alerts, priceData);
    return { triggered, priceData };
  } catch (error) {
    console.error('Background price check failed:', error);
    return { triggered: [], priceData: null };
  }
}

// Register the background task - must be called at app startup (top-level)
export function registerBackgroundTask() {
  if (Platform.OS === 'web') return; // Background tasks not supported on web

  try {
    const TaskManager = require('expo-task-manager');
    const Notifications = require('expo-notifications');

    TaskManager.defineTask(BACKGROUND_PRICE_CHECK_TASK, async () => {
      const BackgroundFetch = require('expo-background-fetch');
      try {
        const { triggered, priceData } = await performBackgroundPriceCheck();

        if (triggered.length > 0 && priceData) {
          for (const alert of triggered) {
            const karatPrice = priceData.karatPrices.find(k => k.karat === alert.karat);
            await Notifications.scheduleNotificationAsync({
              content: {
                title: '🔔 تنبيه سعر الذهب',
                body: `${alert.karat} ${alert.condition === 'gte' ? '≥' : '≤'} ${alert.targetPrice} ${alert.currency} (الحالي: ${karatPrice?.pricePerGram.toFixed(2)})`,
                data: { alertId: alert.id },
              },
              trigger: null,
            });
          }
        }

        return triggered.length > 0
          ? BackgroundFetch.BackgroundFetchResult.NewData
          : BackgroundFetch.BackgroundFetchResult.NoData;
      } catch (error) {
        const BackgroundFetch = require('expo-background-fetch');
        return BackgroundFetch.BackgroundFetchResult.Failed;
      }
    });
  } catch (e) {
    // expo-task-manager not available (web or dev)
    console.log('Background task registration skipped:', e);
  }
}

// Start the background fetch
export async function startBackgroundPriceCheck(intervalMinutes: number = 30) {
  if (Platform.OS === 'web') return;

  try {
    const BackgroundFetch = require('expo-background-fetch');

    const status = await BackgroundFetch.getStatusAsync();
    if (status === BackgroundFetch.BackgroundFetchStatus.Denied) {
      console.log('Background fetch is denied');
      return;
    }

    await BackgroundFetch.registerTaskAsync(BACKGROUND_PRICE_CHECK_TASK, {
      minimumInterval: intervalMinutes * 60,
      stopOnTerminate: false,
      startOnBoot: true,
    });

    console.log('Background price check registered with interval:', intervalMinutes, 'minutes');
  } catch (e) {
    console.log('Failed to register background task:', e);
  }
}

// Stop the background fetch
export async function stopBackgroundPriceCheck() {
  if (Platform.OS === 'web') return;

  try {
    const BackgroundFetch = require('expo-background-fetch');
    await BackgroundFetch.unregisterTaskAsync(BACKGROUND_PRICE_CHECK_TASK);
    console.log('Background price check unregistered');
  } catch (e) {
    console.log('Failed to unregister background task:', e);
  }
}
