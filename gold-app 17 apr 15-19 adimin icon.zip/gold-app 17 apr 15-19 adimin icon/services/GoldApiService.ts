import AsyncStorage from '@react-native-async-storage/async-storage';

// GoldAPI.io response type
export interface GoldApiResponse {
  timestamp: number;
  metal: string;
  currency: string;
  exchange: string;
  symbol: string;
  prev_close_price: number;
  open_price: number;
  low_price: number;
  high_price: number;
  open_time: number;
  price: number;
  ch: number;
  chp: number;
  ask: number;
  bid: number;
  price_gram_24k: number;
  price_gram_22k: number;
  price_gram_21k: number;
  price_gram_20k: number;
  price_gram_18k: number;
  price_gram_16k: number;
  price_gram_14k: number;
  price_gram_10k: number;
}

export interface KaratPrice {
  karat: string;
  pricePerGram: number;
}

export interface GoldPriceData {
  pricePerOunce: number;
  pricePerGram24K: number;
  currency: string;
  change: number;
  changePercent: number;
  high: number;
  low: number;
  open: number;
  prevClose: number;
  ask: number;
  bid: number;
  timestamp: number;
  karatPrices: KaratPrice[];
  source: string;
  isLive: boolean;
}

const CACHE_KEY = 'goldapi_cache';
const CACHE_DURATION = 120000; // 2 min cache
const API_BASE = 'https://www.goldapi.io/api';

interface CachedData {
  data: GoldPriceData;
  fetchedAt: number;
}

let memoryCache: Record<string, CachedData> = {};

async function getCachedData(currency: string): Promise<GoldPriceData | null> {
  const key = `${CACHE_KEY}_${currency}`;
  if (memoryCache[key] && Date.now() - memoryCache[key].fetchedAt < CACHE_DURATION) {
    return memoryCache[key].data;
  }
  try {
    const cached = await AsyncStorage.getItem(key);
    if (cached) {
      const parsed: CachedData = JSON.parse(cached);
      if (Date.now() - parsed.fetchedAt < CACHE_DURATION) {
        memoryCache[key] = parsed;
        return parsed.data;
      }
    }
  } catch (e) {}
  return null;
}

async function setCachedData(currency: string, data: GoldPriceData): Promise<void> {
  const key = `${CACHE_KEY}_${currency}`;
  const cached: CachedData = { data, fetchedAt: Date.now() };
  memoryCache[key] = cached;
  try {
    await AsyncStorage.setItem(key, JSON.stringify(cached));
  } catch (e) {}
}

async function getStaleCache(currency: string): Promise<GoldPriceData | null> {
  const key = `${CACHE_KEY}_${currency}`;
  try {
    if (memoryCache[key]) return memoryCache[key].data;
    const cached = await AsyncStorage.getItem(key);
    if (cached) return JSON.parse(cached).data;
  } catch (e) {}
  return null;
}

function parseResponse(response: GoldApiResponse): GoldPriceData {
  return {
    pricePerOunce: response.price,
    pricePerGram24K: response.price_gram_24k,
    currency: response.currency,
    change: response.ch,
    changePercent: response.chp,
    high: response.high_price,
    low: response.low_price,
    open: response.open_price,
    prevClose: response.prev_close_price,
    ask: response.ask,
    bid: response.bid,
    timestamp: response.timestamp * 1000,
    karatPrices: [
      { karat: '24K', pricePerGram: response.price_gram_24k },
      { karat: '22K', pricePerGram: response.price_gram_22k },
      { karat: '21K', pricePerGram: response.price_gram_21k },
      { karat: '20K', pricePerGram: response.price_gram_20k },
      { karat: '18K', pricePerGram: response.price_gram_18k },
      { karat: '16K', pricePerGram: response.price_gram_16k },
      { karat: '14K', pricePerGram: response.price_gram_14k },
      { karat: '10K', pricePerGram: response.price_gram_10k },
    ],
    source: response.exchange || 'FOREX',
    isLive: true,
  };
}

export interface FetchOptions {
  currency?: string;
  forceRefresh?: boolean;
  apiKey?: string;
  onKeyFailed?: (key: string, error: string) => void;
  getNextKey?: () => string | null;
}

export async function fetchGoldPrice(options: FetchOptions = {}): Promise<GoldPriceData> {
  const { currency = 'USD', forceRefresh = false, apiKey, onKeyFailed, getNextKey } = options;

  // Check cache unless force refresh
  if (!forceRefresh) {
    const cached = await getCachedData(currency);
    if (cached) return cached;
  }

  // Try with provided key
  if (apiKey) {
    const result = await tryFetchWithKey(apiKey, currency);
    if (result.success && result.data) {
      await setCachedData(currency, result.data);
      return result.data;
    }

    // Key failed - notify and try rotation
    if (onKeyFailed) {
      onKeyFailed(apiKey, result.error || 'Unknown error');
    }

    // Try next keys via rotation
    if (getNextKey) {
      let nextKey = getNextKey();
      let attempts = 0;
      while (nextKey && attempts < 5) {
        const rotateResult = await tryFetchWithKey(nextKey, currency);
        if (rotateResult.success && rotateResult.data) {
          await setCachedData(currency, rotateResult.data);
          return rotateResult.data;
        }
        if (onKeyFailed) onKeyFailed(nextKey, rotateResult.error || 'Unknown error');
        nextKey = getNextKey();
        attempts++;
      }
    }
  }

  // All keys failed or no key - try stale cache
  const stale = await getStaleCache(currency);
  if (stale) return { ...stale, isLive: false };

  // Last resort: fallback data
  return getFallbackData(currency);
}

async function tryFetchWithKey(
  key: string,
  currency: string
): Promise<{ success: boolean; data?: GoldPriceData; error?: string }> {
  try {
    const response = await fetch(`${API_BASE}/XAU/${currency}`, {
      headers: {
        'x-access-token': key,
        'Content-Type': 'application/json',
      },
    });

    if (response.status === 200) {
      const data: GoldApiResponse = await response.json();
      if (data.price !== undefined && data.price !== null) {
        return { success: true, data: parseResponse(data) };
      }
      return { success: false, error: 'Invalid response' };
    } else if (response.status === 403) {
      const body = await response.json().catch(() => ({}));
      return { success: false, error: body.error || 'quota_exceeded' };
    } else if (response.status === 401) {
      return { success: false, error: 'invalid_key' };
    } else {
      return { success: false, error: `HTTP ${response.status}` };
    }
  } catch (e: any) {
    return { success: false, error: e.message || 'Network error' };
  }
}

function getFallbackData(currency: string): GoldPriceData {
  const rates: Record<string, number> = {
    USD: 1, EUR: 0.92, GBP: 0.79, AED: 3.67, SAR: 3.75,
    KWD: 0.31, EGP: 50.5, INR: 83.5, TRY: 32.5, JPY: 150.2,
  };
  const rate = rates[currency] || 1;
  const basePrice = 5000;
  const price = basePrice * rate;
  const gram24k = price / 31.1035;

  return {
    pricePerOunce: price,
    pricePerGram24K: gram24k,
    currency,
    change: 0,
    changePercent: 0,
    high: price * 1.005,
    low: price * 0.995,
    open: price,
    prevClose: price,
    ask: price * 1.001,
    bid: price * 0.999,
    timestamp: Date.now(),
    karatPrices: [
      { karat: '24K', pricePerGram: gram24k },
      { karat: '22K', pricePerGram: gram24k * (22 / 24) },
      { karat: '21K', pricePerGram: gram24k * (21 / 24) },
      { karat: '20K', pricePerGram: gram24k * (20 / 24) },
      { karat: '18K', pricePerGram: gram24k * (18 / 24) },
      { karat: '16K', pricePerGram: gram24k * (16 / 24) },
      { karat: '14K', pricePerGram: gram24k * (14 / 24) },
      { karat: '10K', pricePerGram: gram24k * (10 / 24) },
    ],
    source: 'Offline',
    isLive: false,
  };
}

export function clearCache(): void {
  memoryCache = {};
}

export const SUPPORTED_CURRENCIES = [
  { code: 'USD', nameAr: 'دولار أمريكي', nameEn: 'US Dollar', nameFr: 'Dollar américain', symbol: '$' },
  { code: 'EUR', nameAr: 'يورو', nameEn: 'Euro', nameFr: 'Euro', symbol: '€' },
  { code: 'GBP', nameAr: 'جنيه إسترليني', nameEn: 'British Pound', nameFr: 'Livre sterling', symbol: '£' },
  { code: 'AED', nameAr: 'درهم إماراتي', nameEn: 'UAE Dirham', nameFr: 'Dirham des EAU', symbol: 'د.إ' },
  { code: 'SAR', nameAr: 'ريال سعودي', nameEn: 'Saudi Riyal', nameFr: 'Riyal saoudien', symbol: 'ر.س' },
  { code: 'KWD', nameAr: 'دينار كويتي', nameEn: 'Kuwaiti Dinar', nameFr: 'Dinar koweïtien', symbol: 'د.ك' },
  { code: 'EGP', nameAr: 'جنيه مصري', nameEn: 'Egyptian Pound', nameFr: 'Livre égyptienne', symbol: 'ج.م' },
  { code: 'INR', nameAr: 'روبية هندية', nameEn: 'Indian Rupee', nameFr: 'Roupie indienne', symbol: '₹' },
  { code: 'TRY', nameAr: 'ليرة تركية', nameEn: 'Turkish Lira', nameFr: 'Livre turque', symbol: '₺' },
  { code: 'JPY', nameAr: 'ين ياباني', nameEn: 'Japanese Yen', nameFr: 'Yen japonais', symbol: '¥' },
];

export const KARAT_OPTIONS = ['24K', '22K', '21K', '18K', '14K', '10K'];
