import { describe, it, expect, vi, beforeEach } from 'vitest';

// Mock expo-notifications
vi.mock('expo-notifications', () => ({
  setNotificationHandler: vi.fn(),
  setNotificationChannelAsync: vi.fn(),
  getPermissionsAsync: vi.fn().mockResolvedValue({ status: 'granted' }),
  requestPermissionsAsync: vi.fn().mockResolvedValue({ status: 'granted' }),
  scheduleNotificationAsync: vi.fn().mockResolvedValue('notif-id'),
  cancelAllScheduledNotificationsAsync: vi.fn().mockResolvedValue(undefined),
  getAllScheduledNotificationsAsync: vi.fn().mockResolvedValue([]),
  setBadgeCountAsync: vi.fn().mockResolvedValue(undefined),
  addNotificationReceivedListener: vi.fn().mockReturnValue({ remove: vi.fn() }),
  addNotificationResponseReceivedListener: vi.fn().mockReturnValue({ remove: vi.fn() }),
  AndroidImportance: { HIGH: 4 },
  SchedulableTriggerInputTypes: { TIME_INTERVAL: 'timeInterval' },
}));

// Mock react-native Platform
vi.mock('react-native', () => ({
  Platform: { OS: 'ios' },
}));

describe('NotificationService', () => {
  let notificationService: any;

  beforeEach(async () => {
    vi.clearAllMocks();
    // Re-import to get fresh instance
    const mod = await import('../services/NotificationService');
    notificationService = mod.notificationService;
  });

  it('should request permissions', async () => {
    const result = await notificationService.requestPermissions();
    expect(result).toBe(true);
  });

  it('should get permission status', async () => {
    const status = await notificationService.getPermissionStatus();
    expect(status).toBe('granted');
  });

  it('should send test notification', async () => {
    const Notifications = await import('expo-notifications');
    await notificationService.sendTestNotification('Test', 'Test body');
    expect(Notifications.scheduleNotificationAsync).toHaveBeenCalledWith(
      expect.objectContaining({
        content: expect.objectContaining({
          title: 'Test',
          body: 'Test body',
          data: { type: 'test' },
        }),
      })
    );
  });

  it('should send price alert notification', async () => {
    const Notifications = await import('expo-notifications');
    await notificationService.sendPriceAlertNotification('Alert', 'Price reached', 'alert-1');
    expect(Notifications.scheduleNotificationAsync).toHaveBeenCalledWith(
      expect.objectContaining({
        content: expect.objectContaining({
          title: 'Alert',
          body: 'Price reached',
          data: { type: 'price_alert', alertId: 'alert-1' },
        }),
      })
    );
  });

  it('should check alerts and trigger when conditions met', async () => {
    const alerts = [
      {
        id: '1', title: 'Test Alert', karat: '24', currency: 'SAR',
        targetPrice: 300, condition: '>=' as const, enabled: true, status: 'active' as const,
        lastUpdate: '2025-01-01', note: '',
      },
    ];
    const prices = [
      {
        karat: '24', karatLabel: 'عيار 24', buyPrice: 312.50, sellPrice: 310,
        change: 2.5, changePercent: 0.81, currency: 'SAR', source: 'test', lastUpdate: '2025-01-01',
      },
    ];

    const result = await notificationService.checkAlerts(
      alerts, prices,
      'Price Alert',
      (k: string, p: number, c: string) => `${k} above ${p} ${c}`,
      (k: string, p: number, c: string) => `${k} below ${p} ${c}`,
    );

    expect(result.alertsChecked).toBe(1);
    expect(result.alertsTriggered).toBe(1);
    expect(result.triggeredAlerts).toContain('1');
  });

  it('should not trigger when conditions not met', async () => {
    const alerts = [
      {
        id: '1', title: 'Test Alert', karat: '24', currency: 'SAR',
        targetPrice: 400, condition: '>=' as const, enabled: true, status: 'active' as const,
        lastUpdate: '2025-01-01', note: '',
      },
    ];
    const prices = [
      {
        karat: '24', karatLabel: 'عيار 24', buyPrice: 312.50, sellPrice: 310,
        change: 2.5, changePercent: 0.81, currency: 'SAR', source: 'test', lastUpdate: '2025-01-01',
      },
    ];

    const result = await notificationService.checkAlerts(
      alerts, prices,
      'Price Alert',
      (k: string, p: number, c: string) => `${k} above ${p} ${c}`,
      (k: string, p: number, c: string) => `${k} below ${p} ${c}`,
    );

    expect(result.alertsChecked).toBe(1);
    expect(result.alertsTriggered).toBe(0);
  });

  it('should skip disabled alerts', async () => {
    const alerts = [
      {
        id: '1', title: 'Disabled Alert', karat: '24', currency: 'SAR',
        targetPrice: 300, condition: '>=' as const, enabled: false, status: 'active' as const,
        lastUpdate: '2025-01-01', note: '',
      },
    ];
    const prices = [
      {
        karat: '24', karatLabel: 'عيار 24', buyPrice: 312.50, sellPrice: 310,
        change: 2.5, changePercent: 0.81, currency: 'SAR', source: 'test', lastUpdate: '2025-01-01',
      },
    ];

    const result = await notificationService.checkAlerts(
      alerts, prices,
      'Price Alert',
      (k: string, p: number, c: string) => `${k} above ${p} ${c}`,
      (k: string, p: number, c: string) => `${k} below ${p} ${c}`,
    );

    expect(result.alertsChecked).toBe(0);
    expect(result.alertsTriggered).toBe(0);
  });

  it('should handle <= condition correctly', async () => {
    const alerts = [
      {
        id: '1', title: 'Low Price Alert', karat: '14', currency: 'SAR',
        targetPrice: 200, condition: '<=' as const, enabled: true, status: 'active' as const,
        lastUpdate: '2025-01-01', note: '',
      },
    ];
    const prices = [
      {
        karat: '14', karatLabel: 'عيار 14', buyPrice: 182.29, sellPrice: 180,
        change: -0.5, changePercent: -0.27, currency: 'SAR', source: 'test', lastUpdate: '2025-01-01',
      },
    ];

    const result = await notificationService.checkAlerts(
      alerts, prices,
      'Price Alert',
      (k: string, p: number, c: string) => `${k} above ${p} ${c}`,
      (k: string, p: number, c: string) => `${k} below ${p} ${c}`,
    );

    expect(result.alertsChecked).toBe(1);
    expect(result.alertsTriggered).toBe(1);
  });

  it('should cancel all notifications', async () => {
    const Notifications = await import('expo-notifications');
    await notificationService.cancelAll();
    expect(Notifications.cancelAllScheduledNotificationsAsync).toHaveBeenCalled();
  });
});

describe('Notification translations', () => {
  it('should have notification keys in Arabic', async () => {
    const ar = (await import('../i18n/ar')).default;
    expect(ar.notifications).toBeDefined();
    expect(ar.notifications.title).toBe('الإشعارات');
    expect(ar.notifications.priceAlert).toBe('تنبيه سعر الذهب');
    expect(ar.notifications.checkNow).toBeTruthy();
    expect(ar.notifications.sendTest).toBeTruthy();
    expect(ar.notifications.testNotification).toBeTruthy();
    expect(ar.notifications.enabled).toBeTruthy();
    expect(ar.notifications.disabled).toBeTruthy();
  });

  it('should have notification keys in English', async () => {
    const en = (await import('../i18n/en')).default;
    expect(en.notifications).toBeDefined();
    expect(en.notifications.title).toBe('Notifications');
    expect(en.notifications.priceAlert).toBe('Gold Price Alert');
    expect(en.notifications.checkNow).toBeTruthy();
    expect(en.notifications.sendTest).toBeTruthy();
  });

  it('should have notification keys in French', async () => {
    const fr = (await import('../i18n/fr')).default;
    expect(fr.notifications).toBeDefined();
    expect(fr.notifications.title).toBe('Notifications');
    expect(fr.notifications.priceAlert).toBe("Alerte prix de l'or");
    expect(fr.notifications.checkNow).toBeTruthy();
    expect(fr.notifications.sendTest).toBeTruthy();
  });

  it('should have template placeholders in notification strings', async () => {
    const en = (await import('../i18n/en')).default;
    expect(en.notifications.priceReached).toContain('{{karat}}');
    expect(en.notifications.priceReached).toContain('{{price}}');
    expect(en.notifications.priceReached).toContain('{{currency}}');
    expect(en.notifications.priceAbove).toContain('{{karat}}');
    expect(en.notifications.priceBelow).toContain('{{karat}}');
    expect(en.notifications.alertsChecked).toContain('{{count}}');
  });
});
