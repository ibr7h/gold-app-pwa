import { describe, it, expect } from 'vitest';
import * as fs from 'fs';

describe('PDF Export - Portfolio Screen', () => {
  const source = fs.readFileSync('./app/(drawer)/portfolio.tsx', 'utf-8');

  it('should import expo-print for native PDF generation', () => {
    expect(source).toContain("import * as Print from 'expo-print'");
  });

  it('should use Print.printToFileAsync on native platforms', () => {
    expect(source).toContain('Print.printToFileAsync');
  });

  it('should generate PDF with application/pdf mimeType on native', () => {
    expect(source).toContain("mimeType: 'application/pdf'");
  });

  it('should save PDF with .pdf extension on native', () => {
    expect(source).toContain('.pdf`');
  });

  it('should move temp PDF to permanent location', () => {
    expect(source).toContain('FileSystem.moveAsync');
  });

  it('should still use HTML blob download on web', () => {
    expect(source).toContain("Platform.OS === 'web'");
    expect(source).toContain('Blob([html]');
  });

  it('should not use writeAsStringAsync for HTML on native', () => {
    // The native path should NOT write HTML files anymore
    // Only the web path creates HTML blobs
    const nativeSection = source.split("} else {")[1]; // after the web block
    if (nativeSection) {
      expect(nativeSection).not.toContain("writeAsStringAsync");
    }
  });
});

describe('PDF Export - Trader Reports Screen', () => {
  const source = fs.readFileSync('./app/(drawer)/trader-reports.tsx', 'utf-8');

  it('should import expo-print for native PDF generation', () => {
    expect(source).toContain("import * as Print from 'expo-print'");
  });

  it('should use Print.printToFileAsync on native platforms', () => {
    expect(source).toContain('Print.printToFileAsync');
  });

  it('should generate PDF with application/pdf mimeType on native', () => {
    expect(source).toContain("mimeType: 'application/pdf'");
  });

  it('should save PDF with .pdf extension on native', () => {
    expect(source).toContain('.pdf`');
  });

  it('should move temp PDF to permanent location', () => {
    expect(source).toContain('FileSystem.moveAsync');
  });

  it('should still use HTML blob download on web', () => {
    expect(source).toContain("Platform.OS === 'web'");
    expect(source).toContain('Blob([html]');
  });
});
