import { describe, it, expect, vi, beforeEach } from 'vitest';

describe('App Variant System', () => {
  beforeEach(() => {
    vi.resetModules();
  });

  describe('appVariant.ts configuration', () => {
    it('should default to user variant when EXPO_PUBLIC_APP_VARIANT is not set', async () => {
      vi.stubEnv('EXPO_PUBLIC_APP_VARIANT', '');
      const mod = await import('../constants/appVariant');
      // When empty string, defaults to 'user'
      expect(mod.APP_VARIANT).toBe('user');
    });

    it('should have correct config for user variant', async () => {
      const mod = await import('../constants/appVariant');
      expect(mod.VARIANT_CONFIG.user).toEqual({
        appName: 'ذهبي',
        appNameEn: 'Dhahabi',
        defaultScreen: 'home',
        requiredRole: 'user',
      });
    });

    it('should have correct config for trader variant', async () => {
      const mod = await import('../constants/appVariant');
      expect(mod.VARIANT_CONFIG.trader).toEqual({
        appName: 'ذهبي تاجر',
        appNameEn: 'Dhahabi Trader',
        defaultScreen: 'trader-home',
        requiredRole: 'trader',
      });
    });

    it('should have correct config for admin variant', async () => {
      const mod = await import('../constants/appVariant');
      expect(mod.VARIANT_CONFIG.admin).toEqual({
        appName: 'ذهبي إدارة',
        appNameEn: 'Dhahabi Admin',
        defaultScreen: 'admin',
        requiredRole: 'admin',
      });
    });

    it('should export all three variant types', async () => {
      const mod = await import('../constants/appVariant');
      expect(Object.keys(mod.VARIANT_CONFIG)).toEqual(['user', 'trader', 'admin']);
    });
  });

  describe('Variant-specific screens', () => {
    it('user variant should show home as default screen', async () => {
      const mod = await import('../constants/appVariant');
      expect(mod.VARIANT_CONFIG.user.defaultScreen).toBe('home');
    });

    it('trader variant should show trader-home as default screen', async () => {
      const mod = await import('../constants/appVariant');
      expect(mod.VARIANT_CONFIG.trader.defaultScreen).toBe('trader-home');
    });

    it('admin variant should show admin as default screen', async () => {
      const mod = await import('../constants/appVariant');
      expect(mod.VARIANT_CONFIG.admin.defaultScreen).toBe('admin');
    });
  });

  describe('Variant drawer menu items', () => {
    it('user variant should not include trader or admin screens in menu', () => {
      const userScreens = ['home', 'search', 'prices', 'portfolio', 'purchases', 'alerts', 'profile', 'settings', 'faq-support'];
      const traderScreens = ['trader-home', 'trader-orders', 'trader-clients', 'trader-notifications', 'trader-reports', 'trader-messages'];
      const adminScreens = ['admin', 'admin-users', 'admin-invites', 'admin-permissions', 'admin-stats'];
      
      // User screens should not include any trader-specific or admin-specific screens
      for (const screen of traderScreens) {
        expect(userScreens).not.toContain(screen);
      }
      for (const screen of adminScreens) {
        expect(userScreens).not.toContain(screen);
      }
    });

    it('trader variant should include trader screens but not admin screens', () => {
      const traderMenuScreens = ['trader-home', 'search', 'trader-orders', 'trader-clients', 'trader-notifications', 'trader-reports', 'trader-messages', 'prices', 'profile', 'settings', 'faq-support'];
      const adminOnlyScreens = ['admin-users', 'admin-invites', 'admin-permissions', 'admin-stats'];
      
      expect(traderMenuScreens).toContain('trader-home');
      expect(traderMenuScreens).toContain('trader-orders');
      for (const screen of adminOnlyScreens) {
        expect(traderMenuScreens).not.toContain(screen);
      }
    });

    it('admin variant should include admin screens but not trader screens', () => {
      const adminMenuScreens = ['admin', 'admin-users', 'admin-invites', 'admin-permissions', 'admin-stats', 'search', 'profile', 'settings', 'faq-support'];
      const traderOnlyScreens = ['trader-home', 'trader-orders', 'trader-clients', 'trader-notifications', 'trader-reports', 'trader-messages'];
      
      expect(adminMenuScreens).toContain('admin');
      expect(adminMenuScreens).toContain('admin-users');
      for (const screen of traderOnlyScreens) {
        expect(adminMenuScreens).not.toContain(screen);
      }
    });
  });

  describe('Login flow per variant', () => {
    it('user variant login should be direct OAuth without invite code', () => {
      // User variant: just OAuth login, no invite code needed
      const userVariantRequiresInviteCode = false;
      expect(userVariantRequiresInviteCode).toBe(false);
    });

    it('trader variant login should require invite code before OAuth', () => {
      // Trader variant: must validate invite code first, then OAuth
      const traderVariantRequiresInviteCode = true;
      expect(traderVariantRequiresInviteCode).toBe(true);
    });

    it('admin variant login should be direct OAuth with email verification', () => {
      // Admin variant: OAuth login, server auto-assigns admin role based on email
      const adminVariantRequiresInviteCode = false;
      expect(adminVariantRequiresInviteCode).toBe(false);
    });
  });

  describe('Variant icon assets', () => {
    it('should have distinct icon paths for each variant', () => {
      const variantIcons = {
        user: './assets/images/icon.png',
        trader: './assets/images/trader-icon.png',
        admin: './assets/images/admin-icon.png',
      };
      
      expect(variantIcons.user).not.toBe(variantIcons.trader);
      expect(variantIcons.user).not.toBe(variantIcons.admin);
      expect(variantIcons.trader).not.toBe(variantIcons.admin);
    });
  });

  describe('Security: server-side role enforcement', () => {
    it('admin emails should be hardcoded on server side', () => {
      const ADMIN_EMAILS = ['sam.elqari@icloud.com', 'd.alneami@gmail.com'];
      expect(ADMIN_EMAILS).toContain('sam.elqari@icloud.com');
      expect(ADMIN_EMAILS).toContain('d.alneami@gmail.com');
      expect(ADMIN_EMAILS.length).toBe(2);
    });

    it('non-admin email should not get admin role', () => {
      const ADMIN_EMAILS = ['sam.elqari@icloud.com', 'd.alneami@gmail.com'];
      const testEmail = 'random@example.com';
      expect(ADMIN_EMAILS.includes(testEmail)).toBe(false);
    });

    it('trader role requires invite code claim on server', () => {
      // Server-side: invite.claim endpoint changes user role to trader
      // Without calling claim, user stays as 'user' even in trader app variant
      const defaultRole = 'user';
      expect(defaultRole).toBe('user');
    });
  });
});
