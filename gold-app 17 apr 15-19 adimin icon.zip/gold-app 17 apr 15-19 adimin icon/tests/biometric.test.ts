import { describe, it, expect } from 'vitest';
import ar from '../i18n/ar';
import en from '../i18n/en';
import fr from '../i18n/fr';

describe('Biometric Authentication', () => {
  describe('Translation completeness', () => {
    const biometricKeys = [
      'title', 'subtitle', 'faceId', 'fingerprint',
      'loginWithFaceId', 'loginWithFingerprint', 'loginWithBiometric',
      'promptMessage', 'enableBiometric', 'enableFaceId', 'enableFingerprint',
      'disableBiometric', 'biometricEnabled', 'biometricDisabled',
      'notAvailable', 'notEnrolled', 'authFailed',
      'orLoginWith', 'emailPassword',
      'setupPrompt', 'setupYes', 'setupNo', 'security',
    ];

    it('Arabic has all biometric translation keys', () => {
      biometricKeys.forEach(key => {
        expect(ar.biometric).toHaveProperty(key);
        expect((ar.biometric as any)[key]).toBeTruthy();
      });
    });

    it('English has all biometric translation keys', () => {
      biometricKeys.forEach(key => {
        expect(en.biometric).toHaveProperty(key);
        expect((en.biometric as any)[key]).toBeTruthy();
      });
    });

    it('French has all biometric translation keys', () => {
      biometricKeys.forEach(key => {
        expect(fr.biometric).toHaveProperty(key);
        expect((fr.biometric as any)[key]).toBeTruthy();
      });
    });
  });

  describe('Translation content quality', () => {
    it('Arabic biometric strings are in Arabic', () => {
      const arabicRegex = /[\u0600-\u06FF]/;
      expect(arabicRegex.test(ar.biometric.title)).toBe(true);
      expect(arabicRegex.test(ar.biometric.subtitle)).toBe(true);
      expect(arabicRegex.test(ar.biometric.promptMessage)).toBe(true);
      expect(arabicRegex.test(ar.biometric.enableBiometric)).toBe(true);
      expect(arabicRegex.test(ar.biometric.authFailed)).toBe(true);
      expect(arabicRegex.test(ar.biometric.security)).toBe(true);
    });

    it('English biometric strings are in English', () => {
      expect(en.biometric.title).toBe('Biometric Authentication');
      expect(en.biometric.security).toBe('Security');
      expect(en.biometric.loginWithFaceId).toContain('Face ID');
      expect(en.biometric.loginWithFingerprint).toContain('Fingerprint');
    });

    it('French biometric strings are in French', () => {
      expect(fr.biometric.title).toContain('biom');
      expect(fr.biometric.loginWithFaceId).toContain('Face ID');
      expect(fr.biometric.setupYes).toContain('Oui');
      expect(fr.biometric.setupNo).toContain('Plus tard');
    });
  });

  describe('Biometric type detection logic', () => {
    it('should correctly identify biometric types', () => {
      type BiometricType = 'face' | 'fingerprint' | 'none';

      const getBiometricLabel = (type: BiometricType, t: typeof en) => {
        if (type === 'face') return t.biometric.loginWithFaceId;
        if (type === 'fingerprint') return t.biometric.loginWithFingerprint;
        return t.biometric.loginWithBiometric;
      };

      expect(getBiometricLabel('face', en)).toBe('Sign in with Face ID');
      expect(getBiometricLabel('fingerprint', en)).toBe('Sign in with Fingerprint');
      expect(getBiometricLabel('none', en)).toBe('Sign in with Biometrics');
    });

    it('should correctly identify biometric icon', () => {
      type BiometricType = 'face' | 'fingerprint' | 'none';

      const getBiometricIcon = (type: BiometricType) => {
        return type === 'face' ? 'face' : 'fingerprint';
      };

      expect(getBiometricIcon('face')).toBe('face');
      expect(getBiometricIcon('fingerprint')).toBe('fingerprint');
      expect(getBiometricIcon('none')).toBe('fingerprint');
    });
  });

  describe('Auth state management', () => {
    it('should have correct storage keys defined', () => {
      const BIOMETRIC_USER_KEY = 'gold_biometric_user';
      const BIOMETRIC_ENABLED_KEY = 'gold_biometric_enabled';

      expect(BIOMETRIC_USER_KEY).toBe('gold_biometric_user');
      expect(BIOMETRIC_ENABLED_KEY).toBe('gold_biometric_enabled');
    });

    it('should serialize/deserialize user data correctly', () => {
      const user = { email: 'user@gold.app', role: 'user' as const };
      const serialized = JSON.stringify(user);
      const deserialized = JSON.parse(serialized);

      expect(deserialized.email).toBe('user@gold.app');
      expect(deserialized.role).toBe('user');
    });

    it('should handle error types correctly', () => {
      const getErrorMessage = (error: string, t: typeof en) => {
        if (error === 'invalid_credentials') return t.login.errorInvalidCredentials;
        if (error === 'biometric_failed') return t.biometric.authFailed;
        return error;
      };

      expect(getErrorMessage('invalid_credentials', en)).toBe('Invalid email or password');
      expect(getErrorMessage('biometric_failed', en)).toBe('Authentication failed, please try again');
      expect(getErrorMessage('unknown_error', en)).toBe('unknown_error');
    });
  });
});
