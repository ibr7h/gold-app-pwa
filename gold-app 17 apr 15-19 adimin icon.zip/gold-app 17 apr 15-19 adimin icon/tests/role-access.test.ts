import { describe, it, expect, vi, beforeEach } from 'vitest';

// ===== Test: Admin email auto-assignment =====
describe('Admin Email Auto-Assignment', () => {
  const ADMIN_EMAILS = ['sam.elqari@icloud.com', 'd.alneami@gmail.com'];

  it('should recognize admin emails (case-insensitive)', () => {
    expect(ADMIN_EMAILS.includes('sam.elqari@icloud.com')).toBe(true);
    expect(ADMIN_EMAILS.includes('d.alneami@gmail.com')).toBe(true);
    expect(ADMIN_EMAILS.includes('SAM.ELQARI@ICLOUD.COM'.toLowerCase())).toBe(true);
    expect(ADMIN_EMAILS.includes('random@email.com')).toBe(false);
  });

  it('should assign admin role when email matches', () => {
    function getRole(email: string): string {
      if (ADMIN_EMAILS.includes(email.toLowerCase())) return 'admin';
      return 'user';
    }

    expect(getRole('sam.elqari@icloud.com')).toBe('admin');
    expect(getRole('d.alneami@gmail.com')).toBe('admin');
    expect(getRole('SAM.ELQARI@ICLOUD.COM')).toBe('admin');
    expect(getRole('other@email.com')).toBe('user');
  });
});

// ===== Test: Invite Code Generation =====
describe('Invite Code Generation', () => {
  function generateCode(): string {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let code = 'GOLD-';
    for (let i = 0; i < 6; i++) {
      code += chars[Math.floor(Math.random() * chars.length)];
    }
    return code;
  }

  it('should generate codes with GOLD- prefix', () => {
    const code = generateCode();
    expect(code).toMatch(/^GOLD-[A-Z2-9]{6}$/);
  });

  it('should generate unique codes', () => {
    const codes = new Set<string>();
    for (let i = 0; i < 100; i++) {
      codes.add(generateCode());
    }
    // With 6 chars from 32 possible, collisions are extremely unlikely in 100 codes
    expect(codes.size).toBeGreaterThan(95);
  });

  it('should not contain confusing characters (I, O, 0, 1)', () => {
    for (let i = 0; i < 50; i++) {
      const code = generateCode();
      const suffix = code.replace('GOLD-', '');
      expect(suffix).not.toMatch(/[IO01]/);
    }
  });
});

// ===== Test: Invite Code Validation Logic =====
describe('Invite Code Validation', () => {
  interface InviteCode {
    id: number;
    code: string;
    isUsed: boolean;
    isActive: boolean;
    usedBy: number | null;
  }

  const mockCodes: InviteCode[] = [
    { id: 1, code: 'GOLD-ABC123', isUsed: false, isActive: true, usedBy: null },
    { id: 2, code: 'GOLD-DEF456', isUsed: true, isActive: true, usedBy: 5 },
    { id: 3, code: 'GOLD-GHI789', isUsed: false, isActive: false, usedBy: null },
  ];

  function validateCode(code: string): { valid: boolean; codeId?: number } {
    const found = mockCodes.find(c => c.code === code && !c.isUsed && c.isActive);
    if (!found) return { valid: false };
    return { valid: true, codeId: found.id };
  }

  it('should validate active unused codes', () => {
    expect(validateCode('GOLD-ABC123')).toEqual({ valid: true, codeId: 1 });
  });

  it('should reject used codes', () => {
    expect(validateCode('GOLD-DEF456')).toEqual({ valid: false });
  });

  it('should reject revoked (inactive) codes', () => {
    expect(validateCode('GOLD-GHI789')).toEqual({ valid: false });
  });

  it('should reject non-existent codes', () => {
    expect(validateCode('GOLD-XXXXXX')).toEqual({ valid: false });
  });
});

// ===== Test: Login Screen Role Selection =====
describe('Login Screen Role Selection', () => {
  it('should have three login modes', () => {
    type LoginMode = 'select' | 'user' | 'trader';
    const modes: LoginMode[] = ['select', 'user', 'trader'];
    expect(modes).toHaveLength(3);
  });

  it('should require invite code for trader mode', () => {
    function validateTraderLogin(inviteCode: string): string | null {
      const code = inviteCode.trim().toUpperCase();
      if (!code) return 'Invite code is required';
      if (code.length < 5) return 'Invalid invite code';
      return null; // valid
    }

    expect(validateTraderLogin('')).toBe('Invite code is required');
    expect(validateTraderLogin('   ')).toBe('Invite code is required');
    expect(validateTraderLogin('AB')).toBe('Invalid invite code');
    expect(validateTraderLogin('GOLD-ABC123')).toBeNull();
  });

  it('should not require invite code for user mode', () => {
    function validateUserLogin(): string | null {
      // User mode just triggers OAuth, no invite code needed
      return null;
    }

    expect(validateUserLogin()).toBeNull();
  });
});

// ===== Test: Pending Invite Code Storage =====
describe('Pending Invite Code Flow', () => {
  const storage = new Map<string, string>();
  const PENDING_INVITE_CODE_KEY = 'gold_pending_invite_code';

  beforeEach(() => {
    storage.clear();
  });

  it('should store invite code before OAuth redirect', () => {
    const code = 'GOLD-ABC123';
    storage.set(PENDING_INVITE_CODE_KEY, code);
    expect(storage.get(PENDING_INVITE_CODE_KEY)).toBe(code);
  });

  it('should retrieve and clear invite code after OAuth callback', () => {
    storage.set(PENDING_INVITE_CODE_KEY, 'GOLD-ABC123');

    // Simulate OAuth callback
    const code = storage.get(PENDING_INVITE_CODE_KEY);
    expect(code).toBe('GOLD-ABC123');

    // Clear after claiming
    storage.delete(PENDING_INVITE_CODE_KEY);
    expect(storage.get(PENDING_INVITE_CODE_KEY)).toBeUndefined();
  });

  it('should handle missing invite code gracefully', () => {
    const code = storage.get(PENDING_INVITE_CODE_KEY);
    expect(code).toBeUndefined();
    // No invite code to claim, should not error
  });
});

// ===== Test: Role-Based Navigation =====
describe('Role-Based Navigation', () => {
  function getDefaultScreen(role: string): string {
    if (role === 'trader') return 'trader-home';
    return 'home';
  }

  function canAccessAdmin(role: string): boolean {
    return role === 'admin';
  }

  function canAccessTrader(role: string): boolean {
    return role === 'trader' || role === 'admin';
  }

  it('should route traders to trader-home by default', () => {
    expect(getDefaultScreen('trader')).toBe('trader-home');
  });

  it('should route users to home by default', () => {
    expect(getDefaultScreen('user')).toBe('home');
  });

  it('should allow admin access only for admin role', () => {
    expect(canAccessAdmin('admin')).toBe(true);
    expect(canAccessAdmin('trader')).toBe(false);
    expect(canAccessAdmin('user')).toBe(false);
  });

  it('should allow trader access for trader and admin roles', () => {
    expect(canAccessTrader('trader')).toBe(true);
    expect(canAccessTrader('admin')).toBe(true);
    expect(canAccessTrader('user')).toBe(false);
  });
});

// ===== Test: i18n Translations for Invite Codes =====
describe('i18n Invite Code Translations', () => {
  const requiredKeys = [
    'selectRole',
    'roleUser',
    'roleTrader',
    'inviteCode',
    'inviteCodePlaceholder',
    'inviteCodeRequired',
    'inviteCodeInvalid',
    'validatingCode',
    'traderLoginInfo',
    'userLoginInfo',
  ];

  it('should have all required translation keys in Arabic', async () => {
    const { default: ar } = await import('../i18n/ar');
    for (const key of requiredKeys) {
      expect((ar.login as any)[key]).toBeDefined();
      expect((ar.login as any)[key]).not.toBe('');
    }
  });

  it('should have all required translation keys in English', async () => {
    const { default: en } = await import('../i18n/en');
    for (const key of requiredKeys) {
      expect((en.login as any)[key]).toBeDefined();
      expect((en.login as any)[key]).not.toBe('');
    }
  });

  it('should have all required translation keys in French', async () => {
    const { default: fr } = await import('../i18n/fr');
    for (const key of requiredKeys) {
      expect((fr.login as any)[key]).toBeDefined();
      expect((fr.login as any)[key]).not.toBe('');
    }
  });
});
