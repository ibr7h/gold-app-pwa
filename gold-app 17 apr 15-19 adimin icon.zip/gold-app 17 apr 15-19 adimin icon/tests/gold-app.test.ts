import { describe, it, expect } from 'vitest';
import {
  goldPrices,
  portfolioItems,
  purchases,
  alerts,
  offers,
  chartData,
  topMovers,
} from '../data/mock';

describe('Gold App Mock Data', () => {
  it('should have gold prices for all karats', () => {
    expect(goldPrices.length).toBeGreaterThanOrEqual(5);
    const karats = goldPrices.map(p => p.karat);
    expect(karats).toContain('24');
    expect(karats).toContain('22');
    expect(karats).toContain('21');
    expect(karats).toContain('18');
    expect(karats).toContain('14');
  });

  it('should have valid price data structure', () => {
    goldPrices.forEach(price => {
      expect(price.buyPrice).toBeGreaterThan(0);
      expect(price.sellPrice).toBeGreaterThan(0);
      expect(price.buyPrice).toBeGreaterThanOrEqual(price.sellPrice);
      expect(price.currency).toBeTruthy();
      expect(price.karatLabel).toBeTruthy();
      expect(price.source).toBeTruthy();
      expect(price.lastUpdate).toBeTruthy();
    });
  });

  it('should have portfolio items with required fields', () => {
    expect(portfolioItems.length).toBeGreaterThan(0);
    portfolioItems.forEach(item => {
      expect(item.id).toBeTruthy();
      expect(item.name).toBeTruthy();
      expect(item.currency).toBeTruthy();
      expect(typeof item.totalValue).toBe('number');
      expect(typeof item.totalCost).toBe('number');
      expect(typeof item.profitLoss).toBe('number');
      expect(typeof item.profitLossPercent).toBe('number');
    });
  });

  it('should calculate profit/loss correctly', () => {
    portfolioItems.forEach(item => {
      const expectedPL = item.totalValue - item.totalCost;
      expect(Math.abs(item.profitLoss - expectedPL)).toBeLessThan(0.01);
    });
  });

  it('should have purchases with valid data', () => {
    expect(purchases.length).toBeGreaterThan(0);
    purchases.forEach(purchase => {
      expect(purchase.id).toBeTruthy();
      expect(purchase.name).toBeTruthy();
      expect(purchase.price).toBeGreaterThan(0);
      expect(purchase.quantity).toBeGreaterThan(0);
      expect(purchase.date).toMatch(/^\d{4}-\d{2}-\d{2}$/);
    });
  });

  it('should have alerts with valid structure', () => {
    expect(alerts.length).toBeGreaterThan(0);
    alerts.forEach(alert => {
      expect(alert.id).toBeTruthy();
      expect(alert.title).toBeTruthy();
      expect(alert.targetPrice).toBeGreaterThan(0);
      expect(['>=', '<=']).toContain(alert.condition);
      expect(['active', 'triggered', 'expired']).toContain(alert.status);
      expect(typeof alert.enabled).toBe('boolean');
    });
  });

  it('should have offers with valid data', () => {
    expect(offers.length).toBeGreaterThan(0);
    offers.forEach(offer => {
      expect(offer.id).toBeTruthy();
      expect(offer.title).toBeTruthy();
      expect(offer.discount).toBeTruthy();
    });
  });

  it('should have chart data for all periods', () => {
    expect(chartData.day.length).toBeGreaterThan(0);
    expect(chartData.week.length).toBeGreaterThan(0);
    expect(chartData.month.length).toBeGreaterThan(0);
    expect(chartData.year.length).toBeGreaterThan(0);
  });

  it('should have top movers data', () => {
    expect(topMovers.length).toBeGreaterThan(0);
    topMovers.forEach(mover => {
      expect(mover.karat).toBeTruthy();
      expect(mover.price).toBeGreaterThan(0);
      expect(typeof mover.change).toBe('number');
      expect(typeof mover.changePercent).toBe('number');
    });
  });
});

describe('Theme Colors', () => {
  it('should have correct gold app theme colors', async () => {
    const { themeColors } = await import('../theme.config.js');
    expect(themeColors.primary.dark).toBe('#C5A021');
    expect(themeColors.background.dark).toBe('#001F3F');
    expect(themeColors.surface.dark).toBe('#F8F9FA');
    expect(themeColors.foreground.dark).toBe('#F8F9FA');
    expect(themeColors.muted.dark).toBe('#6C737F');
  });
});
