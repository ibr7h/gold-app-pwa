import { describe, it, expect, vi, beforeEach } from 'vitest';

// Mock AsyncStorage
vi.mock('@react-native-async-storage/async-storage', () => ({
  default: {
    getItem: vi.fn().mockResolvedValue(null),
    setItem: vi.fn().mockResolvedValue(undefined),
    removeItem: vi.fn().mockResolvedValue(undefined),
  },
}));

// Mock expo-local-authentication
vi.mock('expo-local-authentication', () => ({
  hasHardwareAsync: vi.fn().mockResolvedValue(false),
  isEnrolledAsync: vi.fn().mockResolvedValue(false),
  supportedAuthenticationTypesAsync: vi.fn().mockResolvedValue([]),
  authenticateAsync: vi.fn().mockResolvedValue({ success: false }),
  AuthenticationType: { FACIAL_RECOGNITION: 1, FINGERPRINT: 2 },
}));

// Mock Platform
vi.mock('react-native', async () => {
  return {
    Platform: { OS: 'web', select: (obj: any) => obj.web ?? obj.default },
    StyleSheet: { create: (s: any) => s },
    View: 'View',
    Text: 'Text',
    TouchableOpacity: 'TouchableOpacity',
    Pressable: 'Pressable',
    ScrollView: 'ScrollView',
    TextInput: 'TextInput',
    Alert: { alert: vi.fn() },
    Dimensions: { get: () => ({ width: 375, height: 812 }) },
    Animated: {
      Value: vi.fn(() => ({ interpolate: vi.fn() })),
      timing: vi.fn(() => ({ start: vi.fn() })),
      View: 'Animated.View',
    },
  };
});

// Mock oauth constants
vi.mock('@/constants/oauth', () => ({
  startOAuthLogin: vi.fn().mockResolvedValue(undefined),
  getApiBaseUrl: vi.fn().mockReturnValue('http://127.0.0.1:3000'),
}));

// Mock auth lib
vi.mock('@/lib/_core/auth', () => ({
  getSessionToken: vi.fn().mockResolvedValue(null),
  removeSessionToken: vi.fn().mockResolvedValue(undefined),
  clearUserInfo: vi.fn().mockResolvedValue(undefined),
  getUserInfo: vi.fn().mockResolvedValue(null),
}));

// Mock api lib
vi.mock('@/lib/_core/api', () => ({
  getMe: vi.fn().mockResolvedValue(null),
  logout: vi.fn().mockResolvedValue(undefined),
}));

describe('Backend Migration - AuthContext Types', () => {
  it('should export UserRole type with all three roles', async () => {
    // Verify the AuthContext module exports the expected types
    const mod = await import('../contexts/AuthContext');
    expect(mod).toBeDefined();
    expect(typeof mod.AuthProvider).toBe('function');
    expect(typeof mod.useAuth).toBe('function');
  });

  it('should have User interface with role field', () => {
    // Verify User type supports all roles
    type UserRole = 'user' | 'admin' | 'trader';
    const roles: UserRole[] = ['user', 'admin', 'trader'];
    expect(roles).toHaveLength(3);

    interface User {
      id?: number;
      openId?: string;
      email: string;
      role: UserRole;
      name?: string;
    }

    const testUser: User = {
      email: 'test@example.com',
      role: 'trader',
      name: 'Test',
    };
    expect(testUser.role).toBe('trader');
  });
});

describe('Backend Migration - OAuth Flow', () => {
  it('login should call startOAuthLogin instead of local auth', async () => {
    const { startOAuthLogin } = await import('@/constants/oauth');
    expect(startOAuthLogin).toBeDefined();
    expect(typeof startOAuthLogin).toBe('function');
  });

  it('should not have demo credentials in the codebase', async () => {
    // Read the AuthContext source to verify no demo credentials
    const fs = await import('fs');
    const source = fs.readFileSync('./contexts/AuthContext.tsx', 'utf-8');

    // Should NOT contain demo email/password patterns
    expect(source).not.toContain('user@gold.app');
    expect(source).not.toContain('trader@gold.app');
    expect(source).not.toContain('admin@gold.app');
    expect(source).not.toContain('123456');
    expect(source).not.toContain('trader123');
    expect(source).not.toContain('admin123');

    // Should contain OAuth-related code
    expect(source).toContain('startOAuthLogin');
    expect(source).toContain('fetchUserFromServer');
  });

  it('login screen should use OAuth button instead of email/password', async () => {
    const fs = await import('fs');
    const source = fs.readFileSync('./app/login.tsx', 'utf-8');

    // Should NOT contain demo credentials section
    expect(source).not.toContain('user@gold.app');
    expect(source).not.toContain('trader@gold.app');
    expect(source).not.toContain('admin@gold.app');

    // Should contain OAuth login flow (uses login() from AuthContext which calls startOAuthLogin)
    expect(source).toContain('handleOAuthLogin');
    expect(source).toContain('OAuth Login Button');
  });
});

describe('Backend Migration - TraderDataContext', () => {
  it('should use tRPC API calls instead of AsyncStorage for data', async () => {
    const fs = await import('fs');
    const source = fs.readFileSync('./contexts/TraderDataContext.tsx', 'utf-8');

    // Should contain tRPC/API call patterns
    expect(source).toContain('trpcCall');
    expect(source).toContain('trader.orders');
    expect(source).toContain('trader.clients');

    // Should still export the same interface
    expect(source).toContain('useTraderData');
    expect(source).toContain('TraderDataProvider');
  });

  it('should have all CRUD operations for orders', async () => {
    const fs = await import('fs');
    const source = fs.readFileSync('./contexts/TraderDataContext.tsx', 'utf-8');

    // Order operations
    expect(source).toContain('trader.orders.list');
    expect(source).toContain('trader.orders.create');
  });

  it('should have all CRUD operations for clients', async () => {
    const fs = await import('fs');
    const source = fs.readFileSync('./contexts/TraderDataContext.tsx', 'utf-8');

    // Client operations
    expect(source).toContain('trader.clients.list');
    expect(source).toContain('trader.clients.create');
  });
});

describe('Backend Migration - MessagingContext', () => {
  it('should use tRPC API calls instead of AsyncStorage', async () => {
    const fs = await import('fs');
    const source = fs.readFileSync('./contexts/MessagingContext.tsx', 'utf-8');

    // Should contain tRPC/API call patterns
    expect(source).toContain('trpcCall');
    expect(source).toContain('messaging.');

    // Should still export the same interface
    expect(source).toContain('useMessaging');
    expect(source).toContain('MessagingProvider');
  });

  it('should have conversation and message operations', async () => {
    const fs = await import('fs');
    const source = fs.readFileSync('./contexts/MessagingContext.tsx', 'utf-8');

    // Conversation operations
    expect(source).toContain('messaging.conversations');
    expect(source).toContain('messaging.messages');
  });
});

describe('Backend Migration - Admin Users Screen', () => {
  it('should use tRPC API calls for user management', async () => {
    const fs = await import('fs');
    const source = fs.readFileSync('./app/(drawer)/admin-users.tsx', 'utf-8');

    // Should contain tRPC/API call patterns
    expect(source).toContain('trpcCall');
    expect(source).toContain('admin.users.list');
    expect(source).toContain('admin.users.updateRole');
    expect(source).toContain('admin.users.toggleActive');
    expect(source).toContain('admin.users.delete');

    // Should NOT contain AsyncStorage for user data
    expect(source).not.toContain('AsyncStorage');
  });
});

describe('Backend Migration - Server Routers', () => {
  it('should have trader router with all required endpoints', async () => {
    const fs = await import('fs');
    const source = fs.readFileSync('./server/traderRouter.ts', 'utf-8');

    // Orders CRUD
    expect(source).toContain('orders');
    expect(source).toContain('clients');
    expect(source).toContain('protectedProcedure');
  });

  it('should have messaging router with required endpoints', async () => {
    const fs = await import('fs');
    const source = fs.readFileSync('./server/messagingRouter.ts', 'utf-8');

    expect(source).toContain('conversations');
    expect(source).toContain('messages');
    expect(source).toContain('protectedProcedure');
  });

  it('should have admin router with user management', async () => {
    const fs = await import('fs');
    const source = fs.readFileSync('./server/adminRouter.ts', 'utf-8');

    expect(source).toContain('adminProcedure');
    expect(source).toContain('users');
    expect(source).toContain('updateRole');
    expect(source).toContain('toggleActive');
    expect(source).toContain('delete');
    expect(source).toContain('stats');
  });

  it('should have role field in user schema', async () => {
    const fs = await import('fs');
    const source = fs.readFileSync('./drizzle/schema.ts', 'utf-8');

    expect(source).toContain('role');
    expect(source).toContain('trader');
    expect(source).toContain('admin');
    expect(source).toContain('user');
  });
});

describe('Backend Migration - Provider Order', () => {
  it('should have correct provider nesting in _layout.tsx', async () => {
    const fs = await import('fs');
    const source = fs.readFileSync('./app/_layout.tsx', 'utf-8');

    // AuthProvider should wrap TraderDataProvider and MessagingProvider
    const authIdx = source.indexOf('<AuthProvider>');
    const traderIdx = source.indexOf('<TraderDataProvider>');
    const messagingIdx = source.indexOf('<MessagingProvider>');
    const trpcIdx = source.indexOf('<trpc.Provider');

    expect(authIdx).toBeGreaterThan(-1);
    expect(traderIdx).toBeGreaterThan(-1);
    expect(messagingIdx).toBeGreaterThan(-1);
    expect(trpcIdx).toBeGreaterThan(-1);

    // Auth should come before Trader and Messaging
    expect(authIdx).toBeLessThan(traderIdx);
    expect(authIdx).toBeLessThan(messagingIdx);
  });
});
