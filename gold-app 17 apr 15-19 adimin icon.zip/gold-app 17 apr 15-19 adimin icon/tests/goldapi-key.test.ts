import { describe, it, expect } from 'vitest';

describe('GoldAPI.io API Key Validation', () => {
  it('should have GOLDAPI_KEY environment variable set', () => {
    const key = process.env.GOLDAPI_KEY;
    expect(key).toBeDefined();
    expect(key).toBeTruthy();
    expect(typeof key).toBe('string');
    expect(key!.length).toBeGreaterThan(10);
  });

  it('should connect to GoldAPI.io (200 or 403 quota exceeded)', async () => {
    const key = process.env.GOLDAPI_KEY;
    if (!key) {
      console.warn('GOLDAPI_KEY not set, skipping live API test');
      return;
    }

    const response = await fetch('https://www.goldapi.io/api/XAU/USD', {
      headers: {
        'x-access-token': key,
        'Content-Type': 'application/json',
      },
    });

    // 200 = success, 403 = quota exceeded (valid key but limit reached)
    expect([200, 403]).toContain(response.status);
    const data = await response.json();
    expect(data).toBeDefined();
    if (response.status === 200) {
      expect(data.price).toBeDefined();
      expect(typeof data.price).toBe('number');
    }
  }, 15000);
});
