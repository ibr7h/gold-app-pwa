import { describe, it, expect } from 'vitest';
import ar from '../i18n/ar';
import en from '../i18n/en';
import fr from '../i18n/fr';
import { RTL_LANGUAGES, LANGUAGE_LABELS } from '../i18n/index';

// Helper to get all leaf keys from a nested object
function getLeafKeys(obj: any, prefix = ''): string[] {
  const keys: string[] = [];
  for (const key of Object.keys(obj)) {
    const fullKey = prefix ? `${prefix}.${key}` : key;
    if (typeof obj[key] === 'object' && obj[key] !== null) {
      keys.push(...getLeafKeys(obj[key], fullKey));
    } else {
      keys.push(fullKey);
    }
  }
  return keys;
}

describe('i18n translations', () => {
  const arKeys = getLeafKeys(ar);
  const enKeys = getLeafKeys(en);
  const frKeys = getLeafKeys(fr);

  it('Arabic translation has all expected top-level sections', () => {
    expect(ar).toHaveProperty('login');
    expect(ar).toHaveProperty('nav');
    expect(ar).toHaveProperty('home');
    expect(ar).toHaveProperty('prices');
    expect(ar).toHaveProperty('portfolio');
    expect(ar).toHaveProperty('purchases');
    expect(ar).toHaveProperty('alerts');
    expect(ar).toHaveProperty('admin');
    expect(ar).toHaveProperty('karats');
  });

  it('English has the same keys as Arabic', () => {
    expect(enKeys.sort()).toEqual(arKeys.sort());
  });

  it('French has the same keys as Arabic', () => {
    expect(frKeys.sort()).toEqual(arKeys.sort());
  });

  it('No empty string values in Arabic', () => {
    for (const key of arKeys) {
      const parts = key.split('.');
      let val: any = ar;
      for (const p of parts) val = val[p];
      expect(val, `ar.${key} should not be empty`).not.toBe('');
    }
  });

  it('No empty string values in English', () => {
    for (const key of enKeys) {
      const parts = key.split('.');
      let val: any = en;
      for (const p of parts) val = val[p];
      expect(val, `en.${key} should not be empty`).not.toBe('');
    }
  });

  it('No empty string values in French', () => {
    for (const key of frKeys) {
      const parts = key.split('.');
      let val: any = fr;
      for (const p of parts) val = val[p];
      expect(val, `fr.${key} should not be empty`).not.toBe('');
    }
  });

  it('RTL_LANGUAGES includes Arabic', () => {
    // RTL_LANGUAGES imported at top
    expect(RTL_LANGUAGES).toContain('ar');
    expect(RTL_LANGUAGES).not.toContain('en');
    expect(RTL_LANGUAGES).not.toContain('fr');
  });

  it('LANGUAGE_LABELS has all three languages', () => {
    // LANGUAGE_LABELS imported at top
    expect(LANGUAGE_LABELS).toHaveProperty('ar', 'العربية');
    expect(LANGUAGE_LABELS).toHaveProperty('en', 'English');
    expect(LANGUAGE_LABELS).toHaveProperty('fr', 'Français');
  });

  it('All translations have at least 50 leaf keys', () => {
    expect(arKeys.length).toBeGreaterThan(50);
    expect(enKeys.length).toBeGreaterThan(50);
    expect(frKeys.length).toBeGreaterThan(50);
  });
});
