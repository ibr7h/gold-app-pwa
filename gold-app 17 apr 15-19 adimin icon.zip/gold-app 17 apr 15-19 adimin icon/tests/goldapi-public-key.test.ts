import { describe, it, expect } from 'vitest';

describe('EXPO_PUBLIC_GOLDAPI_KEY Validation', () => {
  it('should have EXPO_PUBLIC_GOLDAPI_KEY set', () => {
    const key = process.env.EXPO_PUBLIC_GOLDAPI_KEY;
    expect(key).toBeDefined();
    expect(key).toBeTruthy();
    expect(typeof key).toBe('string');
  });

  it('should connect to GoldAPI.io with EXPO_PUBLIC key (200 or 403 quota exceeded)', async () => {
    const key = process.env.EXPO_PUBLIC_GOLDAPI_KEY;
    if (!key) return;

    const response = await fetch('https://www.goldapi.io/api/XAU/USD', {
      headers: {
        'x-access-token': key,
        'Content-Type': 'application/json',
      },
    });

    // 200 = success, 403 = quota exceeded (valid key but limit reached)
    expect([200, 403]).toContain(response.status);
    const data = await response.json();
    expect(data).toBeDefined();
    if (response.status === 200) {
      expect(data.price).toBeDefined();
      expect(data.price_gram_24k).toBeDefined();
    }
  }, 15000);
});
