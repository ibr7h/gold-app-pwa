import { describe, it, expect } from "vitest";

/**
 * Test the state encoding/decoding logic for OAuth deep link support.
 * The state parameter encodes both the redirectUri and an optional deep link.
 */

function base64Encode(str: string): string {
  return Buffer.from(str, "utf-8").toString("base64");
}

function base64Decode(str: string): string {
  return Buffer.from(str, "base64").toString("utf-8");
}

function parseState(state: string): { redirectUri: string; deepLink: string | null } {
  try {
    const decoded = base64Decode(state);
    const pipeIndex = decoded.indexOf("|deeplink:");
    if (pipeIndex !== -1) {
      return {
        redirectUri: decoded.substring(0, pipeIndex),
        deepLink: decoded.substring(pipeIndex + "|deeplink:".length),
      };
    }
    return { redirectUri: decoded, deepLink: null };
  } catch {
    return { redirectUri: "", deepLink: null };
  }
}

describe("OAuth State Encoding", () => {
  it("should encode and decode web state (no deep link)", () => {
    const redirectUri = "https://3000-xxx.sg1.manus.computer/api/oauth/callback";
    const state = base64Encode(redirectUri);
    const parsed = parseState(state);

    expect(parsed.redirectUri).toBe(redirectUri);
    expect(parsed.deepLink).toBeNull();
  });

  it("should encode and decode native state with deep link (user variant)", () => {
    const redirectUri = "https://3000-xxx.sg1.manus.computer/api/oauth/callback";
    const deepLink = "manus20260317035145:///oauth/callback";
    const state = base64Encode(`${redirectUri}|deeplink:${deepLink}`);
    const parsed = parseState(state);

    expect(parsed.redirectUri).toBe(redirectUri);
    expect(parsed.deepLink).toBe(deepLink);
  });

  it("should encode and decode native state with deep link (trader variant)", () => {
    const redirectUri = "https://3000-xxx.sg1.manus.computer/api/oauth/callback";
    const deepLink = "manus20260317035145trader:///oauth/callback";
    const state = base64Encode(`${redirectUri}|deeplink:${deepLink}`);
    const parsed = parseState(state);

    expect(parsed.redirectUri).toBe(redirectUri);
    expect(parsed.deepLink).toBe(deepLink);
    expect(parsed.deepLink).toContain("trader");
  });

  it("should encode and decode native state with deep link (admin variant)", () => {
    const redirectUri = "https://3000-xxx.sg1.manus.computer/api/oauth/callback";
    const deepLink = "manus20260317035145admin:///oauth/callback";
    const state = base64Encode(`${redirectUri}|deeplink:${deepLink}`);
    const parsed = parseState(state);

    expect(parsed.redirectUri).toBe(redirectUri);
    expect(parsed.deepLink).toBe(deepLink);
    expect(parsed.deepLink).toContain("admin");
  });

  it("should detect native deep link starts with 'manus'", () => {
    const deepLink = "manus20260317035145trader:///oauth/callback";
    expect(deepLink.startsWith("manus")).toBe(true);
  });

  it("should build correct deep link redirect URL with session token", () => {
    const deepLink = "manus20260317035145trader:///oauth/callback";
    const sessionToken = "eyJhbGciOiJIUzI1NiJ9.test";
    const userJson = base64Encode(JSON.stringify({ id: 1, name: "Test" }));
    
    const separator = deepLink.includes("?") ? "&" : "?";
    const deepLinkUrl = `${deepLink}${separator}sessionToken=${encodeURIComponent(sessionToken)}&user=${encodeURIComponent(userJson)}`;
    
    expect(deepLinkUrl).toContain("manus20260317035145trader:///oauth/callback?sessionToken=");
    expect(deepLinkUrl).toContain("&user=");
  });

  it("should handle variant scheme correctly", () => {
    const baseScheme = "manus20260317035145";
    
    // User variant - no suffix
    expect(baseScheme + "").toBe("manus20260317035145");
    
    // Trader variant
    expect(baseScheme + "trader").toBe("manus20260317035145trader");
    
    // Admin variant
    expect(baseScheme + "admin").toBe("manus20260317035145admin");
  });

  it("should handle the full redirectUri used in state correctly", () => {
    // The state sent to Manus OAuth portal contains the server callback URL
    // NOT the deep link URL - this is the key fix
    const redirectUri = "https://3000-xxx.sg1.manus.computer/api/oauth/callback";
    
    // Verify it's an https URL (accepted by Manus OAuth)
    expect(redirectUri.startsWith("https://")).toBe(true);
    
    // Verify it's NOT a custom scheme (which was rejected before)
    expect(redirectUri.startsWith("manus")).toBe(false);
    expect(redirectUri.startsWith("exp://")).toBe(false);
  });
});
