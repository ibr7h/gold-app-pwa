import { describe, it, expect } from 'vitest';

describe('OAuth EXPO_PUBLIC environment variables', () => {
  it('EXPO_PUBLIC_APP_ID is set and non-empty', () => {
    expect(process.env.EXPO_PUBLIC_APP_ID).toBeDefined();
    expect(process.env.EXPO_PUBLIC_APP_ID).not.toBe('');
  });

  it('EXPO_PUBLIC_OAUTH_PORTAL_URL is set and is a valid URL', () => {
    expect(process.env.EXPO_PUBLIC_OAUTH_PORTAL_URL).toBeDefined();
    expect(process.env.EXPO_PUBLIC_OAUTH_PORTAL_URL).toMatch(/^https?:\/\//);
  });

  it('EXPO_PUBLIC_OAUTH_SERVER_URL is set and is a valid URL', () => {
    expect(process.env.EXPO_PUBLIC_OAUTH_SERVER_URL).toBeDefined();
    expect(process.env.EXPO_PUBLIC_OAUTH_SERVER_URL).toMatch(/^https?:\/\//);
  });

  it('EXPO_PUBLIC_OWNER_OPEN_ID is set and non-empty', () => {
    expect(process.env.EXPO_PUBLIC_OWNER_OPEN_ID).toBeDefined();
    expect(process.env.EXPO_PUBLIC_OWNER_OPEN_ID).not.toBe('');
  });

  it('EXPO_PUBLIC_OWNER_NAME is set and non-empty', () => {
    expect(process.env.EXPO_PUBLIC_OWNER_NAME).toBeDefined();
    expect(process.env.EXPO_PUBLIC_OWNER_NAME).not.toBe('');
  });

  it('OAuth login URL can be constructed with valid params', () => {
    const portal = process.env.EXPO_PUBLIC_OAUTH_PORTAL_URL;
    const appId = process.env.EXPO_PUBLIC_APP_ID;
    const redirectUri = 'manus20260317035145:///oauth/callback';
    const state = Buffer.from(redirectUri).toString('base64');

    const url = new URL(`${portal}/app-auth`);
    url.searchParams.set('appId', appId!);
    url.searchParams.set('redirectUri', redirectUri);
    url.searchParams.set('state', state);
    url.searchParams.set('type', 'signIn');

    const loginUrl = url.toString();
    expect(loginUrl).toContain('appId=');
    expect(loginUrl).toContain('redirectUri=');
    expect(loginUrl).toContain('state=');
    expect(loginUrl).toContain('type=signIn');
    expect(loginUrl).not.toContain('appId=&'); // appId should not be empty
  });
});
