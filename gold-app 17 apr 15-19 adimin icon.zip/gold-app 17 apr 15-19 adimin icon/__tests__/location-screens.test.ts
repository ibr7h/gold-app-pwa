import { describe, it, expect } from 'vitest';
import * as fs from 'fs';
import * as path from 'path';

describe('Location Feature - File Structure', () => {
  const projectRoot = path.resolve(__dirname, '..');

  it('trader-location screen file exists', () => {
    const filePath = path.join(projectRoot, 'app/(drawer)/trader-location.tsx');
    expect(fs.existsSync(filePath)).toBe(true);
  });

  it('nearby-traders screen file exists', () => {
    const filePath = path.join(projectRoot, 'app/(drawer)/nearby-traders.tsx');
    expect(fs.existsSync(filePath)).toBe(true);
  });

  it('admin-settings screen file exists', () => {
    const filePath = path.join(projectRoot, 'app/(drawer)/admin-settings.tsx');
    expect(fs.existsSync(filePath)).toBe(true);
  });

  it('locationRouter server file exists', () => {
    const filePath = path.join(projectRoot, 'server/locationRouter.ts');
    expect(fs.existsSync(filePath)).toBe(true);
  });

  it('drizzle schema includes traderLocations and adminSettings tables', () => {
    const schemaPath = path.join(projectRoot, 'drizzle/schema.ts');
    const content = fs.readFileSync(schemaPath, 'utf-8');
    expect(content).toContain('traderLocations');
    expect(content).toContain('adminSettings');
  });
});

describe('Location Feature - Screen Content Validation', () => {
  const projectRoot = path.resolve(__dirname, '..');

  it('trader-location screen has required form fields', () => {
    const content = fs.readFileSync(
      path.join(projectRoot, 'app/(drawer)/trader-location.tsx'),
      'utf-8'
    );
    // Must have shop name, address, coordinates, phone fields
    expect(content).toContain('shopName');
    expect(content).toContain('address');
    expect(content).toContain('latitude');
    expect(content).toContain('longitude');
    expect(content).toContain('phone');
    expect(content).toContain('whatsapp');
    // Must have save functionality
    expect(content).toContain('handleSave');
    // Must have current location feature
    expect(content).toContain('getCurrentLocation');
    // Must have visibility toggle
    expect(content).toContain('isVisible');
    // Must have RTL support
    expect(content).toContain('isRTL');
    expect(content).toContain('flexDir');
  });

  it('nearby-traders screen has required features', () => {
    const content = fs.readFileSync(
      path.join(projectRoot, 'app/(drawer)/nearby-traders.tsx'),
      'utf-8'
    );
    // Must have trader list rendering
    expect(content).toContain('FlatList');
    expect(content).toContain('renderTraderCard');
    // Must have distance display
    expect(content).toContain('distanceKm');
    // Must have contact actions
    expect(content).toContain('callPhone');
    expect(content).toContain('openWhatsApp');
    expect(content).toContain('openDirections');
    // Must have location permission handling
    expect(content).toContain('requestForegroundPermissionsAsync');
    // Must have RTL support
    expect(content).toContain('isRTL');
    expect(content).toContain('flexDir');
  });

  it('admin-settings screen has required features', () => {
    const content = fs.readFileSync(
      path.join(projectRoot, 'app/(drawer)/admin-settings.tsx'),
      'utf-8'
    );
    // Must have tabs for contact and locations
    expect(content).toContain('activeTab');
    expect(content).toContain('contact');
    expect(content).toContain('locations');
    // Must have contact settings management
    expect(content).toContain('CONTACT_KEYS');
    expect(content).toContain('handleSaveContact');
    // Must have location management
    expect(content).toContain('handleToggleVisibility');
    expect(content).toContain('handleDeleteLocation');
    // Must have RTL support
    expect(content).toContain('isRTL');
    expect(content).toContain('flexDir');
  });
});

describe('Location Feature - Router Endpoints', () => {
  const projectRoot = path.resolve(__dirname, '..');

  it('locationRouter has all required endpoints', () => {
    const content = fs.readFileSync(
      path.join(projectRoot, 'server/locationRouter.ts'),
      'utf-8'
    );
    // Trader endpoints
    expect(content).toContain('myLocation');
    expect(content).toContain('setLocation');
    expect(content).toContain('toggleVisibility');
    // User endpoints
    expect(content).toContain('nearbyTraders');
    expect(content).toContain('allTraders');
    // Admin endpoints
    expect(content).toContain('adminAllLocations');
    expect(content).toContain('adminToggleVisibility');
    expect(content).toContain('adminDeleteLocation');
  });

  it('settingsRouter has all required endpoints', () => {
    const content = fs.readFileSync(
      path.join(projectRoot, 'server/locationRouter.ts'),
      'utf-8'
    );
    expect(content).toContain('settingsRouter');
    expect(content).toContain('getAll');
    expect(content).toContain('set:');
    expect(content).toContain('delete:');
  });

  it('routers are properly registered in appRouter', () => {
    const content = fs.readFileSync(
      path.join(projectRoot, 'server/routers.ts'),
      'utf-8'
    );
    expect(content).toContain('location: locationRouter');
    expect(content).toContain('settings: settingsRouter');
  });
});

describe('Location Feature - Navigation Integration', () => {
  const projectRoot = path.resolve(__dirname, '..');

  it('drawer layout imports all new screens', () => {
    const content = fs.readFileSync(
      path.join(projectRoot, 'app/(drawer)/_layout.tsx'),
      'utf-8'
    );
    expect(content).toContain("import TraderLocationScreen from './trader-location'");
    expect(content).toContain("import NearbyTradersScreen from './nearby-traders'");
    expect(content).toContain("import AdminSettingsScreen from './admin-settings'");
  });

  it('drawer layout renders all new screens', () => {
    const content = fs.readFileSync(
      path.join(projectRoot, 'app/(drawer)/_layout.tsx'),
      'utf-8'
    );
    expect(content).toContain("case 'trader-location':");
    expect(content).toContain("case 'nearby-traders':");
    expect(content).toContain("case 'admin-settings':");
  });

  it('drawer content has navigation items for all variants', () => {
    const content = fs.readFileSync(
      path.join(projectRoot, 'components/gold/DrawerContent.tsx'),
      'utf-8'
    );
    // Trader variant has shop location
    expect(content).toContain("key: 'trader-location'");
    // User variant has nearby traders
    expect(content).toContain("key: 'nearby-traders'");
    // Admin variant has app settings
    expect(content).toContain("key: 'admin-settings'");
  });
});

describe('Location Feature - Multilingual Support', () => {
  const projectRoot = path.resolve(__dirname, '..');

  it('trader-location has Arabic translations', () => {
    const content = fs.readFileSync(
      path.join(projectRoot, 'app/(drawer)/trader-location.tsx'),
      'utf-8'
    );
    expect(content).toContain('موقع المحل');
    expect(content).toContain('اسم المحل');
    expect(content).toContain('العنوان');
  });

  it('nearby-traders has Arabic translations', () => {
    const content = fs.readFileSync(
      path.join(projectRoot, 'app/(drawer)/nearby-traders.tsx'),
      'utf-8'
    );
    expect(content).toContain('التجار القريبون');
    expect(content).toContain('اتصال');
    expect(content).toContain('واتساب');
  });

  it('admin-settings has Arabic translations', () => {
    const content = fs.readFileSync(
      path.join(projectRoot, 'app/(drawer)/admin-settings.tsx'),
      'utf-8'
    );
    expect(content).toContain('إعدادات التطبيق');
    expect(content).toContain('معلومات الاتصال');
    expect(content).toContain('مواقع التجار');
  });

  it('all screens have French translations', () => {
    const traderLoc = fs.readFileSync(
      path.join(projectRoot, 'app/(drawer)/trader-location.tsx'),
      'utf-8'
    );
    const nearby = fs.readFileSync(
      path.join(projectRoot, 'app/(drawer)/nearby-traders.tsx'),
      'utf-8'
    );
    const adminSettings = fs.readFileSync(
      path.join(projectRoot, 'app/(drawer)/admin-settings.tsx'),
      'utf-8'
    );
    expect(traderLoc).toContain("lang === 'fr'");
    expect(nearby).toContain("lang === 'fr'");
    expect(adminSettings).toContain("lang === 'fr'");
  });
});
