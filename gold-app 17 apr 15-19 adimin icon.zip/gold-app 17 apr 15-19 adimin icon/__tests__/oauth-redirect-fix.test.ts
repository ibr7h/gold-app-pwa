import { describe, it, expect } from 'vitest';
import * as fs from 'fs';
import * as path from 'path';

describe('OAuth redirect_uri fix', () => {
  const projectRoot = path.resolve(__dirname, '..');

  it('getRedirectUri does NOT use Linking.createURL on native (which produces exp:// scheme)', () => {
    const content = fs.readFileSync(
      path.join(projectRoot, 'constants/oauth.ts'),
      'utf-8'
    );
    // The native branch should NOT call Linking.createURL
    // Instead it should build the URI manually with the manus* scheme
    const nativeBranch = content.split('else {')[1]?.split('}')[0] || '';
    expect(nativeBranch).not.toContain('Linking.createURL');
  });

  it('getRedirectUri uses env.deepLinkScheme directly for native', () => {
    const content = fs.readFileSync(
      path.join(projectRoot, 'constants/oauth.ts'),
      'utf-8'
    );
    // Should contain the manual scheme construction
    expect(content).toContain('env.deepLinkScheme');
    expect(content).toContain(':///oauth/callback');
  });

  it('deepLinkScheme starts with "manus" prefix', () => {
    const content = fs.readFileSync(
      path.join(projectRoot, 'constants/oauth.ts'),
      'utf-8'
    );
    // The scheme is built as `manus${timestamp}`
    expect(content).toContain('const schemeFromBundleId = `manus${timestamp}`');
  });

  it('app.config.ts scheme also starts with manus', () => {
    const content = fs.readFileSync(
      path.join(projectRoot, 'app.config.ts'),
      'utf-8'
    );
    expect(content).toContain('const schemeFromBundleId = `manus${timestamp}`');
  });

  it('web redirect still uses API server callback endpoint', () => {
    const content = fs.readFileSync(
      path.join(projectRoot, 'constants/oauth.ts'),
      'utf-8'
    );
    expect(content).toContain('/api/oauth/callback');
  });

  it('comment explains why Linking.createURL is not used', () => {
    const content = fs.readFileSync(
      path.join(projectRoot, 'constants/oauth.ts'),
      'utf-8'
    );
    expect(content).toContain('Expo Go');
    expect(content).toContain('exp://');
  });
});
