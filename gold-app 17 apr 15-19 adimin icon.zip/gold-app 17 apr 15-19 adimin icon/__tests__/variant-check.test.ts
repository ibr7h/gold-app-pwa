import { describe, it, expect } from "vitest";

describe("App Variant Check", () => {
  it("should have EXPO_PUBLIC_APP_VARIANT set to admin", () => {
    expect(process.env.EXPO_PUBLIC_APP_VARIANT).toBe("admin");
  });
});
