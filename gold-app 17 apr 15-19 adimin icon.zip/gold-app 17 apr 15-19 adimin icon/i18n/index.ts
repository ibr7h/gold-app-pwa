import { createContext, useContext } from 'react';
import ar from './ar';
import en from './en';
import fr from './fr';

export type Language = 'ar' | 'en' | 'fr';

// Use a structural type instead of literal type from ar
type DeepStringify<T> = {
  [K in keyof T]: T[K] extends object ? DeepStringify<T[K]> : string;
};

export type Translations = DeepStringify<typeof ar>;

const translations: Record<Language, Translations> = { ar, en, fr };

export const RTL_LANGUAGES: Language[] = ['ar'];
export const LANGUAGE_LABELS: Record<Language, string> = {
  ar: 'العربية',
  en: 'English',
  fr: 'Français',
};

export const STORAGE_KEY = '@gold_app_language';

export interface I18nContextType {
  lang: Language;
  t: Translations;
  isRTL: boolean;
  setLanguage: (lang: Language) => void;
  direction: 'rtl' | 'ltr';
  textAlign: 'right' | 'left';
  flexDir: 'row-reverse' | 'row';
  alignSelf: 'flex-end' | 'flex-start';
}

export const I18nContext = createContext<I18nContextType>({
  lang: 'ar',
  t: ar,
  isRTL: true,
  setLanguage: () => {},
  direction: 'rtl',
  textAlign: 'right',
  flexDir: 'row-reverse',
  alignSelf: 'flex-end',
});

export function useI18n(): I18nContextType {
  return useContext(I18nContext);
}

export { translations };
