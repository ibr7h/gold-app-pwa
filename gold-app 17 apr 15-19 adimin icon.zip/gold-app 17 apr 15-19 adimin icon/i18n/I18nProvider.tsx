import React, { useState, useCallback, useEffect, type ReactNode } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { I18nContext, translations, RTL_LANGUAGES, STORAGE_KEY, type Language } from './index';

interface I18nProviderProps {
  children: ReactNode;
}

export function I18nProvider({ children }: I18nProviderProps) {
  const [lang, setLang] = useState<Language>('ar');

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY).then(stored => {
      if (stored && (stored === 'ar' || stored === 'en' || stored === 'fr')) {
        setLang(stored as Language);
      }
    }).catch(() => {});
  }, []);

  const setLanguage = useCallback((newLang: Language) => {
    setLang(newLang);
    AsyncStorage.setItem(STORAGE_KEY, newLang).catch(() => {});
  }, []);

  const isRTL = RTL_LANGUAGES.includes(lang);

  const value = {
    lang,
    t: translations[lang],
    isRTL,
    setLanguage,
    direction: (isRTL ? 'rtl' : 'ltr') as 'rtl' | 'ltr',
    textAlign: (isRTL ? 'right' : 'left') as 'right' | 'left',
    flexDir: (isRTL ? 'row-reverse' : 'row') as 'row-reverse' | 'row',
    alignSelf: (isRTL ? 'flex-end' : 'flex-start') as 'flex-end' | 'flex-start',
  };

  return (
    <I18nContext.Provider value={value}>
      {children}
    </I18nContext.Provider>
  );
}
