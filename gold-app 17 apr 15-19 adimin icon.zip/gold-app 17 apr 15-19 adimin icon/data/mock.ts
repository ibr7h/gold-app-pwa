// Mock data for Gold App

export interface GoldPrice {
  karat: string;
  karatLabel: string;
  buyPrice: number;
  sellPrice: number;
  change: number;
  changePercent: number;
  currency: string;
  source: string;
  lastUpdate: string;
}

export interface PortfolioItem {
  id: string;
  name: string;
  currency: string;
  totalValue: number;
  totalCost: number;
  profitLoss: number;
  profitLossPercent: number;
  lastUpdate: string;
  purchaseCount: number;
}

export interface Purchase {
  id: string;
  name: string;
  description: string;
  currency: string;
  price: number;
  quantity: number;
  date: string;
  notes: string;
  portfolioId: string;
}

export interface Alert {
  id: string;
  title: string;
  karat: string;
  currency: string;
  targetPrice: number;
  condition: '>=' | '<=';
  enabled: boolean;
  status: 'active' | 'triggered' | 'expired';
  lastUpdate: string;
  note: string;
}

export interface Offer {
  id: string;
  title: string;
  description: string;
  discount: string;
  validUntil: string;
}

export const goldPrices: GoldPrice[] = [
  { karat: '24', karatLabel: 'عيار 24', buyPrice: 312.50, sellPrice: 310.00, change: 2.50, changePercent: 0.81, currency: 'SAR', source: 'السوق المحلي', lastUpdate: '2025-03-17 10:30' },
  { karat: '22', karatLabel: 'عيار 22', buyPrice: 286.46, sellPrice: 284.17, change: 1.80, changePercent: 0.63, currency: 'SAR', source: 'السوق المحلي', lastUpdate: '2025-03-17 10:30' },
  { karat: '21', karatLabel: 'عيار 21', buyPrice: 273.44, sellPrice: 271.25, change: -1.20, changePercent: -0.44, currency: 'SAR', source: 'السوق المحلي', lastUpdate: '2025-03-17 10:30' },
  { karat: '18', karatLabel: 'عيار 18', buyPrice: 234.38, sellPrice: 232.50, change: 1.50, changePercent: 0.64, currency: 'SAR', source: 'السوق المحلي', lastUpdate: '2025-03-17 10:30' },
  { karat: '14', karatLabel: 'عيار 14', buyPrice: 182.29, sellPrice: 180.83, change: -0.50, changePercent: -0.27, currency: 'SAR', source: 'السوق المحلي', lastUpdate: '2025-03-17 10:30' },
];

export const portfolioItems: PortfolioItem[] = [
  { id: '1', name: 'محفظة الذهب الرئيسية', currency: 'SAR', totalValue: 45250.00, totalCost: 42000.00, profitLoss: 3250.00, profitLossPercent: 7.74, lastUpdate: '2025-03-17', purchaseCount: 5 },
  { id: '2', name: 'محفظة الاستثمار', currency: 'SAR', totalValue: 28750.00, totalCost: 30000.00, profitLoss: -1250.00, profitLossPercent: -4.17, lastUpdate: '2025-03-16', purchaseCount: 3 },
  { id: '3', name: 'محفظة الادخار', currency: 'USD', totalValue: 12500.00, totalCost: 11800.00, profitLoss: 700.00, profitLossPercent: 5.93, lastUpdate: '2025-03-15', purchaseCount: 2 },
];

export const purchases: Purchase[] = [
  { id: '1', name: 'سبيكة ذهب 24', description: 'سبيكة ذهب عيار 24 وزن 10 جرام', currency: 'SAR', price: 3125.00, quantity: 2, date: '2025-03-10', notes: 'شراء من محل الراجحي', portfolioId: '1' },
  { id: '2', name: 'جنيه ذهب', description: 'جنيه ذهب عيار 21', currency: 'SAR', price: 2734.40, quantity: 5, date: '2025-03-05', notes: '', portfolioId: '1' },
  { id: '3', name: 'أونصة ذهب', description: 'أونصة ذهب خالص', currency: 'SAR', price: 9718.75, quantity: 1, date: '2025-02-28', notes: 'استثمار طويل الأجل', portfolioId: '1' },
  { id: '4', name: 'سبيكة 50 جرام', description: 'سبيكة ذهب عيار 24 وزن 50 جرام', currency: 'SAR', price: 15625.00, quantity: 1, date: '2025-02-20', notes: '', portfolioId: '2' },
  { id: '5', name: 'عملة ذهبية', description: 'عملة ذهبية تذكارية', currency: 'USD', price: 2500.00, quantity: 2, date: '2025-01-15', notes: 'هدية', portfolioId: '3' },
];

export const alerts: Alert[] = [
  { id: '1', title: 'تنبيه سعر عيار 24', karat: '24', currency: 'SAR', targetPrice: 320.00, condition: '>=', enabled: true, status: 'active', lastUpdate: '2025-03-17 10:00', note: 'بيع عند الوصول' },
  { id: '2', title: 'تنبيه انخفاض عيار 21', karat: '21', currency: 'SAR', targetPrice: 260.00, condition: '<=', enabled: true, status: 'active', lastUpdate: '2025-03-17 09:00', note: 'شراء عند الانخفاض' },
  { id: '3', title: 'تنبيه أونصة الذهب', karat: '24', currency: 'USD', targetPrice: 2100.00, condition: '>=', enabled: false, status: 'expired', lastUpdate: '2025-03-15 14:00', note: '' },
];

export const offers: Offer[] = [
  { id: '1', title: 'عرض خاص - سبائك ذهب', description: 'خصم 2% على جميع السبائك', discount: '2%', validUntil: '2025-04-01' },
  { id: '2', title: 'عرض رمضان', description: 'أسعار مميزة على عيار 21', discount: '3%', validUntil: '2025-04-15' },
  { id: '3', title: 'عرض الجملة', description: 'خصم إضافي للمشتريات فوق 50 جرام', discount: '5%', validUntil: '2025-05-01' },
];

export const chartData = {
  day: [310, 311, 310.5, 312, 311.5, 312.5, 313, 312, 312.5],
  week: [305, 308, 310, 307, 312, 311, 312.5],
  month: [290, 295, 300, 298, 305, 310, 308, 312, 315, 312.5],
  year: [250, 260, 275, 280, 290, 285, 295, 300, 310, 305, 315, 312.5],
};

export const topMovers = [
  { karat: 'عيار 24', price: 312.50, change: 2.50, changePercent: 0.81 },
  { karat: 'عيار 22', price: 286.46, change: 1.80, changePercent: 0.63 },
  { karat: 'عيار 18', price: 234.38, change: 1.50, changePercent: 0.64 },
  { karat: 'عيار 21', price: 273.44, change: -1.20, changePercent: -0.44 },
  { karat: 'عيار 14', price: 182.29, change: -0.50, changePercent: -0.27 },
];
