import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  decimal,
  boolean,
} from "drizzle-orm/mysql-core";

// ===== Users =====
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 20 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin", "trader"]).default("user").notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ===== Trader Clients =====
export const traderClients = mysqlTable("trader_clients", {
  id: int("id").autoincrement().primaryKey(),
  traderId: int("traderId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 20 }),
  status: mysqlEnum("status", ["active", "inactive"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type TraderClient = typeof traderClients.$inferSelect;
export type InsertTraderClient = typeof traderClients.$inferInsert;

// ===== Trader Orders =====
export const traderOrders = mysqlTable("trader_orders", {
  id: int("id").autoincrement().primaryKey(),
  traderId: int("traderId").notNull(),
  clientId: int("clientId").notNull(),
  clientName: varchar("clientName", { length: 255 }).notNull(),
  type: mysqlEnum("type", ["buy", "sell"]).notNull(),
  karat: varchar("karat", { length: 10 }).notNull(),
  grams: decimal("grams", { precision: 10, scale: 3 }).notNull(),
  pricePerGram: decimal("pricePerGram", { precision: 12, scale: 2 }).notNull(),
  totalAmount: decimal("totalAmount", { precision: 14, scale: 2 }).notNull(),
  status: mysqlEnum("status", ["pending", "processing", "completed", "cancelled"]).default("pending").notNull(),
  notes: text("notes"),
  orderDate: timestamp("orderDate").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type TraderOrder = typeof traderOrders.$inferSelect;
export type InsertTraderOrder = typeof traderOrders.$inferInsert;

// ===== Notifications =====
export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  type: mysqlEnum("type", ["new_order", "order_status", "new_client", "new_message", "system"]).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message").notNull(),
  referenceId: int("referenceId"),
  isRead: boolean("isRead").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;

// ===== Conversations =====
export const conversations = mysqlTable("conversations", {
  id: int("id").autoincrement().primaryKey(),
  traderId: int("traderId").notNull(),
  clientId: int("clientId").notNull(),
  clientName: varchar("clientName", { length: 255 }).notNull(),
  lastMessage: text("lastMessage"),
  lastMessageAt: timestamp("lastMessageAt").defaultNow().notNull(),
  traderUnread: int("traderUnread").default(0).notNull(),
  clientUnread: int("clientUnread").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Conversation = typeof conversations.$inferSelect;
export type InsertConversation = typeof conversations.$inferInsert;

// ===== Messages =====
export const messages = mysqlTable("messages", {
  id: int("id").autoincrement().primaryKey(),
  conversationId: int("conversationId").notNull(),
  senderId: int("senderId").notNull(),
  senderName: varchar("senderName", { length: 255 }).notNull(),
  senderRole: mysqlEnum("senderRole", ["trader", "client", "admin"]).notNull(),
  content: text("content").notNull(),
  isRead: boolean("isRead").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Message = typeof messages.$inferSelect;
export type InsertMessage = typeof messages.$inferInsert;

// ===== Invite Codes =====
export const inviteCodes = mysqlTable("invite_codes", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 32 }).notNull().unique(),
  createdBy: int("createdBy").notNull(), // admin user id
  usedBy: int("usedBy"), // trader user id who used this code
  isUsed: boolean("isUsed").default(false).notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  note: text("note"), // optional description
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  usedAt: timestamp("usedAt"),
});

export type InviteCode = typeof inviteCodes.$inferSelect;
export type InsertInviteCode = typeof inviteCodes.$inferInsert;

// ===== Trader Permissions =====
export const traderPermissions = mysqlTable("trader_permissions", {
  id: int("id").autoincrement().primaryKey(),
  traderId: int("traderId").notNull().unique(), // one row per trader
  // Orders permissions
  canViewOrders: boolean("canViewOrders").default(true).notNull(),
  canCreateOrders: boolean("canCreateOrders").default(true).notNull(),
  canEditOrders: boolean("canEditOrders").default(true).notNull(),
  canDeleteOrders: boolean("canDeleteOrders").default(false).notNull(),
  // Clients permissions
  canViewClients: boolean("canViewClients").default(true).notNull(),
  canCreateClients: boolean("canCreateClients").default(true).notNull(),
  canEditClients: boolean("canEditClients").default(true).notNull(),
  canDeleteClients: boolean("canDeleteClients").default(false).notNull(),
  // Reports permissions
  canViewReports: boolean("canViewReports").default(true).notNull(),
  canExportReports: boolean("canExportReports").default(true).notNull(),
  // Messaging permissions
  canUseMessaging: boolean("canUseMessaging").default(true).notNull(),
  // Timestamps
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type TraderPermission = typeof traderPermissions.$inferSelect;
export type InsertTraderPermission = typeof traderPermissions.$inferInsert;

// ===== Trader Locations =====
export const traderLocations = mysqlTable("trader_locations", {
  id: int("id").autoincrement().primaryKey(),
  traderId: int("traderId").notNull().unique(), // one location per trader
  shopName: varchar("shopName", { length: 255 }).notNull(),
  address: text("address").notNull(),
  city: varchar("city", { length: 100 }),
  latitude: decimal("latitude", { precision: 10, scale: 7 }).notNull(),
  longitude: decimal("longitude", { precision: 10, scale: 7 }).notNull(),
  phone: varchar("phone", { length: 20 }),
  whatsapp: varchar("whatsapp", { length: 20 }),
  workingHours: varchar("workingHours", { length: 255 }),
  isVisible: boolean("isVisible").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type TraderLocation = typeof traderLocations.$inferSelect;
export type InsertTraderLocation = typeof traderLocations.$inferInsert;

// ===== Admin Settings (contact info, etc.) =====
export const adminSettings = mysqlTable("admin_settings", {
  id: int("id").autoincrement().primaryKey(),
  key: varchar("key", { length: 100 }).notNull().unique(),
  value: text("value").notNull(),
  label: varchar("label", { length: 255 }),
  updatedBy: int("updatedBy"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AdminSetting = typeof adminSettings.$inferSelect;
export type InsertAdminSetting = typeof adminSettings.$inferInsert;
