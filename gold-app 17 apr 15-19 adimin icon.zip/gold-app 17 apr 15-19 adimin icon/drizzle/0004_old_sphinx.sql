CREATE TABLE `admin_settings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`key` varchar(100) NOT NULL,
	`value` text NOT NULL,
	`label` varchar(255),
	`updatedBy` int,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `admin_settings_id` PRIMARY KEY(`id`),
	CONSTRAINT `admin_settings_key_unique` UNIQUE(`key`)
);
--> statement-breakpoint
CREATE TABLE `trader_locations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`traderId` int NOT NULL,
	`shopName` varchar(255) NOT NULL,
	`address` text NOT NULL,
	`city` varchar(100),
	`latitude` decimal(10,7) NOT NULL,
	`longitude` decimal(10,7) NOT NULL,
	`phone` varchar(20),
	`whatsapp` varchar(20),
	`workingHours` varchar(255),
	`isVisible` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `trader_locations_id` PRIMARY KEY(`id`),
	CONSTRAINT `trader_locations_traderId_unique` UNIQUE(`traderId`)
);
