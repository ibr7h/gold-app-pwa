CREATE TABLE `trader_permissions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`traderId` int NOT NULL,
	`canViewOrders` boolean NOT NULL DEFAULT true,
	`canCreateOrders` boolean NOT NULL DEFAULT true,
	`canEditOrders` boolean NOT NULL DEFAULT true,
	`canDeleteOrders` boolean NOT NULL DEFAULT false,
	`canViewClients` boolean NOT NULL DEFAULT true,
	`canCreateClients` boolean NOT NULL DEFAULT true,
	`canEditClients` boolean NOT NULL DEFAULT true,
	`canDeleteClients` boolean NOT NULL DEFAULT false,
	`canViewReports` boolean NOT NULL DEFAULT true,
	`canExportReports` boolean NOT NULL DEFAULT true,
	`canUseMessaging` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `trader_permissions_id` PRIMARY KEY(`id`),
	CONSTRAINT `trader_permissions_traderId_unique` UNIQUE(`traderId`)
);
