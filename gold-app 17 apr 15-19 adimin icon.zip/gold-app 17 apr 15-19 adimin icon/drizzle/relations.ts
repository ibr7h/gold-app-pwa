import { relations } from "drizzle-orm";
import {
  users,
  traderClients,
  traderOrders,
  notifications,
  conversations,
  messages,
  inviteCodes,
  traderPermissions,
  traderLocations,
  adminSettings,
} from "./schema";

export const usersRelations = relations(users, ({ many }) => ({
  traderClients: many(traderClients),
  traderOrders: many(traderOrders),
  notifications: many(notifications),
  traderConversations: many(conversations),
}));

export const traderClientsRelations = relations(traderClients, ({ one, many }) => ({
  trader: one(users, {
    fields: [traderClients.traderId],
    references: [users.id],
  }),
  orders: many(traderOrders),
}));

export const traderOrdersRelations = relations(traderOrders, ({ one }) => ({
  trader: one(users, {
    fields: [traderOrders.traderId],
    references: [users.id],
  }),
  client: one(traderClients, {
    fields: [traderOrders.clientId],
    references: [traderClients.id],
  }),
}));

export const notificationsRelations = relations(notifications, ({ one }) => ({
  user: one(users, {
    fields: [notifications.userId],
    references: [users.id],
  }),
}));

export const conversationsRelations = relations(conversations, ({ one, many }) => ({
  trader: one(users, {
    fields: [conversations.traderId],
    references: [users.id],
  }),
  messages: many(messages),
}));

export const messagesRelations = relations(messages, ({ one }) => ({
  conversation: one(conversations, {
    fields: [messages.conversationId],
    references: [conversations.id],
  }),
  sender: one(users, {
    fields: [messages.senderId],
    references: [users.id],
  }),
}));

export const inviteCodesRelations = relations(inviteCodes, ({ one }) => ({
  creator: one(users, {
    fields: [inviteCodes.createdBy],
    references: [users.id],
    relationName: "inviteCreator",
  }),
}));

export const traderPermissionsRelations = relations(traderPermissions, ({ one }) => ({
  trader: one(users, {
    fields: [traderPermissions.traderId],
    references: [users.id],
  }),
}));

export const traderLocationsRelations = relations(traderLocations, ({ one }) => ({
  trader: one(users, {
    fields: [traderLocations.traderId],
    references: [users.id],
  }),
}));
