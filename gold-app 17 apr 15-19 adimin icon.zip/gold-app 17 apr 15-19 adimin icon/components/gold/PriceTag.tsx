import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { useI18n } from '@/i18n';

interface PriceTagProps {
  value: number;
  change?: number;
  changePercent?: number;
  currency?: string;
  size?: 'small' | 'medium' | 'large';
  showSign?: boolean;
}

export function PriceTag({
  value,
  change,
  changePercent,
  currency = 'SAR',
  size = 'medium',
  showSign = true,
}: PriceTagProps) {
  const { isRTL } = useI18n();
  const isPositive = (change ?? 0) >= 0;
  const changeColor = isPositive ? '#22C55E' : '#EF4444';
  const arrow = isPositive ? '▲' : '▼';

  const fontSize = size === 'large' ? 24 : size === 'medium' ? 18 : 14;
  const changeFontSize = size === 'large' ? 14 : size === 'medium' ? 12 : 10;

  return (
    <View style={[styles.container, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
      <Text style={[styles.price, { fontSize }]}>
        {(value ?? 0).toFixed(2)} {currency}
      </Text>
      {change !== undefined && (
        <View style={[styles.changeBadge, { backgroundColor: isPositive ? 'rgba(34,197,94,0.15)' : 'rgba(239,68,68,0.15)' }]}>
          <Text style={[styles.changeText, { color: changeColor, fontSize: changeFontSize }]}>
            {arrow} {showSign && (isPositive ? '+' : '')}{change?.toFixed(2)} ({changePercent?.toFixed(2)}%)
          </Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {},
  price: { fontWeight: '700', color: '#1A1A1B', fontVariant: ['tabular-nums'] },
  changeBadge: { borderRadius: 6, paddingHorizontal: 8, paddingVertical: 3, marginTop: 4 },
  changeText: { fontWeight: '600', fontVariant: ['tabular-nums'] },
});
