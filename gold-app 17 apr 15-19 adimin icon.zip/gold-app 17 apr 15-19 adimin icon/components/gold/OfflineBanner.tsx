import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { useOffline } from '@/contexts/OfflineContext';
import { useI18n } from '@/i18n';

export function OfflineBanner() {
  const { isOnline, isInternetReachable, lastOnlineAt, checkConnection } = useOffline();
  const { lang, isRTL, direction, flexDir } = useI18n();

  if (isOnline && isInternetReachable) return null;

  const offlineText = lang === 'ar' ? 'لا يوجد اتصال بالإنترنت' : lang === 'fr' ? 'Pas de connexion Internet' : 'No Internet Connection';
  const cachedText = lang === 'ar' ? 'يتم عرض البيانات المخزنة مؤقتاً' : lang === 'fr' ? 'Affichage des données en cache' : 'Showing cached data';
  const retryText = lang === 'ar' ? 'إعادة المحاولة' : lang === 'fr' ? 'Réessayer' : 'Retry';

  const formatLastOnline = () => {
    if (!lastOnlineAt) return '';
    const diff = Date.now() - lastOnlineAt;
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return lang === 'ar' ? 'منذ لحظات' : lang === 'fr' ? 'Il y a un instant' : 'Just now';
    if (mins < 60) return lang === 'ar' ? `منذ ${mins} دقيقة` : lang === 'fr' ? `Il y a ${mins} min` : `${mins}m ago`;
    const hours = Math.floor(mins / 60);
    return lang === 'ar' ? `منذ ${hours} ساعة` : lang === 'fr' ? `Il y a ${hours}h` : `${hours}h ago`;
  };

  return (
    <View style={styles.banner}>
      <View style={[styles.content, { flexDirection: flexDir }]}>
        <View style={[styles.info, { flexDirection: flexDir, flex: 1 }]}>
          <MaterialIcons name="wifi-off" size={18} color="#FFF" style={isRTL ? { marginLeft: 8 } : { marginRight: 8 }} />
          <View style={{ flex: 1, alignItems: isRTL ? 'flex-end' : 'flex-start' }}>
            <Text style={[styles.title, { writingDirection: direction }]}>{offlineText}</Text>
            <Text style={[styles.subtitle, { writingDirection: direction }]}>
              {cachedText} {lastOnlineAt ? `• ${formatLastOnline()}` : ''}
            </Text>
          </View>
        </View>
        <TouchableOpacity style={styles.retryBtn} onPress={checkConnection} activeOpacity={0.7}>
          <MaterialIcons name="refresh" size={16} color="#FFF" />
          <Text style={styles.retryText}>{retryText}</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}
const styles = StyleSheet.create({
  banner: {
    backgroundColor: '#EF4444',
    paddingHorizontal: 16,
    paddingVertical: 10,
  },
  content: {
    alignItems: 'center',
    gap: 8,
  },
  info: {
    alignItems: 'center',
  },
  title: {
    fontSize: 13,
    fontWeight: '700',
    color: '#FFF',
  },
  subtitle: {
    fontSize: 11,
    color: 'rgba(255,255,255,0.8)',
    marginTop: 1,
  },
  retryBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: 'rgba(255,255,255,0.2)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
  },
  retryText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#FFF',
  },
});
