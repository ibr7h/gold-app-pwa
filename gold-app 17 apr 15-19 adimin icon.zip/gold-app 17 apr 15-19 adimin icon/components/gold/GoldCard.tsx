import React from 'react';
import { View, Text, StyleSheet, type ViewStyle } from 'react-native';
import { useI18n } from '@/i18n';

interface GoldCardProps {
  children: React.ReactNode;
  title?: string;
  style?: ViewStyle;
  noPadding?: boolean;
}

export function GoldCard({ children, title, style, noPadding }: GoldCardProps) {
  const { textAlign, direction } = useI18n();

  return (
    <View style={[styles.card, noPadding && styles.noPadding, style]}>
      {title && <Text style={[styles.title, { textAlign, writingDirection: direction }]}>{title}</Text>}
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#F8F9FA', borderRadius: 12, padding: 16,
    borderWidth: 1, borderColor: '#E6E8EA',
  },
  noPadding: { padding: 0 },
  title: { fontSize: 16, fontWeight: '700', color: '#1A1A1B', marginBottom: 12 },
});
