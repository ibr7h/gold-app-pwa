import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, Alert, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { useAuth } from '@/contexts/AuthContext';
import { useI18n } from '@/i18n';
import { LANGUAGE_LABELS, type Language } from '@/i18n';
import { useTraderData } from '@/contexts/TraderDataContext';
import { useMessaging } from '@/contexts/MessagingContext';
import { APP_VARIANT, currentVariantConfig } from '@/constants/appVariant';

interface DrawerContentProps {
  activeScreen: string;
  onNavigate: (screen: string) => void;
  onClose: () => void;
}

export function DrawerContent({ activeScreen, onNavigate, onClose }: DrawerContentProps) {
  const {
    user, logout,
    biometricType, biometricAvailable, biometricEnrolled,
    biometricEnabled, enableBiometric, disableBiometric,
  } = useAuth();
  const { t, isRTL, textAlign, direction, flexDir, setLanguage, lang } = useI18n();
  // Use APP_VARIANT to determine which menu items to show
  const isAdminVariant = APP_VARIANT === 'admin';
  const isTraderVariant = APP_VARIANT === 'trader';
  const [togglingBiometric, setTogglingBiometric] = useState(false);

  // Trader notifications count
  const traderData = useTraderData();
  const traderUnreadCount = traderData.unreadCount;

  // Messaging unread count
  const messagingData = useMessaging();
  const messagingUnread = messagingData.totalUnread;

  const canShowBiometric = biometricAvailable && biometricEnrolled;

  // Role-based drawer items
  const getDrawerItems = () => {
    const profileItem = { key: 'profile', label: lang === 'ar' ? 'الملف الشخصي' : lang === 'fr' ? 'Profil' : 'Profile', icon: 'person' };
    const settingsItem = { key: 'settings', label: lang === 'ar' ? 'الإعدادات' : lang === 'fr' ? 'Param\u00e8tres' : 'Settings', icon: 'settings' };

    const searchItem = { key: 'search', label: lang === 'ar' ? 'البحث' : lang === 'fr' ? 'Recherche' : 'Search', icon: 'search' };
    const faqItem = { key: 'faq-support', label: lang === 'ar' ? 'المساعدة والدعم' : lang === 'fr' ? 'Aide & Support' : 'Help & Support', icon: 'help-outline' };

    if (isTraderVariant) {
      return [
        { key: 'trader-home', label: t.nav.traderHome, icon: 'storefront' },
        searchItem,
        { key: 'trader-orders', label: t.nav.orders, icon: 'receipt-long' },
        { key: 'trader-clients', label: t.nav.clients, icon: 'people' },
        { key: 'trader-notifications', label: lang === 'ar' ? 'الإشعارات' : lang === 'fr' ? 'Notifications' : 'Notifications', icon: 'notifications', badge: traderUnreadCount },
        { key: 'trader-reports', label: lang === 'ar' ? 'التقارير' : lang === 'fr' ? 'Rapports' : 'Reports', icon: 'bar-chart' },
        { key: 'trader-messages', label: lang === 'ar' ? 'الرسائل' : lang === 'fr' ? 'Messages' : 'Messages', icon: 'chat', badge: messagingUnread },
        { key: 'trader-location', label: lang === 'ar' ? 'موقع المحل' : lang === 'fr' ? 'Emplacement' : 'Shop Location', icon: 'location-on' },
        { key: 'prices', label: t.nav.prices, icon: 'show-chart' },
        profileItem,
        settingsItem,
        faqItem,
      ];
    }

    if (isAdminVariant) {
      return [
        { key: 'admin', label: t.nav.admin, icon: 'admin-panel-settings' },
        { key: 'admin-users', label: lang === 'ar' ? 'إدارة المستخدمين' : lang === 'fr' ? 'Gestion des utilisateurs' : 'User Management', icon: 'people' },
        { key: 'admin-invites', label: lang === 'ar' ? 'أكواد الدعوة' : lang === 'fr' ? 'Codes d\'invitation' : 'Invite Codes', icon: 'vpn-key' },
        { key: 'admin-permissions', label: lang === 'ar' ? 'صلاحيات التجار' : lang === 'fr' ? 'Permissions' : 'Permissions', icon: 'security' },
        { key: 'admin-stats', label: lang === 'ar' ? 'الإحصائيات' : lang === 'fr' ? 'Statistiques' : 'Statistics', icon: 'analytics' },
        { key: 'admin-settings', label: lang === 'ar' ? 'إعدادات التطبيق' : lang === 'fr' ? 'Paramètres app' : 'App Settings', icon: 'tune' },
        searchItem,
        profileItem,
        settingsItem,
        faqItem,
      ];
    }

    // Regular user variant
    return [
      { key: 'home', label: t.nav.home, icon: 'home' },
      searchItem,
      { key: 'prices', label: t.nav.prices, icon: 'show-chart' },
      { key: 'portfolio', label: t.nav.portfolio, icon: 'account-balance-wallet' },
      { key: 'purchases', label: t.nav.purchases, icon: 'shopping-cart' },
      { key: 'alerts', label: t.nav.alerts, icon: 'notifications' },
      { key: 'nearby-traders', label: lang === 'ar' ? 'التجار القريبون' : lang === 'fr' ? 'Commerçants proches' : 'Nearby Traders', icon: 'store' },
      profileItem,
      settingsItem,
      faqItem,
    ];
  };

  const drawerItems = getDrawerItems();

  const languages: Language[] = ['ar', 'en', 'fr'];

  const getBiometricLabel = (): string => {
    if (biometricType === 'face') return biometricEnabled ? t.biometric.disableBiometric : t.biometric.enableFaceId;
    if (biometricType === 'fingerprint') return biometricEnabled ? t.biometric.disableBiometric : t.biometric.enableFingerprint;
    return biometricEnabled ? t.biometric.disableBiometric : t.biometric.enableBiometric;
  };

  const getBiometricIcon = (): 'face' | 'fingerprint' => {
    return biometricType === 'face' ? 'face' : 'fingerprint';
  };

  const handleToggleBiometric = async () => {
    setTogglingBiometric(true);
    try {
      if (biometricEnabled) {
        await disableBiometric();
        if (Platform.OS !== 'web') {
          Alert.alert('', t.biometric.biometricDisabled);
        }
      } else {
        await enableBiometric();
        if (Platform.OS !== 'web') {
          Alert.alert('', t.biometric.biometricEnabled);
        }
      }
    } catch {
      // Silently handle
    }
    setTogglingBiometric(false);
  };

  return (
    <View style={styles.container}>
      <SafeAreaView style={styles.safeArea} edges={['top', 'bottom']}>
        {/* Header */}
        <TouchableOpacity
          style={styles.header}
          activeOpacity={0.7}
          onPress={() => { onNavigate('profile'); onClose(); }}
        >
          <View style={[styles.headerContent, { flexDirection: flexDir }]}>
            <View style={[styles.avatar, isRTL ? { marginLeft: 12 } : { marginRight: 12 }]}>
              <Text style={styles.avatarText}>
                {(user?.name || user?.email || 'U').charAt(0).toUpperCase()}
              </Text>
            </View>
            <View style={[styles.headerInfo, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
              <Text style={[styles.headerEmail, { textAlign, writingDirection: direction }]} numberOfLines={1}>
                {user?.name || user?.email}
              </Text>
              <View style={styles.roleBadge}>
                <Text style={[styles.roleText, { writingDirection: direction }]}>
                  {isAdminVariant ? t.home.roleAdmin : isTraderVariant ? t.home.roleTrader : t.home.roleUser}
                </Text>
              </View>
            </View>
          </View>
        </TouchableOpacity>

        {/* Menu Items */}
        <ScrollView style={styles.menuContainer} showsVerticalScrollIndicator={false}>
          {drawerItems.map(item => {
            const isActive = activeScreen === item.key;
            return (
              <TouchableOpacity
                key={item.key}
                onPress={() => { onNavigate(item.key); onClose(); }}
                activeOpacity={0.7}
                style={[styles.menuItem, { flexDirection: flexDir }, isActive && styles.menuItemActive]}
              >
                <Text style={[
                  styles.menuLabel,
                  { textAlign, writingDirection: direction },
                  isActive && styles.menuLabelActive,
                ]}>
                  {item.label}
                </Text>
                <View style={[
                  styles.menuIconContainer,
                  isRTL ? { marginLeft: 12 } : { marginRight: 12 },
                  isActive && styles.menuIconContainerActive,
                ]}>
                  <MaterialIcons
                    name={item.icon as any}
                    size={22}
                    color={isActive ? '#C5A021' : '#F8F9FA'}
                  />
                  {'badge' in item && (item as any).badge > 0 && (
                    <View style={styles.badgeContainer}>
                      <Text style={styles.badgeText}>{(item as any).badge}</Text>
                    </View>
                  )}
                </View>
              </TouchableOpacity>
            );
          })}
        </ScrollView>

        {/* Biometric Toggle Section */}
        {canShowBiometric && (
          <View style={styles.biometricSection}>
            <Text style={[styles.sectionTitle, { textAlign, writingDirection: direction }]}>
              {t.biometric.security}
            </Text>
            <TouchableOpacity
              onPress={handleToggleBiometric}
              activeOpacity={0.7}
              disabled={togglingBiometric}
              style={[styles.biometricRow, { flexDirection: flexDir }]}
            >
              <View style={[styles.biometricInfo, { flexDirection: flexDir }]}>
                <View style={[styles.biometricIconBox, isRTL ? { marginLeft: 10 } : { marginRight: 10 }]}>
                  <MaterialIcons name={getBiometricIcon()} size={20} color="#C5A021" />
                </View>
                <Text style={[styles.biometricLabel, { writingDirection: direction }]}>
                  {getBiometricLabel()}
                </Text>
              </View>
              <View style={[styles.toggleTrack, biometricEnabled && styles.toggleTrackActive]}>
                <View style={[styles.toggleThumb, biometricEnabled && styles.toggleThumbActive]} />
              </View>
            </TouchableOpacity>
          </View>
        )}

        {/* Language Switcher */}
        <View style={styles.langSection}>
          <Text style={[styles.sectionTitle, { textAlign, writingDirection: direction }]}>{t.language}</Text>
          <View style={styles.langRow}>
            {languages.map(l => (
              <TouchableOpacity
                key={l}
                onPress={() => setLanguage(l)}
                style={[styles.langBtn, lang === l && styles.langBtnActive]}
                activeOpacity={0.7}
              >
                <Text style={[styles.langBtnText, lang === l && styles.langBtnTextActive]}>
                  {LANGUAGE_LABELS[l]}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Logout */}
        <View style={styles.footer}>
          <TouchableOpacity
            onPress={logout}
            activeOpacity={0.7}
            style={[styles.logoutBtn, { flexDirection: flexDir }]}
          >
            <Text style={[styles.logoutText, { writingDirection: direction }, isRTL ? { marginLeft: 8 } : { marginRight: 8 }]}>{t.nav.logout}</Text>
            <MaterialIcons name="logout" size={20} color="#EF4444" />
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#001F3F' },
  safeArea: { flex: 1 },
  header: { paddingHorizontal: 20, paddingVertical: 24, borderBottomWidth: 1, borderBottomColor: 'rgba(248,249,250,0.1)' },
  headerContent: { alignItems: 'center' },
  avatar: {
    width: 48, height: 48, borderRadius: 24,
    backgroundColor: '#C5A021', alignItems: 'center', justifyContent: 'center',
  },
  avatarText: { fontSize: 20, fontWeight: '700', color: '#001F3F' },
  headerInfo: { flex: 1 },
  headerEmail: { fontSize: 14, fontWeight: '600', color: '#F8F9FA' },
  roleBadge: { backgroundColor: 'rgba(197,160,33,0.2)', borderRadius: 6, paddingHorizontal: 10, paddingVertical: 3, marginTop: 4 },
  roleText: { fontSize: 11, fontWeight: '600', color: '#C5A021' },
  menuContainer: { flex: 1, paddingTop: 12 },
  menuItem: { alignItems: 'center', paddingVertical: 14, paddingHorizontal: 20, marginHorizontal: 12, marginVertical: 2, borderRadius: 12 },
  menuItemActive: { backgroundColor: 'rgba(197,160,33,0.12)' },
  menuIconContainer: { width: 36, height: 36, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  menuIconContainerActive: { backgroundColor: 'rgba(197,160,33,0.2)' },
  menuLabel: { fontSize: 15, fontWeight: '500', color: '#F8F9FA', flex: 1 },
  menuLabelActive: { color: '#C5A021', fontWeight: '700' },

  // Biometric section
  biometricSection: { paddingHorizontal: 20, paddingVertical: 12, borderTopWidth: 1, borderTopColor: 'rgba(248,249,250,0.1)' },
  sectionTitle: { fontSize: 12, fontWeight: '600', color: '#6C737F', marginBottom: 10 },
  biometricRow: {
    alignItems: 'center', justifyContent: 'space-between',
    paddingVertical: 10, paddingHorizontal: 12, borderRadius: 12,
    backgroundColor: 'rgba(248,249,250,0.05)',
  },
  biometricInfo: { alignItems: 'center', flex: 1 },
  biometricIconBox: {
    width: 32, height: 32, borderRadius: 8,
    backgroundColor: 'rgba(197,160,33,0.15)', alignItems: 'center', justifyContent: 'center',
  },
  biometricLabel: { fontSize: 13, fontWeight: '500', color: '#F8F9FA', flex: 1 },

  // Toggle
  toggleTrack: {
    width: 44, height: 26, borderRadius: 13,
    backgroundColor: 'rgba(248,249,250,0.15)', justifyContent: 'center', paddingHorizontal: 2,
  },
  toggleTrackActive: { backgroundColor: '#C5A021' },
  toggleThumb: {
    width: 22, height: 22, borderRadius: 11,
    backgroundColor: '#F8F9FA',
  },
  toggleThumbActive: { alignSelf: 'flex-end' },

  // Language
  langSection: { paddingHorizontal: 20, paddingVertical: 12, borderTopWidth: 1, borderTopColor: 'rgba(248,249,250,0.1)' },
  langRow: { flexDirection: 'row', justifyContent: 'center', gap: 8 },
  langBtn: {
    flex: 1, paddingVertical: 8, borderRadius: 10, alignItems: 'center',
    backgroundColor: 'rgba(248,249,250,0.06)', borderWidth: 1, borderColor: 'rgba(248,249,250,0.1)',
  },
  langBtnActive: { backgroundColor: 'rgba(197,160,33,0.15)', borderColor: 'rgba(197,160,33,0.5)' },
  langBtnText: { fontSize: 12, color: '#F8F9FA', fontWeight: '500' },
  langBtnTextActive: { color: '#C5A021', fontWeight: '600' },
  footer: { paddingHorizontal: 20, paddingVertical: 16, borderTopWidth: 1, borderTopColor: 'rgba(248,249,250,0.1)' },
  logoutBtn: { alignItems: 'center', paddingVertical: 12, paddingHorizontal: 8 },
  logoutText: { fontSize: 15, fontWeight: '500', color: '#EF4444' },

  // Badge
  badgeContainer: {
    position: 'absolute', top: -4, right: -4,
    backgroundColor: '#EF4444', borderRadius: 9,
    minWidth: 18, height: 18, alignItems: 'center', justifyContent: 'center',
    paddingHorizontal: 4,
  },
  badgeText: { fontSize: 10, fontWeight: '700', color: '#FFFFFF' },
});
