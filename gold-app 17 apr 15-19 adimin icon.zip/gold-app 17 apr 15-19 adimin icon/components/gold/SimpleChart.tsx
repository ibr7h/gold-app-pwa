import React from 'react';
import { View, StyleSheet } from 'react-native';
import Svg, { Polyline, Defs, LinearGradient, Stop, Rect, Line, Text as SvgText } from 'react-native-svg';

interface SimpleChartProps {
  data: number[];
  width?: number;
  height?: number;
  color?: string;
}

export function SimpleChart({ data, width = 320, height = 160, color = '#C5A021' }: SimpleChartProps) {
  if (!data || data.length < 2) return null;

  const padding = { top: 20, right: 16, bottom: 24, left: 50 };
  const chartW = width - padding.left - padding.right;
  const chartH = height - padding.top - padding.bottom;

  const minVal = Math.min(...data);
  const maxVal = Math.max(...data);
  const range = maxVal - minVal || 1;

  const points = data.map((val, i) => {
    const x = padding.left + (i / (data.length - 1)) * chartW;
    const y = padding.top + chartH - ((val - minVal) / range) * chartH;
    return `${x},${y}`;
  }).join(' ');

  // Y-axis labels
  const yLabels = [minVal, minVal + range * 0.5, maxVal];

  return (
    <View style={styles.container}>
      <Svg width={width} height={height}>
        <Defs>
          <LinearGradient id="lineGrad" x1="0" y1="0" x2="0" y2="1">
            <Stop offset="0" stopColor={color} stopOpacity="0.3" />
            <Stop offset="1" stopColor={color} stopOpacity="0" />
          </LinearGradient>
        </Defs>

        {/* Grid lines */}
        {yLabels.map((val, i) => {
          const y = padding.top + chartH - ((val - minVal) / range) * chartH;
          return (
            <React.Fragment key={i}>
              <Line
                x1={padding.left}
                y1={y}
                x2={width - padding.right}
                y2={y}
                stroke="rgba(0,31,63,0.1)"
                strokeWidth={1}
              />
              <SvgText
                x={padding.left - 8}
                y={y + 4}
                fill="#6B7280"
                fontSize={10}
                textAnchor="end"
              >
                {val.toFixed(0)}
              </SvgText>
            </React.Fragment>
          );
        })}

        {/* Fill area */}
        <Polyline
          points={`${padding.left},${padding.top + chartH} ${points} ${width - padding.right},${padding.top + chartH}`}
          fill="url(#lineGrad)"
          stroke="none"
        />

        {/* Line */}
        <Polyline
          points={points}
          fill="none"
          stroke={color}
          strokeWidth={2.5}
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </Svg>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
  },
});
