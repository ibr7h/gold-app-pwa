import React from 'react';
import { Switch, StyleSheet } from 'react-native';

interface GoldToggleProps {
  value: boolean;
  onValueChange: (value: boolean) => void;
  disabled?: boolean;
}

export function GoldToggle({ value, onValueChange, disabled }: GoldToggleProps) {
  return (
    <Switch
      value={value}
      onValueChange={onValueChange}
      disabled={disabled}
      trackColor={{ false: '#E6E8EA', true: '#C5A021' }}
      thumbColor={value ? '#FFFFFF' : '#9CA3AF'}
      style={styles.toggle}
    />
  );
}

const styles = StyleSheet.create({
  toggle: {
    transform: [{ scaleX: 0.9 }, { scaleY: 0.9 }],
  },
});
