import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, type DimensionValue } from 'react-native';

interface PieSegment {
  label: string;
  value: number;
  color: string;
}

interface InteractivePieChartProps {
  data: PieSegment[];
  size?: number;
  isRTL?: boolean;
  formatValue?: (value: number) => string;
}

export function InteractivePieChart({
  data,
  size = 160,
  isRTL = false,
  formatValue = (v) => v.toString(),
}: InteractivePieChartProps) {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  const total = data.reduce((sum, d) => sum + d.value, 0) || 1;

  return (
    <View style={styles.container}>
      {/* Donut Chart using View-based approach */}
      <View style={[styles.chartRow, isRTL && { flexDirection: 'row-reverse' }]}>
        <View style={[styles.donutContainer, { width: size, height: size }]}>
          {/* Background ring */}
          <View style={[styles.donutBg, { width: size, height: size, borderRadius: size / 2 }]} />
          {/* Center */}
          <View style={[styles.donutCenter, { width: size * 0.55, height: size * 0.55, borderRadius: size * 0.275 }]}>
            {activeIndex !== null && data[activeIndex] ? (
              <>
                <Text style={[styles.centerValue, { color: data[activeIndex].color }]}>
                  {formatValue(data[activeIndex].value)}
                </Text>
                <Text style={styles.centerLabel} numberOfLines={1}>
                  {data[activeIndex].label}
                </Text>
              </>
            ) : (
              <>
                <Text style={styles.centerValue}>{total}</Text>
                <Text style={styles.centerLabel}>
                  {isRTL ? 'الإجمالي' : 'Total'}
                </Text>
              </>
            )}
          </View>
          {/* Segments as colored arcs approximated with progress bars */}
          {data.map((segment, i) => {
            const pct = (segment.value / total) * 100;
            const startAngle = data.slice(0, i).reduce((sum, d) => sum + (d.value / total) * 360, 0);
            const isActive = activeIndex === i;
            return (
              <View
                key={i}
                style={[
                  styles.segmentArc,
                  {
                    width: size,
                    height: size,
                    borderRadius: size / 2,
                    borderWidth: isActive ? size * 0.14 : size * 0.12,
                    borderColor: 'transparent',
                    borderTopColor: segment.color,
                    borderRightColor: pct > 25 ? segment.color : 'transparent',
                    borderBottomColor: pct > 50 ? segment.color : 'transparent',
                    borderLeftColor: pct > 75 ? segment.color : 'transparent',
                    transform: [{ rotate: `${startAngle - 90}deg` }],
                    opacity: activeIndex === null || isActive ? 1 : 0.4,
                  },
                ]}
              />
            );
          })}
        </View>

        {/* Legend */}
        <View style={styles.legend}>
          {data.map((segment, i) => {
            const pct = ((segment.value / total) * 100).toFixed(0);
            const isActive = activeIndex === i;
            return (
              <TouchableOpacity
                key={i}
                style={[styles.legendItem, isActive && styles.legendItemActive]}
                onPress={() => setActiveIndex(isActive ? null : i)}
                activeOpacity={0.7}
              >
                <View style={[styles.legendDot, { backgroundColor: segment.color }]} />
                <View style={styles.legendTextCol}>
                  <Text style={[styles.legendLabel, isActive && { color: segment.color }]} numberOfLines={1}>
                    {segment.label}
                  </Text>
                  <Text style={styles.legendValue}>{pct}%</Text>
                </View>
              </TouchableOpacity>
            );
          })}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingVertical: 8,
  },
  chartRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  donutContainer: {
    position: 'relative',
    justifyContent: 'center',
    alignItems: 'center',
  },
  donutBg: {
    position: 'absolute',
    backgroundColor: 'rgba(255,255,255,0.04)',
  },
  donutCenter: {
    position: 'absolute',
    backgroundColor: '#0D1B2A',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 10,
  },
  centerValue: {
    color: '#C5A021',
    fontSize: 18,
    fontWeight: '700',
  },
  centerLabel: {
    color: '#6C737F',
    fontSize: 10,
    marginTop: 2,
  },
  segmentArc: {
    position: 'absolute',
  },
  legend: {
    flex: 1,
    gap: 6,
  },
  legendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 8,
  },
  legendItemActive: {
    backgroundColor: 'rgba(197,160,33,0.08)',
  },
  legendDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    marginRight: 8,
  },
  legendTextCol: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  legendLabel: {
    color: '#E0E0E0',
    fontSize: 12,
    flex: 1,
  },
  legendValue: {
    color: '#9BA1A6',
    fontSize: 12,
    fontWeight: '600',
    marginLeft: 8,
  },
});
