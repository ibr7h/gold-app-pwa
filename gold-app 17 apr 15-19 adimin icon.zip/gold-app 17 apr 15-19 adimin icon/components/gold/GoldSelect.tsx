import React, { useState } from 'react';
import { View, Text, TouchableOpacity, Modal, FlatList, StyleSheet } from 'react-native';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { useI18n } from '@/i18n';

interface Option {
  label: string;
  value: string;
}

interface GoldSelectProps {
  label: string;
  value: string;
  options: Option[];
  onSelect: (value: string) => void;
  placeholder?: string;
  error?: string;
}

export function GoldSelect({ label, value, options, onSelect, placeholder, error }: GoldSelectProps) {
  const [visible, setVisible] = useState(false);
  const { textAlign, direction, flexDir } = useI18n();
  const selectedLabel = options.find(o => o.value === value)?.label || placeholder || '...';

  return (
    <View style={styles.container}>
      <Text style={[styles.label, { textAlign, writingDirection: direction }]}>{label}</Text>
      <TouchableOpacity
        onPress={() => setVisible(true)}
        style={[styles.selector, { flexDirection: flexDir }, error ? styles.selectorError : null]}
        activeOpacity={0.7}
      >
        <MaterialIcons name="keyboard-arrow-down" size={20} color="#6C737F" />
        <Text style={[styles.selectorText, { textAlign, writingDirection: direction }, !value && styles.placeholder]}>{selectedLabel}</Text>
      </TouchableOpacity>
      {error ? <Text style={[styles.error, { textAlign, writingDirection: direction }]}>{error}</Text> : null}

      <Modal visible={visible} transparent animationType="fade">
        <TouchableOpacity style={styles.overlay} activeOpacity={1} onPress={() => setVisible(false)}>
          <View style={styles.modal}>
            <Text style={[styles.modalTitle, { textAlign, writingDirection: direction }]}>{label}</Text>
            <FlatList
              data={options}
              keyExtractor={item => item.value}
              renderItem={({ item }) => (
                <TouchableOpacity
                  onPress={() => { onSelect(item.value); setVisible(false); }}
                  style={[styles.option, { flexDirection: flexDir }, item.value === value && styles.optionSelected]}
                  activeOpacity={0.7}
                >
                  <Text style={[styles.optionText, { textAlign, writingDirection: direction }, item.value === value && styles.optionTextSelected]}>
                    {item.label}
                  </Text>
                  {item.value === value && (
                    <MaterialIcons name="check" size={20} color="#C5A021" />
                  )}
                </TouchableOpacity>
              )}
            />
          </View>
        </TouchableOpacity>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { marginBottom: 16 },
  label: { fontSize: 14, fontWeight: '600', color: '#1A1A1B', marginBottom: 8 },
  selector: {
    backgroundColor: '#FFFFFF', borderRadius: 12, borderWidth: 1,
    borderColor: '#E6E8EA', paddingHorizontal: 16, paddingVertical: 14,
    alignItems: 'center', justifyContent: 'space-between',
  },
  selectorError: { borderColor: '#EF4444' },
  selectorText: { fontSize: 15, color: '#1A1A1B', flex: 1 },
  placeholder: { color: '#6C737F' },
  error: { fontSize: 12, color: '#EF4444', marginTop: 4 },
  overlay: { flex: 1, backgroundColor: 'rgba(0,31,63,0.6)', justifyContent: 'center', padding: 32 },
  modal: { backgroundColor: '#F8F9FA', borderRadius: 16, maxHeight: 400, padding: 16 },
  modalTitle: {
    fontSize: 16, fontWeight: '700', color: '#1A1A1B', marginBottom: 12,
    paddingBottom: 12, borderBottomWidth: 1, borderBottomColor: '#E6E8EA',
  },
  option: { alignItems: 'center', paddingVertical: 14, paddingHorizontal: 12, borderRadius: 8 },
  optionSelected: { backgroundColor: 'rgba(197,160,33,0.1)' },
  optionText: { fontSize: 15, color: '#1A1A1B', flex: 1 },
  optionTextSelected: { color: '#C5A021', fontWeight: '600' },
});
