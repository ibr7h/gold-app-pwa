import React from 'react';
import { View, Text, TextInput, StyleSheet, type KeyboardTypeOptions } from 'react-native';
import { useI18n } from '@/i18n';

export interface GoldInputProps {
  label: string;
  value: string;
  onChangeText: (text: string) => void;
  placeholder?: string;
  error?: string;
  secureTextEntry?: boolean;
  keyboardType?: KeyboardTypeOptions;
  multiline?: boolean;
  numberOfLines?: number;
  editable?: boolean;
  maxLength?: number;
  returnKeyType?: 'done' | 'go' | 'next' | 'search' | 'send' | 'default';
  onSubmitEditing?: () => void;
  autoCapitalize?: 'none' | 'sentences' | 'words' | 'characters';
}

export function GoldInput({
  label,
  value,
  onChangeText,
  placeholder,
  error,
  secureTextEntry,
  keyboardType,
  multiline,
  numberOfLines,
  editable = true,
  maxLength,
  returnKeyType,
  onSubmitEditing,
  autoCapitalize,
}: GoldInputProps) {
  const { textAlign, direction } = useI18n();

  return (
    <View style={styles.container}>
      <Text style={[styles.label, { textAlign, writingDirection: direction }]}>{label}</Text>
      <TextInput
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor="#6C737F"
        secureTextEntry={secureTextEntry}
        keyboardType={keyboardType}
        multiline={multiline}
        numberOfLines={numberOfLines}
        editable={editable}
        style={[
          styles.input,
          { textAlign, writingDirection: direction },
          multiline && styles.multiline,
          error ? styles.inputError : null,
          !editable && styles.inputDisabled,
        ]}
        returnKeyType={returnKeyType || 'done'}
        maxLength={maxLength}
        onSubmitEditing={onSubmitEditing}
        autoCapitalize={autoCapitalize}
      />
      {error ? <Text style={[styles.error, { textAlign, writingDirection: direction }]}>{error}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { marginBottom: 16 },
  label: { fontSize: 14, fontWeight: '600', color: '#1A1A1B', marginBottom: 8 },
  input: {
    backgroundColor: '#FFFFFF', borderRadius: 12, borderWidth: 1,
    borderColor: '#E6E8EA', paddingHorizontal: 16, paddingVertical: 14,
    fontSize: 15, color: '#1A1A1B',
  },
  multiline: { minHeight: 80, textAlignVertical: 'top', paddingTop: 14 },
  inputError: { borderColor: '#EF4444' },
  inputDisabled: { opacity: 0.5 },
  error: { fontSize: 12, color: '#EF4444', marginTop: 4 },
});
