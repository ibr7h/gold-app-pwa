import React from 'react';
import { View, Text, ActivityIndicator, StyleSheet } from 'react-native';
import { GoldButton } from './GoldButton';
import { useI18n } from '@/i18n';

interface StateViewProps {
  type: 'loading' | 'empty' | 'error';
  message?: string;
  onRetry?: () => void;
}

export function StateView({ type, message, onRetry }: StateViewProps) {
  const { t, direction } = useI18n();

  if (type === 'loading') {
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" color="#C5A021" />
        <Text style={[styles.text, { writingDirection: direction }]}>{message || t.loading}</Text>
      </View>
    );
  }

  if (type === 'empty') {
    return (
      <View style={styles.container}>
        <Text style={styles.icon}>📭</Text>
        <Text style={[styles.text, { writingDirection: direction }]}>{message || t.noData}</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.icon}>⚠️</Text>
      <Text style={[styles.errorText, { writingDirection: direction }]}>{message || t.error}</Text>
      {onRetry && (
        <GoldButton
          title={t.retry}
          onPress={onRetry}
          variant="outline"
          fullWidth={false}
          style={{ marginTop: 12, paddingHorizontal: 32 }}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingVertical: 48 },
  icon: { fontSize: 48, marginBottom: 12 },
  text: { fontSize: 15, color: '#F8F9FA', marginTop: 12, textAlign: 'center' },
  errorText: { fontSize: 15, color: '#EF4444', marginTop: 8, textAlign: 'center' },
});
