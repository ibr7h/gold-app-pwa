import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, type ViewStyle } from 'react-native';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { useI18n } from '@/i18n';

interface GoldListItemProps {
  title: string;
  subtitle?: string;
  trailing?: React.ReactNode;
  onPress?: () => void;
  onEdit?: () => void;
  onDelete?: () => void;
  leftIcon?: string;
  style?: ViewStyle;
}

export function GoldListItem({
  title,
  subtitle,
  trailing,
  onPress,
  onEdit,
  onDelete,
  leftIcon,
  style,
}: GoldListItemProps) {
  const { isRTL, textAlign, direction, flexDir } = useI18n();

  const content = (
    <View style={[styles.container, { flexDirection: flexDir }, style]}>
      <View style={styles.actions}>
        {onDelete && (
          <TouchableOpacity onPress={onDelete} style={styles.actionBtn} activeOpacity={0.6}>
            <MaterialIcons name="delete-outline" size={20} color="#EF4444" />
          </TouchableOpacity>
        )}
        {onEdit && (
          <TouchableOpacity onPress={onEdit} style={styles.actionBtn} activeOpacity={0.6}>
            <MaterialIcons name="edit" size={20} color="#C5A021" />
          </TouchableOpacity>
        )}
        {trailing}
      </View>
      <View style={[styles.textContainer, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
        <Text style={[styles.title, { textAlign, writingDirection: direction }]} numberOfLines={1}>{title}</Text>
        {subtitle && <Text style={[styles.subtitle, { textAlign, writingDirection: direction }]} numberOfLines={1}>{subtitle}</Text>}
      </View>
      {leftIcon && (
        <View style={[styles.iconContainer, isRTL ? { marginLeft: 12 } : { marginRight: 12 }]}>
          <MaterialIcons name={leftIcon as any} size={24} color="#C5A021" />
        </View>
      )}
    </View>
  );

  if (onPress) {
    return (
      <TouchableOpacity onPress={onPress} activeOpacity={0.7}>
        {content}
      </TouchableOpacity>
    );
  }

  return content;
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center', paddingVertical: 14, paddingHorizontal: 16,
    backgroundColor: '#F8F9FA', borderRadius: 12, borderWidth: 1,
    borderColor: '#E6E8EA', marginBottom: 8,
  },
  iconContainer: {
    width: 40, height: 40, borderRadius: 10,
    backgroundColor: 'rgba(197,160,33,0.12)', alignItems: 'center', justifyContent: 'center',
  },
  textContainer: { flex: 1 },
  title: { fontSize: 15, fontWeight: '600', color: '#1A1A1B' },
  subtitle: { fontSize: 13, color: '#6C737F', marginTop: 2 },
  actions: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  actionBtn: { padding: 6 },
});
