import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableWithoutFeedback, Dimensions } from 'react-native';
import Svg, { Polyline, Defs, LinearGradient, Stop, Line, Circle, Text as SvgText, Rect } from 'react-native-svg';

interface DataPoint {
  label: string;
  value: number;
}

interface InteractiveLineChartProps {
  data: DataPoint[];
  width?: number;
  height?: number;
  color?: string;
  formatValue?: (value: number) => string;
  isRTL?: boolean;
}

export function InteractiveLineChart({
  data,
  width = Dimensions.get('window').width - 64,
  height = 180,
  color = '#C5A021',
  formatValue = (v) => v.toLocaleString(),
  isRTL = false,
}: InteractiveLineChartProps) {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  if (!data || data.length < 2) return null;

  const padding = { top: 30, right: 16, bottom: 28, left: 50 };
  const chartW = width - padding.left - padding.right;
  const chartH = height - padding.top - padding.bottom;

  const values = data.map(d => d.value);
  const minVal = Math.min(...values);
  const maxVal = Math.max(...values);
  const range = maxVal - minVal || 1;

  const getX = (i: number) => padding.left + (i / (data.length - 1)) * chartW;
  const getY = (val: number) => padding.top + chartH - ((val - minVal) / range) * chartH;

  const points = data.map((d, i) => `${getX(i)},${getY(d.value)}`).join(' ');

  // Y-axis labels
  const yLabels = [minVal, minVal + range * 0.5, maxVal];

  const handlePress = (evt: any) => {
    const { locationX } = evt.nativeEvent;
    // Find closest data point
    let closestIdx = 0;
    let closestDist = Infinity;
    data.forEach((_, i) => {
      const dist = Math.abs(getX(i) - locationX);
      if (dist < closestDist) {
        closestDist = dist;
        closestIdx = i;
      }
    });
    setActiveIndex(closestIdx === activeIndex ? null : closestIdx);
  };

  return (
    <View style={styles.container}>
      <TouchableWithoutFeedback onPress={handlePress}>
        <View>
          <Svg width={width} height={height}>
            <Defs>
              <LinearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
                <Stop offset="0" stopColor={color} stopOpacity="0.25" />
                <Stop offset="1" stopColor={color} stopOpacity="0" />
              </LinearGradient>
            </Defs>

            {/* Grid lines */}
            {yLabels.map((val, i) => {
              const y = getY(val);
              return (
                <React.Fragment key={i}>
                  <Line
                    x1={padding.left}
                    y1={y}
                    x2={width - padding.right}
                    y2={y}
                    stroke="rgba(255,255,255,0.06)"
                    strokeWidth={1}
                  />
                  <SvgText
                    x={padding.left - 8}
                    y={y + 4}
                    fill="#6C737F"
                    fontSize={10}
                    textAnchor="end"
                  >
                    {val >= 1000 ? `${(val / 1000).toFixed(0)}K` : val.toFixed(0)}
                  </SvgText>
                </React.Fragment>
              );
            })}

            {/* X-axis labels */}
            {data.map((d, i) => (
              <SvgText
                key={i}
                x={getX(i)}
                y={height - 6}
                fill={activeIndex === i ? color : '#6C737F'}
                fontSize={10}
                textAnchor="middle"
                fontWeight={activeIndex === i ? 'bold' : 'normal'}
              >
                {d.label}
              </SvgText>
            ))}

            {/* Fill area */}
            <Polyline
              points={`${padding.left},${padding.top + chartH} ${points} ${width - padding.right},${padding.top + chartH}`}
              fill="url(#areaGrad)"
              stroke="none"
            />

            {/* Line */}
            <Polyline
              points={points}
              fill="none"
              stroke={color}
              strokeWidth={2.5}
              strokeLinecap="round"
              strokeLinejoin="round"
            />

            {/* Data points */}
            {data.map((d, i) => (
              <Circle
                key={i}
                cx={getX(i)}
                cy={getY(d.value)}
                r={activeIndex === i ? 6 : 3}
                fill={activeIndex === i ? color : '#0D1B2A'}
                stroke={color}
                strokeWidth={activeIndex === i ? 2.5 : 1.5}
              />
            ))}

            {/* Active point tooltip */}
            {activeIndex !== null && data[activeIndex] && (
              <>
                {/* Vertical line */}
                <Line
                  x1={getX(activeIndex)}
                  y1={padding.top}
                  x2={getX(activeIndex)}
                  y2={padding.top + chartH}
                  stroke={color}
                  strokeWidth={1}
                  strokeDasharray="4,4"
                  opacity={0.5}
                />
                {/* Tooltip background */}
                <Rect
                  x={Math.min(Math.max(getX(activeIndex) - 40, 0), width - 80)}
                  y={Math.max(getY(data[activeIndex].value) - 32, 0)}
                  width={80}
                  height={22}
                  rx={6}
                  fill="#001F3F"
                  stroke={color}
                  strokeWidth={1}
                  opacity={0.95}
                />
                {/* Tooltip text */}
                <SvgText
                  x={Math.min(Math.max(getX(activeIndex), 40), width - 40)}
                  y={Math.max(getY(data[activeIndex].value) - 16, 16)}
                  fill={color}
                  fontSize={12}
                  fontWeight="bold"
                  textAnchor="middle"
                >
                  {formatValue(data[activeIndex].value)}
                </SvgText>
              </>
            )}
          </Svg>
        </View>
      </TouchableWithoutFeedback>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
  },
});
