import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Dimensions, type DimensionValue } from 'react-native';

const SCREEN_WIDTH = Dimensions.get('window').width;

interface BarData {
  label: string;
  value: number;
  color?: string;
}

interface InteractiveBarChartProps {
  data: BarData[];
  height?: number;
  barColor?: string;
  activeBarColor?: string;
  formatValue?: (value: number) => string;
  isRTL?: boolean;
}

export function InteractiveBarChart({
  data,
  height = 200,
  barColor = '#C5A021',
  activeBarColor = '#E8C547',
  formatValue = (v) => v.toLocaleString(),
  isRTL = false,
}: InteractiveBarChartProps) {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  const maxValue = Math.max(...data.map(d => d.value), 1);
  const barWidth = Math.min(36, (SCREEN_WIDTH - 100) / data.length - 8);

  return (
    <View style={styles.container}>
      {/* Tooltip */}
      {activeIndex !== null && data[activeIndex] && (
        <View style={styles.tooltipContainer}>
          <View style={styles.tooltip}>
            <Text style={styles.tooltipLabel}>{data[activeIndex].label}</Text>
            <Text style={styles.tooltipValue}>{formatValue(data[activeIndex].value)}</Text>
          </View>
        </View>
      )}

      {/* Chart */}
      <View style={[styles.chartArea, { height }]}>
        {/* Grid lines */}
        {[0, 0.25, 0.5, 0.75, 1].map((pct, i) => (
          <View
            key={i}
            style={[
              styles.gridLine,
              { bottom: `${pct * 100}%` as DimensionValue },
            ]}
          />
        ))}

        {/* Bars */}
        <View style={[styles.barsRow, isRTL && { flexDirection: 'row-reverse' }]}>
          {data.map((item, i) => {
            const isActive = activeIndex === i;
            const barHeight = Math.max((item.value / maxValue) * 100, 3);
            const color = item.color || (isActive ? activeBarColor : barColor);

            return (
              <TouchableOpacity
                key={i}
                style={styles.barColumn}
                onPress={() => setActiveIndex(isActive ? null : i)}
                activeOpacity={0.7}
              >
                <View style={[styles.barTrack, { height: '100%' }]}>
                  <View
                    style={[
                      styles.barFill,
                      {
                        height: `${barHeight}%` as DimensionValue,
                        backgroundColor: color,
                        width: barWidth,
                        opacity: isActive ? 1 : 0.8,
                        transform: [{ scale: isActive ? 1.05 : 1 }],
                      },
                    ]}
                  />
                </View>
                <Text style={[styles.barLabel, isActive && styles.barLabelActive]} numberOfLines={1}>
                  {item.label}
                </Text>
              </TouchableOpacity>
            );
          })}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingVertical: 8,
  },
  tooltipContainer: {
    alignItems: 'center',
    marginBottom: 8,
  },
  tooltip: {
    backgroundColor: '#001F3F',
    borderRadius: 8,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderWidth: 1,
    borderColor: 'rgba(197,160,33,0.3)',
    alignItems: 'center',
  },
  tooltipLabel: {
    color: '#9BA1A6',
    fontSize: 11,
    marginBottom: 2,
  },
  tooltipValue: {
    color: '#C5A021',
    fontSize: 16,
    fontWeight: '700',
  },
  chartArea: {
    position: 'relative',
  },
  gridLine: {
    position: 'absolute',
    left: 0,
    right: 0,
    height: 1,
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  barsRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-around',
    height: '100%',
    paddingBottom: 24,
  },
  barColumn: {
    alignItems: 'center',
    flex: 1,
  },
  barTrack: {
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  barFill: {
    borderRadius: 4,
    minHeight: 4,
  },
  barLabel: {
    color: '#6C737F',
    fontSize: 10,
    marginTop: 6,
    textAlign: 'center',
  },
  barLabelActive: {
    color: '#C5A021',
    fontWeight: '600',
  },
});
