/** @type {const} */
const themeColors = {
  primary: { light: '#C5A021', dark: '#C5A021' },
  background: { light: '#001F3F', dark: '#001F3F' },
  surface: { light: '#F8F9FA', dark: '#F8F9FA' },
  foreground: { light: '#F8F9FA', dark: '#F8F9FA' },
  muted: { light: '#6C737F', dark: '#6C737F' },
  border: { light: '#E6E8EA', dark: '#E6E8EA' },
  success: { light: '#22C55E', dark: '#22C55E' },
  warning: { light: '#F59E0B', dark: '#F59E0B' },
  error: { light: '#EF4444', dark: '#EF4444' },
};

module.exports = { themeColors };
